---
title: "Get Started with Application Lifecycle Management"
source: https://docs.rafay.co/learn/km_apps/
category: Get-Started
---

# Application Lifecycle using Rafay Kubernetes Management

- **Workload Lifecycle**   **Deploy** containerized applications to clusters with drift detection and policy based deployment policies.  [Get Started](https://docs.rafay.co/learn/quickstart/applications/workloads/overview/)
- **Multi Stage GitOps Pipeline**   Configure and deploy multiple applications using a multi stage GitOps pipeline.  [Get Started](https://docs.rafay.co/learn/quickstart/applications/workloads/overview/)
- **Troubleshooting**   Use the integrated tools to **debug and diagnose** issues with applications operating on remote Kubernetes clusters  [Get Started](https://docs.rafay.co/learn/gke/)
- **Progressive Rollouts-Blue/Green**   Upgrade your workload using a **blue/green** based progressive deployment pattern.  [Get Started](https://docs.rafay.co/learn/mks/)
- **Progressive Rollouts-Canary**   Upgrade your workload using a **canary** based progressive deployment pattern  [Get Started](https://docs.rafay.co/learn/quickstart/openshift/overview/)

---
