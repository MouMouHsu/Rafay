---
title: "Get Started Guides"
source: https://docs.rafay.co/learn/overview/
category: Get-Started
---

# Get Started

## Cloud Native Automation (CNA)

- **Environment Management**   Define, version, and manage environment blueprints—ensuring consistency, governance, and automation for rapid and reliable environment provisioning on any infrastructure.  [Get Started](https://docs.rafay.co/learn/envmgr/)
- **Kubernetes Management**   Provision and Manage a fleet of Kubernetes clusters with ease using Rafay's Kubernetes Management's capabilities.  [By Cluster Type](https://docs.rafay.co/learn/km_cluster_type/) [By Capability](https://docs.rafay.co/learn/km_feature/)
- **End User Self Service**   Encapsulate your custom applications and deliver them as a 1-click end user experience using Rafay's PaaS  [Get Started](https://docs.rafay.co/learn/envmgr/custom-app/overview/)

---

## AI/ML Tooling

- **Jupyter Notebooks**   Provide your data scientists and researchers with [**seamless access**](https://docs.rafay.co/aiml/jupyter/jupyter_guide/) to [Jupyter Notebooks](https://jupyter.org/) enabling rapid experimentation.  [Get Started](https://docs.rafay.co/aiml/jupyter/get_started/setup/)
- **Inference (Hourly Metering)**   Provide users with access to on-demand, serverless inference powered by open source LLMs with hourly metering.  [Get Started](https://docs.rafay.co/aiml/inference/get_started/setup/)
- **Token Factory**   Configure and use Rafay Token Factory for secure token creation and lifecycle management. Learn the essential setup steps, key workflows, and best practices to generate, manage, and distribute tokens for multiple tenants.  [Part-1](https://docs.rafay.co/learn/aiml/genai/tf_101/) [Part-2](https://docs.rafay.co/learn/aiml/genai/tf_201/) [Part-3](https://docs.rafay.co/learn/aiml/genai/tf_301/)
- **Training (Ray)**   Provide users with access to an on-demand MLOps training environment powered by Ray.  [Get Started](https://docs.rafay.co/aiml/mlops-ray/getstarted/overview/)
- **MLOps (Kubeflow)**   Provide users with access to a managed MLOps platform based on Kubeflow pre-integrated with MLflow etc.  [Get Started](https://docs.rafay.co/aiml/mlops-kubeflow/gs/overview/)

---

## AI Infrastructure

- ![🖥](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/1f5a5.svg) **Virtual Machines (VM)**   Provide users with self-service access to Virtual Machines (VMs) with one/many GPUs.  [Basics](https://docs.rafay.co/aiml/vm_service/get_started/setup/)
- **Bare Metal Servers**   Provide users with self-service access to Bare Metal Servers with one/many GPUs.  [Basics](https://docs.rafay.co/aiml/bm_service/get_started/mdc_bmaas_ironic_getting_started/)
- **Kubernetes Clusters**   Provide users with self-service access to Managed Kubernetes Clusters with one/many GPUs.  [Basics](https://docs.rafay.co/aiml/k8s_service/get_started/mks_vmaas_getting_started/)
- **Developer Pods**   Provide users with serverless compute options for flexible and ephemeral workloads.  [Basics](https://docs.rafay.co/aiml/serverless_pods/get_started/setup/)
- **SLURM on Bare Metal**   Provide users with access to a high-performance [**SLURM**](https://slurm.schedmd.com/overview.html) cluster deployed on Bare Metal Servers — ideal for traditional HPC and tightly coupled AI/ML workloads.
