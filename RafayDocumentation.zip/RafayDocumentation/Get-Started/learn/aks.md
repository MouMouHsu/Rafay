---
title: "Azure AKS Getting Started Guides using Rafay"
source: https://docs.rafay.co/learn/aks/
category: Get-Started
---

# Lifecycle Management for Azure AKS using Rafay

Curated guides to help users provision, scale, upgrade and operate [Azure AKS](https://docs.rafay.co/clusters/aks/overview/) clusters using Rafay's Lifecycle Management capabilities for Azure AKS. We maintain a [public Git repository](https://github.com/RafaySystems/getstarted) with tested code and examples for each guide below.

- **Cluster Lifecycle Management**   Provision and manage the lifecycle of AKS clusters using web console or declarative specs or Terraform  [**Get Started**](https://docs.rafay.co/learn/quickstart/aks/clusterlifecycle/overview/)
- **Cluster Lifecycle-Managed Identity**   Provision and manage the lifecycle of AKS clusters with User Assigned Managed Identity using web console or declarative specs or Terraform  [**Get Started**](https://docs.rafay.co/learn/quickstart/aks/clusterlifecycle/provision/)
- **Click Ops to GitOps for AKS**   Provision AKS clusters using Click Ops. Automatically generate Infra as Code and write to configured Git repository.  [**Get Started**](https://docs.rafay.co/learn/gitops/akssystemsync/overview/)
- **Takeover Imported AKS Clusters**   Import and Takeover lifecycle management of existing Azure AKS clusters  [**Get Started**](https://docs.rafay.co/learn/quickstart/aks/takeover/overview/)
- **Backup & Restore**   Securely backup your AKS cluster resources and volumes to protect against infrastructure loss, data corruption, and/or service outages.  [**Get Started**](https://docs.rafay.co/learn/quickstart/aks/backup/overview/)
- **Nvidia GPUs**   Operate AI/ML applications on Azure AKS clusters with Nvidia GPU enabled node pools.  [**Get Started**](https://docs.rafay.co/learn/quickstart/aks/gpu/overview/)

---
