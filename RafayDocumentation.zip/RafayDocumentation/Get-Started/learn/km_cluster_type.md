---
title: "Get Started with Kubernetes Management by Kubernetes Distribution"
source: https://docs.rafay.co/learn/km_cluster_type/
category: Get-Started
---

# By Kubernetes Distribution

- **Amazon EKS**   Provision & Manage the Lifecycle of EKS Clusters with various configurations. Standardize and Operate your EKS cluster fleet at scale.  [Get Started](https://docs.rafay.co/learn/eks/)
- **Azure AKS**   Provision & Manage the Lifecycle of AKS Clusters with various configurations. Standardize and Operate your AKS cluster fleet at scale.  [Get Started](https://docs.rafay.co/learn/aks/)
- **Google GKE**   Provision & Manage the Lifecycle of GKE Clusters with various configurations. Standardize and Operate your GKE cluster fleet at scale.  [Get Started](https://docs.rafay.co/learn/gke/)
- **Rafay MKS**   Provision & Manage the Lifecycle of Rafay MKS Clusters for Bare Metal and VM based Environments. Deploy with various supported configurations and options.  [Get Started](https://docs.rafay.co/learn/mks/)
- **RedHat OpenShift**   Provision a RedHat OpenShift Cluster, import it and experience the capabalities of Rafay Kubernetes Management Platform on top of OpenShift.  [Get Started](https://docs.rafay.co/learn/quickstart/openshift/overview/)
