---
title: "Get Started with Application Lifecycle Management"
source: https://docs.rafay.co/learn/km_feature/
category: Get-Started
---

# By Capability of Rafay Kubernetes Managenent

- **Basics**   Experience the foundational aspects of Kubernetes Management in <60 mins.  [Get Started](https://docs.rafay.co/learn/quickstart/basics/overview/)
- **Blueprints for Cluster Fleets**   Centralized configuration with software add-ons and governance policies. Enforce continuous reconciliation with drift detection policies.  [Get Started](https://docs.rafay.co/learn/quickstart/blueprint/blueprintlifecycle/overview/)
- **Cost Visibility & Governance**   Consolidated fine-grained visibility and reporting of costs across the Kubernetes cluster fleet. Automate showback and chargeback workflows for governance.  [Get Started](https://docs.rafay.co/learn/quickstart/cost_management/overview/)
- **Multi Tenancy**   Securely share clusters with multiple teams with enforcement of resource quotas and policies.  [Get Started](https://docs.rafay.co/learn/quickstart/multi-tenancy/overview/)
- **Notifications & Alerts**   Centralized aggregation of alerts generated on remote clusters with proactive notifications of issues for administrators and users.  [Get Started](https://docs.rafay.co/learn/quickstart/alert_notification/alert/)
- **Policy Management**   Centrally enforce OPA Gatekeeper policies. Aggregate and view policy metrics, violations and audits in a central dashboard.  [Get Started](https://docs.rafay.co/learn/quickstart/opa_gatekeeper/overview/)
- **Role based Access Control**   Centralized authentication and authorization enabling **role based access control** for administrators and developers accessing their clusters and applications  [Get Started](https://docs.rafay.co/learn/quickstart/idp/overview/)
- **Workloads**   Deploy and operate containerized applications to remote Kubernetes clusters with drift detection and policy based deployment policies.  [Get Started](https://docs.rafay.co/learn/quickstart/applications/workloads/overview/)
- **Zero Trust User Access**   Controlled, audited, secure **kubectl** access for developers, SREs and automation systems to your clusters, with just-in-time service account creation and centralized auditing of all activity.  [Get Started](https://docs.rafay.co/learn/quickstart/ztka/overview/)

---
