---
title: "Get Started with Environment Manager"
source: https://docs.rafay.co/learn/envmgr/
category: Get-Started
---

# Get Started with Environment Manager

## By Feature

- ![🌱](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/1f331.svg) **Introductory**   Introductory concepts of Rafay Environment Manager.  [**Overview**](https://docs.rafay.co/learn/envmgr/introductory/overview/)  |  [**Prereqs**](https://docs.rafay.co/learn/envmgr/introductory/prereqs/)  |  [**OpenTofu**](https://docs.rafay.co/learn/envmgr/introductory/part1/)  |  [**Python**](https://docs.rafay.co/learn/envmgr/introductory/part2/)  |  [**User Inputs**](https://docs.rafay.co/learn/envmgr/introductory/part3/)
- **Intermediate**   Intermediate concepts of Rafay Environment Manager. Builds on the Introductory section.  [**Schedules**](https://docs.rafay.co/learn/envmgr/intermediate/schedules/)  |  [**Hooks**](https://docs.rafay.co/learn/envmgr/intermediate/hooks/)  |  [**Actions**](https://docs.rafay.co/learn/envmgr/intermediate/actions/)  |  [**Function Workflow Handler**](https://docs.rafay.co/learn/envmgr/intermediate/function_wfh/function_wfh/)

---

## By Cloud Provider

- **AWS**   Infrastructure Automation and Self Service Workflows for [Amazon Web Services](https://docs.rafay.co/learn/quickstart/eaas/aws/101/overview/) (AWS).
- **Azure**   Infrastructure Automation and Self Service Workflows for [Azure](https://docs.rafay.co/learn/quickstart/eaas/azure/101/overview/).
- **Google Cloud**   Infrastructure Automation and Self Service Workflows for [Google Cloud](https://docs.rafay.co/learn/quickstart/eaas/gcp/101/overview/).
