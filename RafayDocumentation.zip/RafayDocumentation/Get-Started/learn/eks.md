---
title: "Amazon EKS Getting Started Guides using Rafay"
source: https://docs.rafay.co/learn/eks/
category: Get-Started
---

# Lifecycle Management For Amazon EKS using Rafay

Curated guides to help users provision, scale, upgrade and operate [Amazon EKS](https://docs.rafay.co/clusters/eks/overview/) clusters using Rafay's Lifecycle Management capabilities for Amazon EKS. We maintain a [public Git repository](https://github.com/RafaySystems/getstarted) with tested code and examples for each guide below.

- **Cluster Lifecycle Management**   Provision and manage the lifecycle of EKS clusters using web console or declarative specs or Terraform  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/clusterlifecycle/overview/)
- **Auto Mode for EKS**   Developer Self Service of Amazon EKS Auto Mode clusters using GitOps based automation  [**Get Started**](https://docs.rafay.co/blog/2024/12/13/get-started-with-auto-mode-for-amazon-eks-with-rafay/)
- **Click Ops to GitOps**   Provision EKS clusters using Click Ops. Automatically generate Infra as Code (IaC) and sync to configured Git repository.  [**Get Started**](https://docs.rafay.co/learn/gitops/ekssystemsync/overview/)
- **Blue/Green Upgrade**   Upgrade your EKS clusters to a new Kubernetes version using a Blue/Green strategy  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/bluegreen/overview/)
- **Takeover Imported EKS**   Import and Takeover lifecycle management of existing Amazon EKS clusters  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/takeover/overview/)
- **Cluster Blueprints**   Centralized configuration of EKS clusters with software add-ons and governance policies. Enforce continuous reconciliation with drift detection policies.  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/cloudwatch/overview/)
- **Custom Networking**   Provision EKS clusters using Custom Networking. Automatically manage and provision ENIs to utilize subnets from your VPC's secondary CIDR  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/custom_networking/overview/)
- **Fleet Operations**   Learn to manage and operate a fleet of EKS clusters with a fleet plan, enabling actions like upgrades, scaling, blueprint updates, and efficient pre/post flight checks.  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/fleet/overview/)
- **Backup & Restore**   Securely backup your EKS cluster resources and volumes to protect against infrastructure loss, data corruption, and/or service outages.  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/backup/overview/)
- **External DNS**   Automatically update/sync DNS in AWS Route 53 for applications deployed to EKS clusters.  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/external_dns/overview/)
- **Nvidia GPUs**   Operate AI/ML applications on Amazon EKS clusters with Nvidia GPU enabled nodes  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/gpu/overview/)
- **Nvidia Triton Inference Server (AI)**   Configure, Deploy and Operate Nvidia Triton based AI/ML applications on Amazon EKS clusters with Nvidia GPU enabled nodes.  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/triton/overview/)
- **Spot Instances**   Save costs by using node groups based on EC2 Spot Instances  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/spot/overview/)
- **Persistent Storage with AWS EFS**   Use AWS EFS to create shared storage between Kubernetes pods within and across AWS Availability Zones.  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/efs/overview/)
- **Windows**   Provision and manage Amazon EKS clusters with Windows based Managed Node Groups  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/windows/overview/)
- **AWS Fargate**   Deploy and operate containerized applications to on-demand, right sized AWS Fargate profiles attached to your EKS Cluster  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/fargate/overview/)
- **AWS Graviton**   Provision and manage Amazon EKS clusters based on AWS Graviton ARM based nodes  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/graviton/overview/)
- **Autoscaling with Karpenter and Spot**   Dynamically autoscale your EKS cluster with Spot instances using Karpenter  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/karpenter/overview/)
- **AWS Secrets Manager**   Secure application secrets and automate lifecycle management and delivery using the platform's turnkey integration with AWS Secrets Manager  [**Get Started**](https://docs.rafay.co/learn/quickstart/eks/secretsmanager/overview/)

---
