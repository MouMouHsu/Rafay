---
title: "Basics of Kubernetes"
source: https://docs.rafay.co/learn/k8s_basics/
category: Get-Started
---

# Basics of Kubernetes

## Basics of Kubernetes

- **Prerequisities**   Requirements for this exercise  [Get Started](https://docs.rafay.co/learn/quickstart/kubernetes/prerequisites/)
- **Kubernetes 101**   Namespaces, Pods, Deployments, Services, Ingress  [Get Started](https://docs.rafay.co/learn/quickstart/kubernetes/namespaces/)
- **Kubernetes 201**   ConfigMaps, Secrets, Persistent Volumes, Persistent Volume Claims  [Get Started](https://docs.rafay.co/learn/quickstart/kubernetes/configmaps/)
- **Kubernetes 301**   Deployments, DaemonSets, StatefulSets.  [Get Started](https://docs.rafay.co/learn/quickstart/kubernetes/deployments-daemonsets-statefulsets/)
- **Kubernetes 401**   Port-Forward  [Get Started](https://docs.rafay.co/learn/quickstart/kubernetes/port-forward/)

---
