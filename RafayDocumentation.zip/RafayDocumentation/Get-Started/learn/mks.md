---
title: "Rafay MKS Getting Started Guides"
source: https://docs.rafay.co/learn/mks/
category: Get-Started
---

# Rafay MKS for Bare Metal and VMs

[Rafay MKS](https://docs.rafay.co/clusters/upstream/baremetal_vm/overview/) is an enterprise Kubernetes distribution that allows users to provision and operate CNCF conformant upstream Kubernetes clusters in data centers and edge environments. We maintain a [public Git repository](https://github.com/RafaySystems/getstarted) with tested code and examples for each guide below.

- **Cluster Lifecycle Management**   Provision and manage the lifecycle of Upstream Kubernetes clusters on bare metal and VMs.  [**Get Started**](https://docs.rafay.co/learn/quickstart/mks/clusterlifecycle/overview/)
- **MKS with Cilium and Hubble**   Learn how to create an MKS cluster with Cilium CNI and Hubble enabled for advanced networking and observability.  [**Get Started**](https://docs.rafay.co/learn/quickstart/mks/mks_hub_cluster/overview/)
- **Windows**   Provision and manage Windows worker nodes. Deploy and operate Windows containers.  [**Get Started**](https://docs.rafay.co/learn/quickstart/mks/windows/overview/)
- **Backup & Restore**   Securely backup your Upstream Kubernetes cluster resources and volumes to protect against infrastructure loss, data corruption, and/or service outages.  [**Get Started**](https://docs.rafay.co/learn/quickstart/mks/backup/overview/)
- **Managed Storage**   Deploy and operate Rook/Ceph based managed storage for Block, File and Object based storage for your stateful applications.  [**Get Started**](https://docs.rafay.co/learn/quickstart/managed_storage/overview/)
- **Nvidia GPUs**   Operate AI/ML applications on Upstream Kubernetes clusters with Nvidia GPU enabled nodes  [**Get Started**](https://docs.rafay.co/learn/quickstart/mks/gpu/overview/)
- **Virtual Machines on Kubernetes**   Deploy and Operate Virtual Machines on Upstream Kubernetes alongside containers using KubeVirt  [**Get Started**](https://docs.rafay.co/learn/quickstart/kubevirt/overview/)

---
