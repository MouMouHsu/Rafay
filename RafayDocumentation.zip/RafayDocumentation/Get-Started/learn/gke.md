---
title: "Google GKE Getting Started Guides"
source: https://docs.rafay.co/learn/gke/
category: Get-Started
---

# Lifecycle Management for Google Kubernetes Engine (GKE)

Curated guides to help users provision, scale, upgrade and operate [Google GKE](https://docs.rafay.co/clusters/gke/overview/) clusters using Rafay's Lifecycle Management capabilities for Google GKE. We maintain a [public Git repository](https://github.com/RafaySystems/getstarted) with tested code and examples for each guide below.

- **Cluster Lifecycle Management**   Provision and manage the lifecycle of GKE clusters using web console or declarative specs or Terraform  [**Get Started**](https://docs.rafay.co/learn/quickstart/gke/clusterlifecycle/overview/)
- **Click Ops to GitOps**   Provision GKE clusters using Click Ops. Automatically generate Infra as Code (IaC) and sync to configured Git repository.  [**Get Started**](https://docs.rafay.co/learn/gitops/gkesystemsync/overview/)

---
