---
title: "AI/ML and Generative AI"
source: https://docs.rafay.co/aiml/overview/
category: AI-ML
---

# AI/ML and GenAI

## Core Platform

The Core Platform delivers the essential building blocks for constructing a production-grade GPU Cloud, including dynamic GPU partitioning, multi-tenancy isolation, policy enforcement, and automated lifecycle management. These capabilities enable reliable and cost-efficient execution of AI/ML and GenAI workloads across diverse infrastructure environments.

- **GPU PaaS**   Convert a stack of GPUs into a dynamically partitioned, multi-tenant GPU Cloud for data scientists and GenAI developers.  [**Overview**](https://docs.rafay.co/aiml/gpupaas/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/gpupaas/administration/overview/)  |  [**End Users**](https://docs.rafay.co/aiml/gpupaas/users/overview/)  |  [**GPU Cloud Providers**](https://docs.rafay.co/aiml/gpupaas/csp/overview/)  |  [**Get Started**](https://docs.rafay.co/aiml/gpupaas/getstarted/overview/)
- **GPU Sharing**   Share your GPU resources with multiple users/applications.  [**Overview**](https://docs.rafay.co/blog/2024/10/22/gpu-sharing-strategies-in-kubernetes/)  |  [**Time Slicing**](https://docs.rafay.co/recipes/gpu/sharing/time_slice/time_slice/)  |  [**Nvidia MIG-Single**](https://docs.rafay.co/recipes/gpu/sharing/mig_single/mig_single/)  |  [**Nvidia MIG-Mixed**](https://docs.rafay.co/recipes/gpu/sharing/mig_mixed/mig_mixed/)  |  [**Get Started**](https://docs.rafay.co/learn/aiml/gpu-naas/overview/)

---

## AI Infrastructure SKUs

Rafay’s AI infrastructure SKUs deliver turnkey, production-grade compute environments—ranging from bare metal servers and GPU-enabled VMs to Kubernetes-based clusters and serverless execution frameworks. Each SKU is optimized for multi-tenancy, automated lifecycle management, and high-performance AI/ML workloads, enabling teams to build and scale modern AI platforms with ease.

- **Bare Metal Servers**   Instant self-service provisioning of GPU-enabled bare metal servers with a single click.  [**Overview**](https://docs.rafay.co/aiml/bm_service/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/gpupaas/administration/bm_type/)  |  [**End Users**](https://docs.rafay.co/aiml/gpupaas/users/baremetal/)  |  [**Videos**](https://docs.rafay.co/aiml/bm_service/videos/)
- **Virtual Machines**   1-Click, self-service provisioning of GPU-enabled virtual machines.  [**Overview**](https://docs.rafay.co/aiml/vm_service/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/gpupaas/administration/vm_type/)  |  [**End Users**](https://docs.rafay.co/aiml/gpupaas/users/vm/)  |  [**Videos**](https://docs.rafay.co/aiml/vm_service/videos/)
- **Managed Kubernetes**   1-Click, self-service provisioning of GPU enabled Managed Kubernetes Clusters.  [**Overview**](https://docs.rafay.co/aiml/k8s_service/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/gpupaas/administration/k8s_type/)  |  [**End Users**](https://docs.rafay.co/aiml/gpupaas/users/k8s_type/)
- **Virtual Clusters**   1-Click, virtual clusters providing users with a lightweight, fully isolated virtual Kubernetes clusters  [**Overview**](#)
- **Serverless Pods**   Deploy custom containers from prebuilt templates in isolated environments enabling users to efficiently run CPU and GPU-intensive tasks without managing physical infrastructure.  [**Overview**](https://docs.rafay.co/aiml/serverless_pods/overview/)  |  [**Capabilities**](https://docs.rafay.co/aiml/serverless_pods/capabilities/)  |  [**Architecture**](https://docs.rafay.co/aiml/serverless_pods/architecture/)  |  [**Requirements**](https://docs.rafay.co/aiml/serverless_pods/requirements/)  |  [**Architecture**](https://docs.rafay.co/aiml/serverless_pods/setup/)
- **SLURM on Bare Metal Servers**   Batch or interactive workloads on SLURM based HPC clusters based on bare metal servers. Run CPU and GPU-intensive tasks efficiently across distributed compute resources.  [**Administration**](https://docs.rafay.co/aiml/gpupaas/administration/slurm/)  |  [**End Users**](https://docs.rafay.co/aiml/gpupaas/users/slurm_type/)
- **SLURM on Kubernetes**   Batch or interactive workloads on SLURM based HPC clusters running on Kubernetes.  [**Overview**](https://docs.rafay.co/aiml/slurm-k8s/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/slurm-k8s/admin/lifecycle/)  |  [**End Users**](https://docs.rafay.co/aiml/slurm-k8s/access_slurm/)

---

## AIML App SKUs

Rafay’s AIML SKUs provide fully managed, GPU-accelerated environments for interactive development, distributed training, automated MLOps pipelines, and real-time inference. Each SKU is optimized for multi-tenancy, lifecycle automation, and operational consistency, enabling organizations to streamline the entire AI/ML model lifecycle from experimentation to production.

- **Jupyter Notebooks**   1-Click Jupyter Notebook based Interactive Development Environment with instant access to NVIDIA GPUs – start building in minutes.  [**Overview**](https://docs.rafay.co/aiml/jupyter/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/jupyter/jupyter_guide/)  |  [**End Users**](https://docs.rafay.co/aiml/gpupaas/users/notebook/)
- **Inferencing with Hourly Metering**   Deploy and operate real-time AI inference for popular LLMs with support for hourly metering/billing.  [**Overview**](https://docs.rafay.co/aiml/inference/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/inference/get_started/setup/)  |  [**End Users**](https://docs.rafay.co/aiml/gpupaas/users/inference/)
- **Token Factory**   Deliver a Token Factory for popular LLMs with support for token based metering/billing.  [**Overview**](https://docs.rafay.co/aiml/token_factory/overview/)  |  [**Users**](https://docs.rafay.co/aiml/token_factory/users/models/)  |  [**Administration**](https://docs.rafay.co/aiml/token_factory/requirements/)  |  [**Click Thru Demos**](https://docs.rafay.co/aiml/token_factory/videos/)  |  [**Get Started**](https://docs.rafay.co/learn/aiml/genai/tf_101/)  |  [**Best Practices**](https://docs.rafay.co/aiml/token_factory/csp/best_practices/kv/)
- **MLOps-Kubeflow**   Deploy and operate a multi-tenant MLOps platform on your infrastructure based on Kubeflow, MLflow, TensorBoard etc.  [**Overview**](https://docs.rafay.co/aiml/mlops-kubeflow/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/mlops-kubeflow/install/design/)  |  [**Users**](https://docs.rafay.co/aiml/mlops-kubeflow/user/overview/)  |  [**Get Started**](https://docs.rafay.co/aiml/mlops-kubeflow/gs/overview/)  |  [**Videos**](https://docs.rafay.co/aiml/mlops-kubeflow/videos/)
- **MLOps-KubeRay**   Provide your users with a **Ray as a Service** multi-tenant offering on your infrastructure.  [**Overview**](https://docs.rafay.co/aiml/mlops-ray/overview/)  |  [**Administration**](https://docs.rafay.co/aiml/mlops-ray/admin/setup/)  |  [**Users**](https://docs.rafay.co/aiml/mlops-ray/users/launch/)  |  [**Get Started**](https://docs.rafay.co/aiml/mlops-ray/getstarted/overview/)  |  [**Videos**](https://www.youtube.com/playlist?list=PLqXTbqGdL83cKiSypILAM9DdbdDxTceTm)
- ![🥼](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/1f97c.svg) **AI Lab**   Structured and scalable solution to manage shared lab environments with shared GPU infrastructure.  [**Overview**](https://docs.rafay.co/aiml/ai_labs/overview/)

---

## App Marketplace

The App Marketplace enables service providers to publish open-source or custom applications that can be consumed by end users across hundreds of tenants, with all deployments running on the provider’s managed infrastructure. This delivers a seamless, one-click self-service experience for every tenant while ensuring consistency, security, and operational efficiency.

- **Overview**   Prepackaged or custom applications deployable on Kubernetes clusters using manifests, Helm charts, or other Kubernetes-native formats.  [Overview](https://docs.rafay.co/aiml/app_marketplace/overview/)
- **Kubernetes Apps**   Prepackaged or custom applications deployable on Kubernetes clusters using manifests, Helm charts, or other Kubernetes-native formats.  [Learn More](https://docs.rafay.co/aiml/app_marketplace/helm_app/overview/)
- **Docker Apps**   Containerized applications deployable via Docker images from DockerHub or private registries, enabling fast and portable deployments.  [Learn More](https://docs.rafay.co/aiml/app_marketplace/docker_app/overview/)
- **3rd Party App Examples**   Examples of 3rd Party Apps (Docker Containers and Kubernetes Apps) delivered as a 1-click experience for users via the App Marketplace  [Learn More](https://docs.rafay.co/aiml/app_marketplace/integrations/)
- **SaaS Apps**   Consolidate and deliver SaaS applications to users via the self service portal.  [Learn More](https://docs.rafay.co/aiml/app_marketplace/saas_app/overview/)
- ![⚙](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/2699.svg) **Custom Automation**   Deliver custom automation as a 1-click, self service experience for users.  Learn More
