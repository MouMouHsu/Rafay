---
title: "Air-Gapped Controller Overview"
source: https://docs.rafay.co/selfhosted/airgapped/overview/
category: Home
---

Due to security and operational requirements, some organizations may be unable to allow even outbound connectivity on port 443 to the SaaS Controller. As a result, these organizations may be required to deploy and operate the controller itself in their infrastructure. Here are some examples:

- A defense agency that needs to manage their clusters in GovCloud
- A highly regulated business that needs to operate their clusters in a private network

The Rafay Platform can be deployed in "fully air gapped" environments. All software and dependencies for the "controller" and "upstream Kubernetes clusters" are "pre-packaged" into the installer. Once the controller is installed, new upstream Kubernetes clusters can be provisioned, operated and kept up to date without requiring any software downloads from the Internet.

---

# Air-Gapped Controller Installation Guide

This guide provides an overview and step-by-step instructions for installing the Rafay Controller in air-gapped environments such as VMs or bare metal servers.

Watch the video below for a high-level walkthrough of the installation process:

---

## Core Components

The diagram below illustrates the key software components automatically installed and configured by Rafay’s air-gapped installer. These components span multiple layers:

- **Rafay Controller Application Layer**
- **Observability Layer**
- **Software Infrastructure Layer**
- **Kubernetes Cluster Layer**

[![Components of Air Gapped Controller](https://docs.rafay.co/selfhosted/img/components-architecture.png)](https://docs.rafay.co/selfhosted/img/components-architecture.png)

> **Note**
> The provisioning and lifecycle management of the underlying VMs or servers is the responsibility of the operator.

---

## Requirements and Setup Steps

Before you begin the installation process, make sure your environment is ready and meets all the required prerequisites.

Use the links below to navigate directly to each section of the documentation.

| Section | Link |
| --- | --- |
| ✅ Prerequisites | [View Prerequisites](https://docs.rafay.co/selfhosted/airgapped/pre-requisites/) |
| ⚙️ Installation Steps | [Installation](https://docs.rafay.co/selfhosted/airgapped/install/) |
| ⬆️ Upgrade | [Upgrade](https://docs.rafay.co/selfhosted/airgapped/upgrade/) |
| 📊 Monitor & Dashboard | [Monitoring](https://docs.rafay.co/selfhosted/airgapped/monitoring/) |
| 🛠️ Troubleshooting | [Troubleshooting](https://docs.rafay.co/selfhosted/troubleshooting/) |

---
