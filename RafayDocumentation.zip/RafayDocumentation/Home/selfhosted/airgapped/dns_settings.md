---
title: "DNS Requirements"
source: https://docs.rafay.co/selfhosted/airgapped/dns_settings/
category: Home
---

# DNS Requirements

## DNS Requirements

This page explains the DNS records listed under [Prerequisites → DNS Configuration](https://docs.rafay.co/selfhosted/airgapped/pre-requisites/#12-dns-configuration): what each record is for, which Rafay component depends on it, whether it is required or optional, and what breaks if it isn't created. Use it alongside the Prerequisites page when handing DNS provisioning to your network/DNS administration team ahead of controller go-live.

All records below are shown relative to your base domain, represented here as `<rafay.example.com>`. Replace this placeholder with the actual domain assigned to your Rafay Controller deployment (e.g. `api.rafay.example.com`).

---

### Wildcard Records

Records prefixed with an asterisk (`*`) are wildcard records. The controller dynamically generates a unique identifier for each agent, gateway, cluster, or user, and that identifier becomes the DNS label at request time (for example, `abc1.cdrelay.<rafay.example.com>`). Because these identifiers aren't known in advance and grow over time as new agents, clusters, or users are added, a wildcard record is required rather than individual static entries.

> **Note**
> If wildcard DNS isn't available in your environment, see **Individual Records** under [Prerequisites → DNS Configuration](https://docs.rafay.co/selfhosted/airgapped/pre-requisites/#12-dns-configuration) for the full list of static entries to create instead.

---

### Standard Platform Records

These records support the core web portals and controller services. Each is a single, static hostname.

| DNS Record | Status | Purpose | Used By | Impact if Not Created |
| --- | --- | --- | --- | --- |
| `console.<rafay.example.com>` | Required | Web portal used by administrators and end users to access the Rafay Controller UI. The same endpoint is also used by APIs, for automation performed by admins/users. | Admins / End Users (UI and API automation) | No browser-based access to the controller, and API-based automation performed by admins/users against this endpoint also fails. |
| `ops-console.<rafay.example.com>` | Required | Admin-only portal for managing tenants, inventory, and SKUs. | Rafay Operations / Admins | Tenant onboarding, inventory management, and SKU configuration cannot be performed through the UI, blocking core operational administration of the platform. |
| `api.<rafay.example.com>` | Required | Endpoint used by the Rafay Kubernetes Operator running on each managed cluster to connect and register with the Rafay Controller. | Rafay K8s Operator | Managed clusters cannot connect to or register with the controller. Core cluster lifecycle management (provisioning, upgrades, add-ons, health reporting) fails entirely. |
| `fluentd-aggr.<rafay.example.com>` | Required | Log aggregation endpoint used by the controller to collect operational and audit logs. | Rafay Controller | Controller logs cannot be aggregated or centrally collected, severely limiting troubleshooting, audit trail, and support-case diagnostics. |
| `grafana.<rafay.example.com>` | Optional | Web portal providing monitoring dashboards and metrics visualization for the controller. | Admins | Monitoring dashboards are not reachable via the UI. Underlying metrics collection is unaffected, but admins lose visual insight into controller health and performance trends. |
| `kibana.<rafay.example.com>` | Optional | Web portal for searching and visualizing aggregated logs. | Admins | Logs already collected via `fluentd-aggr` cannot be searched or visualized through a UI. Log data itself is not lost, but self-service log investigation is unavailable. |
| `repo.<rafay.example.com>` | Optional | Access to the controller's repository, used to retrieve platform artifacts such as images and charts. | Controller / Clusters | Artifacts served from this repository cannot be pulled. Depending on how the environment is configured, this may affect add-on installs or upgrade workflows that rely on this repository. |

---

### Wildcard / Dynamic Agent-Connectivity Records

These records support agents, gateways, and clusters that connect back to the controller using a controller-assigned unique identifier as a DNS label. Because the identifier is generated dynamically, each entry below must be created as a wildcard record covering all subdomains under the given suffix.

| DNS Record | Status | Purpose | Used By | Impact if Not Created |
| --- | --- | --- | --- | --- |
| `*.cdrelay.<rafay.example.com>` | Required | Endpoint used by agents to connect to the controller. The controller assigns each agent instance a unique ID, used as the subdomain (e.g. `abc1.cdrelay.<rafay.example.com>`). | Agent | Agents cannot connect to the controller. Dependent functionality (e.g. gateway operations) fails. |
| `*.core-connector.<rafay.example.com>` | Required | Endpoint used by the Rafay Kubernetes Operator to connect to controller services, using a unique ID per instance as the subdomain. | K8s Operator | The K8s Operator cannot connect to controller services, breaking cluster connectivity to the controller. |
| `*.core.<rafay.example.com>` | Required | Endpoint used by the Rafay Kubernetes Operator on each managed cluster to reach controller core services, using a unique ID per cluster as the subdomain. | Rafay K8s Operator | The affected cluster's operator cannot reach controller core services, breaking cluster connectivity to the controller. |
| `*.connector.infrarelay.<rafay.example.com>` `*.user.infrarelay.<rafay.example.com>` | Required | Endpoints used by the bare-metal gateway agent/service to connect to the controller. The controller assigns each gateway instance a unique ID, and the gateway connects using `<uniqueID>.connector.infrarelay.<rafay.example.com>` (e.g. `xyz1.connector.infrarelay.<rafay.example.com>`). The `.user.infrarelay` variant is used by the BMaaS gateway to reach controller services. | Bare-Metal-as-a-Service (BMaaS) Gateway | The bare-metal gateway cannot connect to the controller. Bare-metal provisioning and BMaaS functionality fails for the affected gateway. |
| `*.kubeapi-proxy.<rafay.example.com>` `*.user.<rafay.example.com>` | Required | Endpoints exposing per-cluster and per-user Kubernetes API access through the controller. `kubeapi-proxy` provides a unique proxy subdomain per managed cluster; `user` provides a unique URL and credentials per user for cluster access via Rafay Zero Trust Kubectl (ZTK). | K8s Clusters / kubectl; End Users (via ZTK) | The affected cluster's API server cannot be reached through the controller's proxy, blocking kubectl access, and users cannot access clusters via Zero Trust Kubectl (ZTK). |

> **Info**
> If you're using external SSL offloading, additional frontend/backend FQDN considerations apply — see [DNS Settings for Using External SSL Offload](https://docs.rafay.co/selfhosted/airgapped/pre-requisites/#15-dns-settings-for-using-external-ssl-offload-optional) on the Prerequisites page.

---
