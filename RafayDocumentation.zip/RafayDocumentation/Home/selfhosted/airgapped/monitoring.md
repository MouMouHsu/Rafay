---
title: "Monitoring the Rafay Controller"
source: https://docs.rafay.co/selfhosted/airgapped/monitoring/
category: Home
---

# Monitor and Dashboard

This guide provides instructions on how to monitor the controller resources using the built-in Grafana endpoint.

## Overview

As part of the controller deployment, a Grafana deployment is provisioned in the Kubernetes cluster, allowing users to monitor key resource metrics such as CPU, memory, and network usage for all pods involved in the controller setup.

## Accessing Grafana

Once the controller is installed, users can access the Grafana dashboard using the **super-user credentials** that were configured during installation. These credentials, defined in the `config.yaml` file, are used by the `radm` CLI tool during the controller installation process.

The same credentials can also be used to authenticate and access the Grafana endpoint.

- **Grafana URL**:
 `https://grafana.<your-domain-name>`

This endpoint is part of the required DNS records outlined in the [Pre-requisites](https://docs.rafay.co/selfhosted/airgapped/pre-requisites/). Ensure the DNS entry for `grafana.<your-domain-name>` is correctly configured before proceeding.

## What Can You Monitor?

After logging into Grafana, you can monitor and navigate to the Rafay dashboard in the Dashboards section

### Pod-Level Metrics

- CPU usage
- Memory consumption
- Network I/O

These metrics are visible for all pods deployed as part of the controller setup, specifically those in the following namespaces:

- `rafay-system` (core controller components)
- `kube-system` (Kubernetes control plane components)
- Any other controller related namespaces like openebs,cert-manager,engine-agents.

### Import Grafana Dashboard

You can import the provided Grafana dashboard template to get a **global view of your controller usage**. This includes metrics such as:

- Node CPU and Memory usage
- Total memory and number of running pods
- Total namespaces

When you import this Grafana JSON file, it will give you a consolidated visual overview of your Controller with the following key insights:

- **Controller-Wide Metrics** – CPU, RAM, uptime, node health
- **Node-Level Metrics** – Resource usage, file descriptors, system load, time sync
- **Pod-Level Details** – Pod distribution, resource usage per container

**Download the dashboard template and create a dashboard by importing this JSON file:** [controller-grafana.json](https://docs.rafay.co/selfhosted/airgapped/grafana.json)

[![Grafana](https://docs.rafay.co/selfhosted/img/Dashboards-Grafana.png)](https://docs.rafay.co/selfhosted/img/Dashboards-Grafana.png)

### View Controller Metrics in Grafana

[![Grafana UI](https://docs.rafay.co/selfhosted/img/grafana-ui.gif)](https://docs.rafay.co/selfhosted/img/grafana-ui.gif)

---
