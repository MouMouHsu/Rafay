---
title: "Air-Gapped Controller Preflight Checks"
source: https://docs.rafay.co/selfhosted/airgapped/preflight/
category: Home
---

# Preflight Check

## Preflight Checks

Rafay provides two approaches to run preflight checks before installing the air-gapped controller. Both approaches validate OS, node size, and other important configurations before the actual installation, and can be run independently of the controller installation commands.

---

## Approach 1: Preflight Check via radm

**Release Information**
 Approach 1 is available from release **v3.1-41** onwards.

Preflight validation is integrated with the radm CLI. It runs as a standalone check before installation, and automatically before each installation phase.

### Install radm

The radm CLI must be present on the controller nodes before running preflight checks.

1. Get the installer package.  

```
wget <URL_of_airgap_installation_package>
```
2. Extract the package and move radm to `/usr/bin`.  

```
tar -xf <package_name>
sudo mv ./radm /usr/bin/
```
3. Confirm the installation.  

```
radm --help
```

> **Note**
> This approach applies to GPU PaaS deployments starting with the 3.1.41 release, and to CNA deployments from the 4.3 release onward.

> **Important**
> Do not proceed to the next step unless the preflight checks pass.

### Standalone Preflight Check

Run this command on the controller nodes, independently of the installation commands, before starting installation.

```
sudo ./radm pre-flight --config config.yaml
```

**Example output: success**

```
./radm pre-flight --config config.yaml
╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                                                                    ║
║ Radm Version: v3.1-41                                                                                                               ║
║ Date: September 24, 2026                                                                                                            ║
╠════════════════════╦════════╦════════╦════════════════════════════════════════════════════════════════════════════════════════════╣
║ CHECK               ║ RESULT ║ STATUS ║ DETAILS                                                                                      ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Operating System     ║ Passed ║ ✔      ║ OS: Ubuntu 24.04. Supported OS: [Ubuntu 24.04, RHEL 9, RHEL 10]                              ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Root Disk            ║ Passed ║ ✔      ║ Used: 7% (123 GB), Available: 1909 GB                                                        ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ /tmp Disk            ║ Passed ║ ✔      ║ Shares root disk                                                                             ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ CPU                  ║ Passed ║ ✔      ║ Required: 32 CPU, Available: 32 CPU                                                          ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Memory               ║ Passed ║ ✔      ║ Size class: 64 GB (min 62 GB host-visible), Available: 62 GB (64286 MB)                      ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ MongoDB CPU Flags    ║ Passed ║ ✔      ║ AVX avx2 detected — MongoDB CPU requirements met                                             ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Data Disk Check      ║ Warning║ ⚠      ║ /data: 1.9 TB available. 2 TB recommended.                                                   ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Firewall Status      ║ Passed ║ ✔      ║ firewalld/ufw/nftables service not active                                                    ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ AppArmor Status      ║ Passed ║ ✔      ║ AppArmor is disabled at runtime                                                              ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Local Ports Check    ║ Passed ║ ✔      ║ All required local ports are available (checked: [8443 443 2379 5005 5006 8500 80 5000])     ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ iscsid Service       ║ Passed ║ ✔      ║ iscsid service is not in failed state                                                        ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Container Runtimes   ║ Passed ║ ✔      ║ No conflicting container runtimes detected                                                   ║
╚════════════════════╩════════╩════════╩════════════════════════════════════════════════════════════════════════════════════════════╝
Rafay controller preflight check has been completed!
✔ Indicates the service has passed the required checks.
✖ Indicates the service has failed one or more checks.
```

**Example output: failure**

```
./radm pre-flight --config config.yaml
╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                                                                    ║
║ Radm Version: v4.3-01                                                                                                               ║
║ Date: September 24, 2026                                                                                                            ║
╠════════════════════╦════════╦════════╦════════════════════════════════════════════════════════════════════════════════════════════╣
║ CHECK               ║ RESULT ║ STATUS ║ DETAILS                                                                                      ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Operating System     ║ Passed ║ ✔      ║ OS: Ubuntu 24.04. Supported OS: [Ubuntu 24.04, RHEL 9, RHEL 10]                              ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Root Disk            ║ Passed ║ ✔      ║ Used: 22% (211 GB), Available: 756 GB                                                        ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ /tmp Disk            ║ Passed ║ ✔      ║ Shares root disk                                                                             ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ CPU                  ║ Passed ║ ✔      ║ Required: 32 CPU, Available: 32 CPU                                                          ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Memory               ║ Passed ║ ✔      ║ Size class: 64 GB (min 62 GB host-visible), Available: 62 GB (64289 MB)                      ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ MongoDB CPU Flags    ║ Passed ║ ✔      ║ AVX avx2 detected — MongoDB CPU requirements met                                             ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Data Disk Check      ║ Failed ║ ✖      ║ /data: 756 GB available. Minimum 1 TB(1000 GB) required.                                     ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Firewall Status      ║ Passed ║ ✔      ║ firewalld/ufw/nftables service not active                                                    ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ AppArmor Status      ║ Failed ║ ✖      ║ AppArmor is enabled. Disable with GRUB: apparmor=0 security=, then update-grub and reboot.   ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Local Ports Check    ║ Failed ║ ✖      ║ Ports in use: [443 2379 5005 5006 8500 80] (checked: [8443 443 2379 5005 5006 8500 80 5000]) ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ iscsid Service       ║ Passed ║ ✔      ║ iscsid service is not in failed state                                                        ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Container Runtimes   ║ Failed ║ ✖      ║ Services running: containerd kubelet consul — must be stopped before install                 ║
╚════════════════════╩════════╩════════╩════════════════════════════════════════════════════════════════════════════════════════════╝
:x: One or more pre-flight checks failed.
error execution phase preflightcheck: preflight checks failed
To see the stack trace of this error execute with --v=5 or higher
```

---

### Automatic Checks During Installation

Each of the following radm commands also performs a preflight check before proceeding with its phase of the installation. When all checks pass, or only produce a warning, the command continues automatically. When a check fails, radm prompts to continue or abort:

```
Proceed with controller installation despite failed preflight checks? [yes/NO]:
```

Answering `NO` (the default) aborts the command and reports which phase failed.

**Skipping Preflight Checks**

To skip preflight checks for a command, add the `--skip-preflight` flag.

```
./radm init --config config.yaml --skip-preflight
```

#### radm init

```
sudo ./radm init --config config.yaml
```

**Example output: success**

```
./radm init --config config.yaml
╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                                                                    ║
║ Radm Version: v3.1-41                                                                                                               ║
║ Date: September 24, 2026                                                                                                            ║
╠════════════════════╦════════╦════════╦════════════════════════════════════════════════════════════════════════════════════════════╣
║ CHECK               ║ RESULT ║ STATUS ║ DETAILS                                                                                      ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Operating System     ║ Passed ║ ✔      ║ OS: Ubuntu 24.04. Supported OS: [Ubuntu 24.04, RHEL 9, RHEL 10]                              ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Root Disk            ║ Passed ║ ✔      ║ Used: 7% (123 GB), Available: 1909 GB                                                        ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ /tmp Disk            ║ Passed ║ ✔      ║ Shares root disk                                                                             ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ CPU                  ║ Passed ║ ✔      ║ Required: 32 CPU, Available: 32 CPU                                                          ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Memory               ║ Passed ║ ✔      ║ Size class: 64 GB (min 62 GB host-visible), Available: 62 GB (64286 MB)                      ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ MongoDB CPU Flags    ║ Passed ║ ✔      ║ AVX avx2 detected — MongoDB CPU requirements met                                             ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Data Disk Check      ║ Warning║ ⚠      ║ /data: 1.9 TB available. 2 TB recommended.                                                   ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Firewall Status      ║ Passed ║ ✔      ║ firewalld/ufw/nftables service not active                                                    ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ AppArmor Status      ║ Passed ║ ✔      ║ AppArmor is disabled at runtime                                                              ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Local Ports Check    ║ Passed ║ ✔      ║ All required local ports are available (checked: [8443 443 2379 5005 5006 8500 80 5000])     ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ iscsid Service       ║ Passed ║ ✔      ║ iscsid service is not in failed state                                                        ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Container Runtimes   ║ Passed ║ ✔      ║ No conflicting container runtimes detected                                                   ║
╚════════════════════╩════════╩════════╩════════════════════════════════════════════════════════════════════════════════════════════╝
[Archive] Extracting archive /home/ubuntu/dev-rafay-airgapped-controller-v3.1-41/rafay-infra-v3.tar.gz to /tmp/rafay-infra
```

**Example output: failure**

```
./radm init --config config.yaml
╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                                                                    ║
║ Radm Version: v4.3-01                                                                                                               ║
║ Date: September 24, 2026                                                                                                            ║
╠════════════════════╦════════╦════════╦════════════════════════════════════════════════════════════════════════════════════════════╣
║ CHECK               ║ RESULT ║ STATUS ║ DETAILS                                                                                      ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Operating System     ║ Passed ║ ✔      ║ OS: Ubuntu 24.04. Supported OS: [Ubuntu 24.04, RHEL 9, RHEL 10]                              ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Root Disk            ║ Passed ║ ✔      ║ Used: 22% (211 GB), Available: 756 GB                                                        ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ /tmp Disk            ║ Passed ║ ✔      ║ Shares root disk                                                                             ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ CPU                  ║ Passed ║ ✔      ║ Required: 32 CPU, Available: 32 CPU                                                          ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Memory               ║ Passed ║ ✔      ║ Size class: 64 GB (min 62 GB host-visible), Available: 62 GB (64289 MB)                      ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ MongoDB CPU Flags    ║ Passed ║ ✔      ║ AVX avx2 detected — MongoDB CPU requirements met                                             ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Data Disk Check      ║ Failed ║ ✖      ║ /data: 756 GB available. Minimum 1 TB(1000 GB) required.                                     ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Firewall Status      ║ Passed ║ ✔      ║ firewalld/ufw/nftables service not active                                                    ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ AppArmor Status      ║ Failed ║ ✖      ║ AppArmor is enabled. Disable with GRUB: apparmor=0 security=, then update-grub and reboot.   ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Local Ports Check    ║ Failed ║ ✖      ║ Ports in use: [443 2379 5005 5006 8500 80] (checked: [8443 443 2379 5005 5006 8500 80 5000]) ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ iscsid Service       ║ Passed ║ ✔      ║ iscsid service is not in failed state                                                        ║
╠════════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ Container Runtimes   ║ Failed ║ ✖      ║ Services running: containerd kubelet consul — must be stopped before install                 ║
╚════════════════════╩════════╩════════╩════════════════════════════════════════════════════════════════════════════════════════════╝
:x: One or more pre-flight checks failed.
Proceed with controller installation despite failed preflight checks? [yes/NO]: NO
preflight checks failed: error execution phase initpreflightcheck: preflight checks failed; aborted by user
To see the stack trace of this error execute with --v=5 or higher
```

#### radm dependency

```
sudo ./radm dependency --config config.yaml
```

**Example output: success**

```
./radm dependency --config config.yaml
╔═════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                          ║
║ Radm Version: v3.1-41                                                                     ║
║ Date: September 24, 2026                                                                  ║
╠═════════════════════════╦════════╦════════╦════════════════════════════════════════════╣
║ CHECK                    ║ RESULT ║ STATUS ║ DETAILS                                      ║
╠═════════════════════════╬════════╬════════╬════════════════════════════════════════════╣
║ Root Disk                ║ Passed ║ ✔      ║ Used: 7% (135 GB), Available: 1897 GB         ║
╠═════════════════════════╬════════╬════════╬════════════════════════════════════════════╣
║ Data Disk Check          ║ Warning║ ⚠      ║ /data: 1.9 TB available. 2 TB recommended.    ║
╠═════════════════════════╬════════╬════════╬════════════════════════════════════════════╣
║ Kubeconfig Reachability  ║ Passed ║ ✔      ║ Kubernetes API server is reachable.           ║
╚═════════════════════════╩════════╩════════╩════════════════════════════════════════════╝
Source: /home/ubuntu/dev-rafay-airgapped-controller-v3.1-41/rafay-dep-images-v3.tar.gz
[Archive] Extracting archive /home/ubuntu/dev-rafay-airgapped-controller-v3.1-41/rafay-dep-images-v3.tar.gz to /tmp/rafay-dep-images
```

**Example output: failure**

```
./radm dependency --config config.yaml
╔══════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                                        ║
║ Radm Version: v4.3-01                                                                                   ║
║ Date: September 24, 2026                                                                                 ║
╠═════════════════════════╦════════╦════════╦══════════════════════════════════════════════════════════╣
║ CHECK                    ║ RESULT ║ STATUS ║ DETAILS                                                     ║
╠═════════════════════════╬════════╬════════╬══════════════════════════════════════════════════════════╣
║ Root Disk                ║ Passed ║ ✔      ║ Used: 22% (211 GB), Available: 756 GB                       ║
╠═════════════════════════╬════════╬════════╬══════════════════════════════════════════════════════════╣
║ Data Disk Check          ║ Failed ║ ✖      ║ /data: 756 GB available. Minimum 1 TB(1000 GB) required.   ║
╠═════════════════════════╬════════╬════════╬══════════════════════════════════════════════════════════╣
║ Kubeconfig Reachability  ║ Passed ║ ✔      ║ Kubernetes API server is reachable.                         ║
╚═════════════════════════╩════════╩════════╩══════════════════════════════════════════════════════════╝
:x: One or more pre-flight checks failed.
Proceed with controller installation despite failed preflight checks? [yes/NO]: NO
preflight checks failed: error execution phase dependencypreflightcheck: preflight checks failed; aborted by user
To see the stack trace of this error execute with --v=5 or higher
```

#### radm application

```
sudo ./radm application --config config.yaml
```

**Example output: success**

```
./radm application --config config.yaml
╔═════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                          ║
║ Radm Version: v3.1-41                                                                     ║
║ Date: September 24, 2026                                                                  ║
╠═════════════════════════╦════════╦════════╦════════════════════════════════════════════╣
║ CHECK                    ║ RESULT ║ STATUS ║ DETAILS                                      ║
╠═════════════════════════╬════════╬════════╬════════════════════════════════════════════╣
║ Root Disk                ║ Passed ║ ✔      ║ Used: 10% (201 GB), Available: 1831 GB        ║
╠═════════════════════════╬════════╬════════╬════════════════════════════════════════════╣
║ Data Disk Check          ║ Warning║ ⚠      ║ /data: 1.8 TB available. 2 TB recommended.    ║
╠═════════════════════════╬════════╬════════╬════════════════════════════════════════════╣
║ Kubeconfig Reachability  ║ Passed ║ ✔      ║ Kubernetes API server is reachable.           ║
╚═════════════════════════╩════════╩════════╩════════════════════════════════════════════╝
[Archive] Extracting archive /home/ubuntu/dev-rafay-airgapped-controller-v3.1-41/rafay-core.tar.gz to /tmp/rafay-core
```

**Example output: failure**

```
./radm application --config config.yaml
╔══════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                                        ║
║ Radm Version: v4.3-01                                                                                   ║
║ Date: September 24, 2026                                                                                 ║
╠═════════════════════════╦════════╦════════╦══════════════════════════════════════════════════════════╣
║ CHECK                    ║ RESULT ║ STATUS ║ DETAILS                                                     ║
╠═════════════════════════╬════════╬════════╬══════════════════════════════════════════════════════════╣
║ Root Disk                ║ Passed ║ ✔      ║ Used: 22% (211 GB), Available: 756 GB                       ║
╠═════════════════════════╬════════╬════════╬══════════════════════════════════════════════════════════╣
║ Data Disk Check          ║ Failed ║ ✖      ║ /data: 756 GB available. Minimum 1 TB(1000 GB) required.   ║
╠═════════════════════════╬════════╬════════╬══════════════════════════════════════════════════════════╣
║ Kubeconfig Reachability  ║ Passed ║ ✔      ║ Kubernetes API server is reachable.                         ║
╚═════════════════════════╩════════╩════════╩══════════════════════════════════════════════════════════╝
:x: One or more pre-flight checks failed.
Proceed with controller installation despite failed preflight checks? [yes/NO]: NO
preflight checks failed: error execution phase dependencypreflightcheck: preflight checks failed; aborted by user
To see the stack trace of this error execute with --v=5 or higher
```

#### radm cluster

```
sudo ./radm cluster --config config.yaml
```

**Example output: success**

```
./radm cluster --config config.yaml
╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                                                                ║
║ Radm Version: v3.1-41                                                                                                           ║
║ Date: September 24, 2026                                                                                                        ║
╠════════════════╦════════╦════════╦════════════════════════════════════════════════════════════════════════════════════════════╣
║ CHECK           ║ RESULT ║ STATUS ║ DETAILS                                                                                      ║
╠════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ DNS Resolution   ║ Passed ║ ✔      ║ ops-console.varun-2-6-9may.dev.rafay-edge.net resolves to 129.146.105.10:443 and answered   ║
║                  ║        ║        ║ HTTPS with 401                                                                               ║
╚════════════════╩════════╩════════╩════════════════════════════════════════════════════════════════════════════════════════════╝
[Archive] Extracting archive /home/ubuntu/dev-rafay-airgapped-controller-v3.1-41/rafay-cluster-images.tar.gz to /tmp/rafay-cluster-images
```

**Example output: failure**

```
./radm cluster --config config.yaml
╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║ Rafay Controller PreFlight Check                                                                                                ║
║ Radm Version: v4.3-01                                                                                                           ║
║ Date: September 24, 2026                                                                                                        ║
╠════════════════╦════════╦════════╦════════════════════════════════════════════════════════════════════════════════════════════╣
║ CHECK           ║ RESULT ║ STATUS ║ DETAILS                                                                                      ║
╠════════════════╬════════╬════════╬════════════════════════════════════════════════════════════════════════════════════════════╣
║ DNS Resolution   ║ Failed ║ ✖      ║ ops-console.varun-4-3.dev.rafay-edge.net resolves and 129.153.198.56:443 accepts TCP, but   ║
║                  ║        ║        ║ the HTTPS request failed: Get "https://ops-console.varun-4-3.dev.rafay-edge.net/v2/": cont  ║
║                  ║        ║        ║ ext deadline exceeded (Client.Timeout exceeded while awaiting headers)                      ║
╚════════════════╩════════╩════════╩════════════════════════════════════════════════════════════════════════════════════════════╝
:x: One or more pre-flight checks failed.
Proceed with controller installation despite failed preflight checks? [yes/NO]: NO
preflight checks failed: error execution phase clusterpreflightcheck: preflight checks failed; aborted by user
To see the stack trace of this error execute with --v=5 or higher
```

---

## Approach 2: Standalone Preflight Script

Rafay provides a standalone preflight check utility/script. Run the preflight check script on the controller nodes to avoid common installation issues. This utility validates OS, node size, and other important configurations before the actual installation.

```
curl -sSL https://rafay-airgap-controller.s3.us-west-2.amazonaws.com/Publish/preflight-check.sh | bash
```

> **Important**
> Do not proceed to the next step unless the preflight checks pass.

---

### Example Results

Shown below are example results for successful and failed preflight checks.

#### Success

```
curl -sSL https://rafay-airgap-controller.s3.us-west-2.amazonaws.com/Publish/preflight-check.sh | bash
```

[![Successful Check](https://docs.rafay.co/selfhosted/img/preflight/success.png)](https://docs.rafay.co/selfhosted/img/preflight/success.png)

#### Failure

```
curl -sSL https://rafay-airgap-controller.s3.us-west-2.amazonaws.com/Publish/preflight-check.sh | bash
```

[![Failed Check](https://docs.rafay.co/selfhosted/img/preflight/failure.png)](https://docs.rafay.co/selfhosted/img/preflight/failure.png)

---
