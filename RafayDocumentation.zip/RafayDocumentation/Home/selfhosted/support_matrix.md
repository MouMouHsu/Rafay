---
title: "Rafay - Official Documentation"
source: https://docs.rafay.co/selfhosted/support_matrix/
category: Home
---

# Self Hosted Controller

## Supported Controller Deployment Sizes

| Size | CPU | Memory | Notes |
| --- | --- | --- | --- |
| Small | 64 | 128 GB | Non-HA |
| Medium | 96 | 192 GB |  |
| Large | 128 | 192 GB | Only HA |

## Supported Operating Systems for Air-Gapped Controller on Baremetal/VM

| Operating System | Version |
| --- | --- |
| Ubuntu | 24.04 |
| RHEL | 8 |
| RHEL | 9 |
| RHEL | 10 |

## Storage Requirements for Air-Gapped Controller on Baremetal/VM

| Storage Component | Minimum Requirement |
| --- | --- |
| Root Disk | 500 GB |
| Temp Directory (/tmp) | 50 GB (if not part of root disk) |
| Data Disk | 1 TB (mounted as /data volume, size varies based on storage requirements) |

---

## Supported self hosted controller versions

| Platform | Supported Controller Version |
| --- | --- |
| Amazon EKS | v3.3,v3.1, v2.12, v2.10 and v2.8 |
| Google GKE | v3.3,v3.1, v2.12, v2.10 and v2.8 |
| Bare Metal/VM | v3.3,v3.1, v2.12, v2.10 and v2.8 |

> Note: For details on support for previous versions(EOL), please contact the customer support team

---

## Installation Options for Self-Hosted Controllers

### Supported Environments

- Google Kubernetes Engine (GKE)
- Amazon Elastic Kubernetes Service (EKS)
- Air Gapped Environments (Air Gapped controller on BareMetal/VM). Supported Operation Systems are Ubuntu24.04, RHEL 8, RHEL 9, and RHEL 10
- Cloud-based Self-Hosted Controllers on EKS/GKE with Custom Registry and supported registries are Amazon Elastic Container Registry (ECR) and Jfrog Registry

---

## Kubernetes Versions

The latest Kubernetes version(s) on which the self-hosted controller type runs.

| Self-Hosted Controller Type | Kubernetes Version |
| --- | --- |
| BareMetal | v1.32 |
| GKE, EKS | v1.31, v1.30, and all supported K8s versions by EKS/GKE |

---

## Supported Infrastructure

- Aurora DB and Postgress DB
- External Elastic Search and Opensearch support for log management
- External Vault and AWS secret manager support for secret management

---

## Supported Registries

- For self hosted controllers, we support JFrog and Amazon Elastic Container Registry (ECR) as custom supported registries.
- For air-gapped controller, we include a local registry as part of the contained package. Additionally, we can use JFrog as well provided that the air-gapped controller has access to JFrog.

---

## Terraform Provider

List of supported controller versions by TF provider version

| Terraform Provider version | Minimum Supported Controller version |
| --- | --- |
| v1.1.46 | v3.3 |
| v1.1.45 | v3.2 |
| v1.1.43 | v3.1 |
| v1.1.39 | v2.12 |
| v1.1.38 | v2.11 |
| v1.1.37 | v2.11 |
| v1.1.36 | v2.10 |
| v1.1.35 | v2.10 |
| v1.1.34 | v2.8 |
| v1.1.33 | v2.7 |
| v1.1.32 | v2.6 |
| v1.1.30 | v2.6 |
| v1.1.29 | v2.5 |
| v1.1.24 | v2.4 |
| v1.1.23 | v2.3 |
| v1.1.22 | v2.2 |
| v1.1.20 | v2.0 |
| v1.1.19 | v2.0 |
| v1.1.18 | v2.0 |
| v1.1.17 | v1.28 (EOL) |
| v1.1.15 | v1.27 (EOL) |
| v1.1.13 | v1.26 (EOL) |
| v1.1.12 | v1.25 (EOL) |
| v1.1.10 | v1.24 (EOL) |

---

## Supported Platform Services

The "self hosted controller" and the "air gapped controller" deployment options do not support all the "platform services" supported in the SaaS controller. The table below provides a summary of services supported.

### Self Hosted Controller

| Service | Supported |
| --- | --- |
| Backup & Restore | YES |
| Catalog | YES |
| Cluster Blueprints | YES |
| Cluster Lifecycle Management | YES (All Cluster Types, excluding AKS clusters on self-signed certificate based controller) |
| Copilot | NO |
| Cost Management | YES (requires user-provided InfluxDB) |
| Email Alert Notification | NO |
| Environment Manager | YES |
| Fleet Ops | YES |
| Integrated GitOps | YES |
| Network Policy Manager | NO |
| Policy Management | YES |
| Visibility & Monitoring | YES |
| Zero Trust Kubectl | YES |

### Air Gapped Controller

| Service | Supported |
| --- | --- |
| Cluster Lifecycle Management | YES (GKE and VMWare not currently supported) |
| Cluster Blueprints | YES |
| Zero Trust Kubectl | YES |
| Visibility & Monitoring | YES |
| Policy Management | YES |
| Integrated GitOps | YES |
| Network Policy Manager | NO |
| Cost Management | YES(requires user provided InfluxDB |
| ) |  |
| Environment Manager | YES |
| Email Alert Notification | NO |
| Fleet Ops | YES |
| Copilot | NO |

---
