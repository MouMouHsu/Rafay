---
title: "Rafay - Official Documentation"
source: https://docs.rafay.co/selfhosted/gke_install/
category: Home
---

# Self-hosted Controller on GKE

Self-hosted controller on GKE enables organizations to take full ownership and customization of their Kubernetes clusters by managing and deploying their own controller components directly within the GKE environment. This approach provides organizations with increased flexibility, allowing them to fine-tune their Kubernetes infrastructure to meet specific performance, security, and compliance requirements. With self-hosted controller on GKE, organizations can optimize resource utilization, streamline deployment processes, and ensure seamless scalability for their containerized applications.

To learn about the installation process of Self-hosted Controller on GKE, refer [this page](https://docs.google.com/document/d/1xGFoG_9RT4NaBEGPenkTMa_5ZUVteUiV/view).

> **Important**
> Login is required to access the documentation on the support portal. Contact support for portal access.

---
