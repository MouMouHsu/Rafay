---
title: "KOP Self Hosted Controller - ConfigBuilder Input Parameters Guide"
source: https://docs.rafay.co/selfhosted/configbuilder_parameters/
category: Home
---

# Input Parameters

This section outlines the key configuration parameters for setting up a self-hosted controller. These parameters include network settings, storage options, and file system details. Proper configuration of these parameters ensures optimal performance and seamless operation of the controller.

---

## Fully Qualified Domain Name (FQDN)

- Parameter: `wildcard`
- Description: Specifies the Fully Qualified Domain Name for the controller
- CLI Prompt: "Provide a Fully Qualified Domain Name (FQDN) for the controller"
- Type: `string`

## NFS Server

- Parameter: `nfs.server`
- Description: The hostname or IP address of the NFS server.
- CLI Prompt: "Provide the Filestore NFS IP address"
- Type: `string`

## EFS (Elastic File System)

Parameters for configuring Amazon EFS for the controller.

### File System ID

- Parameter: `storageClass.efsFilesystemId`
- Description: The ID of the EFS file system to be used.
- CLI Prompt: "Provide the EFS File System ID (e.g., fs-12345678)"
- Type: `string`

### EFS Role ARN

- Parameter: `controller.serviceAccount.annotations`
- Description: The ARN of the IAM role with permissions to access the EFS file system.
- CLI Prompt: "Provide the EFS Role ARN"
- Type: `string`

## Load Balancer

Parameters for configuring the Load Balancer for the controller.

### Load Balancer Role ARN

- Parameter: `global.lb_controller.role_arn`
- Description: The ARN of the IAM role that provides permissions for the Load Balancer.
- CLI Prompt: "Provide the Load Balancer IAM Role ARN"
- Type: `string`

### Load Balancer Subnets

- Parameter: `global.lb_subnet_ids`
- Description: The subnets where the Load Balancer will be created. Private subnets for internal Load Balancers or public subnets for internet-facing ones.
- CLI Prompt: "Provide the subnet ID for the Load Balancer"
- Type: `string`

## Advanced Configurations

### High Availability (HA) Controller

- Parameter: `ha`
- Description: This parameter configures the deployment mode of the Rafay controller. When set to `true`, the controller is deployed in High Availability (HA) mode, ensuring redundancy and increased resilience in case of node failure. If set to `false`, the controller will run in a single-node mode.
- Question in CLI: “Do you want to create a High-Availability (HA) controller?”
- Type: `bool`
- Default: `false`

### Controller Size

- Parameter: `size`
- Description: Defines the size of the controller deployment, based on load and performance requirements. Options include Small, Medium, and Large, each corresponding to different CPU and memory allocations.
- CLI Prompt: "Select the size of your controller deployment (Small/S: 16 CPU/64GB, Medium/M: 32 CPU/64GB, Large/L: 48 CPU/72GB)"
- Type: `string`
- Default: `S`
- Options:
  - S: Small 16 CPU/64GB
  - M: Medium 32 CPU/64GB
  - L: Large 48 CPU/72GB

### Custom Registry Configuration

Parameters for configuring a custom container registry.

#### Enabled

- Description: Enables or disables the configuration of a custom container registry, such as AWS ECR or JFrog.
- CLI Prompt: "Would you like to configure the controller with a custom registry?"
- Type: `bool`
- Default: `false`

#### Registry Type

- Description: Specifies the type of registry (e.g., AWS ECR or JFrog).
- CLI Prompt: "Provide the registry type (ecr/jfrog)"
- Type: `string`
- Options: `ECR`, `JFrog`

#### Registry Endpoint

- Description: The URL of the custom registry.
- CLI Prompt: "Provide AWS ECR/JFrog endpoint."
- Type: `string`

#### Registry Username

- Description: Username for authenticating to the custom registry.
- CLI Prompt: "Provide the username for the custom registry."
- Type: `string`

#### Registry Password

- Description: Password used for authenticating to the custom registry.
- Question in CLI: "Enter the password for the custom registry."
- Type: `string`

---

## External Database Configuration

The parameters below are for configuring an external database to use AWS RDS in EKS or Google Cloud SQL.

### Enable External Database

- Parameter: `external-database`
- Description: Enables or disables the use of an external database for the controller, such as AWS RDS or Google Cloud SQL. If set to `true`, users must provide the database endpoint, credentials, and other configuration details.
- Question in CLI: “Would you like to configure the external database (RDS/SQL)?”
- Type: `bool`
- Default: `false`

### Database Host

- Parameter: `host`
- Description: The database endpoint (FQDN or IP address) where the Rafay controller can connect to store its data. Question in CLI: “Please provide the external database endpoint (FQDN or IP address).”
- Type: `string`

---

## SSL Certificates Configuration

The following parameters pertain to the SSL certificate configuration for the controller’s fully qualified domain name (FQDN).

### SSL Certificates

- Description: Determines whether you have SSL certificates for the provided FQDN. If the answer is "yes," you will be prompted to specify whether you are using AWS ACM or private certificates. If the answer is "no," Rafay will generate self-signed certificates for the controller.
- Question in CLI: “Do you have SSL certificates for the provided fully qualified domain name (FQDN)?”
- Type: `bool`
- Default: `false`

---

## OpenSearch Configuration

The following parameters are for configuring OpenSearch for the controller.

### Enable OpenSearch

- Parameter: `global.opensearch.enabled`
- Description: Enables or disables the configuration of OpenSearch.
- Question in CLI: “Would you like to configure AWS OpenSearch?”
- Type: Boolean
- Default: `false`

### OpenSearch Domain Endpoint

- Parameter: `global.opensearch.endpoint`
- Description: The endpoint for the OpenSearch domain.
- Question in CLI: “Provide the OpenSearch endpoint.”
- Type: `String`

### OpenSearch Username

- Parameter: `global.opensearch.user_name`
- Description: Username for authenticating to the OpenSearch domain.
- Question in CLI: “Provide the OpenSearch username.”
- Type: `String`

### OpenSearch Password

- Parameter: `global.opensearch.user_password`
- Description: Password for authenticating to the OpenSearch domain.
- Question in CLI: “Provide the OpenSearch password.”
- Type: `String`

### OpenSearch Region

- Parameter: `global.opensearch.region`
- Description: Region of the OpenSearch domain.
- Question in CLI: “Provide the OpenSearch region.”
- Type: `String`

---

## Karpenter Configuration

The following parameters configure Karpenter, a Kubernetes-native autoscaler, to manage scaling of EKS worker nodes dynamically.

### Enable Karpenter

- Parameter: `karpenter.enabled`
- Description: Enables or disables Karpenter for dynamic node provisioning.
- Question in CLI: “Would you like to configure karpenter service for the controller”
- Type: `bool`
- Default: `false`

### Karpenter role arn

- Parameter: `karpenter.serviceAccount.annotations`
- Description: The ARN of the IAM role that has permissions to provision new nodes based on the controller configuration.
- Question in CLI: “Provide the Karpenter role ARN.”
- Type: `string`

### EKS Cluster Name

- Parameter: `karpenter.clusterName`
- Description: The name of the EKS cluster where Karpenter will be deployed.
- Question in CLI: “Provide the EKS cluster name.”
- Type: `string`

### EKS Cluster Endpoint

- Parameter: `karpenter.clusterEndpoint`
- Description: The endpoint of your EKS cluster.
- Question in CLI: “Provide the EKS cluster endpoint.”
- Type: `string`

---

## IRSA Configuration

The following parameters configure IRSA (IAM Roles for Service Accounts) for Rafay controllers.

### Enable IRSA

- Parameter: `global.edge.irsa_role_enabled`
- Description: Enables or disables IRSA for managing permissions to provision EKS clusters on AWS using the Rafay console.
- Question in CLI: “Would you like to configure the IRSA role to provision clusters?”
- Type: `bool`
- Default: `false`

### IRSA Role ARN

- Parameter: `global.edge.irsa_role_arn`
- Description: The ARN of the IAM role that grants permission to provision EKS clusters on AWS using the Rafay console.
- Question in CLI: “Provide the IRSA role ARN.”
- Type: `string`

---

## More Advanced Configurations

### Backup and Restore

The following parameters configure the backup and restore functionality for the controller.

#### Enable Backup

- Parameter: `backup_restore.enabled`
- Description: This parameter enables or disables the backup and restore feature for the Rafay controller. When enabled, the controller's data will be regularly backed up to an S3 bucket.
- Question in CLI: “Would you like to configure backup and restore for the controller?”
- Type: `bool`
- Default: `false`

#### Enable Restore

- Parameter: `backup_restore.restore`
- Description: This parameter enables or disables the restore configuration, allowing restoration from a previous backup if desired.
- Question in CLI: “Do you want to restore from a previous backup?”
- Type: `bool`
- Default: `false`

#### Storage Container for Backup

- Parameter: `backup_restore.bucketName`
- Description: The name of the S3 bucket where the Rafay controller backups will be stored.
- Question in CLI: “Provide the name of the S3 bucket for storing backups.”
- Type: `string`

#### Restore Folder Name

- Parameter: `backup_restore.restoreFolderName`
- Description: The name of the folder for the latest backup to restore.
- Question in CLI: “Provide the name of the latest backup folder for the controller restore.”
- Type: `string`

#### Backup Region

- Parameter: `backup_restore.region`
- Description: The AWS region where the backup S3 bucket is located.
- Question in CLI: “Provide the backup bucket region.”
- Type: `string`

#### Backup IAM Role ARN

- Parameter: `backup_restore.role_arn`
- Description: The ARN of the IAM role that grants permission to perform backup and restore operations in S3.
- Question in CLI: “Provide the backup IAM role ARN.”
- Type: `string`

---

## Namespace Labels

The following parameters are used to add labels to the Rafay-managed namespace.

### Enable Namespace Labels

- Parameter: `namespace_labels.enabled`
- Description: Enables or disables the addition of labels to the namespace where the Rafay controller operates.
- Question in CLI: “Would you like to configure namespace labels?”
- Type: `bool`
- Default: `false`

### Number of Labels

- Parameter: `namespace_labels.numLabels`
- Description: Defines the number of labels to be added to the namespace.
- Question in CLI: “How many namespace labels do you want to add?”
- Type: `int`
- Default: `1`

### Label Key

- Parameter: `namespace_labels.key`
- Description: Specifies the key for the namespace label.
- Question in CLI: “Provide the namespace label key.”
- Type: `string`
- Default: `Owner`

### Label Value

- Parameter: `namespace_labels.value`
- Description: Specifies the value for the namespace label.
- Question in CLI: “Provide the namespace label value.”
- Type: `string`
- Default: `Rafay`

---

## Pod Tolerations

The following parameters are used to add pod tolerations to the master and worker nodes.

### Enable Pod Tolerations

- Parameter: `pod_tolerations.enabled`
- Description: Enables or disables the addition of pod tolerations to nodes. Tolerations allow the controller pods to run on nodes with specific taints.
- Question in CLI: “Would you like to configure pod tolerations?”
- Type: `bool`
- Default: `false`

### Number of Tolerations

- Parameter: `pod_tolerations.numTolerations`
- Description: Specifies the number of pod tolerations to be applied to the controller pods.
- Type: `integer`
- Default: `1`

### Toleration Key

- Parameter: `pod_tolerations.key`
- Description: The taint key that the toleration applies to. This key must match a taint on a node for the pod to tolerate it.
- Question in CLI: “Provide the pod toleration key.”
- Type: `string`

### Toleration Value

- Parameter: `pod_tolerations.value`
- Description: The taint value that the toleration matches. If the operator is Equal, the pod will only tolerate nodes that have this taint value.
- Question in CLI: “Provide the pod toleration value.”
- Type: `string`

### Toleration Operator

- Parameter: `pod_tolerations.operator`
- Description: Defines the relationship between the key and value. The possible values are: Equal, Exists.
- Question in CLI: “Provide the pod toleration operator (Exists/Equal).”
- Type: `string`

### Toleration Effect

- Parameter: `pod_tolerations.effect`
- Description: Specifies the taint effect to match. The possible values are: NoSchedule, PreferNoSchedule, NoExecute.
- Question in CLI: “Provide the pod toleration effect (NoSchedule/PreferNoSchedule/NoExecute).”
- Type: `string`

---

## TSDB Backup Configuration

The following parameters are for configuring the time-series database (TSDB) backup for the controller.

### Enable TSDB Backup

- Parameter: `global.tsdb_backup.enabled`
- Description: This parameter enables or disables the backup of TSDB data to a specified bucket.
- Question in CLI: “Would you like to configure the TSDB backup?”
- Type: `bool`
- Default: `false`

### Storage Container for Backup

- Parameter: `global.tsdb_backup.bucket`
- Description: The name of the bucket where the TSDB backups will be stored.
- Question in CLI: “Provide the TSDB backup bucket name.”
- Type: `string`

### Backup Region

- Parameter: `global.tsdb_backup.bucket_region`
- Description: The AWS region where the bucket for TSDB backup is located.
- Question in CLI: “Provide the TSDB backup bucket region.”
- Type: `string`

### Backup Role ARN

- Parameter: `global.tsdb_backup.role_arn`
- Description: The ARN of the IAM role that has permissions to upload TSDB backups to the bucket.
- Question in CLI: “Provide the TSDB backup role ARN.”
- Type: `string`

---

## EAAS Configuration

The following parameters configure the EAAS service on the Rafay Controller.

### EAAS Enable

- Parameter: `eaas.enabled`
- Description: Enables or disables the EAAS service for the Rafay Controller.
- Question in CLI: “Would you like to configure the EAAS service?”
- Type: `bool`
- Default: `false`

### S3 Bucket Name

- Parameter: `global.engine_api_blob_bucket`
- Description: The name of the bucket where the EAAS service activity logs will be stored.
- Question in CLI: “Provide the EAAS bucket name.”
- Type: `string`

### S3 Bucket Region

- Parameter: `global.engine_api_region`
- Description: The AWS region where the EAAS bucket is located.
- Question in CLI: “Provide the EAAS bucket region.”
- Type: `string`

### Role ARN

- Parameter: `global.engine_api_irsa_role_arn`
- Description: The ARN of the IAM role to be used with the service account.
- Question in CLI: “Provide the EAAS role ARN.”
- Type: `string`

---

## Monitoring Configuration

The following parameter enables or disables monitoring for the Rafay Self-Hosted Controller.

### Enable Amazon Managed Prometheus (AMP)

- Parameter: `monitoring.enabled`
- Description: Enables or disables the integration with Amazon Managed Prometheus (AMP) for monitoring the Rafay controller. If enabled, the user must provide details such as the workspace ID and IAM roles for Prometheus ingestion and querying.
- Question in CLI: “Would you like to configure Amazon Managed Prometheus for the controller?”
- Type: `bool`
- Default: `false`

### AMP Workspace ID

- Parameter: `monitoring.workspace_id`
- Description: The unique identifier of the Amazon Managed Prometheus workspace where metrics from the Rafay controller will be stored.
- Question in CLI: “Provide the AMP workspace ID (e.g., ws-h046j0s0-ui39-4bsc-90fu-012dfabb2y0e).”
- Type: `string`

### AMP Ingest Role ARN

- Parameter: `monitoring.ingest_role_arn`
- Description: The ARN of the IAM role that grants Prometheus permission to ingest monitoring data.
- Question in CLI: “Provide the ingest role ARN for AMP.”
- Type: `string`

### AMP Query Role ARN

- Parameter: `monitoring.query_role_arn`
- Description: The ARN of the IAM role that allows querying data from the Prometheus workspace.
- Question in CLI: “Provide the query role ARN for AMP.”
- Type: `string`

### Prometheus Region

- Parameter: `monitoring.region`
- Description: The AWS region where the Amazon Managed Prometheus workspace is located.
- Question in CLI: “Provide the AMP region.”
- Type: `string`

---
