---
title: "Self-Hosted and Air-Gapped Controller Deployments of Rafay"
source: https://docs.rafay.co/selfhosted/overview/
category: Home
---

# Provision, Manage & Operate the Rafay Platform on your Infrastructure

The Rafay Platform can be deployed and operated on your own environment while maintaining full control over your data and infrastructure.

- **Architecture**   Deployment architecture and components of the Rafay Controller.  [**Get Started**](https://docs.rafay.co/selfhosted/architecture/)
- **By Environment**   Learn about the types of environments for self-hosted controller.  [**Air Gapped**](https://docs.rafay.co/selfhosted/airgapped/overview/) | [**Amazon EKS**](https://docs.rafay.co/selfhosted/awseks_install/) | [**Google GKE**](https://docs.rafay.co/selfhosted/gke_install/)| [**Helm Install**](https://docs.rafay.co/selfhosted/installation_helm/)| [**FIPS**](https://docs.rafay.co/selfhosted/fips_controller/)
- **Support Matrix**   Support Matrix for the self hosted controller including compatible platforms and versions  [**Get Started**](https://docs.rafay.co/selfhosted/support_matrix/)

---
