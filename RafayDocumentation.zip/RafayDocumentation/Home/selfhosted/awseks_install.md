---
title: "Rafay - Official Documentation"
source: https://docs.rafay.co/selfhosted/awseks_install/
category: Home
---

# Self-hosted Controller on EKS

Deploying the Self-Hosted Controller on AWS EKS offers a robust solution for managing containerized workloads with ease. By leveraging Amazon's Elastic Kubernetes Service (EKS), organizations gain seamless integration into a scalable and flexible infrastructure environment. EKS provides the necessary foundation for hosting Kubernetes clusters, allowing for effortless scalability to meet evolving demands. With built-in security features such as encryption and IAM integration, deploying the Self-Hosted Controller on EKS ensures a secure environment for running containerized applications.

To learn about the installation process of Self-hosted Controller on AWS EKS, refer [this page](https://support.rafay.co/hc/en-us/articles/4804751394317-Resources-for-Rafay-Controller-Deployments).

> **Important**
> Login is required to access the documentation on the support portal. Contact support for portal access.

---
