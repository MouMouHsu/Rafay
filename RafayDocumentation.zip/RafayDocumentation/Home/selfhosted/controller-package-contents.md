---
title: "KOP Self Hosted Controller - Controller Package Details"
source: https://docs.rafay.co/selfhosted/controller-package-contents/
category: Home
---

# Controller Package Contents

The controller package contains a curated set of tools, binaries, configuration templates, and Docker images required for provisioning and managing the Rafay controller on Kubernetes-based infrastructure

Below is a breakdown of the files included in the package along with their descriptions:

### Files and Descriptions

| **Path** | **Description** |
| --- | --- |
| `./rafay-infra-<build-version>.tar.gz` | Contains binaries to bring up the Kubernetes layer, including `kubeadm`, `consul`, `containerd`, `registry`, etc. |
| `./certificates/` | Contains AWS RDS-related CA certificates, used in FIPS deployments on AWS. |
| `./certificates/rds-global-ca.pem` | Global CA certificate for AWS RDS for FIPS Based Controller Deployed on AWS. |
| `./rafay-core.tar.gz` | Helm charts for Rafay platform applications. |
| `./rafay-dep.tar.gz` | Helm charts for dependency addons required by Rafay applications. |
| `./rafay-dep-images-<build-version>.tar.gz` | Docker images for the above dependencies. |
| `./rafay-cluster-assets.tar.gz` | Binaries for clusters including Salt, Kubernetes (e.g., `kubeadm`), RPM/DEB files. |
| `./rafay-cluster-images.tar.gz` | Cluster provisioning Docker images. |
| `./rafay-infra-images.tar.gz` | Infrastructure images such as Kubernetes base images, OpenEBS, and CNI plugins like Calico. |
| `./rafay-core-images.tar.gz` | Docker images for Rafay platform applications. |
| `./istio-<build-version>-blueprint.tar.gz` | Helm charts for deploying Istio (service mesh). |
| `./rafay-istio-<build-version>-images.tar.gz` | Docker images for Istio components. |
| `./rcollect` | Log collection utility for Linux. |
| `./rcollect-mac` | Log collection utility for macOS. |
| `./configbuilder` | CLI utility that interactively generates a `config.yaml` file. |
| `./configbuilder-mac` | macOS version of the `configbuilder` utility. |
| `./config.yaml-tmpl` | Generic configuration template for EKS, GKE, or airgapped deployments. |
| `./config.yaml-eks-tmpl` | Configuration template specific to EKS. |
| `./config.yaml-aks-tmpl` | Configuration template specific to AKS. |
| `./config.yaml-gke-tmpl` | Configuration template specific to GKE. |
| `./config.yaml-airgap-tmpl` | Configuration template for airgapped environments. |
| `./radm` | Command-line tool for managing the Rafay controller. |
| `./.radm-build-Info.md` | Hidden file containing internal build metadata for the controller. |

---
