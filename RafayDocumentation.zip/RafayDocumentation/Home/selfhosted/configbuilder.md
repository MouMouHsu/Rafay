---
title: "KOP Self Hosted Controller - ConfigBuilder CLI Tool"
source: https://docs.rafay.co/selfhosted/configbuilder/
category: Home
---

# Configuration

## Overview

ConfigBuilder is a command-line tool designed to generate YAML configuration files for different environments (Baremetal, EKS, GKE) from predefined templates by prompting users for the necessary inputs. It simplifies the process of configuring Rafay Self-Hosted environments by guiding users through a series of prompts to collect the required information and generate a configuration file.

---

## Installation

Download the ConfigBuilder CLI tool for the required operating system using the following links.

- [Linux ConfigBuilder Tool](https://rafay-prod-configbuilder.s3.us-west-2.amazonaws.com/linux/configbuilder)
- [macOS ConfigBuilder Tool](https://rafay-prod-configbuilder.s3.us-west-2.amazonaws.com/darwin/configbuilder-mac)

---

## Supported Flags

ConfigBuilder supports the following flags, which can be used with the commands:

- `-u` (Optional): Prompts for custom super-user name and password details. If this flag is not provided, the tool uses default super-user name and password values
- `-o` (Optional): Specifies a custom directory to save the generated configuration file. The directory path must be provided as an absolute path. If not specified, the file is saved in the current working directory

---

## ConfigBuilder Commands for Controller Configuration

- **Baremetal**: Generates a configuration YAML file for an air-gapped controller
- **EKS**: Generates a configuration YAML file for an EKS controller
- **GKE**: Generates a configuration YAML file for a GKE controller
- **Version**: Prints the version number of ConfigBuilder
- **Help**: Displays help information for ConfigBuilder or any subcommand

![💡](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/1f4a1.svg) ***If you are using ConfigBuilder for the first time, it is recommended to start with the **Baremetal** command to generate a configuration YAML file for an air-gapped controller. This approach uses minimal options and can help familiarize you with the tool and its configuration process***

### Baremetal ConfigBuilder

- This command generates a config.yaml file for an air-gapped controller:

```
$./configbuilder baremetal
```

- After running this command, the system will prompt for a series of inputs during the configuration process. For detailed information on each parameter, refer to [ConfigBuilder Configuration Parameters](https://docs.rafay.co/selfhosted/configbuilder_parameters/)
- By default, the generated `config.yaml` file is saved in the current directory, unless the `-o` flag is used to specify a custom directory. The tool uses the default username and password unless the `-u` flag is provided to set custom credentials

**Example**

Here is an example of executing the ConfigBuilder binary in a Baremetal environment:

1. Downloading the Binary
  - Download the ConfigBuilder binary for Linux from [this](https://dev-rafay-controller.s3.us-west-1.amazonaws.com/configbuilder/linux/configbuilder) link. This will save the ConfigBuilder binary to the default download location or the current directory, depending on the system's configuration
2. Executing the Binary
  - After downloading, the binary file needs to be made executable. This is typically done using the chmod command: 

```
chmod +x configbuilder
```

 This command changes the file permissions to allow execution of the binary.
3. Running the Binary:
  - Once the binary is executable, it can be run by simply typing: 

```
./configbuilder
```

 This command executes the ConfigBuilder binary.
4. Run the 'configbuilder' binary with the 'baremetal' option to start configuring the environment. 

```
./configbuilder baremetal
```
5. Interactive Configuration Steps appears as shown below

```
./configbuilder baremetal

Do you want to create a High-Availability (HA) controller?  (yes/no) : y

Select the size of your controller deployment: (Small/S - Medium/M - Large/L) (default: M): s

Provide a fully qualified domain name (FQDN) for the controller : rafay.dev.rafay-edge.net

Do you want to generate self signed certificates for the provided FQDN?  (yes/no) : y

Would you like to enable advanced configuration  (yes/no) : y

Would you like to configure backup and restore for the controller?  (yes/no) : n

Would you like to configure namespace labels :  (yes/no) : y

 How many namespace labels do you want to add :  (default: 1): 1
Namespace Label 1:
  Provide the namespace label key : environment
  Provide the namespace label value : dev

Would you like to configure pod tolerations :  (yes/no) : n

Configuration YAML file generated successfully at '/home/ubuntu/user1/Configbuilder/config-28-August-2024-06:53:59.yaml'!
```

After completing the prompts, the configbuilder generates a YAML configuration file based on the provided inputs. Refer to [this page](https://docs.rafay.co/selfhosted/support_matrix/#supported-controller-deployment-sizes) for more information on the Supported Controller Deployment Sizes

1. Custom Output Path (Optional): To save the configuration file to a custom path, use the -o option: 

```
./configbuilder baremetal -o /home/ubuntu/
```

 This saves the file to ***/home/ubuntu/***
2. Review the Configuration File: The configuration file, named `config-28-August-2024-06:55:34.yaml`, will be generated and contain all the settings specified during the configuration process

---

### EKS ConfigBuilder

This command generates a config.yaml file for an EKS controller:

```
$./configbuilder eks
```

The tool prompts for necessary inputs, such as High Availability (HA) settings, backup settings, namespace labels, and others. By default, the generated `config.yaml` file is saved in the current directory, unless the `-o` flag is used to specify a custom directory. The default username and password are used unless the `-u` flag is provided to set custom credentials.

### GKE ConfigBuilder

This command generates a config.yaml file for a GKE controller:

```
$./configbuilder gke
```

The tool prompts for necessary inputs, such as High Availability (HA) settings, backup settings, namespace labels, and more. By default, the generated `config.yaml` file is saved in the current directory unless the `-o` flag is used to specify a custom directory. The default username and password are applied unless the `-u` flag is provided to set custom credentials.

### Verify ConfigBuilder Version

To verify the version number of the ConfigBuilder tool, run the following command:

```
$ ./configbuilder version
Confibuilder-v2.7
```

### Explore ConfigBuilder Commands

To access detailed help information for ConfigBuilder commands and flags, use the following command:

```
$./configbuilder help
ConfigBuilder is a CLI tool that helps you generate configuration files for Rafay Self Hosted by prompting you for necessary inputs..

Usage:
  configbuilder [command]

Available Commands:
  baremetal   Generates a configuration YAML file for airgapped controller
  eks         Generates a configuration YAML file for EKS
controller
  gke         Generates a configuration YAML file for GKE controller
  help        Help about any command
  version     Print the version number of Confibuilder

Flags:
  -u, --custom-super-user   Provide custom super-user name and password
  -h, --help                help for configbuilder
  -o, --output string       Output path for the YAML file (default "config.yaml")

Use "configbuilder [command] --help" for more information about a command.
```

The example below displays detailed help and usage instructions for the EKS command.

```
$./configbuilder help eks
Generate a configuration YAML file based on user input. By default, the file is named 'config.yaml' and located in the current directory. Use the -o/--output flag to specify a different path.

Usage:
  configbuilder eks [flags]

Flags:
  -h, --help              help for eks
  -o, --output string     Output path for the YAML file (default "config.yaml")
      --password string   Super-user password (default "changeplz")
      --username string   Super-user name (default "[email protected]")

Global Flags:
  -u, --custom-super-user   Provide custom super-user name and password
```

---
