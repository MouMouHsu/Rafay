---
title: "KOP Self-Hosted Controller - Helm Chart Configuration Reference"
source: https://docs.rafay.co/selfhosted/helm_configuration/
category: Home
---

# Configuration

Deploying the air gapped controller application in a multi-node Kubernetes cluster within your production environment can be accomplished using the Helm Chart. This chart allows for customization through the values.yaml file, which outlines the available parameters for your installation. For detailed installation instructions, please refer to the [Helm installation guide](https://docs.rafay.co/selfhosted/installation_helm/).

---

## Required Configuration

The following parameters have to be updated in the `values.yaml`.

- Specifies the valid wildcard domain name used to access the controller. Example: `*.user.company-edge.net`

```
 default_partner_console_domain: <user_domain>
```

- Determines if High Availability (HA) is enabled. Set to 'false' for a single-node cluster, or 'true' for clusters with 3 or more nodes with the required capacity

```
ha_enabled: false
```

- Defines the size of the controller based on system resources. Supported sizes are S (Small), M (Medium), and L (Large)

> **Info**
> - For controllers with 16 CPUs, 64 GB RAM, and a minimum of 1 node, define the size as "S" (Supports less than 100 clusters)
> - For controllers with 32 CPUs, 64 GB RAM, and a minimum of 3 nodes, define the size as "M" (default) (Supports 100-250 clusters)
> - For large-scale controllers with 48 CPUs, 72 GB RAM, and a minimum of 3 nodes, define the size as "L" (Supports more than 250 clusters)

```
size: <size_of_the_controller>
```

Refer to the [Supported Controller Deployment Sizes](https://docs.rafay.co/selfhosted/support_matrix/#supported-controller-deployment-sizes) for more details

- Sets the super admin username for accessing the Operations console

```
admin_user: <admin_username_to_access_operations_console>
```

- Specifies the **Super-admin** password for accessing the Operations console in Base64-encoded format

```
admin_passwd: <admin_password_to_access_operations_console>
```

### Advanced Settings

- Specifies the partner name associated with the controller. This name is displayed on the browser tab in the user interface

```
# partner_name: <User>
```

Once you have finished configuring the `values.yaml` file, return to the [Installation guide](https://docs.rafay.co/selfhosted/installation_helm/#installation) to proceed with the next steps.

---

## DNS Record Creation

The installation of the Controller requires wildcard DNS records. In the examples below, replace `rafay.example.com` with the desired domain:

```
*.rafay.example.com
```

If wildcard DNS is not available, individual DNS records are needed:

```
api.<rafay.example.com>
console.<rafay.example.com>
fluentd-aggr.<rafay.example.com>
kibana.<rafay.example.com>
nexus.<rafay.example.com>
ops-console.<rafay.example.com>
rcr.<rafay.example.com>
regauth.<rafay.example.com>
repo.<rafay.example.com>
*.cdrelay.<rafay.example.com>       
*.core-connector.<rafay.example.com>    
*.core.<rafay.example.com>  
*.connector.infrarelay.<rafay.example.com>  
*.user.infrarelay.<rafay.example.com>
*.kubeapi-proxy.<rafay.example.com>
*.user.<rafay.example.com>
```

> Note: DNS records for the wildcard Fully Qualified Domain Name (FQDN) should point to the IP address of the controller node. In the case of High Availability (HA), the DNS records should point to the IP address of one of the controller nodes

---
