---
title: "KOP Self Hosted Controller - Controller Installation on EKS (FIPS)"
source: https://docs.rafay.co/selfhosted/fips_controller/
category: Home
---

# FIPS Compliant Controller

## Introduction

To install the FIPS-compliant Controller with an ECR registry in the Amazon EKS environment, follow the steps outlined below. This installation adheres to FIPS 140-2 standards, with all software libraries and components within the controller compiled using cryptographic libraries for robust security in sensitive, regulated environments. Leveraging Amazon EKS for managed Kubernetes and ECR for secure container image storage, this setup ensures a highly secure and compliant deployment of the Controller.

---

## Supported Platforms and Compatibility

- **Supported Platforms**: Amazon EKS with ECR Public Registry
- **Controller Version**: Rafay Controller Version 2.6
- **Kubernetes Version Compatibility**: Supports Kubernetes versions 1.27, 1.28, and 1.29, provided the nodes are FIPS enabled
- **Node Operating Systems**: Compatible with FIPS-enabled Amazon Linux 2 (AL2) AMIs for all node groups
- **CNI Compatibility**: The FIPS controller uses the `aws-cni`
- **Cluster Type**: Currently supports only EKS cluster type

---

## Getting Started with FIPS-Enabled Installation

The installation process requires specific prerequisites, including DNS configurations and X.509 certificates for secure communication. Additional setup may involve IAM roles to enable seamless integration with ECR.

For detailed, step-by-step guidance or to obtain the required FIPS installer, contact the [support team](https://docs.rafay.co/contact/email/) for assistance in configuring the Rafay Controller to meet compliance and security requirements for your environment.

---

## Managing Cloud Credentials During Cluster Migration

When migrating clusters or updating credentials in a FIPS environment, it's important to properly configure cloud credentials to ensure seamless access and operation. The following sections outline how to update cloud credentials after migration and how to prepare the target controller with required resources.

### Update Cloud Credentials Post-Migration

1. Use `Terraform` to create new access-based cloud credentials
2. Modify the `cloud_credentials` field in the cluster's Terraform resource to use the new credentials
3. After the update, all cluster operations will use the new credentials

### Migrate Credentials to Target Controller

Before migrating a cluster, ensure the following dependent resources exist on the target controller:

- Blueprint
- Addons
- Cloud Credentials

These resources must be created or imported using Terraform **before** starting the cluster migration.

---
