---
title: "Namespace Schema"
source: https://docs.rafay.co/namespaces/ns_schema/
category: Home
---

# Namespace Schema

## Namespace configuration - Wizard

## Namespace configuration - Upload

## Namespace configuration - Git
