---
title: "KOP Network Policy Manager - Introduction"
source: https://docs.rafay.co/network_policy/introduction/
category: Home
---

# Background

One of the most significant benefits of Kubernetes is the ability to quickly deploy and connect applications, whether across namespaces in a cluster or across different cloud environments.

By default, a pod/application running in a K8s cluster has the freedom to communicate with anything inside and outside the cluster with no security rules applied. While this model reduces friction for developers, it can seriously compromise the security posture of applications in production.

This is why [Kubernetes Security Hardening Guide](https://www.cisa.gov/uscert/ncas/current-activity/2022/03/15/updated-kubernetes-hardening-guide) published by CISA recommends the use of [network policies](https://kubernetes.io/docs/concepts/services-networking/network-policies/) for controlling ingress/egress traffic and enforcing segmentation between different applications in K8s clusters.

## Introduction To Network Policies

In Kubernetes environments, network isolation and traffic flow enforcement are typically implemented through network policies. A network policy is essentially a construct that allows definition of:

- Rules for what an application can talk to (different entities in the cluster, the internet, etc.) - this is very similar to firewall rules
- What type of traffic do these rules apply to (for example, does this apply to traffic coming in, i.e., ingress, or traffic going out, i.e., egress)
- The scope - which pods or applications is the policy being enforced for

Network policy enforcement enables you to control the communication between your pods and services while also ensuring that your applications are properly isolated from each other to reduce the attack surface.

## Typical Requirements

### Platform Teams

While network policies can be created for individual pods or namespaces today, platform teams need a zero-trust solution that can scale and work across the enterprise specifically. Some key requirements include:

- Ability to define default sets of rules that can be applied at scale to a fleet of resources
- Standardize deployment and configuration of network policies via blueprinting
- Controlling access to traffic flows controlled by assigned role
- Ability to isolate namespaces and workloads in a shared cluster environment
- Scoping of network policy rules at a cluster level as well for zero-trust across entire infrastructure

### Application teams

Application teams need their own sets of requirements including:

- Ability to secure individual applications based on requirements
- Ability to grant or deny network access to specific pods or namespaces based on application requirements

The Network Policy solution can deliver these outcomes and enables both the enterprise platform and developer teams to operationalize K8s network policies at scale.

---
