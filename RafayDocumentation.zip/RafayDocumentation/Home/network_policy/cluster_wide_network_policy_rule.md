---
title: "KOP Network Policy Manager - Cluster-Wide Network Policy Rule"
source: https://docs.rafay.co/network_policy/cluster_wide_network_policy_rule/
category: Home
---

# Cluster-Wide Network Policy rules

## Overview

Cluster-Wide Network Policy Rules is a construct that defines a grouping of network security rules that can then be applied to a [cluster-wide policy](https://docs.rafay.co/network_policy/cluster_wide_policy/).

### RBAC

Only **Org Admins** and **Infra Admins** can create/manage cluster-wide network policy rules.

## How To Write Cluster-Wide Network Policy Rules

- Examples can be found [here](https://docs.cilium.io/en/stable/security/policy/#network-policy)
- [Cilium Network Policy Editor](https://editor.cilium.io/) can also be used to build network policy rules

The following types of CRDs are supported for cluster-wide network policy rules:

- **CiliumClusterWideNetworkPolicy:** This CRD is best when applying rules that are agnostic of namespace or pod and need to be applied across the entire cluster. They make use of a node selector meaning that traffic flows can be controlled between different nodes in your cluster.

**Example**: Allow ingress from all pods to core-dns pods

```
apiVersion: cilium.io/v2
kind: CiliumClusterwideNetworkPolicy
metadata:
  name: core-dns-ingress
spec:
  endpointSelector:
    matchLabels:
      io.cilium.k8s.policy.serviceaccount: coredns
      k8s:io.kubernetes.pod.namespace: kube-system
  ingress:
  - fromEndpoints:
    - {}
    toPorts:
    - ports:
      - port: "53"
        protocol: UDP
```

- **CiliumNetworkPolicy:** This CRD is best when applying rules that need to take namespaces and pods into account. This can be used when enforcing multi-tenancy via namespace isolation for example via labels. Specific endpoints can also be selected.

**Example**: For endpoints whose env is prod, only allow incoming traffic (ingress) if the source also has label tenant1.

```
apiVersion: "cilium.io/v2"
kind: CiliumNetworkPolicy
metadata:
  name: "l3-rule"
specs:
  - description: "For endpoints with env=prod, allow if source also has label role=tenant1"
    endpointSelector:
      matchLabels:
        env: prod
    ingress:
    - fromEndpoints:
      - matchLabels:
          role: tenant1
```

## Creating a Cluster-Wide Network Policy Rules

Rules can be created by either uploading a YAML file with the CRD definition or by pulling the YAML file from Git.

- Login to the controller and select **Rules** under Network Policy
- Click the **Cluster** tab and click **New Rule**
- Provide a name for the rule, Click **Create**
- Provide a version name
- If uploading the file directly, click **choose file** and upload the file
- If using Git, select **Pull file from repository** and select the appropriate Git repository, revision number, and path to the YAML file in the git repo
- Click **Save changes**

Rules can be added to a cluster-wide policy by following the instructions in [cluster-wide policy](https://docs.rafay.co/network_policy/cluster_wide_policy/)

[![Create Network Policy Rule](https://docs.rafay.co/network_policy/img/network_policy_rule_creation.png)](https://docs.rafay.co/network_policy/img/network_policy_rule_creation.png)

## Updating a Cluster-Wide Network Policy Rules

- Login to the controller and select **Rules** under Network Policy
- Go the **Cluster** tab and find or search for the name of the rule you want to update
- Click the edit button to the right of the name of the rule and click **New version**
- Provide a version name
- If uploading the file directly, click **choose file** and upload the file
- If using Git, select **Pull file from repository** and select the appropriate Git repository, revision number, and path to the YAML file in the git repo
- Click **Save changes**

Rules can be added to a cluster-wide policy by following the instructions in [cluster-wide policy](https://docs.rafay.co/network_policy/cluster_wide_policy/)

[![Update Network Policy Rule](https://docs.rafay.co/network_policy/img/network_policy_rule_edit.png)](https://docs.rafay.co/network_policy/img/network_policy_rule_edit.png)

## Deleting a Cluster-Wide Network Policy Rules

- Login to the controller and select **Rules** under Network Policy
- Go the **Cluster** tab and find or search for the name of the rule you want to update
- Click the delete button to the right of the name of the rule

---
