---
title: "KOP Network Policy Manager - Cluster-Wide Policies"
source: https://docs.rafay.co/network_policy/cluster_wide_policy/
category: Home
---

# Cluster-Wide Network Policies

## Overview

> **Important**
> For any pods/workloads that existed pre deployment of Cilium/Network Policy Manager onto the cluster, those pods/workloads must be **RESTARTED** in order for policies to take effect. New pods/workloads do NOT need to be restarted.

> **Important**
> **Org Admin** or **Infra Admin** role is required to create and use cluster-wide network policies

A cluster-wide network policy is a bundle of network security rules that can be applied to one or more clusters via blueprints. They streamline the application of a standard default posture by allowing the admin to apply a single policy which applies to pods in all namespaces, regardless of the policies that exist in individual namespaces.

## Workflow

The typical workflow for using cluster-wide policies is the following:

**Step 1**: Create Cluster-Wide Policy Rules **Step 2**: Create Cluster-Wide Policies **Step 3**: Add the Cluster-Wide Policies To a Custom or Golden Blueprint

## Use Cases

As an admin, you would want to use cluster-wide policies for the following use cases:

- **Establish zero-trust defaults:** as an admin, you may want your pods and namespaces to have a default security posture, for example deny all internet traffic as they are created
- **Allowing requests to a baseline set of allowed destinations:** Rather than creating policies per namespace (for example to allow ingress from all pods to core-dns), create a cluster wide policy that can apply to all the pods/namespaces in the cluster
- **Reducing management overhead of network policies in high-scale environments:**: With cluster-wide policies being applied to blueprints, you can easily create one policy that can be applied to a fleet of clusters rather than having to create a policy per cluster

---

## Managing Cluster-Wide Policies

### Creating a Cluster-Wide Policy

In order to create a cluster-wide policy, you must add cluster-scoped network policy rules to it. Refer [here](https://docs.rafay.co/network_policy/cluster_wide_network_policy_rule/) for instructions to create Network Policy rules.

- Login to the controller and under **Network Policy** go to the Policies screen. Select the cluster tab and click **new policy**
- Give a name for the policy and click **Create**
- Provide a version name
- Click **Add Rules** and add your cluster-scoped rules with the corresponding version
- Click **Save Changes**

[![Create cluster-wide policy](https://docs.rafay.co/network_policy/img/cluster_wide_policy_workflow.png)](https://docs.rafay.co/network_policy/img/cluster_wide_policy_workflow.png)

Rules can be added to or removed from a policy using the same workflow. A new version needs to be created every time a policy is updated.

---

## Using Cluster-Wide Policies

Cluster-Wide Policies are applied to clusters via blueprints. These policies can be added to either custom blueprints or golden blueprints. See the [blueprint documentation](https://docs.rafay.co/blueprints/overview/) to learn how to create a custom or golden blueprint.

### Adding/Removing Cluster-Wide To/From Blueprints

- Under **Infrastructure**, navigate to **Blueprints.**
- Select a blueprint to update or create a new custom/golden blueprint.
- Navigate to the **Network Visibility and Policy** section and enable it
- Click **Add Policy** and add the cluster-wide policies with the corresponding version
- Delete a cluster-wide policy from the blueprint by simply clicking the delete icon next to the policy you want to delete.
- Click **Save Changes**

> **Important**
> When using a custom blueprint, if it inherits from a golden blueprint, then the cluster-wide policies specified in the golden blueprint cannot be overridden or deleted. This is to ensure that an admin can specify key sets of policies that are always on for compliance and security.

[![Update Blueprint with Cluster-Wide Policy](https://docs.rafay.co/network_policy/img/cluster_wide_policy_blueprint.png)](https://docs.rafay.co/network_policy/img/cluster_wide_policy_blueprint.png)

---
