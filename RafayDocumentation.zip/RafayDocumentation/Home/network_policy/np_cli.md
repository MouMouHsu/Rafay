---
title: "KOP Network Policy Manager - CLI"
source: https://docs.rafay.co/network_policy/np_cli/
category: Home
---

# Network Policy

RCTL support helps to automate the lifecycle of operations associated with **Network Policy Profiles, Rules and Policies**.

| Resource | Create | Get | Delete |
| --- | --- | --- | --- |
| Profiles | YES | YES | YES |
| Rules | YES | YES | YES |
| Policy | YES | YES | YES |

---

The declarative method allows the users to create **Network Policy Profiles, Rules, and Policies** on the required project and enables to develop automation for reproducible infrastructure

## Profiles

### Create Profile

Run the below command to create a Network Policy Profile using the spec yaml file

```
./rctl apply -f profile_filename.yaml
```

An illustrative example of the profile spec YAML file is shown below

```
apiVersion: security.k8smgmt.io/v3
kind: NetworkPolicyProfile
metadata:
  name: demo-profile
  project: defaultproject
spec:
  installationParams:
    policyEnforcementMode: default
  sharing:
    enabled: true
    projects:
    - name: project_1
    - name: project_2
  version: v1.0
```

### Get Profile

Use any of the below command to get the list of Network Policy Profiles of a specific project

| S. No | Command |
| --- | --- |
| 1 | `./rctl get networkpolicyprofile -p <project-name>` |
| 2 | `./rctl get npp -p <project-name>` |
| 3 | `./rctl get networkpolicyprofile` |
| 4 | `./rctl get npp` |

***Example Output***

```
./rctl get npp -p default-project
+----------------------+-------------------+
| PROFILE NAME         | VERSION NAME      |
+----------------------+-------------------+
| demo-profile         | v1                |
+----------------------+-------------------+
| profile-user1        | v2.0              |
+----------------------+-------------------+
| test-profile         | v2.1              |
+----------------------+-------------------+
```

To view the profiles of all the projects, use the below command

### Delete Profile

To delete a profile, use the below command

```
./rctl delete networkpolicyprofile <profile name>
```

(or)

```
./rctl delete npp <profile name>
```

---

## Network Policy in Blueprint

Once the Network Policy Profiles are created, users can deploy the Network Policy Visibility via blueprint spec yaml. This provides visibility into the traffic flows across your K8s infrastructure. Refer [Blueprint CLI](https://docs.rafay.co/blueprints/bp_cli/) for both the declarative and imperative RCTL commands.

An illustrative example of the blueprint spec YAML with Network Visibility is shown below.

```
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: demo-bp
  project: defaultproject
spec:
  base:
    name: default
    version: 1.17.0
  defaultAddons:
    csiSecretStoreConfig:
      providers: {}
    enableIngress: false
    enableLogging: false
    enableMonitoring: false
    enableVM: false
  drift:
    enabled: false
  networkPolicy:
    profile:
      name: demo-profile
      version: v1.1
  opaPolicy: {}
  placement: {}
  sharing:
    enabled: true
    projects:
    - name: project_1
    - name: project_2
  type: custom
  version: v1
```

To enforce one or more policies to the Network Profiles, users can add the below components to the blueprint yaml file once the rules and policies are created

```
policies:
- name: demo-policy-1
  version: v1.1
- name: demo-policy-2
  version: v2.1
```

---

## Cluster Network Policy Rule

### Create Cluster Network Policy Rule

Users can create a Cluster Network Policy Rule either through **upload file manually** or **Pull file from repository**

Run the below command to create a Cluster Network Policy Rule using the spec yaml file

```
./rctl apply -f cluster_network_rule.yaml
```

An illustrative example of the cluster Network Policy Rule spec YAML of **upload file manually** type is shown below. The highlighted parameter shows the yaml file path located in your system

```
apiVersion: security.k8smgmt.io/v3
kind: ClusterNetworkPolicyRule
metadata:
  name: demo-rule-upload
  project: defaultproject
spec:
  artifact:
    artifact:
      paths:
      - name: file://policy.yaml
    options: {}
    type: Yaml
  sharing:
    enabled: true
    projects:
    - name: project_1
    - name: project_2
  version: v1.0
```

An illustrative example of the cluster Network Policy Rule spec YAML of **Pull file from repository** type is shown below. The highlighted parameters show the repository details of the yaml file

```
apiVersion: security.k8smgmt.io/v3
kind: ClusterNetworkPolicyRule
metadata:
  name: demo-rule-repo
  project: defaultproject
spec:
  version: v1.0
  artifact:
    artifact:
      paths:
      - name: cilium-allow-all-from-frontend.yaml
      repository: demo-rule-repo
      revision: main
    options: {}
    type: Yaml
```

### Get Cluster Network Policy Rule

Use any of the below command to get the list of Cluster Network Policy Rules of a specific project

| S. No | Command |
| --- | --- |
| 1 | `./rctl get clusternetworkpolicyrule -p <project-name>` |
| 2 | `./rctl get cnpr -p <project-name>` |
| 3 | `./rctl get clusternetworkpolicyrule` |
| 4 | `./rctl get cnpr` |

***Example Output***

```
./rctl get clusternetworkpolicyrule -p default-project
+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+------------+
| RULE NAME                | VERSION NAME    | ARTIFACT TYPE | ARTIFACT FILES                                                                              | REPOSITORY |
+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+------------+
| cluster-wide-xwing-block | v2              | Yaml          | paths:{name:"file://artifacts/cluster-wide-xwing-block/standard_cilium_networkpolicy.yaml"} |            |
+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+------------+
| cluster-rule-upload-12      | 1.0             | Yaml          | paths:{name:"file://artifacts/example-rule-upload-12/policy.yaml"}                          |            |
+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+------------+
```

### Delete Cluster Network Policy Rule

To delete a cluster network policy rule, use the below command

```
./rctl delete clusternetworkpolicyrule <rule name>
```

(or)

```
./rctl delete cnpr <rule name>
```

---

## Namespace Network Policy Rule

### Create Namespace Network Policy Rule

Users can create a Namespace Network Policy Rule either through **upload file manually** or **Pull file from repository**

Run the below command to create a Namespace Network Policy Rule using the spec yaml file

```
./rctl apply -f namespace_network_rule.yaml
```

An illustrative example of the namespace Network Policy Rule spec YAML of **upload file manually** type is shown below. The highlighted parameter show the yaml file path located in your system

```
apiVersion: security.k8smgmt.io/v3
kind: NamespaceNetworkPolicyRule
metadata:
  name: demo-nsrule-upload
  project: defaultproject
spec:
  artifact:
    artifact:
      paths:
      - name: file://policy.yaml
    options: {}
    type: Yaml
  sharing:
    enabled: true
    projects:
    - name: project_1
    - name: project_2
  version: v1.0
```

An illustrative example of the namespace Network Policy Rule spec YAML of **Pull file from repository** type is shown below. The highlighted parameters shows the repository details of the yaml file

```
apiVersion: security.k8smgmt.io/v3
kind: NamespaceNetworkPolicyRule
metadata:
  name: demo-nsrule
  project: defaultproject
spec:
  version: v1.0
  artifact:
    artifact:
      paths:
      - name: cilium-allow-all-from-frontend.yaml
      repository: demo-nsrepo-rule
      revision: main
    options: {}
    type: Yaml
```

### Get Namespace Network Policy Rule

Use any of the below command to get the list of Namespace Network Policy Rules of a specific project

| S. No | Command |
| --- | --- |
| 1 | `./rctl get namespacenetworkpolicyrule -p <project-name>` |
| 2 | `./rctl get nnpr -p <project-name>` |
| 3 | `./rctl get namespacenetworkpolicyrule` |
| 4 | `./rctl get nnpr` |

***Example Output***

```
./rctl get namespacenetworkpolicyrule -p default-project
+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+------------+
| RULE NAME                | VERSION NAME    | ARTIFACT TYPE | ARTIFACT FILES                                                                              | REPOSITORY |
+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+------------+
| ns-cluster-wide-xwing | v2              | Yaml          | paths:{name:"file://artifacts/cluster-wide-xwing-block/standard_cilium_networkpolicy.yaml"} |            |
+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+------------+
| ns-demo-rule-upload      | 1.0             | Yaml          | paths:{name:"file://artifacts/example-rule-upload-12/policy.yaml"}                          |            |
+--------------------------+-----------------+---------------+---------------------------------------------------------------------------------------------+------------+
```

### Delete Namespace Network Policy Rule

To delete a namespace network policy rule, use the below command

```
./rctl delete namespacenetworkpolicyrule <rule name>
```

(or)

```
./rctl delete nnpr <rule name>
```

---

## Cluster Network Policy

### Create Cluster Network Policy

Run the below command to create a Cluster Network Policy using the spec yaml file

```
./rctl apply -f cluster_network_policy.yaml
```

An illustrative example of the cluster Network Policy spec YAML is shown below

```
apiVersion: security.k8smgmt.io/v3
kind: ClusterNetworkPolicy
metadata:
  name: demo-policy
  project: defaultproject
spec:
  rules:
  - name: test
    version: v1
  sharing:
    enabled: true
    projects:
    - name: project_1
    - name: project_2
  version: v1.0
```

### Get Cluster Network Policy

Use any of the below command to get the list of Cluster Network Policies of a specific project

| S. No | Command |
| --- | --- |
| 1 | `./rctl get clusternetworkpolicy -p <project-name>` |
| 2 | `./rctl get cnp -p <project-name>` |
| 3 | `./rctl get clusternetworkpolicy` |
| 4 | `./rctl get cnp` |

***Example Output***

```
./rctl get clusternetworkpolicy -p default-name
+-----------------------------------+--------------+-----------------------------------------+
| POLICY NAME                       | VERSION NAME | RULES(VERSION)                          |
+-----------------------------------+--------------+-----------------------------------------+
| cluster-xwing-block-policy        | v2           | cluster-wide-xwing-block(v2)            |
|                                   |              |                                         |
+-----------------------------------+--------------+-----------------------------------------+
| project-ns-policy           | v4           | project-ns-rule(v4)               |
|                                   |              |                                         |
+-----------------------------------+--------------+-----------------------------------------+
| policy-test                       | v1           | rule-upload-12(demo-version) |
|                                   |              |                                         |
+-----------------------------------+--------------+-----------------------------------------+
```

### Delete Cluster Network Policy

To delete a profile, use the below command

```
./rctl delete clusternetworkpolicy
```

(or)

```
./rctl delete cnp
```

---

## Namespace Network Policy

### Create Namespace Network Policy

Run the below command to create a Namespace Network Policy using the spec yaml file

```
./rctl apply -f namespace_network_policy.yaml
```

An illustrative example of the namespace Network Policy spec YAML is shown below

```
apiVersion: security.k8smgmt.io/v3
kind: NamespaceNetworkPolicy
metadata:
  name: demo-nspolicy
  project: defaultproject
spec:
  rules:
  - name: test
    version: v1
  sharing:
    enabled: true
    projects:
    - name: project_1
    - name: project_2
  version: v1.0
```

### Get Namespace Network Policy

Use any of the below command to get the list of Namespace Network Policies of a specific project

| S. No | Command |
| --- | --- |
| 1 | `./rctl get namespacenetworkpolicy -p <project-name>` |
| 2 | `./rctl get nnp -p <project-name>` |
| 3 | `./rctl get namespacenetworkpolicy` |
| 4 | `./rctl get nnp` |

***Example Output***

```
./rctl get namespacenetworkpolicy -p default-name
+-----------------------------------+--------------+-----------------------------------------+
| POLICY NAME                       | VERSION NAME | RULES(VERSION)                          |
+-----------------------------------+--------------+-----------------------------------------+
| ns-xwing-block-policy        | v2           | cluster-wide-xwing-block(v2)            |
|                                   |              |                                         |
+-----------------------------------+--------------+-----------------------------------------+
| ns-project-ns-policy           | v4           | project-ns-rule(v4)               |
|                                   |              |                                         |
+-----------------------------------+--------------+-----------------------------------------+
| ns-policy-test                       | v1           | demo-rule-upload-12(demo-version) |
|                                   |              |                                         |
+-----------------------------------+--------------+-----------------------------------------+
```

### Applying a Namespace Network Policy To a Namespace

A namespace network policy can be applied to a namespace during namespace creation.

#### Creating a namespace

Run the below command to create a Namespace Network Policy using the spec yaml file with a specified network policy. Note the policies section, which has the name and version of each policy you want to use.

```
./rctl create namespace -f <path-to-namespace-yaml>
```

```
apiVersion: config.rafay.dev/v2
kind: ManagedNamespace
metadata:
  name: demo-ns
  description: a demo namespace
spec:
  type: RafayWizard
  networkPolicyParams:
    networkPolicyEnabled: true
    policies:
    - name: demo-nspolicy
      version: v1
```

**NOTE**: The example below only shows a namespace created with a namespace policy and no other parameters.

Read [Namespace CLI Doc](https://docs.rafay.co/cli/namespaces/) to learn more about creating a namespace with more parameters and publishing the namespace to cluster(s).

### Delete Namespace Network Policy

To delete a namespace network policy, use the below command

```
./rctl delete namespacenetworkpolicy
```

(or)

```
./rctl delete nnp
```

---
