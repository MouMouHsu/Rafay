---
title: "KOP Network Policy Manager - Network Policy Rule Overview"
source: https://docs.rafay.co/network_policy/network_policy_rule_overview/
category: Home
---

# Overview

**Network policy Rules** is a construct that helps define traffic flow patterns that should be allowed or denied. Two types of network policy rules are supported:

- Cluster-Wide Network Policy rules
- Namespace Network Policy Rules

Network policy rules in a CRD YAML definition of either a CiliumClusterWideNetworkPolicy or a CiliumNetworkPolicy can either be uploaded directly to the console or pulled from a Git Repository. Use of CiliumClusterWideNetworkPolicy versus a CiliumNetworkPolicy is dependent on the security policies being enforced.

## General Considerations around Network Policy Rules

### Rule Enforcement

All policy rules are based upon a whitelist model, that is, each rule in the policy allows traffic that matches the rule. If two rules exist, and one would match a broader set of traffic, then all traffic matching the broader rule will be allowed. If there is an intersection between two or more rules, then traffic matching the union of those rules will be allowed. Finally, if traffic does not match any of the rules, it will be dropped pursuant to the Policy Enforcement Modes.

### Rule Precedence

If there is both ‘Deny’ and ‘Allow’ configured for a particular flow pattern, **‘Deny’** is enforced regardless of the type of network policy rule that is being configured.

---
