---
title: "KOP Network Policy Manager - Namespace Network Policy Rule"
source: https://docs.rafay.co/network_policy/namespace_network_policy_rule/
category: Home
---

# Namespace Network Policy rules

## Overview

Namespace Network Policy Rules is a construct that defines a grouping of network security rules that can then be applied to a [namespace policy](https://docs.rafay.co/network_policy/namespace_policy/).

### RBAC

Only **Org Admins**, **Project Admins** and **Workspace Admins** can create/manage namespace network policy rules.

## How To Write Namespace Network Policy Rules

- Examples can be found [here](https://docs.cilium.io/en/stable/security/policy/language/#policy-examples)
- [Cilium Network Policy Editor](https://editor.cilium.io/) can also be used to build network policy rules

For configuring namespace network policy rules, the **CiliumNetworkPolicy** CRD should be used.

Cilium supports configuring network policy rules based on labels, entities, IP/CIDR, DNS, Services, and more.

**Example**: Allow communication from endpoints with the label role=frontend to endpoints with the label role=backend.

```
apiVersion: "cilium.io/v2"
kind: CiliumNetworkPolicy
metadata:
  name: "l3-rule"
spec:
  endpointSelector:
    matchLabels:
      role: backend
  ingress:
  - fromEndpoints:
    - matchLabels:
        role: frontend
```

## Creating a Namespace Network Policy Rules

Rules can be created by either uploading a YAML file with the CRD definition or by pulling the YAML file from Git.

- Login to the controller and select **Rules** under Network Policy
- Click the **namespace** tab and click **New Rule**
- Provide a name for the rule. Click **Create**
- Provide a version name
- If uploading the file directly, click **choose file** and upload the file
- If using Git, select **Pull file from repository** and select the appropriate Git repository, revision number, and path to the YAML file in the git repo
- Click **save changes**

Rules can be added to a namespace policy by following the instructions in [namespace policy](https://docs.rafay.co/network_policy/namespace_policy/)

[![Create Network Policy Rule](https://docs.rafay.co/network_policy/img/network_policy_rule_creation.png)](https://docs.rafay.co/network_policy/img/network_policy_rule_creation.png)

## Updating a Namespace Network Policy Rules

Rules can be updated by either uploading a direct YAML file with the policy CRD definition and rules defined or by pulling the YAML file from Git.

- Login to the controller and select **Rules** under Network Policy
- Go the **namespace** tab and find or search for the name of the rule you want to update
- Click the edit button to the right of the name of the rule and click **new version**
- Provide a version name
- If uploading the file directly, click **choose file** and upload the file. You can click **edit** to make any changes to the YAML file directly in the console
- If using Git, select **Pull file from repository** and select the appropriate Git repository, revision number, and path to the YAML file in the git repo
- Click **save changes**

Rules can be added to a namespace policy by following the instructions in [namespace policy](https://docs.rafay.co/network_policy/namespace_policy/)

[![Update Network Policy Rule](https://docs.rafay.co/network_policy/img/network_policy_rule_edit.png)](https://docs.rafay.co/network_policy/img/network_policy_rule_edit.png)

## Deleting a Namespace Network Policy Rules

- Login to the controller and select **Rules** under Network Policy
- Go the **namespace** tab and find or search for the name of the rule you want to update
- Click the delete button to the right of the name of the rule

---
