---
title: "KOP Blueprints - Cluster Override (Managed components)"
source: https://docs.rafay.co/blueprints/overrides_managed_components/
category: Home
---

# Customization

## Management Operator and Managed Add-ons

In cases involving very large or highly active clusters, customization of the Management Operator and Managed Add-ons may be necessary to ensure optimal performance. Examples of these include:

- Clusters with more than 50 nodes
- Clusters with a lot of Kubernetes API server requests

This can be achieved through the use of cluster overrides.

> **Important**
> Overrides for the management operator and managed add-ons can be configured via RCTL CLI, Swagger API and TF provider. This facility is not available through UI.

For information around spec for Cluster add-on override, refer [here](https://docs.rafay.co/cli/overrides/)

To achieve this, refer to the below examples:

### Customizing Rafay connector

Within the cluster override add-on spec, specify the resource selector and override values as shown below.

```
resourceSelector: rafay.dev/system=true,rafay.dev/component=v2-infra
```

```
overrideValues: |
    connector:
      resources:
        requests:
          cpu: 100m
          memory: 128Mi
        limits:
          memory: 1024Mi
          cpu: 1000m
```

## Customizing Prometheus Adapter components

Within the cluster override add-on spec, specify the resource selector and override values as shown below.

```
resourceSelector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
```

```
overrideValues: |
  prometheusAdapter:
    image:
      repository: registry.rafay-edge.net/rafay/k8s-prometheus-adapter
      pullPolicy: IfNotPresent
      tag: v0.8.4-1
    resources:
      requests:
        memory: 128Mi
        cpu: 40m
      limits:
        memory: 10Gi
        cpu: 2000m
```

### Customizing Prometheus Helm Exporter

Within the cluster override add-on spec, specify the resource selector and override values as shown below.

```
resourceSelector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
```

```
overrideValues: |
  helmExporter:
    image:
      repository: registry.rafay-edge.net/rafay/helm-exporter
      pullPolicy: Always
      tag: 0.6.0-1
    resources:
      requests:
        memory: 128Mi
        cpu: 40m
      limits:
        memory: 512Mi
        cpu: 400m
```

### Customizing Prometheus Kube-state Metrics

Within the cluster override add-on spec, specify the resource selector and override values as shown below.

```
resourceSelector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
```

```
overrideValues: |
  kubeStateMetrics:
    image:
      repository: registry.rafay-edge.net/rafay/kube-state-metrics
      pullPolicy: IfNotPresent
      tag: v1.9.5
    resources:
      requests:
        memory: 256Mi
        cpu: 200m
      limits:
        memory: 10Gi
        cpu: 2000m
```

### Customizing Prometheus Node Exporter

Within the cluster override add-on spec, specify the resource selector and override values as shown below.

```
resourceSelector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
```

```
overrideValues: |
  nodeExporter:
    image:
      repository: registry.rafay-edge.net/rafay/prom-node-exporter
      pullPolicy: IfNotPresent
      tag: v1.0.1-2
      arm64Tag: arm64-v1.0.1-2
    resources:
      requests:
        memory: 128Mi
        cpu: 40m
      limits:
        memory: 512Mi
        cpu: 400m
```

### Customizing rook-ceph add-on

Within the cluster override add-on spec, specify the resource selector and override values as shown below.

```
resourceSelector: rafay.dev/system=true,rafay.dev/component=rook-ceph
```

```
overrideValues: |
    rook-ceph:
      csi:
        cephfsGrpcMetricsPort: "19091"
        rbdGrpcMetricsPort: "19090"
```

### Customizing OPA Gatekeeper Components

Within the cluster override OPA spec, specify the resource selector and override values as shown below.

```
resourceSelector: rafay.dev/component=opa-gatekeeper,rafay.dev/auxiliary=true
```

```
overrideValues: |
  replicas: 3
  revisionHistoryLimit: 10
  auditInterval: 60
  metricsBackends: ["prometheus"]
  auditMatchKindOnly: false
  constraintViolationsLimit: 20
  auditFromCache: false
  disableMutation: false
  disableValidatingWebhook: false
  postUpgrade:
    labelNamespace:
      enabled: false
  postInstall:
    labelNamespace:
      enabled: false
  psp:
    enabled: false
  controllerManager:
    resources:
      limits:
        memory: 512Mi
      requests:
        cpu: 100m
        memory: 512Mi
```

---
