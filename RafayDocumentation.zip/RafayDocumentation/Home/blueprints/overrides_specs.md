---
title: "KOP Blueprints - Cluster Overrides"
source: https://docs.rafay.co/blueprints/overrides_specs/
category: Home
---

# v3 Specifications (Recommended)

## Resource Override Specification Examples

This page provides resource override spec examples for commonly used system applications. These examples help customize CPU and memory allocations using `AddonOverride` configuration. Apply these overrides through the default blueprint to optimize application stability and performance in large-scale environments.

The examples cover the following applications:

- rafay-prometheus-adapter
- rafay-prometheus-helm-exporter
- rafay-prometheus-kube-state-metrics
- rafay-prometheus-metrics-server
- rafay-prometheus-node-exporter
- rafay-prometheus-server
- controller-manager-v3
- edge-client
- ingress-controller-v1-controller
- rafay-connector-v3
- velero
- opa-gatekeeper
- rook-ceph

## Add-On Override Examples

- Example 1: Add-on Override Using Version Regex

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  name: another-override
  project: defaultproject
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: manifestsFile
spec:
  placement:
    labels:
      - key: rafay.dev/clusterName
        value: logos-2
  resource:
    type: Addon
    selector:
      name: nginx-yaml
      versionRegex: "^v[6-8]$"
  type: Yaml
  valuesPath:
    name: file://nginx-yaml.yaml
```

This override applies only to add-on versions `v6`, `v7`, and `v8`. If `versionRegex` is not specified, the override applies to all versions of the add-on by default.

- Example 2: Resource Override for `rafay-prometheus-adapter`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  annotations:
    key1: value1
    key2: value2
    key3: value3
    document-link: "https://<demo-url>"
    key4: "demo-annotations"
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: prometheus-adapter-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
    type: Addon
  type: Helm
  valuesPath:
    name: file://prometheus-adapter-override-values.yaml
```

The values file (`prometheus-adapter-override-values.yaml`) for configuring resource allocations:

```
prometheusAdapter:
  image:
    repository: registry.rafay-edge.net/rafay/k8s-prometheus-adapter
    pullPolicy: IfNotPresent
    tag: v0.8.4-1
  resources:
    requests:
      memory: 128Mi
      cpu: 40m
    limits:
      memory: 10Gi
      cpu: 2000m
```

- Example 3: Resource Override for `rafay-prometheus-helm-exporter`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: prometheus-helm-exporter-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
    type: Addon
  type: Helm
  valuesPath:
    name: file://prometheus-helm-exporter-override-values.yaml
```

The values file (`prometheus-helm-exporter-override-values.yaml`) for configuring resource allocations:

```
helmExporter:
  image:
    repository: registry.rafay-edge.net/rafay/helm-exporter
    pullPolicy: IfNotPresent
    tag: v0.8.4-1
  resources:
    requests:
      memory: 128Mi
      cpu: 40m
    limits:
      memory: 10Gi
      cpu: 2000m
```

- Example 4: Resource Override for `rafay-prometheus-kube-state-metrics`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: prometheus-helm-exporter-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
    type: Addon
  type: Helm
  valuesPath:
    name: file://prometheus-helm-exporter-override-values.yaml
```

The values file (`prometheus-helm-exporter-override-values.yaml`) for configuring resource allocations:

```
kubeStateMetrics:
  image:
    repository: registry.rafay-edge.net/rafay/kube-state-metrics
    pullPolicy: IfNotPresent
    tag: v0.8.4-1
  resources:
    requests:
      memory: 128Mi
      cpu: 40m
    limits:
      memory: 10Gi
      cpu: 2000m
```

- Example 5: Resource Override for `rafay-prometheus-metrics-server`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: prom-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
    type: Addon
  type: Helm
  valuesPath:
    name: file://prom-override-values.yaml
```

The values file (`prom-override-values.yaml`) for configuring resource allocations:

```
metricsServer:
  image:
    repository: registry.rafay-edge.net/rafay/metrics-server
    pullPolicy: IfNotPresent
    tag: v0.6.0
  resources:
    requests:
      memory: 128Mi
      cpu: 100m
    limits:
      memory: 1024Mi
      cpu: 1000m
```

- Example 6: Resource Override for `rafay-prometheus-node-exporter`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: prometheus-node-exporter-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
    type: Addon
  type: Helm
  valuesPath:
    name: file://prometheus-node-exporter-override-values.yaml
```

The values file (`prometheus-node-exporter-override-values.yaml`) for configuring resource allocations:

```
nodeExporter:
  image:
    repository: registry.rafay-edge.net/rafay/prom-node-exporter
    pullPolicy: IfNotPresent
    tag: v1.0.1-2
    arm64Tag: arm64-v1.0.1-2
  resources:
    requests:
      memory: 128Mi
      cpu: 40m
    limits:
      memory: 512Mi
      cpu: 400m
```

- Example 7: Resource Override for `rafay-prometheus-server`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: prometheus-server-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
    type: Addon
  type: Helm
  valuesPath:
    name: file://prometheus-server-override-values.yaml
```

The values file (`prometheus-server-override-values.yaml`) for configuring resource allocations:

```
image:
  repository: registry.rafay-edge.net/rafay/prometheus
  pullPolicy: IfNotPresent
  # Overrides the image tag whose default is the chart appVersion.
  tag: v2.24.1-2
resources:
  requests:
    memory: 128Mi
    cpu: 100m
```

- Example 8: Resource Override for `controller-manager-v3`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: controller-manager-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=v2-infra
    type: Addon
  type: Helm
  valuesPath:
    name: file://controller-manager-override-values.yaml
```

The values file (`controller-manager-override-values.yaml`) for configuring resource allocations:

```
controller:
  resources:
    requests:
      cpu: 100m
      memory: 128Mi
    limits:
      memory: 1024Mi
      cpu: 1000m
```

- Example 9: Resource Override for `edge-client`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: edge-client-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=v2-edge-client
    type: Addon
  type: Helm
  valuesPath:
    name: file://edge-client-override-values.yaml
```

The values file (`edge-client-override-values.yaml`) for configuring resource allocations:

```
resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    memory: 1024Mi
    cpu: 1000m
```

- Example 10: Resource Override for `ingress-controller-v1-controller`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: ingress-controller-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=v2-ingress-infra
    type: Addon
  type: Helm
  valuesPath:
    name: file://ingress-controller-override-values.yaml
```

The values file (`ingress-controller-override-values.yaml`) for configuring resource allocations:

```
ingress-nginx-v1:
    fullnameOverride: ingress-controller-v1
    controller:
      kind: DaemonSet
      image:
        registry: registry.rafay-edge.net
        image: rafay/ingress-nginx-controller
        tag: "v1.1.1"
        digest: ""
      service:
        type: ClusterIP
        enableHttp: false
      podAnnotations:
        prometheus.io/port: "10254"
        prometheus.io/scrape: "true"
      updateStrategy:
        type: RollingUpdate
        rollingUpdate:
          maxUnavailable: 25%
      resources:
        requests:
          cpu: 200m
          memory: 180Mi
        limits:
          cpu: 1000m
          memory: 1024Mi
```

- Example 11: Resource Override for `rafay-connector-v3`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: connector-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=v2-infra
    type: Addon
  type: Helm
  valuesPath:
    name: file://connector-override-values.yaml
```

The values file (`connector-override-values.yaml`) for configuring resource allocations:

```
connector:
  resources:
    requests:
      cpu: 100m
      memory: 128Mi
    limits:
      memory: 1024Mi
      cpu: 1000m
```

- Example 12: Resource Override for `velero` (Data Agent)

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: velero-override-addon
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/placement=velero-5m1vwmy-km
    type: Addon
  type: Helm
  valuesPath:
    name: file://velero-override-addon-values.yaml
```

The values file (`velero-override-addon-values.yaml`) for configuring resource allocations:

```
resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    memory: 1024Mi
    cpu: 1000m
```

- Example 13: Resource Override for `OPA Gatekeeper`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: opa-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      name: opa-gatekeeper-3.14.0
      selector: rafay.dev/system=true,rafay.dev/global=true
    type: Addon
  type: Helm
  valuesPath:
    name: file://opa-override-values.yaml
```

The values file (`opa-override-values.yaml`) for configuring resource allocations:

```
psp:
  enabled: false
```

- Example 14: Resource Override for `rook-ceph`

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: rook-ceph-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=rook-ceph
    type: Addon
  type: Helm
  valuesPath:
    name: file://rook-ceph-override-values.yaml
```

The values file (`rook-ceph-override-values.yaml`) for configuring resource allocations:

```
rook-ceph:
  csi:
    cephfsGrpcMetricsPort: "19091"
    rbdGrpcMetricsPort: "19090"
```

---
