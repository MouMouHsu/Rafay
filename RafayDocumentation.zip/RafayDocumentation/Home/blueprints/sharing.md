---
title: "Sharing Cluster Blueprints"
source: https://docs.rafay.co/blueprints/sharing/
category: Home
---

# Sharing

By default, custom addons and cluster blueprints are NOT "Org Wide" resources. They are scoped to a specific Project where they are created to guarantee a "hard" isolation boundary. All clusters in a given project can use/leverage addons and blueprints in the Project.

Administrators can "share" both addons and blueprints with "select" or "all projects" in their Organization. Sharing enables organizations to implement "standardization and governance" across the enterprise. When addons and blueprints are shared, the downstream projects automatically inherit them.

---

## Share Addons

To share an addon with one or more projects,

- Click on the "share" icon next to the addon.
- Select the Projects you would like to share with

[![Sharing Addons](https://docs.rafay.co/blueprints/img/share/share_addons.png)](https://docs.rafay.co/blueprints/img/share/share_addons.png)

Once shared, admins can determine "which projects" an addon is shared with. For example, the kubeless addon in the "dev" project is shared with the "production" project.

[![Which Projects](https://docs.rafay.co/blueprints/img/share/shared_addon.png)](https://docs.rafay.co/blueprints/img/share/shared_addon.png)

Admins can also quickly determine which project an addon is "inherited" from. For example, the kubeless addon in the "production" project is inherited from the "dev" project

[![Inherited Addon](https://docs.rafay.co/blueprints/img/share/inherited_addon.png)](https://docs.rafay.co/blueprints/img/share/inherited_addon.png)

---

## Share Blueprints

To share a custom blueprint with one or more projects,

- Click on the "share" icon next to the blueprint.
- Select the Projects you would like to share with

[![Sharing Addons](https://docs.rafay.co/blueprints/img/share/select_project_share_bp.png)](https://docs.rafay.co/blueprints/img/share/select_project_share_bp.png)

Once shared, admins can determine "which projects" a blueprint is shared with. For example, the faas blueprint in the "dev" project is shared with the "production" project.

[![Which Projects](https://docs.rafay.co/blueprints/img/share/shared_bp.png)](https://docs.rafay.co/blueprints/img/share/shared_bp.png)

Admins can also quickly determine which project a blueprint is "inherited" from. For example, the faas blueprint in the "production" project is inherited from the "dev" project

[![Inherited Addon](https://docs.rafay.co/blueprints/img/share/inherited_bp.png)](https://docs.rafay.co/blueprints/img/share/inherited_bp.png)

---
