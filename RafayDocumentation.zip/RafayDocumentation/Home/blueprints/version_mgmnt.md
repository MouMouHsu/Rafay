---
title: "KOP Blueprints - Add-Ons Version Management"
source: https://docs.rafay.co/blueprints/version_mgmnt/
category: Home
---

# Draft Versions

## Draft Versioning for Blueprints and Add-ons

The platform now supports marking **Blueprint** and **Add-on versions** as **“Draft”**, enabling more flexible and controlled version management during development and testing.

### Key Benefits

- **Iterative Editing**: Platform teams can iteratively modify Draft versions during validation without creating multiple versions. Once finalized, the version can be marked **Active**. Previously, any change required a new version, leading to version sprawl.
- **Scoped Visibility**: Draft versions are project-scoped, they are only visible within the parent project and not shared downstream, ensuring only vetted, Active versions are exposed to other projects.
- **Immutability of Active Versions**: Once a version is marked **Active**, it becomes read-only. The **Edit** option is exclusive to **Draft** versions.

> ⚠️ Note: The Disable state is available only for Blueprints, not Add-ons.

### Version States and Behavior

| **State** | **Behavior** |
| --- | --- |
| `draft` | Editable, visible only in the parent project, not shared with child projects |
| `active` | Immutable; only Active versions are accessible when shared across projects |
| `disable` | Immutable; not usable for new use but does not affect existing clusters using the version |

---

## Validation Rules by Type and State

| **Type** | **State** | **Validation Rules** |
| --- | --- | --- |
| Custom Blueprint | Active | Cannot use Draft add-ons or Draft Golden BPs as base |
| Custom Blueprint | Draft | Can use Active or Draft add-ons; base Golden BP must be Active |
| Golden Blueprint | Active | Cannot reference Draft add-ons |
| Golden Blueprint | Draft | Can reference Active or Draft add-ons |

> ℹ️ Golden Blueprints are used when the Platform team defines a core set of add-ons that must be deployed across all clusters, while allowing downstream teams or projects to extend them by layering additional add-ons. However, because Draft versions are not shareable across projects, a Golden BP marked as Draft cannot be used as a base blueprint in Custom BPs.

---

## Version Management via UI

> Note: UI-based configuration of Draft versions will be available in the 3.7 release.

### Add-Ons Version Management

- On the **New Blueprint Version** page, after entering the required details, click **Save as Draft** to save the version as a draft, or **Save as Active** to save as an active version.

### Blueprint Version Management

- On the **New Blueprint Version** page, after entering the required details, click **Save as Draft** to save the version as a draft, or **Save as Active** to save as an active version.

[![Save Blueprint Version](https://docs.rafay.co/blueprints/img/save_blueprint_versions.png)](https://docs.rafay.co/blueprints/img/save_blueprint_versions.png)

For example, if the version is saved as a draft, its status will be displayed as **Draft**, as shown below.

[![Save Blueprint Version](https://docs.rafay.co/blueprints/img/bp_status.png)](https://docs.rafay.co/blueprints/img/bp_status.png)

---

## Version Management via RCTL

### Blueprint Spec with Version Parameters

Below is an example Blueprint spec where the version parameters are defined:

```
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: demo-bp
  project: default
spec:
  base:
    name: minimal
    version: 2.11.0
  customAddons:
  - name: demo-addon
    version: v1
  defaultAddons:
    csiSecretStoreConfig:
      providers: {}
    enableIngress: true
    enableLogging: true
    enableMonitoring: true
    enableVM: true
  drift:
    enabled: true
  sharing:
    enabled: false
  type: custom
  version: v2
  versionState: draft
```

### Add-On Spec with Version Parameters

Below is an example Add-On spec where the version parameters are defined:

```
apiVersion: infra.k8smgmt.io/v3
kind: Addon
metadata:
  name: demo-addon
  project: default
spec:
  artifact:
    artifact:
      paths:
      - name: file://demopath.yaml
    type: Yaml
  namespace: demo-ns
  sharing: {}
  version: v1
  versionState: draft
```

---
