---
title: "KOP Blueprints - Standard Default Blueprint"
source: https://docs.rafay.co/blueprints/standard_default_blueprint/
category: Home
---

# Standard Default Blueprint

## Standard Default Blueprint

The default blueprint in the system is the baseline for Amazon EKS Clusters and other cluster types not specific to AKS, GKE, Upstream Kubernetes, and Red Hat Openshift.

In order to streamline cluster deployments and installation of commonly used services, the platform has default blueprints in the system that can be leveraged by admins. There are two primary use cases for default system blueprints:.

### Use Cases

- **Standardize on Best Practices managed by the platform:** Streamline cluster deployments by using standard, best-practice templates already built-in to the platform rather than having to create custom blueprints. With this approach, there is less overhead in terms of having to update versions for managed add-ons
- **Use default blueprints as the baseline for your custom blueprints**: Rather than having to create completely custom blueprints and having to re-specify add-ons that are common, use a default blueprint as your base and then specify the other custom add-ons or services that you want to use

---

## Default Blueprint Configuration

### Managed Add Ons

The table below shows the Managed Add Ons that are enabled in the **default** blueprint

| Category | Add On |
| --- | --- |
| k8s Management Operator | YES |
| Managed Storage | NO |
| Local Storage | YES |
| Ingress Controller | YES |
| Log Aggregation (Deprecated) | NO |
| Monitoring & Alerting | YES |
| VM Operator | NO |
| Secrets Store CSI Driver | NO |

---

## View Default Standard Blueprint

As an Admin, login into the Web Console

- Select Project
- Select Infrastructure -> Blueprints
- Select the **Default Blueprints** tab

[![View Default Blueprint](https://docs.rafay.co/blueprints/img/default_bp/standard_default_blueprint_list.png)](https://docs.rafay.co/blueprints/img/default_bp/standard_default_blueprint_list.png)
