---
title: "KOP Blueprints - Pod Security Policy (PSP)"
source: https://docs.rafay.co/blueprints/psp/
category: Home
---

# Pod Security Policy (EOL)

> **Important**
> Pod Security Policy (PSP) is not supported post upgrade of K8s version to 1.25. Users must clean up all the PSP related components after an upgrade to K8s version 1.25 if required.

---

Security is critical for organizations of all sizes. The platform provides a number of security capabilities (both native and turnkey integrations with 3rd party products) that users can incorporate into their core architecture and design.

The platform provides support for the following as part of the core offering: secrets, certificates, registry pull secrets, RBAC, SSO integration etc. Pod Security Policies (PSP) is a key building block for k8s security as well.

---

## Overview

PSPs are cluster-wide resources that control security sensitive aspects of **pod specification**. PSP objects define a set of conditions that a pod must run with in order to be "allowed" into the cluster.

---

### PSP Capabilities

Pod Security Policies allow you to control:

- The running of privileged containers
- Usage of host namespaces
- Usage of host networking and ports
- Usage of volume types
- Usage of the host filesystem
- A white list of Flexvolume drivers
- The allocation of an FSGroup that owns the pod’s volumes
- Requirements for use of a read only root file system
- The user and group IDs of the container
- Escalations of root privileges
- Linux capabilities, SELinux context, AppArmor, seccomp, sysctl profile

Official [Kubernetes documentation](https://kubernetes.io/docs/concepts/policy/pod-security-policy/) on PSPs

> **Important**
> For capabilities beyond what PSPs support, users can use [OPA Gatekeeper](https://docs.rafay.co/recipes/governance/opa/) using the provided, curated recipe.

---

## View PSPs

Click the eye icon to view the details of each PSP

### General

[![Create PSP Wizard](https://docs.rafay.co/blueprints/img/psp/psp-general.png)](https://docs.rafay.co/blueprints/img/psp/psp-general.png)

### Host Namespaces

[![Create PSP Wizard](https://docs.rafay.co/blueprints/img/psp/psp_hostns.png)](https://docs.rafay.co/blueprints/img/psp/psp_hostns.png)

### Volumes and File Systems

[![Create PSP Wizard](https://docs.rafay.co/blueprints/img/psp/psp-volumes.png)](https://docs.rafay.co/blueprints/img/psp/psp-volumes.png)

### Users & Groups

[![Create PSP Wizard](https://docs.rafay.co/blueprints/img/psp/psp-users.png)](https://docs.rafay.co/blueprints/img/psp/psp-users.png)

### SE Linux and Capabilities

[![Create PSP Wizard](https://docs.rafay.co/blueprints/img/psp/psp_selinux-capabilities.png)](https://docs.rafay.co/blueprints/img/psp/psp_selinux-capabilities.png)

---
