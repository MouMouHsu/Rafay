---
title: "KOP Blueprints - Default GKE Blueprint"
source: https://docs.rafay.co/blueprints/default_gke/
category: Home
---

# Default GKE

The "default GKE blueprint" can be used as a baseline for GKE clusters provisioned and managed by the controller.

[![Default GKE Cluster Blueprint](https://docs.rafay.co/blueprints/img/default_gke/default_gke_list.png)](https://docs.rafay.co/blueprints/img/default_gke/default_gke_list.png)

> **Important**
> The default blueprints are version controlled. New versions are made available automatically when patches or upgrades are necessary.

---
