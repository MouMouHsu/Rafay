---
title: "KOP Blueprints - Default AKS"
source: https://docs.rafay.co/blueprints/default_aks/
category: Home
---

# Default AKS

## Default AKS Cluster Blueprint

The **default-aks** blueprint is the baseline for any AKS cluster and is version controlled.

In the example below, the AKS cluster is based on a default AKS blueprint. Note the following details:

- Name of Blueprint: **default-aks** in this example
- The version/timestamp of the default-aks blueprint
- Blueprint Sync Status

[![Default Cluster Blueprint](https://docs.rafay.co/blueprints/img/default_aks/default_aks_bp.png)](https://docs.rafay.co/blueprints/img/default_aks/default_aks_bp.png)

---

## Default AKS Blueprint Configuration

### Managed Add Ons

The table below shows the Managed Add Ons that are enabled in the **default-aks** blueprint

| Category | Add On |
| --- | --- |
| k8s Management Operator | YES |
| Managed Storage | NO |
| Local Storage | NO |
| Ingress Controller | NO |
| Log Aggregation (Deprecated) | NO |
| Monitoring & Alerting | NO |
| VM Operator | NO |
| Secrets Store CSI Driver | NO |

---

## View Default AKS Blueprint

As an Admin, login into the Web Console

- Select Project
- Select Infrastructure -> Blueprints
- Select the **Default Blueprints** tab

In the example below, the dashboard shows >50 versions of the default-aks blueprint over the entire lifecycle and one cluster in the Project based on the default-aks blueprint

[![View Default Blueprint](https://docs.rafay.co/blueprints/img/default_aks/aksbp_count.png)](https://docs.rafay.co/blueprints/img/default_aks/aksbp_count.png)

Clicking on the clusters link will display the status of the default-aks blueprint on the list of clusters. An illustrative example is shown below.

[![Clusters with Default Blueprint](https://docs.rafay.co/blueprints/img/default_aks/akscluster_bp.png)](https://docs.rafay.co/blueprints/img/default_aks/akscluster_bp.png)

## Using Visibility & Monitoring Add On With Azure AKS Blueprint

Azure has its own in-built Prometheus Adapter and Metrics servers, hence when deploying AKS clusters, the blueprints associated with these clusters should meet a few criteria

The creation of a blueprint with Base Blueprint **default-aks**, and enabling all the metrics of **Monitoring & Alerting** displays an error as below

[![AKS Monitoring & Visibility](https://docs.rafay.co/blueprints/img/default_aks/aks_monitoring.png)](https://docs.rafay.co/blueprints/img/default_aks/aks_monitoring.png)

[![AKS BP Error Message](https://docs.rafay.co/blueprints/img/default_aks/aks_bp_error.png)](https://docs.rafay.co/blueprints/img/default_aks/aks_bp_error.png)

To avoid this error, perform the below steps:

- Login to the controller and select **Blueprints** under **Infrastructure**
- Select **default-aks** from the Base Blueprint drop-down and provide the other required details
- Click the wrench icon of **Monitoring & Alerting** add-on and the **Customize Prometheus Addons** pane appears to the right
- Deselect the **Prometheus Adapter** and **Metrics Server** metrics and click **Save**

[![Disable Prometheus Metrics](https://docs.rafay.co/blueprints/img/default_aks/disable_metrics.png)](https://docs.rafay.co/blueprints/img/default_aks/disable_metrics.png)

> **Important**

Any customized blueprint selected for AKS cluster provisioning should have these options disabled to avoid this error

---
