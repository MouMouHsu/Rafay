---
title: "Organization-Level Blueprints and Drift Management"
source: https://docs.rafay.co/blueprints/settings/
category: Home
---

# Organization-Level Settings

Organization-level settings for Blueprints allow admins to control default behaviors and manage system-level automation applied to all Blueprints.

## Default Blueprint

Located at: **System → Settings → Default Blueprint**

- **Purpose**: Defines an organization-wide default blueprint that is automatically applied to clusters when no specific blueprint is assigned. Administrators can override this setting by explicitly assigning a different blueprint.
- **Benefit**: Ensures consistent baseline configurations across clusters, reducing manual effort in blueprint assignment.

[![Namespace sync](https://docs.rafay.co/blueprints/img/defaultbp_set.png)](https://docs.rafay.co/blueprints/img/defaultbp_set.png)

---

## Drift

Located at: **System → Settings → Drift**

- **Purpose**: Deploys a drift webhook through blueprints to clusters, enabling detection of configuration changes that deviate from the defined blueprint.
- **Benefit**: Provides visibility into cluster configuration drift, helping administrators identify and address discrepancies early.
- **Behavior**:
  - **ON** → Drift webhook is deployed, and clusters are monitored for drift against the blueprint.
  - **OFF** → Drift webhook is not deployed, and configuration drift is not detected or reported.

[![Namespace sync](https://docs.rafay.co/blueprints/img/drift_set.png)](https://docs.rafay.co/blueprints/img/drift_set.png)

---

## Artifact Retry Setting

Located at: **System → Settings → Artifact Retry Setting**

- **Purpose**: Defines the maximum number of retries performed while downloading Git or Helm artifacts whenever failures occur. This setting applies across the organization for addons associated with blueprints.
- **Max Retries**: Enter the number of retries (e.g., 5).
  - Addons in Pending, InProgress, or Retry state for more than 10 minutes in the last 24 hours are automatically reattempted.
  - Applies to both Git and Helm repositories.
  - Workload artifacts are skipped since publishing a workload creates a new version.
  - Addons in Failed state (when published via blueprints) are also reattempted.
- **Benefit**: Reduces manual intervention by automatically retrying artifact downloads when transient issues occur.

[![Namespace sync](https://docs.rafay.co/blueprints/img/retry_options.png)](https://docs.rafay.co/blueprints/img/retry_options.png)

---
