---
title: "KOP Blueprints - CLI"
source: https://docs.rafay.co/blueprints/bp_cli_v2/
category: Home
---

# Blueprints

> **This is a legacy version**
> For the latest Blueprint CLI information, see the [Blueprint CLI](https://docs.rafay.co/blueprints/bp_cli/) topic.

Users can use RCTL to automate the lifecycle of operations associated with cluster blueprints.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Blueprint | YES | YES | YES | YES |

---

## Create Blueprint

### Declarative

You can also create a blueprint in your project based on a version controlled blueprint spec that you can store in a Git repository. This enables users to develop automation for reproducible infrastructure.

```
./rctl create blueprint -f blueprint-spec.yml
```

An illustrative example of the blueprint spec YAML file is shown below

```
kind: Blueprint
metadata:
  # blueprint name
  name: custom-blueprint
  # Rafay project name
  project: defaultproject
```

An illustrative example of the blueprint version spec YAML file is shown below. To remove the cluster fleet(s) configuration, do not include the placement parameters (highlighted in yellow) in the YAML file

```
apiVersion: config.rafay.dev/v2
kind: Blueprint
metadata:
  name: demo-bp
  project: defaultproject
---
apiVersion: config.rafay.dev/v2
kind: BlueprintVersion
metadata:
  name: v1
  project: defaultproject
  description: Blueprint version v1
  annotations:
    "demo-annotation-key": "demo-annotation-value"
  labels:
    "key": "value"
spec:
  blueprint: demo-bp
  baseSystemBlueprint: minimal
  baseSystemBlueprintVersion: 3.6.0
  pspScope: cluster-scoped
  defaultAddons:
    enableIngress: true
    enableMonitoring: true
    enableLogging: true
  addons:
    - name: addon-01
      version: v1.0
    - name: simple-helm-addon
      version: v1.0
  placement:
    autoPublish: true
    fleetValues:
      - fleet-01
      - fleet-02
```

Use the below command to create a specific type blueprint

```
./rctl create blueprint bp_name --type custom
```

(or)

```
./rctl create blueprint bp_name --type golden
```

---

### Imperative

Users can use this to create a custom cluster blueprint assembled with a number of addons from the same project. You can also optionally disable the Managed Ingress Controller and the Log Aggregation addons in the default cluster blueprint if it is not required or will conflict with your preferred ingress controller.

```
./rctl create blueprint <blueprint-name>
```

Use the below command to create blueprint version(s)

```
./rctl create blueprint version <blueprint-name> <blueprint-version-name> <addon1-name>/<addon1-version-name> <addon2-name>/<addon2-version-name>
```

---

## Enable/Disable Blueprint Versions

- Use the below command to **enable** a specific blueprint version

```
./rctl set blueprintversion <bp-name> <version> enable
```

An illustrative example is shown below

```
./rctl set blueprintversion demo-blueprint v1.0 enable
Blueprint demo-blueprint version v1.0 is successfully enabled
```

- Enabling a blueprint version which is already enabled shows the output as below

```
./rctl set blueprintversion demo-blueprint v1.0 enable
Blueprint demo-blueprint version v1.0 is already enabled
```

- Use the below command to **disable** a specific blueprint version

```
./rctl set blueprintversion <bp-name> <version> disable
```

An illustrative example is shown below

```
./rctl set blueprintversion demo-blueprint v1.0 disable
Blueprint demo-blueprint version v1.0 is successfully disabled
```

- Disabling a blueprint version which is already disabled shows the output as below

```
./rctl set blueprintversion demo-blueprint v1.0 disable
Blueprint demo-blueprint version v1.0 is already disabled
```

---

## List Blueprints

You can retrieve/list the blueprints in the current project.

```
./rctl get blueprint
```

An illustrative example is shown below.

```
./rctl get blueprint
+-------------+----------+----------+--------------+---------------------------+--------------+------------------------------+-----------+
| NAME | VERSIONS | CLUSTERS | FLEET VALUES | LATEST PUBLISHED REVISION | AUTO PUBLISH | MODIFIED AT | OWNERSHIP |
+-------------+----------+----------+--------------+---------------------------+--------------+------------------------------+-----------+
| trial | 0 | 0 | | 0 | false | Wed Mar 9 13:31:04 UTC 2022 | self |
+-------------+----------+----------+--------------+---------------------------+--------------+------------------------------+-----------+
| bp1 | 1 | 0 | fleet-01 | 0 | false | Wed Mar 9 14:09:02 UTC 2022 | self |
+-------------+----------+----------+--------------+---------------------------+--------------+------------------------------+-----------+
| bp2 | 1 | 0 | fleet-02 | 0 | false | Wed Mar 9 14:11:19 UTC 2022 | self |
+-------------+----------+----------+--------------+---------------------------+--------------+------------------------------+-----------+
```

---

## Get The Specific Blueprint Info

Use this command to retrieve a specific blueprint's detailed information in the configured project.

```
./rctl get blueprint <blueprint-name>
```

Below is the illustrative example of the "standard-blueprint" blueprint information:

```
./rctl get blueprint demo-blueprint
OWNERSHIP:  self
DETAILS:    not shared
FLEET VALUES: fleet-1, fleet-2
LAST PUBLISHED JOB ID: 1
AUTO PUBLISH: DISABLED
+------------------------+--------------------------------+------------------------------+---------+
| BLUEPRINT VERSION NAME | COMPONENTS                     | CREATED AT                   | ENABLED |
+------------------------+--------------------------------+------------------------------+---------+
| v1.0                   | v1-edge-client,                | Tue Apr 19 13:21:36 UTC 2022 | true    |
|                        | v1-logging-infra,              |                              |         |
|                        | v2-alertmanager,               |                              |         |
|                        | v2-relay-agent,                |                              |         |
|                        | v2-infra, v2-ingress-infra,    |                              |         |
|                        | rafay-prometheus,              |                              |         |
|                        | aws-node-termination-handler   |                              |         |
+------------------------+--------------------------------+------------------------------+---------+
| v1.1                   | v1-edge-client,                | Tue Apr 19 13:22:42 UTC 2022 | false   |
|                        | v1-logging-infra,              |                              |         |
|                        | v2-alertmanager,               |                              |         |
|                        | v2-relay-agent,                |                              |         |
|                        | v2-infra, v2-ingress-infra,    |                              |         |
|                        | rafay-prometheus,              |                              |         |
|                        | aws-node-termination-handler   |                              |         |
+------------------------+--------------------------------+------------------------------+---------+
| v1.2                   | v1-edge-client,                | Tue Apr 19 13:56:58 UTC 2022 | true    |
|                        | v1-logging-infra,              |                              |         |
|                        | v2-alertmanager,               |                              |         |
|                        | v2-relay-agent,                |                              |         |
|                        | v2-infra, v2-ingress-infra,    |                              |         |
|                        | rafay-prometheus,              |                              |         |
|                        | aws-node-termination-handler   |                              |         |
+------------------------+--------------------------------+------------------------------+---------+
```

Or you can use the below commands to get more information of the blueprint in json or yaml format

```
./rctl get blueprint <blueprint-name> -o json
```

```
./rctl get blueprint <blueprint-name> -o yaml
```

---

## Publish Blueprint

Use the below command to publish the blueprints

```
./rctl publish blueprint <bp-name> v1
```

> **Important**
> If the **autoPublish** parameter is set to **true**, the new version is automatically published to the fleet(s). When the **autoPublish** parameter is set to **false**, the publish command is mandatory.

---

### autoPublish Blueprint

autoPublish is always enabled when a user create blueprint creates via v3 along with the fleet values

Below is an illustrative example of Blueprint v3 spec file

```
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: rctlv3-autopublish
  project: qa
spec:
  base:
    name: default
    version: 1.11.0
  customAddons:
  - name: demoaddon4
    version: v1.0
  - name: demoaddon5
    version: v1.0
  defaultAddons:
    enableIngress: true
    enableLogging: true
    enableMonitoring: true
    enableVM: false
    monitoring:
      helmExporter:
        discovery: {}
        enabled: true
      kubeStateMetrics:
        discovery: {}
        enabled: true
      metricsServer:
        enabled: true
      nodeExporter:
        discovery: {}
        enabled: true
      prometheusAdapter:
        enabled: true
      resources: {}
  drift:
    enabled: false
  placement:
    autoPublish: true
    fleetValues:
    - v3-fleet-rctlv3-a1-f
    - v3-fleet-rctlv3-a2-f
  sharing:
    enabled: false
  version: v5
```

---

## Delete Blueprint

Delete a cluster blueprint in the configured project. This is a destructive operation and will delete all versions of the blueprint.

```
./rctl delete blueprint <blueprint name>
```

> **Important**
> It is not possible to delete a blueprint that is actively being used on clusters.

---

## Blueprint Status

You can view the blueprints status in the current project.

```
./rctl status blueprint <bp-name>
```

An illustrative example of the output is shown below

```
./rctl status b demo-bp
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
| BLUEPRINT  | VERSION | FLEET VALUES          | JOB ID | ASSIGNED CLUSTERS       | READY CLUSTERS         | FAILED CLUSTERS          |
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
| demo-bp | voper  | test-qc-rctlwed1,       | 13   |                |                |                  |
|       |     | test-qc-rctlwed2        |    |                |                |                  |
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
| demo-bp | v12   | test-qc-rctlwed1,       | 12   | demoeks2-stage2, demoaks1  | demoaks1           |                  |
|       |     | test-qc-rctlwed2        |    |                |                |                  |
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
| demo-bp | v11   | test-qc-rctlwed1,       | 11   | demoaks1, demoeks2-stage2  | demoaks1           |                  |
|       |     | test-qc-rctlwed2        |    |                |                |                  |
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
```

To view the status of a job, use the below command with the job id

```
./rctl status blueprint <bp-name> <job-id>
```

***Example***

```
./rctl status b demo-b 1
+-------------+---------+--------------------------------+--------+--------------------------------+------------------+-----------------+
| BLUEPRINT  | VERSION | FLEET VALUES   | JOB ID | ASSIGNED CLUSTERS       | READY CLUSTERS  | FAILED CLUSTERS |
+-------------+---------+--------------------------------+--------+--------------------------------+------------------+-----------------+
| demo-b     | v2   | test-qc-rctlwed1,   | 1   | demoeks2-stage2, demoaks1,  | demoeks1-stage1 |         |
|            |      | test-qc-rctlwed2    |     | demoeks1-stage1             |                 |         |
+-------------+---------+--------------------------------+--------+--------------------------------+------------------+-----------------+
```

---
