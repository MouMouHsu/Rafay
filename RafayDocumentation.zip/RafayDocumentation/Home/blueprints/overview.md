---
title: "Cluster Blueprints - Kubernetes Fleet Management as a Service"
source: https://docs.rafay.co/blueprints/overview/
category: Home
---

# Cluster Blueprints

Centralized management and deployment of Kubernetes add-ons and configurations across your entire fleet. Simplify lifecycle management, ensure compliance, and accelerate deployments with standardized blueprints.

#### Add-On Management

Centralized Lifecycle Management

Centralized management of Kubernetes YAML and Helm charts for cluster add-ons across fleets.

#### Managed Add-Ons

Pre-packaged Solutions

Pre-packaged, fully managed add-ons curated by Rafay with automated security patches and updates.

#### Custom Add-Ons

Enterprise Integration

Ability to integrate organization-specific add-ons to meet unique enterprise requirements.

#### Cluster Overrides

Fine-tuned Configuration

Override configuration values at the cluster level for environment-specific customization.

#### Version Control

Reproducible Deployments

Track, pin, and roll back to specific versions of add-ons and blueprints for quick recovery and reproducibility.

#### Integrated Troubleshooting

Real-time Visibility

Real-time health and error visibility for add-ons and blueprint deployments for faster resolution.

#### Sharing

Cross-team Standardization

Share blueprints across multiple projects within Rafay to promote standardization and reuse.

#### Golden Blueprints

Compliance & Security

Approved, compliance-checked blueprints designated as "golden" for organization-wide enforcement.

#### Add-On Criticality

Essential Component Protection

Mark add-ons as critical to cluster health to prevent accidental removal or modification.

#### Fleet Workflows

Large-scale Governance

Integration with a fleet workflows for consistent deployment across large-scale environments.

#### Minimal Blueprint

Lightweight Deployment

Lightweight blueprint for bare-bones cluster setup, ideal for rapid prototyping.

#### Staged Rollouts

Progressive Deployments

Maintain multiple versions of a blueprint for testing and versioned deployments.

#### Drift Detection

Compliance Assurance

Detect and Block on configuration drift from the blueprint definition to ensure consistency.

#### Installation Sequencing

Predictable Outcomes

Ensures that components are initialized in the correct sequence, preventing race conditions or startup failures.

#### Dependency Management

Prerequisites

Define and enforce dependencies between add-ons to ensure that prerequisites are met before deployment.

[← Back](https://docs.rafay.co/services/overview/)
