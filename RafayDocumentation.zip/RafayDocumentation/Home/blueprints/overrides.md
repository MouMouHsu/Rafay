---
title: "KOP Blueprints - Cluster Overrides"
source: https://docs.rafay.co/blueprints/overrides/
category: Home
---

# Overview

By default, K8s objects require certain values be set inside their specs that match the cluster's configuration. If this were to done within the add-on (or workload) manifest, it would require that many duplicate add-ons (or workloads) would need to be created for a fleet of clusters. To mitigate this, the platform supports cluster overrides. These allow the customer to use a single add-on (or workload) org wide and override the values when add-ons (or workloads) are deployed to the clusters.

Platform resources such as add-ons and workloads utilize labels which are added by the platform or by the end user. These labels can be used as selectors for both the resource they will be applied as well as the clusters where the cluster override will be applied.

> **Important**
> You can manage the lifecycle of cluster overrides using the Web Console or RCTL CLI or REST APIs. It is strongly recommended to automate this by integrating RCTL with your existing CI system based automation pipeline.

---

[Cluster Overrides using the CLI](https://docs.rafay.co/cli/overrides/)

[Cluster Overrides for Workloads](https://docs.rafay.co/workloads/overrides/)

---
