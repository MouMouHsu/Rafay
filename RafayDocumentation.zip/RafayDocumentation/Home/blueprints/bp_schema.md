---
title: "Blueprint Schema"
source: https://docs.rafay.co/blueprints/bp_schema/
category: Home
---

# Blueprint Schema

Blueprint configuration
