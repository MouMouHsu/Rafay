---
title: "KOP Resource Override Approach"
source: https://docs.rafay.co/blueprints/override_workaround/
category: Home
---

# Resource Allocation

## Steps to Configure Overrides

To apply custom resource allocations for system applications like the `rafay-connector`, follow the steps below:

### Step 1: Create an Override Using `rctl`

```
./rctl create cluster-override -f <override.yamlfile>
```

**Example of v3 override yaml file (Recommended)**

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: connector-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=v2-infra
    type: Addon
  type: Helm
  valuesPath:
    name: file://connector_override_values.yaml
```

File named `connector_override_values.yaml` with the following content to specify the resource requests and limits:

```
connector:
  resources:
    requests:
      cpu: 100m
      memory: 128Mi
    limits:
      memory: 1024Mi
      cpu: 1000m
```

- `resourceSelector` must remain unchanged, as it targets values in `v2-infra` for override
- `clusterSelector` can include any label key-value pair, for example: `venus=flytrap`

**Example of v2 override yaml file (Deprecated)**

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: connector-override
spec:
  clusterSelector: venus=flytrap
  resourceSelector: rafay.dev/system=true,rafay.dev/component=v2-infra
  type: ClusterOverrideTypeAddon
  overrideValues: |
    connector:
      resources:
        requests:
          cpu: 100m
          memory: 128Mi
        limits:
          memory: 1024Mi
          cpu: 1000m
  clusterPlacement:
    placementType: ClusterSelector
    clusterSelector: venus=flytrap
    driftAction: DriftReconcillationActionNotSet
    clusterLabels: []
```

### Step 2: **Republish the blueprint**

- The `v2-infra` add-on should succeed and apply the updated resource values.

> Note: It is not necessary to provide all the overrideValues parameters.

For a list of resource override specifications for other system applications, refer to the [Override Examples](https://docs.rafay.co/blueprints/overrides_specs/).

---
