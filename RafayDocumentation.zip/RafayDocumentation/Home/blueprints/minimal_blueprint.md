---
title: "Minimal Cluster Blueprint"
source: https://docs.rafay.co/blueprints/minimal_blueprint/
category: Home
---

# Minimal Blueprint

The minimal blueprint is the cluster blueprint selected by "default" for both provisioned and imported cluster types. With the minimal blueprint, all the optional addons are disabled by default. Customers can use the minimal blueprint as the base blueprint and select the supported addons as required.

> **Important**

Both **arm64** and **amd64** based architecture are supported with the **minimal** blueprint

---

## Minimal Blueprint Configuration

### Drift Detection

Drift Detection is not enabled as part of the minimal blueprint. To use this functionality, [custom blueprints](https://docs.rafay.co/blueprints/custom_blueprint/) must be used.

### Managed System Add-ons

With the minimal blueprint, all managed system add-ons are disabled except the **K8s Management Operator**.

### Services

All services such as network policy and cost management are disabled with the minimal blueprint. To use this functionality, [custom blueprints](https://docs.rafay.co/blueprints/custom_blueprint/) must be used.

---

## Kubernetes Operator Components

The following pods are deployed into the "rafay-system" namespace on managed clusters as part and are considered the components of the "Kubernetes Management Operator". These are the only resources deployed as part of the **Minimal Cluster Blueprint**.

| Name | Role & Responsibility |
| --- | --- |
| controller-manager | crd controller for taskset related crds |
| edge-client | Handles cluster health checks |
| rafay-connector | Runs drift detection webhook, project crd controller, namespace sync handlers etc. This is the primary point of presence in the cluster for centralized management |
| relay-agent | Provide zero trust kube api connectivity from controller |

---

## Impact to Dashboards

The majority of the widgets in the dashboards are powered by the Monitoring addons. Since this addon is not available with the minimal blueprint, many of these widgets will be disabled. Basic cluster level resource metrics are still captured and presented on the cluster card. The lack of an integrated monitoring and alerting stack means that users have to resort to an alternate stack for equivalent functionality or use the zero trust kubectl access (ztka) channel for visibility etc.

[![Cluster Card](https://docs.rafay.co/blueprints/img/minimal/cluster_minimalbp.png)](https://docs.rafay.co/blueprints/img/minimal/cluster_minimalbp.png)

---
