---
title: "Addon Node Affinity Specifications"
source: https://docs.rafay.co/blueprints/node_affinity_spec/
category: Home
---

# Node Affinity Specifications

This page provides node affinity configuration specifications for supported system addons. These configurations are used in the values file referenced by an `AddonOverride` when overriding node affinity for blueprint-managed addons.

Refer to the [Override Node Affinity for Addons](https://docs.rafay.co/blueprints/node_affinity/) page for details on configuring the override and applying it to clusters.

---

## `v2-infra` (V3 Spec)

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: v2-infra-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=v2-infra
    type: Addon
  type: Helm
  valuesPath:
    name: file://v2-infra-override-values.yaml
```

***Values file (v2-infra-override-values.yaml):***

```
controller:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: kubernetes.io/os
                operator: In
                values:
                  - linux
              - key: kubernetes.io/arch
                operator: In
                values:
                  - amd64
                  - arm64
connector:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: kubernetes.io/os
                operator: In
                values:
                  - linux
              - key: kubernetes.io/arch
                operator: In
                values:
                  - amd64
                  - arm64
relay:
  affinity:
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
              - matchExpressions:
                  - key: kubernetes.io/os
                    operator: In
                    values:
                      - linux
                  - key: kubernetes.io/arch
                    operator: In
                    values:
                      - amd64
                      - arm64
```

---

## `v2-edge-client` (V3 Spec)

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: edge-client-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=v2-edge-client
    type: Addon
  type: Helm
  valuesPath:
    name: file://edge-client-override-values.yaml
```

***Values file(edge-client-override-values.yaml)***

```
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/os
              operator: In
              values:
                - linux
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - arm64
```

---

## `v2-alertmanager` (V3 Spec)

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: v2-alertmanager-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=v2-alertmanager
    type: Addon
  type: Helm
  valuesPath:
    name: file://v2-alertmanager-override-values.yaml
```

***Values file(v2-alertmanager-override-values.yaml)***

```
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/os
              operator: In
              values:
                - linux
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - arm64
```

---

## `rafay-prometheus` (V3 Spec)

To override node affinity for node exporter pods based on arm64 systems, the node affinity must be explicitly specified as shown in the values file below.

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: rafay-prometheus-override
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: cluster-1
  resource:
    selector:
      selector: rafay.dev/system=true,rafay.dev/component=rafay-prometheus
    type: Addon
  type: Helm
  valuesPath:
    name: file://rafay-prometheus-override-values.yaml
```

***Values file(rafay-prometheus-override-values.yaml)***

```
#Override node affinity for prometheus server
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/os
              operator: In
              values:
                - linux
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - arm64
#Override node affinity for prometheus adapter
prometheusAdapter:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: kubernetes.io/os
                operator: In
                values:
                  - linux
              - key: kubernetes.io/arch
                operator: In
                values:
                  - amd64
                  - arm64
#Override node affinity for prometheus metrics server
metricsServer:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: kubernetes.io/os
                operator: In
                values:
                  - linux
              - key: kubernetes.io/arch
                operator: In
                values:
                  - amd64
                  - arm64
#Override node affinity for prometheus kube state metrics
kubeStateMetrics:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: kubernetes.io/os
                operator: In
                values:
                  - linux
              - key: kubernetes.io/arch
                operator: In
                values:
                  - amd64
                  - arm64
#Override node affinity for prometheus node exporter
nodeExporter:
  #for amd based systems
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: kubernetes.io/os
                operator: In
                values:
                  - linux
              - key: kubernetes.io/arch
                operator: In
                values:
                  - amd64
              - key: eks.amazonaws.com/compute-type
                operator: NotIn
                values:
                  - fargate
  #for arm based systems
  arm64Affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: kubernetes.io/os
                operator: In
                values:
                  - linux
              - key: kubernetes.io/arch
                operator: In
                values:
                  - arm64
              - key: eks.amazonaws.com/compute-type
                operator: NotIn
                values:
                  - fargate
#Override node affinity for prometheus helm exporter
helmExporter:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: kubernetes.io/os
                operator: In
                values:
                  - linux
              - key: kubernetes.io/arch
                operator: In
                values:
                  - amd64
                  - arm64
```

---
