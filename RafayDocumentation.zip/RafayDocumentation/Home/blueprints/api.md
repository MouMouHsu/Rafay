---
title: "KOP Providers - API"
source: https://docs.rafay.co/blueprints/api/
category: Home
---

# API

Users can **enable or disable** a blueprint version using the **REST APIs**, and **force sync** blueprint add-ons on a cluster using the scheduler API.

Replace `<console-url>` with the URL of your Rafay Console.

## Enable Blueprint Version

- Login to the console and click **API DOCS** from the Home page

[![API DOCS](https://docs.rafay.co/blueprints/img/api/linkto-api.png)](https://docs.rafay.co/blueprints/img/api/linkto-api.png)

Platform API screen appears

- Under Blueprint, use the below **POST** REST API to enable the required blueprint version
- Enter the **project_id**, **blueprint_id**, and **version_name**
- Click **Execute** to complete the enabling process

[![API DOCS](https://docs.rafay.co/blueprints/img/api/enable-api.png)](https://docs.rafay.co/blueprints/img/api/enable-api.png)

---

## Disable Blueprint Version

- Under Blueprint, use the below **POST** REST API to disable the required blueprint version
- Enter the **project_id**, **blueprint_id**, and **version_name**
- Click **Execute** to complete the disabling process

[![API DOCS](https://docs.rafay.co/blueprints/img/api/disable_api.png)](https://docs.rafay.co/blueprints/img/api/disable_api.png)

---

## Force Sync Blueprint Add-ons on a Cluster

Publishes a blueprint version to a cluster and force syncs its add-ons. List the add-ons to force sync, or omit the list to force sync all of them.

### Endpoint

```
POST https://<console-url>/v2/scheduler/project/{project-id}/cluster/{cluster-name}/publish/blueprint
```

### Path Parameters

| Parameter | Description |
| --- | --- |
| `project-id` | ID of the project the cluster is in |
| `cluster-name` | Name of the cluster |

### Request Body

```
{
  "metadata": {
    "forceSync": true
  },
  "blueprintName": "{blueprint-name}",
  "blueprintVersion": "{blueprint-version}",
  "addons": ["{addon-name1}", "{addon-name2}"]
}
```

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `metadata.forceSync` | boolean | Yes | Set to `true` to force sync add-ons |
| `blueprintName` | string | Yes | Name of the blueprint applied to the cluster |
| `blueprintVersion` | string | Yes | Version of the blueprint |
| `addons` | string[] | No | Add-ons to force sync. If omitted or empty, all add-ons are force synced |

### Examples

**Force sync specific add-ons**

```
curl -X POST \
  --url 'https://<console-url>/v2/scheduler/project/{project-id}/cluster/{cluster-name}/publish/blueprint' \
  -H 'Content-Type: application/json' \
  -H 'X-API-KEY: {api-key}' \
  --data-raw '{
    "metadata": { "forceSync": true },
    "blueprintName": "{blueprint-name}",
    "blueprintVersion": "{blueprint-version}",
    "addons": ["{addon-name1}", "{addon-name2}"]
  }'
```

**Force sync all add-ons**

```
curl -X POST \
  --url 'https://<console-url>/v2/scheduler/project/{project-id}/cluster/{cluster-name}/publish/blueprint' \
  -H 'Content-Type: application/json' \
  -H 'X-API-KEY: {api-key}' \
  --data-raw '{
    "metadata": { "forceSync": true },
    "blueprintName": "{blueprint-name}",
    "blueprintVersion": "{blueprint-version}"
  }'
```

---
