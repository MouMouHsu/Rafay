---
title: "KOP Blueprints - Default CNI Blueprints for Upstream"
source: https://docs.rafay.co/blueprints/default_cni/
category: Home
---

# Default CNI Blueprints

Default CNI blueprints are provided for popular CNI providers to simplify and speed up the process of deploying MKS clusters. These predefined blueprints are designed for direct usage, enabling users to quickly provision clusters with their selected CNI. However, these system default blueprints cannot be customized.

## Default CNI Blueprints for Deploying MKS Clusters

Users can deploy MKS clusters using the following system default CNI blueprints:

- **default-upstream-calico**
- **default-upstream-cilium**
- **default-upstream-kubeovn**
- **default-upstream-kubeovn-chaining**

[![Default Cluster Blueprint](https://docs.rafay.co/blueprints/img/default_upstream/default_cni.png)](https://docs.rafay.co/blueprints/img/default_upstream/default_cni.png)

> ⚠️ Note: These default CNI blueprints are only applicable for MKS clusters

## Default Custom CNI BP Versions

| Name | Version |
| --- | --- |
| default-upstream-calico | v3.29.0 |
| default-upstream-cilium | v1.16.4 |
| default-upstream-kubeovn | v1.13.0 |
| default-upstream-kubeovn-chaining | kubeovn-v1.13.0, cilium-v1.16.4 |

For users requiring custom configurations are recommended to create their own addons with tailored settings and using a custom blueprint instead, as discussed [here](https://docs.rafay.co/clusters/upstream/cni_provider/).

---
