---
title: "KOP Blueprints - Default Openshift"
source: https://docs.rafay.co/blueprints/default_openshift/
category: Home
---

# Default Openshift

## Default Openshift Cluster Blueprint

The **default-openshift** blueprint is the baseline for any Openshift cluster to deploy on multi-cloud AWS or Azure, and is version controlled.

In the example below, the openshift cluster is based on a default openshift blueprint. Note the following details

- Name of Blueprint: **default-openshift** in this example
- The version/timestamp of the default-openshift blueprint
- Blueprint Sync Status

[![Default Cluster Blueprint](https://docs.rafay.co/blueprints/img/openshift_bp/ops_bp_cluster.png)](https://docs.rafay.co/blueprints/img/openshift_bp/ops_bp_cluster.png)

---

## Available Addons

The table below shows the addons that are enabled in the **default-openshift** blueprint

| Category | Addon |
| --- | --- |
| k8s Management Operator | YES |
| Monitoring & Alerting | NO |
| Log Aggregation | NO |
| Ingress Controller | NO |
| Instance Interruption | NO |
| Network Policy | NO |

---

## View Default Openshift Blueprints

As an Admin, login into the Web Console

- Select Project
- Select Infrastructure -> Blueprints
- Select the "Default Blueprints" tab

In the example below, the dashboard shows >50 versions of the default-openshift blueprint over the entire lifecycle and one cluster in the Project based on the default-openshift blueprint

[![View Default Blueprint](https://docs.rafay.co/blueprints/img/openshift_bp/openshift_list.png)](https://docs.rafay.co/blueprints/img/openshift_bp/openshift_list.png)

Clicking on the clusters link will display the status of the default-openshift blueprint on the list of clusters. An illustrative example is shown below.

[![Clusters with Default Blueprint](https://docs.rafay.co/blueprints/img/openshift_bp/openshift_clusters.png)](https://docs.rafay.co/blueprints/img/openshift_bp/openshift_clusters.png)

---
