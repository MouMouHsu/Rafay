---
title: "KOP Blueprints - Default Upstream"
source: https://docs.rafay.co/blueprints/default_upstream/
category: Home
---

# Default Upstream

The **default-upstream** blueprint can be used as the "baseline cluster blueprint" for Upstream Kubernetes clusters provisioning and managed by the controller in bare metal and VM based environments.

In the example below, the upstream cluster is based on a default upstream blueprint. Note the following details

- Cluster Blueprint: **default-upstream**
- The version/timestamp of the default-upstream blueprint
- Blueprint Sync Status

[![Default Cluster Blueprint](https://docs.rafay.co/blueprints/img/default_upstream/bp_upstream.png)](https://docs.rafay.co/blueprints/img/default_upstream/bp_upstream.png)

---

## Available Addons

The table below shows the addons that are enabled in the **default-upstream** blueprint

| Category | Addon |
| --- | --- |
| k8s Management Operator | YES |
| Managed Storage | YES |
| Monitoring & Alerting | NO |
| Log Aggregation | NO |
| Ingress Controller | NO |
| VM Operator | NO |

---

## View Default Upstream Blueprints

As an Admin, login into the Web Console

- Select Project
- Select Infrastructure -> Blueprints
- Select the "Default Blueprints" tab

In the example below, the dashboard shows 15 versions of the default-upstream blueprint over the entire lifecycle and two clusters in the Project based on the default-upstream blueprint

[![View Default Blueprint](https://docs.rafay.co/blueprints/img/default_upstream/view_upstreambp.png)](https://docs.rafay.co/blueprints/img/default_upstream/view_upstreambp.png)

Clicking on the clusters link will display the status of the default-upstream blueprint on the list of clusters. An illustrative example is shown below.

[![Clusters with Default Blueprint](https://docs.rafay.co/blueprints/img/default_upstream/upstreambp_clusters.png)](https://docs.rafay.co/blueprints/img/default_upstream/upstreambp_clusters.png)

---
