---
title: "Blueprint CLI"
source: https://docs.rafay.co/blueprints/bp_cli_services/
category: Home
---

# Blueprint CLI

Users can use RCTL to automate the lifecycle of operations associated with cluster blueprints.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Blueprint | YES | YES | YES | YES |

---

## Create/Update Blueprint

Use the below command to create/update a blueprint in your project based on a version controlled blueprint spec that you can store in a Git repository. This enables users to develop automation for reproducible infrastructure.

```
./rctl apply -f blueprint-spec.yml
```

A simple illustrative example of the blueprint spec YAML file is shown below. This example will create a blank blueprint named `custom-blueprint` and place it in the default project. You can change the `name` and `project` to suit your needs.

```
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  # blueprint name
  name: custom-blueprint
  # Rafay project name
  project: defaultproject
```

Another illustrative example of the blueprint version spec YAML file is shown below. This example contains all resources that are available to configure as part of the blueprint spec. Remove any unneeded resources. For example, to remove the cluster fleet(s) configuration, do not include the placement parameters (highlighted below) in the YAML file.

```
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: test-blueprint-allenabled
  project: rctlproject
  labels:
    env: dev
  annotations:
    "pre-change-check-url": "https://<console-url>/login"
    "demo-annotation": "sample-value"
spec:
  base:
    name: default
    version: 1.23.0
  costProfile:
    enabled: true
    name: default-cost-profile-aws
    version: latest
  defaultAddons:
    csiSecretStoreConfig:
      providers:
        aws: true
    enableIngress: true
    enableMonitoring: true
    enableRookCeph: true
  drift:
    action: Notify
    enabled: true
  namespaceConfig:
    enableSync: true
    syncType: Managed
  networkPolicy:
    enabled: true
    policies:
    - name: policy1
      version: v1
    profile:
      name: default
      version: latest
  opaPolicy:
    opaPolicy:
    - name: test-opapolicy
      version: v1
    profile:
      name: default
      version: latest
  placement:
    autoPublish: true
    fleetValues:
    - fleet1
    - fleet2
  sharing:
    enabled: true
    projects:
    -  name: demoproject  
  type: custom
  version: v1
```

### Disable AWS Node Termination Handler (Amazon EKS only)

For **Amazon EKS clusters** that use the **Default Blueprint**, the **AWS Node Termination Handler** add-on is enabled by default.

When creating or updating a blueprint using `rctl`, the add-on can be disabled by explicitly setting the following field under `defaultAddons`:

```
defaultAddons:
  disableAwsNodeTerminationHandler: true
```

When this field is set to `true`, the AWS Node Termination Handler is not installed on the target EKS clusters. If the field is not specified or is set to `false`, the add-on remains enabled by default.

This configuration applies only to Default Blueprints for EKS clusters.

> **Info**
> - Change the "type" parameter to **golden** to create a Golden Blueprint
> - See the [Blueprint Schema](https://docs.rafay.co/blueprints/bp_schema/) for more details around blueprint resources

---

## Enable/Disable Blueprint Versions

- Use the below command to **enable** a specific blueprint version

```
./rctl set blueprintversion <bp-name> <version> enable
```

An illustrative example is shown below

```
./rctl set blueprintversion demo-blueprint v1.0 enable
Blueprint demo-blueprint version v1.0 is successfully enabled
```

- Enabling a blueprint version which is already enabled shows the output as below

```
./rctl set blueprintversion demo-blueprint v1.0 enable
Blueprint demo-blueprint version v1.0 is already enabled
```

- Use the below command to **disable** a specific blueprint version

```
./rctl set blueprintversion <bp-name> <version> disable
```

An illustrative example is shown below

```
./rctl set blueprintversion demo-blueprint v1.0 disable
Blueprint demo-blueprint version v1.0 is successfully disabled
```

- Disabling a blueprint version which is already disabled shows the output as below

```
./rctl set blueprintversion demo-blueprint v1.0 disable
Blueprint demo-blueprint version v1.0 is already disabled
```

---

## List Blueprints

You can retrieve/list the blueprints in the current project.

```
./rctl get blueprint --v3
```

An illustrative example is shown below.

```
./rctl get blueprint --v3
+------------------------------------------+------------------------+----------------------------------------------+---------------------------------------+--------+--------+
| BLUEPRINT NAME                           | BLUEPRINT VERSION NAME | DEFAULT COMPONENTS                           | CUSTOM COMPONENTS                     | FLEETS | TYPE   |
+------------------------------------------+------------------------+----------------------------------------------+---------------------------------------+--------+--------+
| new-acr-bp                               | v3                     | enableIngress:true                           | acr-new-addon-helm3,                  |        | custom |
|                                          |                        | enableLogging:true                           |                                       |        |        |
|                                          |                        | enableMonitoring:true                        |                                       |        |        |
+------------------------------------------+------------------------+----------------------------------------------+---------------------------------------+--------+--------+
| new-rctl-blueprint-postfix               | v6                     | enableLogging:true                           | new-rctl-addon-helmrepo-postfix,      |        | custom |
|                                          |                        |                                              |                                       |        |        |
+------------------------------------------+------------------------+----------------------------------------------+---------------------------------------+--------+--------+
| old-rctl-bp-postfix                      | gh                     | enableLogging:true                           |                                       |        | custom |
|                                          |                        | csiSecretStoreConfig:{syncSecrets:true       |                                       |        |        |
|                                          |                        | enableSecretRotation:true                    |                                       |        |        |
|                                          |                        | providers:{aws:true}}                        |                                       |        |        |
+------------------------------------------+------------------------+----------------------------------------------+---------------------------------------+--------+--------+
```

> Note: When a custom blueprint is created with the base blueprint set as Golden BP, the addons of the Golden BP are not displayed in the output. Only the addons specific to the custom blueprint are shown.

---

## Get Specific Blueprint Info

Use this command to retrieve a specific blueprint's detailed information.

```
./rctl get blueprint <blueprint-name> --v3
```

Below is the illustrative example of the "standard-blueprint" blueprint information:

```
./rctl get blueprint new-acr-bp --v3
+----------------+------------------------+--------------------------------+-----------------------+--------+--------+
| BLUEPRINT NAME | BLUEPRINT VERSION NAME | DEFAULT COMPONENTS             | CUSTOM COMPONENTS     | FLEETS | TYPE   |
+----------------+------------------------+--------------------------------+-----------------------+--------+--------+
| new-acr-bp     | v3                     | enableIngress:true             | acr-new-addon-helm3,  |        | custom |
|                |                        | enableLogging:true             |                       |        |        |
|                |                        | enableMonitoring:true          |                       |        |        |
+----------------+------------------------+--------------------------------+-----------------------+--------+--------+
```

Or you can use the below commands to get more information of the blueprint in json or yaml format

```
./rctl get blueprint <blueprint-name> -o json --v3
```

```
./rctl get blueprint <blueprint-name> -o yaml --v3
```

***Example:***

```
./rctl get blueprint new-acr-bp -o yaml --v3
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: new-acr-bp
  project: prod-test
spec:
  base:
    name: default
    version: snapshot - 2021-12-11T06:24:32Z
  customAddons:
  - name: acr-new-addon-helm3
    version: v1
  defaultAddons:
    enableIngress: true
    enableLogging: true
    enableMonitoring: true
  type: custom
  version: v3
```

### Dependency

To specify that an addon depends on another when creating a Blueprint from RCTL, use the following custom addon parameters:

```
customAddons:
- name: parentaddon
  version: v1
- name: childaddon
  version: v1
  dependsOn:
  - parentaddon
```

---

## Fleet configuration

Users can manage a group of clusters as a single fleet and simultaneously apply custom blueprint(s) to one or more fleet(s).

Below is an illustrative example. If the **autoPublish** parameter is set to **true**, the new version is automatically published to the fleet(s). If the **autoPublish** parameter is set to **false**, the publish command is mandatory.

```
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: rctlv3-autopublish
  project: qa
spec:
  base:
    name: default
    version: 1.11.0
  customAddons:
  - name: demoaddon4
    version: v1.0
  - name: demoaddon5
    version: v1.0
  defaultAddons:
    enableIngress: true
    enableLogging: true
    enableMonitoring: true
    enableVM: false
    monitoring:
      helmExporter:
        discovery: {}
        enabled: true
      kubeStateMetrics:
        discovery: {}
        enabled: true
      metricsServer:
        enabled: true
      nodeExporter:
        discovery: {}
        enabled: true
      prometheusAdapter:
        enabled: true
      resources: {}
  drift:
    enabled: false
  placement:
    autoPublish: true
    fleetValues:
    - v3-fleet-rctlv3-a1-f
    - v3-fleet-rctlv3-a2-f
  sharing:
    enabled: false
  version: v5
```

### Blueprint Status

You can view the blueprint's status when fleet is configured using the command below.

```
./rctl status blueprint <bp-name>
```

An illustrative example of the output is shown below

```
./rctl status blueprint demo-bp
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
| BLUEPRINT  | VERSION | FLEET VALUES          | JOB ID | ASSIGNED CLUSTERS       | READY CLUSTERS         | FAILED CLUSTERS          |
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
| demo-bp | voper  | test-qc-rctlwed1,       | 13   |                |                |                  |
|       |     | test-qc-rctlwed2        |    |                |                |                  |
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
| demo-bp | v12   | test-qc-rctlwed1,       | 12   | demoeks2-stage2, demoaks1  | demoaks1           |                  |
|       |     | test-qc-rctlwed2        |    |                |                |                  |
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
| demo-bp | v11   | test-qc-rctlwed1,       | 11   | demoaks1, demoeks2-stage2  | demoaks1           |                  |
|       |     | test-qc-rctlwed2        |    |                |                |                  |
+-------------+---------+--------------------------------+--------+--------------------------------+--------------------------------+-----------------------------------+
```

To view the status of a job, use the below command with the job id

```
./rctl status blueprint <bp-name> <job-id>
```

***Example***

```
./rctl status blueprint demo-b 1
+-------------+---------+--------------------------------+--------+--------------------------------+------------------+-----------------+
| BLUEPRINT  | VERSION | FLEET VALUES   | JOB ID | ASSIGNED CLUSTERS       | READY CLUSTERS  | FAILED CLUSTERS |
+-------------+---------+--------------------------------+--------+--------------------------------+------------------+-----------------+
| demo-b     | v2   | test-qc-rctlwed1,   | 1   | demoeks2-stage2, demoaks1,  | demoeks1-stage1 |         |
|            |      | test-qc-rctlwed2    |     | demoeks1-stage1             |                 |         |
+-------------+---------+--------------------------------+--------+--------------------------------+------------------+-----------------+
```

---

## Critical Add-ons in Blueprint

Use the following configuration specification to create a blueprint with the critical add-ons ***addon-helm*** and ***demo-addon***.

```
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: testing-critical
  project: default
spec:
  base:
    name: minimal
    version: 2.7.0
  defaultAddons:
    csiSecretStoreConfig:
      providers: {}
    enableIngress: true
    enableLogging: false
    enableMonitoring: false
    enableVM: false
  drift:
    enabled: false
  customAddons:
  - name: addon-helm
    version: v2
  - name: demo-addon
    version: v1
  componentsCriticality:
  - name: demo-addon
  - name: addon-helm
  sharing:
    enabled: false
  type: custom
  version: v1
```

For more information on **Critical Add-ons**, refer to [this page](https://docs.rafay.co/blueprints/addons_criticality/)

---

## Delete Blueprint

Delete a cluster blueprint in the configured project. This is a destructive operation and will delete all versions of the blueprint.

```
./rctl delete blueprint -f <bp-name> --v3
```

> **Important**
> It is not possible to delete a blueprint that is actively being used on clusters.

---

## Templating

Users can also create multiple blueprints with a set of defined configurations. The template file contains a list of objects that helps to create multiple blueprint(s) from a single source template.

Below is an example of a blueprint config template

```
# Generated: {{now.UTC.Format "2006-01-02T15:04:05UTC"}}
#      With: {{command_line}}
{{ $envName := environment "PWD" | basename}}
{{ $glbCtx := . }}{{ range $i, $project := .ProjectNames }}
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: bluebird
  project: {{$envName}}-{{$project}}
spec:
  base:
    name: default
    version: {{$glbCtx.BaseVersion}}
  customAddons:
  - name: logstash
    version: {{$glbCtx.AddonLogStashVersion}}
  defaultAddons:
    csiSecretStoreConfig:
      providers: {}
    enableIngress: {{$glbCtx.SystemAddonEgress}}
    enableLogging: false
    enableMonitoring: {{$glbCtx.SystemAddonMonitoring}}
    enableVM: false
  drift:
    enabled: {{$glbCtx.Drift}}
  networkPolicy: {}
  placement: {}
  sharing:
    enabled: false
  version: {{$glbCtx.Version}}

---

apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: kingfish
  project: {{$envName}}-{{$project}}
spec:
  base:
    name: default
    version: {{$glbCtx.BaseVersion}}
  customAddons:
  - name: apache
    version: {{$glbCtx.AddonApacheVersion}}
  defaultAddons:
    csiSecretStoreConfig:
      providers: {}
    enableIngress: false
    enableLogging: false
    enableMonitoring: false
    enableVM: false
  drift:
    enabled: false
  networkPolicy: {}
  opaPolicy: {}
  placement: {}
  sharing:
    enabled: false
  version: {{$glbCtx.Version}}
---
{{end}}
```

Users can create one or more blueprint(s) with the required configuration defined in the template file. Below is an example of a blueprint value file. This file helps to create blueprint with the specified objects

```
BaseVersion: 1.16.0
AddonLogStashVersion: v1.0
AddonApacheVersion: v1.0
SystemAddonEgress: false
SystemAddonMonitoring: false
Drift: false
Version: v1.0
```

> **Important**
> Only the objects defined in the template must be present in the value files

Use the command below to create blueprint(s) with the specified configuration once the value file(s) are prepared with the necessary objects

```
 ./rctl apply -t blueprint.tmpl --values values.yaml
```

Change these values:

- ***blueprint.tmpl***: The name of the template file.
- ***value.yaml***: The name of the value file.

Refer [Templating](https://docs.rafay.co/cli/templating_overview/) for more details on Templating flags and examples

---
