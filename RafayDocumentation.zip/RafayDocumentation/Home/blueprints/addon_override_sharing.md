---
title: "Share Cluster Overrides"
source: https://docs.rafay.co/blueprints/addon_override_sharing/
category: Home
---

# Sharing Overrides

The Cluster Override sharing enhancement has been implemented to support a model similar to other Rafay objects, whereby only **Organization Administrators** will have the ability to share cluster overrides across projects within their organization, ensuring better control and governance.

Cluster overrides are now project-scoped to ensure consistent governance by maintaining project-specific controls. When cluster overrides are shared, the downstream projects will have access to the shared configurations, which get applied during BP sync based on the cluster and resource selection.

> **Did you know ?**
> Cluster Addon Override Sharing can be managed through various methods:
>
> - [UI](https://docs.rafay.co/blueprints/addon_override_sharing/#share-cluster-addon-overrides)
> - [CLI](https://docs.rafay.co/cli/overrides/)
> - [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/cluster_override)
> - [GitOps](https://docs.rafay.co/gitops/stages/system_sync/)

---

## Share Cluster Addon Overrides

To share a cluster addon override with one or more projects,

- Navigate to the Project
- Click on **Cluster Overrides** under Infrastructure. Cluster Override page appears
- Click on the "share" icon next to the override.
- Select the Projects you would like to share with

[![New Override](https://docs.rafay.co/blueprints/img/overrides/share_icon.png)](https://docs.rafay.co/blueprints/img/overrides/share_icon.png)

Once shared, Org Admins can determine "which projects" an addon override is shared with. For example, the demo-yamloverride override in the "defaultproject" project is shared with four (4) projects.

[![Which Projects](https://docs.rafay.co/blueprints/img/overrides/share_list.png)](https://docs.rafay.co/blueprints/img/overrides/share_list.png)

Org Admins can also quickly determine which project an addon override is "inherited" from. For example, the demo-yamloverride is inherited from the "defaultproject" project

[![Inherited Addon](https://docs.rafay.co/blueprints/img/overrides/inherited_overrides.png)](https://docs.rafay.co/blueprints/img/overrides/inherited_overrides.png)

> **Important**
> - Once an override is shared from a parent project, it cannot be deleted from the parent project until it is unshared with all the projects
> - Cluster Override Sharing activities can be tracked on the [Audit Log page](https://docs.rafay.co/security/audit/)
> - When a cluster override is created or updated via a Git sync operation, it is created under the Git pipeline owner's role. Override sharing (assigning or unassigning projects) is applied only if the pipeline owner's role has permission to assign and unassign projects.

---
