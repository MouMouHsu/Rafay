---
title: "KOP Backstage - Entity Cards"
source: https://docs.rafay.co/backstage/entity_cards/
category: Home
---

# Entity Cards

Entity Cards are the UI components that can be imported from the Rafay Backstage plugin. These components can be used in Backstage Entity views to embed the logic from the plugin. These can be used out-of-the-box or customized as needed.

Using the plugin entity cards can provide useful and visual information for developers who have access to the Backstage console but do not have access to the Rafay console or the cluster providers' consoles (EKS, AKS, and GKE).

Some examples of what can be shown or enabled:

- Ability to download the Zero Trust Kubectl (as shown below)
- Show only specific resources based on a label (example: user namespace vs system namespace)
- Show specific types of health metrics

[![Rafay Backstage Entity Cards](https://docs.rafay.co/backstage/img/entity_cards_backstage_demo.png)](https://docs.rafay.co/backstage/img/entity_cards_backstage_demo.png)
