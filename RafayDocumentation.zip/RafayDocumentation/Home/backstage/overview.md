---
title: "KOP Backstage - Overview"
source: https://docs.rafay.co/backstage/overview/
category: Home
---

# Overview

> **Important**
> Rafay Backstage Plugin is available in the [Marketplace](https://backstage.io/plugins/).

[Backstage](https://backstage.io/) is an open platform, developed by Spotify, for building internal developer portals and enabling developer self-service. Developer portals help centralize all of the tooling, software components, data, and documentation for your developer users.

An internal developer portal (IDP) can reduce operational bottlenecks associated with provisioning environments and deploying apps. An IDP allows platform engineering teams to enforce best practices and control the parameters that are exposed for provisioning environments and deploying apps.

Some key features of Backstage include:

- An easy-to-use interface for developers
- Extensible plugin ecosystem (including GitHub Actions, ArgoCD, and AWS)
- Ability to easily build and publish tech documentation
- Native Kubernetes plugin for cloud-native apps
- Ability to compose different developer workflows

There is a [Backstage recipe](https://docs.rafay.co/recipes/developer-self-service/backstage/) that provides instructions for creating a Backstage add-on via Rafay.

---

## Backstage Plugin

The Rafay Backstage Plugin enables a self-service model where developers can provision the infrastructure stack that they need to test/debug their applications:

**Environment as a Service**

Platform teams can configure the required infrastructure resources as templates and expose those in an interface for developers. Developers can configure input parameters (exposed through the templates) and provision the full infrastructure stack needed for their applications with a single click.

**Cluster as a Service**

Platform teams can configure templates for clusters and expose them in an interface for developers. Developers can configure input parameters (exposed through the templates) and provision clusters with a single click.

**Namespace as a Service**

Platform teams can configure the appropriate resource quotas and can enable developers to create namespaces as needed for their applicationss.

---

## Workflow Diagram

[![Workflow](https://docs.rafay.co/backstage/img/backstage_diagram.png)](https://docs.rafay.co/backstage/img/backstage_diagram.png)

- Platform teams configure the necessary governance templates in the Rafay Org.
- Platform teams will configure the Backstage code to use the templates and the API token pointing to the Rafay Org.
- Platform teams expose the workflow in Backstage to the developers.
- Developers can deploy a cluster or namespace, depending on what is exposed by the platform team.
- Developers access entity cards to download the zero trust kubeconfig file (ZTKA) to use for application provisioning.
- Platform teams continue to make refinements and update template versions to use in Backstage.

---

## Backstage Key Terms

### Catalog

In Backstage, the catalog is the system that keeps track of ownership and metadata for all the software in your ecosystem. The catalog has all the resources (such as clusters, namespaces, and pipelines), templates (workflows), and locations (repos and geo locations) that can be leveraged by development teams.

### Templates

Templates are forms or cards that can be used to abstract complexities away from the developer and have them execute self-service workflows. For example, there can be a template for creating an EKS Cluster or an environment that includes an EKS Cluster, RDS instance and ElastiCache.

> **Note**
> The Rafay Backstage Plugin repository will include the environment as a service, cluster as a service, namespace as a service, and other example templates that platform teams can extend or modify, as needed.

### Entity Cards

After a resource is created, like a cluster, developers may want to operate within a cluster, provision workloads, and download the kubeconfig file. This is done using an entity card.
