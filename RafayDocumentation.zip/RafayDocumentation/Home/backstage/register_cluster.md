---
title: "KOP Backstage - Register Existing Cluster"
source: https://docs.rafay.co/backstage/register_cluster/
category: Home
---

# Register Existing

The following is an example for registering an existing cluster to a Backstage environment.

1. Log in to Backstage.
2. Click **Create**.
3. For **Register Existing Cluster**, click **Choose**.
4. Type a name and description for the cluster.  [![Register Existing Cluster Component Details](https://docs.rafay.co/backstage/img/backstage_cluster_exist1.png)](https://docs.rafay.co/backstage/img/backstage_cluster_exist1.png)
5. Click **Next Step**.
6. Type the project ID and cluster ID to register the cluster to.  [![Register Existing Cluster Cluster Details](https://docs.rafay.co/backstage/img/backstage_cluster_exist2.png)](https://docs.rafay.co/backstage/img/backstage_cluster_exist2.png)
7. Click **Next Step**.
8. Type the name of the owner and type the name for the repository.  [![Register Existing Cluster Choose Location](https://docs.rafay.co/backstage/img/backstage_cluster_exist3.png)](https://docs.rafay.co/backstage/img/backstage_cluster_exist3.png)
9. Click **Next Step**. Review the configuration for the resource.
10. Click **Create**.
11. After the cluster registration process is initiated, click **Open in catalog**. This takes you to the cluster entity card. Some cluster details will display after the cluster has been registered, like being able to download the kubeconfig file.

---
