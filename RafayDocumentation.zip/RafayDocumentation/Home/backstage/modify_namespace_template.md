---
title: "KOP Backstage - Namespace Template - Modify"
source: https://docs.rafay.co/backstage/modify_namespace_template/
category: Home
---

# Edit Template

Modify the sample namespace template to create a new namespace template that suit the needs of the organization and developers.

1. In Backstage, click **Create**.
2. Click the actions icon (upper-right), then select **Template Editor**.
3. Click **Edit Template Form**.
4. Click the Load Existing Template field, then select the **Create Namespace** template.
5. In the text editor, modify the settings for creating a namespace.
6. In the preview pane, test your modifications. For example, type a name and description for the namespace template. If the template has multiple steps, click **Next Step**.

---

## Example Namespace Template

```
parameters:
  - title: Component Details
    required:
      - name
      - description
    properties:
      name:
        title: Name
        type: string
        description: Unique name of the component
        ui:field: EntityNamePicker
        ui:autofocus: true
      description:
        title: Description
        type: string
        description: A description for the component
      owner:
        title: Owner
        type: string
        description: Owner of the component
        ui:field: OwnerPicker
        ui:options:
          allowedKinds:
            - Group
      project:
        title: Project
        type: string
        description: The project to be used
        default: 12345abcde
        enum:
          - 12345abcde
          - fghij67890
        enumNames:
          - demos
          - defaultproject
      clusters:
        title: Clusters
        type: array
        items:
          type: string
        description: Select the clusters where you wish to deploy your namespace
      labels:
        title: Cluster Labels
        type: array
        items:
          type: object
          properties:
            key:
              type: string
            value:
              type: string
        description: Select the cluster labels where you wish to deploy your namespace
  - title: Choose a location
    required:
      - repoUrl
    properties:
      repoUrl:
        title: Repository Location
        type: string
        ui:field: RepoUrlPicker
        ui:options:
          allowedHosts:
            - github.com
steps:
  - id: create-namespace
    name: Create Namespace
    action: rafay:create-namespace
    input:
      project: ${{ parameters.project }}
      name: ${{ parameters.name }}
      clusters: ${{ parameters.clusters }}
      labels: ${{ parameters.labels }}
  - id: fetch
    name: Template Skeleton
    action: fetch:template
    input:
      url: ./skeleton
      values:
        name: ${{ parameters.name }}
        description: ${{ parameters.description }}
        destination: ${{ parameters.repoUrl | parseRepoUrl }}
        owner: ${{ parameters.owner }}
        project: ${{ parameters.project }}
        clusters: ${{ parameters.clusters }}
  - id: publish
    name: Publish
    action: publish:github
    input:
      allowedHosts:
        - github.com
      description: This is ${{ parameters.name }}
      repoUrl: ${{ parameters.repoUrl }}
  - id: register
    name: Register
    action: catalog:register
    input:
      repoContentsUrl: ${{ steps.publish.output.repoContentsUrl }}
      catalogInfoPath: /catalog-info.yaml
output:
  links:
    - title: Repository
      url: ${{ steps.publish.output.remoteUrl }}
    - title: Open in catalog
      icon: catalog
      entityRef: ${{ steps.register.output.entityRef }}
```

---
