---
title: "KOP Backstage - Create an Environment"
source: https://docs.rafay.co/backstage/create_backstage_environment/
category: Home
---

# Create

The following is an example for creating an environment from a template using backstage_environment_entity_card.

1. Log in to Backstage
2. Click **Create**
3. For **Create environment**, click **Choose**
4. Type a name and description for the environment
5. Type the Project, environment template name and template version to use for creating the environment  [![Create Environment](https://docs.rafay.co/backstage/img/backstage_environment.png)](https://docs.rafay.co/backstage/img/backstage_environment.png)
6. Specify the input variables for the environment  [![Input variables](https://docs.rafay.co/backstage/img/backstage_input_variables.png)](https://docs.rafay.co/backstage/img/backstage_input_variables.png)
7. Type the name of the owner and type the name for the repository  [![Environment Owner](https://docs.rafay.co/backstage/img/backstage_environment_owner.png)](https://docs.rafay.co/backstage/img/backstage_environment_owner.png)
8. Click **Next Step**. Review the configuration for the environment
9. Click **Create**.
10. After the environment creation process is initiated, click **Open in catalog**. This takes you to the entity card where more information about the environment and the environment runs are available  [![Environment Entity card](https://docs.rafay.co/backstage/img/backstage_environment_entity_card.png)](https://docs.rafay.co/backstage/img/backstage_environment_entity_card.png)

---
