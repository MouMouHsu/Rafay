---
title: "KOP Backstage - Create a Cluster"
source: https://docs.rafay.co/backstage/create_cluster/
category: Home
---

# Create

The following is an example for creating a cluster from a template using a Backstage environment.

1. Log in to Backstage.
2. Click **Create**.
3. For **Create Cluster From Template**, click **Choose**.
4. Type a name and description for the cluster.  [![Create Cluster Component Details](https://docs.rafay.co/backstage/img/backstage_cluster_from_template1.png)](https://docs.rafay.co/backstage/img/backstage_cluster_from_template1.png)
5. Click **Next Step**.
6. Type the cluster template name and template version to use for creating the cluster.  [![Create Cluster Cluster Details](https://docs.rafay.co/backstage/img/backstage_cluster_from_template2.png)](https://docs.rafay.co/backstage/img/backstage_cluster_from_template2.png)
7. Click **Next Step**.
8. Type the name of the owner and type the name for the repository.  [![Create Cluster Choose Location](https://docs.rafay.co/backstage/img/backstage_cluster_from_template3.png)](https://docs.rafay.co/backstage/img/backstage_cluster_from_template3.png)
9. Click **Next Step**. Review the configuration for the resource.
10. Click **Create**.
11. After the cluster creation process is initiated, click **Open in catalog**. This takes you to the cluster entity card. Some cluster details will display after the cluster has been created, like being able to download the kubeconfig file.

---
