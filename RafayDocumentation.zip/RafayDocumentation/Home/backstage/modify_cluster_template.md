---
title: "KOP Backstage - Cluster Template - Modify"
source: https://docs.rafay.co/backstage/modify_cluster_template/
category: Home
---

# Edit Template

The Backstage template editor allows you to try out modifying the sample cluster template to create a new cluster template that suit the needs of the organization and developers.

1. In Backstage, click **Create**.
2. Click the actions icon (upper-right), then select **Template Editor**.
3. Click **Edit Template Form**.
4. Click the Load Existing Template field, then select the **Create EKS Cluster** template. Or chose one of the other cluster templates.
5. In the text editor, modify the settings for creating a cluster.
6. In the preview pane, test your modifications. For example, type a name and description for the cluster template. If the template has multiple steps, click **Next Step**.

---

## Example Cluster Template

```
parameters:
  - title: Component Details
    required:
      - name
      - description
    properties:
      name:
        title: Name
        type: string
        description: Unique name of the component
        ui:field: EntityNamePicker
        ui:autofocus: true
      description:
        title: Description
        type: string
        description: A description for the component
      owner:
        title: Owner
        type: string
        description: Owner of the component
        ui:field: OwnerPicker
        ui:options:
          allowedKinds:
            - Group
  - title: Choose a location
    required:
      - repoUrl
    properties:
      repoUrl:
        title: Repository Location
        type: string
        ui:field: RepoUrlPicker
        ui:options:
          allowedHosts:
            - github.com
steps:
  - id: create-cluster
    name: Create EKS Cluster
    action: rafay:create-aks-cluster
    input:
      project: 12345abcde
      name: ${{ parameters.name }}
      blueprint: minimal
      blueprintVersion: ""
      region: aws/us-west-2
      cloudProviderId: 54321edcba
      instanceType: m5.xlarge
      resourceGroupName: cluster-template
  - id: fetch
    name: Template Skeleton
    action: fetch:template
    input:
      url: ./skeleton
      values:
        name: ${{ parameters.name }}
        description: ${{ parameters.description }}
        destination: ${{ parameters.repoUrl | parseRepoUrl }}
        owner: ${{ parameters.owner }}
        clusterId: ${{ steps["create-cluster"].output.clusterId }}
  - id: publish
    name: Publish
    action: publish:github
    input:
      allowedHosts:
        - github.com
      description: This is ${{ parameters.name }}
      repoUrl: ${{ parameters.repoUrl }}
  - id: register
    name: Register
    action: catalog:register
    input:
      repoContentsUrl: ${{ steps.publish.output.repoContentsUrl }}
      catalogInfoPath: /catalog-info.yaml
output:
  links:
    - title: Repository
      url: ${{ steps.publish.output.remoteUrl }}
    - title: Open in catalog
      icon: catalog
      entityRef: ${{ steps.register.output.entityRef }}
```

---
