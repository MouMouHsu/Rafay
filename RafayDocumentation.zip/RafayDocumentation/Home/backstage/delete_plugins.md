---
title: "KOP Backstage - Delete Plugins"
source: https://docs.rafay.co/backstage/delete_plugins/
category: Home
---

# Delete Plugins

Removing the Rafay Backstage plugin requires deleting the frontend and the backend plugins.

## Delete Frontend Plugin

```
yarn --cwd packages/app remove @rafaysystems/backstage-plugin-rafay
```

## Delete Backend Plugin

```
yarn --cwd packages/backend remove @rafaysystems/backstage-plugin-rafay-backend
```
