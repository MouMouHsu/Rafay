---
title: "KOP Backstage - Create a Workload"
source: https://docs.rafay.co/backstage/create_workload/
category: Home
---

# Create

The following is an example for creating a workload using a Backstage environment.

1. Log in to Backstage.
2. Click **Create**.
3. For **Create Workload**, click **Choose**.
4. Type a name and description for the workload.  [![Create Workload Component Details](https://docs.rafay.co/backstage/img/backstage_workload_create1.png)](https://docs.rafay.co/backstage/img/backstage_workload_create1.png)
5. Click **Next Step**.
6. Type the project ID, cluster name, namespace name, repository name, repository branch, and the path to the YAML file.  [![Create Workload Workload Details](https://docs.rafay.co/backstage/img/backstage_workload_create2.png)](https://docs.rafay.co/backstage/img/backstage_workload_create2.png)
7. Click **Next Step**.
8. Type the name of the owner and type the name for the repository.  [![Create Workload Choose Location](https://docs.rafay.co/backstage/img/backstage_workload_create3.png)](https://docs.rafay.co/backstage/img/backstage_workload_create3.png)
9. Click **Next Step**. Review the configuration for the resource.
10. Click **Create**.
11. After the workload creation process is initiated, click **Open in catalog**. This takes you to the workload entity card. Some workload details will display after the workload has been created.

---
