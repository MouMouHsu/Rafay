---
title: "KOP Backstage - Register Existing Namespace"
source: https://docs.rafay.co/backstage/register_namespace/
category: Home
---

# Register Existing

The following is an example for registering an existing namespace to a Backstage environment.

1. Log in to Backstage.
2. Click **Create**.
3. For **Register Existing Namespace**, click **Choose**.
4. Type a name and description for the cluster.
5. Type the project ID for the project to register the namespace to.  [![Register Existing Namespace Component Details](https://docs.rafay.co/backstage/img/backstage_namespace_exist1.png)](https://docs.rafay.co/backstage/img/backstage_namespace_exist1.png)
6. Click **Next Step**.
7. Type the name of the owner and type the name for the repository.  [![Register Existing Namespace Choose Location](https://docs.rafay.co/backstage/img/backstage_namespace_exist2.png)](https://docs.rafay.co/backstage/img/backstage_namespace_exist2.png)
8. Click **Next Step**. Review the configuration for the resource.
9. Click **Create**.
10. After the namespace registration process is initiated, click **Open in catalog**. This takes you to the namespace entity card. Some namespace details will display after the namespace has been registered.

---
