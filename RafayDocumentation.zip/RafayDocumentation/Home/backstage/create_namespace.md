---
title: "KOP Backstage - Create a Namespace"
source: https://docs.rafay.co/backstage/create_namespace/
category: Home
---

# Create

The following is an example for creating a namespace using a Backstage environment.

1. Log in to Backstage.
2. Click **Create**.
3. For **Create Namespace**, click **Choose**.
4. Type a name and description for the namespace.
5. Click **+Add Item** and type the name of the cluster to to provision the namespace to.  [![Create Namespace Component Details](https://docs.rafay.co/backstage/img/backstage_create_namespace1.png)](https://docs.rafay.co/backstage/img/backstage_create_namespace1.png)
6. Click **Next Step**.
7. Type an Owner and the name for the repository.  [![Create Namespace Choose Location](https://docs.rafay.co/backstage/img/backstage_create_namespace2.png)](https://docs.rafay.co/backstage/img/backstage_create_namespace2.png)
8. Click **Next Step**. Review the configuration for the resource.
9. Click **Create**.
10. After the namespace creation process is initiated, click **Open in catalog**. This takes you to the namespace entity card. Some namespace details will display after the namespace has been created.

---
