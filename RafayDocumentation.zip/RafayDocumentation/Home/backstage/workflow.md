---
title: "KOP Backstage - Workflow"
source: https://docs.rafay.co/backstage/workflow/
category: Home
---

# Workflow

### Step 1

- Deploy [Backstage](https://backstage.io/docs/getting-started/)

### Step 2

- Install the Rafay Backstage plugin. Follow thew instructions [here](https://docs.rafay.co/backstage/setup/#step-2-configure-rafay-org-account-in-backstage)

### Step 3

- Authenticate the Backstage environment to the Rafay Org using an API token as part of the set-up process

### Step 4

- Customize Backstage workflows as appropriate and select 'templates' to enable for users in the Backstage environment

---
