---
title: "KOP Application Lifecycle Management using Integrated GitOps"
source: https://docs.rafay.co/applifecycle/gitops/overview/
category: Home
---

# Integrated GitOps

An Integrated Application GitOps service is available for users as part of the platform. Click **[here](https://docs.rafay.co/gitops/overview/)** to learn more about this service

[![Integrated App GitOps](https://docs.rafay.co/applifecycle/gitops/img/architecture.png)](https://docs.rafay.co/applifecycle/gitops/img/architecture.png)

---
