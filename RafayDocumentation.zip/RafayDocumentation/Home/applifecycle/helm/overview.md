---
title: "KOP Application Lifecycle Management using Helm CLI"
source: https://docs.rafay.co/applifecycle/helm/overview/
category: Home
---

# Helm

## About

Helm is known as "the package manager for Kubernetes". The original goal of Helm was to provide users with a better way to manage all the Kubernetes YAML files we create on Kubernetes projects.

Helm addresses this via Helm Charts. Each chart is a bundle with one or more Kubernetes manifests – a chart can have child charts and dependent charts as well.

Helm installs the whole dependency tree of a project for the top-level chart. With just a single command, the entire application can be deployed instead of listing the files to install via kubectl.

---

## Push to Cluster Pattern

It is a common pattern to deploy application manifests to remote clusters using the Helm CLI. Users typically **embed** the Helm CLI into their automation platforms such as Jenkins, CircleCI, GitHub Actions etc.

[![Helm CLI Deployments](https://docs.rafay.co/applifecycle/helm/img/helm-ci.png)](https://docs.rafay.co/applifecycle/helm/img/helm-ci.png)

---

## Kubectl and ZTKA

Instead of being forced to use a bastion host or similar ineffecient alternatives in order to make direct calls to the remote Kubernetes cluster's API server using the Helm CLI, users can use the "zero trust kubectl" service to perform this across security domains in a secure manner.

- All actions are access controlled using RBAC
- All actions are audited
- No inbound access to the remote cluster is needed

The typical steps for this are

- Download the zero trust kubectl's **kubeconfig** file
- Configure kubectl with the downloaded kubeconfig
- Deploy application manifests to remote clusters using Helm CLI commands

[![ZTKA based Kubectl Deployments](https://docs.rafay.co/applifecycle/helm/img/helm-deploy.png)](https://docs.rafay.co/applifecycle/helm/img/helm-deploy.png)

---
