---
title: "Application Lifecycle Management using ArgoCD GitOps"
source: https://docs.rafay.co/applifecycle/argocd/overview/
category: Home
---

# ArgoCD

## About

[Argo CD](https://argo-cd.readthedocs.io/) is a declarative, GitOps continuous delivery tool for Kubernetes.

Argo CD follows the GitOps pattern of using Git repositories as the source of truth for defining the desired application state. Kubernetes manifests can be specified in several ways:

- Kustomize applications
- Helm charts
- jsonnet files
- Plain directory of YAML/json manifests

Argo CD automates the deployment of the desired application states in the specified target environments. Application deployments can track updates to branches, tags, or pinned to a specific version of manifests at a Git commit.

> Read Related Blog Posts

| Title | Link |
| --- | --- |
| ArgoCD + Rafay Integration | [ArgoCD + Rafay Integration](https://docs.rafay.co/blog/2025/08/06/gitops-without-borders-running-argo-cd-across-isolated-security-domains-with-rafays-zero-trust-kubectl/) |
| Understanding ArgoCD Reconciliation | [Understanding ArgoCD Reconciliation](https://docs.rafay.co/blog/2025/08/04/understanding-argocd-reconciliation-how-it-works-why-it-matters-and-best-practices/) |

---

## Install ArgoCD

The configuration, installation and ongoing operations of ArgoCD is the responsibility of the customer.

For every project in an Org, all versions of ArgoCD are available as part of the integrated "Catalog". Users can use the catalog to configure and deploy ArgoCD instances in minutes.

### Search for Argo-CD

- Navigate to your Project in your Org
- Click on Catalog
- Type in "argo-cd" in the search box

You should see Argo CD listed from the official Argo Project Helm Repository.

[![ArgoCD Searcg](https://docs.rafay.co/applifecycle/argocd/img/argocd-search.png)](https://docs.rafay.co/applifecycle/argocd/img/argocd-search.png)

### Configure and Install

- Select the "Argo CD" chiclet for the official Argo Project
- Customize the "values.yaml" as per your requirement
- Deploy to your cluster as a workload

[![ArgoCD in Catalog](https://docs.rafay.co/applifecycle/argocd/img/argocd-catalog.png)](https://docs.rafay.co/applifecycle/argocd/img/argocd-catalog.png)

> **Important**
> Depending on your specific requirements, you can also configure Argo CD as a workload template or addon that can then be parameterized and reused multiple times.

---
