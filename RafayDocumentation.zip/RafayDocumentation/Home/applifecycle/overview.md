---
title: "Application Lifecycle Management"
source: https://docs.rafay.co/applifecycle/overview/
category: Home
---

# Overview

The Kubernetes Operations Platform provides an "unopinionated" approach to Application Lifecycle Management. What this means is that lifecycle of different applications can be managed via completely different approaches by the respective application teams.

The common approaches used by Application Teams for app deployments using the Kubernetes Operations Platform are described below.

| Pattern | Deployment Automation | When to Use |
| --- | --- | --- |
| [Kubectl CLI](https://docs.rafay.co/applifecycle/kubectl/overview/) | Download ZTKA kubeconfig and use it with kubectl CLI embedded in an external automation pipeline | Have rudimentary, single "named" cluster app deployment |
| [Helm CLI](https://docs.rafay.co/applifecycle/helm/overview/) | Download ZTKA kubeconfig and use it with Helm CLI embedded in an external pipeline | Have standardized on Helm charts and wish to perform rudimentary, single "named" cluster app deployments |
| [Workloads](https://docs.rafay.co/workloads/workload_types/) | Embedding RCTL CLI into external pipeline or use integrated GitOps for app deployments | Need sophisticated, placement policy (specific cluster, cluster location, cluster labels) based app deployments. Multi cluster app deployments esp. edge. Ability to detect and block inadvertent and malicious detection and action |
| [Integrated GitOps](https://docs.rafay.co/gitops/overview/) | Integrated, multi stage GitOps pipeline wrapping workloads or workload templates | Need sophisticated, multi-stage, GitOps based deployment automation with approvals. Ability to integrate Infra changes with k8s deployments. Support for behind firewall repos |
| [3rd Party GitOps](https://docs.rafay.co/applifecycle/argocd/overview/) | Use a separate, standalone GitOps offering for app deployments | Have necessary inhouse expertise to deploy, secure and operate a standalone GitOps platform such as Argo CD. Do not require support for behind firewall repos |
| [MySQL](https://docs.rafay.co/applifecycle/mysql/overview/) | Rafay Access Control of integrated MySQL Database within Kubernetes cluster | Database user access needs to be restricted with the help namespace segregation when database deployed on kubernetes cluster. Rafay ZTKA can be used to access database and perform necessary action |

---
