---
title: "KOP Application Lifecycle Management using Kubectl"
source: https://docs.rafay.co/applifecycle/kubectl/overview/
category: Home
---

# Kubectl

## About

The Kubernetes command-line tool (kubectl) allows you to run commands against Kubernetes clusters. You can use kubectl to deploy applications, inspect and manage cluster resources, and view logs.

kubectl is installable on a variety of Linux platforms, macOS and Windows. Find your preferred operating system below. For more information including a complete list of kubectl operations, see the [kubectl reference documentation](https://kubernetes.io/docs/reference/kubectl/).

---

## Push to Cluster Pattern

It is a common pattern to deploy application manifests to remote clusters using the kubectl CLI. Users typically **embed** the kubectl CLI into their automation platforms such as Jenkins, CircleCI, GitHub Actions etc.

[![Kubectl Deployments](https://docs.rafay.co/applifecycle/kubectl/img/kubectl-ci.png)](https://docs.rafay.co/applifecycle/kubectl/img/kubectl-ci.png)

---

## Kubectl and ZTKA

Instead of being forced to use a bastion host or similar ineffecient alternatives in order to make direct calls to the remote Kubernetes cluster's API server using the Kubectl CLI, users can use the "zero trust kubectl" service to perform this across security domains in a secure manner.

- All actions are access controlled using RBAC
- All actions are audited
- No inbound access to the remote cluster is needed

The typical steps for this are

- Download the zero trust kubectl's **kubeconfig** file
- Configure kubectl with the downloaded kubeconfig
- Deploy application manifests to remote clusters using Kubectl CLI

[![ZTKA based Kubectl Deployments](https://docs.rafay.co/applifecycle/kubectl/img/kubectl-deploy.png)](https://docs.rafay.co/applifecycle/kubectl/img/kubectl-deploy.png)

---
