---
title: "Managing Agent Pools"
source: https://docs.rafay.co/gitops/gitops_agentpool/
category: Home
---

# Agent Pools

Agent Pools provide a way to group multiple agents together, making it easier to manage and update them collectively across templates and environments.

> **Info**
> Agent Pools can be managed through various methods:
>
> - [UI](https://docs.rafay.co/gitops/gitops_agentpool/)
> - [CLI](https://docs.rafay.co/gitops/gitops_agentpool/)
> - Terraform
> - [API](https://docs.rafay.co/automation/api/apis/)

---

## Overview

An **Agent Pool** is a first-class object that enables managing multiple agents as a group. This is especially beneficial in high-load environments where a single agent might become a bottleneck.

With Agent Pools, users can: - Group existing agents for easier management - Modify the pool to add or remove agents, and have changes automatically reflected across all associated templates - Use Agent Pools anywhere agents are currently supported, such as **Environment Templates**, **Resource Templates**, and **Environments** - Choose to attach either individual agents or agent pools

---

## Key Benefits

- **Centralized Management**: Update the pool once and changes apply everywhere it’s used
- **Flexibility**: Supports mixing Docker and Kubernetes agents in the same pool
- **Scalability**: Distribute workloads across multiple agents to avoid performance bottlenecks

---

## Configuration Guidelines

- Agents must be created before adding them to an Agent Pool (pools cannot create agents)
- Configuration such as CPU/memory limits and worker count remains at the **agent level**
- An agent can belong to **only one** Agent Pool
- Agent and Agent Pool names are independent; they can be the same without conflict
- Pools can contain agents with different versions (though uniform versions are recommended)
- Multiple Agent Pools can be attached to an Environment Template, or Resource Template, supporting transitional workflows

---

## UI Workflow

1. Navigate to **GitOps → Agent Pools**
2. Click **New Agent Pool**

[![New Agent](https://docs.rafay.co/gitops/img/agents/agentpool_menu.png)](https://docs.rafay.co/gitops/img/agents/agentpool_menu.png)

The **New Agent Pool** pop-up appears

1. Enter a **Name** for the pool
2. Select one or more existing agents to include in the pool
3. Click **Create**

[![New Agent](https://docs.rafay.co/gitops/img/agents/agent_list.png)](https://docs.rafay.co/gitops/img/agents/agent_list.png)

Once an agent pool is added, it appears in the **Agent Pools** list.

[![New Agent](https://docs.rafay.co/gitops/img/agents/agents_added.png)](https://docs.rafay.co/gitops/img/agents/agents_added.png)

The agent pool can be configured when creating an environment template, resource template, and environment.

Below is an example of an **Environment Template** where the agent pool is selected.

[![New Agent](https://docs.rafay.co/gitops/img/agents/envtemp_agents.png)](https://docs.rafay.co/gitops/img/agents/envtemp_agents.png)

> Note: Additional individual agents can also be added, even if they are already part of the selected agent pool.

---

## RCTL CLI

The following example demonstrates how to create an Agent Pool using the RCTL CLI.

```
apiVersion: gitops.k8smgmt.io/v3
kind: AgentPool
metadata:
  name: cluster-agentpool
  project: defaultproject
spec:
  agents:
    - agentpool-1
    - agentpool-2
    - agentpool-3
    - agentpool-4
```

Use the below commands to create/get/delete agent pool(s)

### Create Agent Pool

Apply an Agent Pool specification file to create a new pool.

```
./rctl apply -f <agentpool.yaml>
```

### List Agent Pools

To list all agent pools:

```
./rctl get agentpools
```

(or)

```
./rctl get ap
```

***Example***

```
./rctl get agentpools
+-------------------+----------------+----------------+
| AGENT POOL NAME   | AGENTS         | HEALTHY AGENTS |
+-------------------+----------------+----------------+
| p1                | agent1         |                |
+-------------------+----------------+----------------+
| def-ap-1          | def-a-1        | def-a-1        |
+-------------------+----------------+----------------+
| def-ap-2          | def-a-2        | def-a-2        |
+-------------------+----------------+----------------+
| cluster-agentpool | demo-1agent    | demo-3agent    |
|                   | demo-2agent    |                |
|                   | demo-3agent    |                |
|                   | cluster1-agent |                |
+-------------------+----------------+----------------+
```

To retrieve details of an individual Agent Pool:

```
./rctl get agentpool <agentpool-name>
```

***Example***

```
./rctl get ap cluster-agentpool
+-------------------+----------------+----------------+
| AGENT POOL NAME   | AGENTS         | HEALTHY AGENTS |
+-------------------+----------------+----------------+
| cluster-agentpool | demo-1agent    |  demo-3agent   |
|                   | demo-2agent    |                |
|                   | demo-3agent    |                |
|                   | cluster1-agent |                |
+-------------------+----------------+----------------+
```

### Delete Agent Pool

To delete a specific Agent Pool:

```
./rctl delete agentpool <agentpool-name>
```

(or)

```
./rctl delete ap <agentpool-name>
```

---
