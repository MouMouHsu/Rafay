---
title: "KOP GitOps - Troubleshooting"
source: https://docs.rafay.co/gitops/triggers_troubleshoot/
category: Home
---

# Troubleshooting

On successful External Git repos configuration, the webhook will be sent to the controller each time when one or more subscribed events occurs

## Webhooks (for GitHub)

To verify the Github webhook process is successful or failed, perform the below steps:

- Login to the Github Repo and open the configured folder
- Click **Settings** tab and select **Webhooks** under the **Code and automation**
- Click **Recent Deliverables** to view the Github webhook request and responses

Every **Recent Deliveries** screen lists the successful (green tick mark) or failed (red mark) deliverables. Also, users can identify the time of each deliverable

- **Request** tab provides information on which Headers were sent by GitHub and the details of the JSON payload

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/github_req.png)](https://docs.rafay.co/gitops/img/trigger/github_req.png)

- **Response** tab lists how the server replied once it received the payload from GitHub. This includes the status code, the headers, and any additional data within the response body

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/github_responses.png)](https://docs.rafay.co/gitops/img/trigger/github_responses.png)

---

## Webhooks (for Gitlab)

To verify the Gitlab webhook process is successful or failed, perform the below steps:

- In your Gitlab project, click **Settings** -> **Webhooks**. Users can view all the recent webhook events
- Select the required webhook and click **View details**

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/gitlab_webhookslist.png)](https://docs.rafay.co/gitops/img/trigger/gitlab_webhookslist.png)

- Response and Request details are shown in the Request Details page along with the Headers sent by Gitlab and the delivered time
- Click **Resend Request** to retry the failed webhook events

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/gitlab_responses_requests.png)](https://docs.rafay.co/gitops/img/trigger/gitlab_responses_requests.png)

---

## Webhooks (for Bitbucket)

### Create Webhooks

- To add a Bitbucket Webhook, click **Add Webhook**

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/add_webhook-button.png)](https://docs.rafay.co/gitops/img/trigger/add_webhook-button.png)

- Enter a title and URL of the pipeline created in the controller
- Provide the required data and click **Save**

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/add-webhook-save.png)](https://docs.rafay.co/gitops/img/trigger/add-webhook-save.png)

### Edit/Delete Webhooks

Users are allowed to edit/delete the active Bitbucket Webhooks

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/edit_delete_webhook.png)](https://docs.rafay.co/gitops/img/trigger/edit_delete_webhook.png)

### Verify Webhooks

To verify whether the Bitbucket Webhook process is successful or failed, perform the below steps:

- In your Bitbucket project, click **Repository Settings** -> **Webhooks** available in the left pane. Users can view all the recent webhook events
- Select the required webhook and click **View requests**

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/bitbucket-webhook.png)](https://docs.rafay.co/gitops/img/trigger/bitbucket-webhook.png)

By default, **Request history collection** is set to **Off**

- Click **Enable History** to view the request logs along with the event history

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/enable-history.png)](https://docs.rafay.co/gitops/img/trigger/enable-history.png)

- Click **View details** to know more about the webhook event requests

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/view_webhook-request.png)](https://docs.rafay.co/gitops/img/trigger/view_webhook-request.png)

- You can view the request details here when an event in Bitbucket triggers a webhook

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/request_detail.png)](https://docs.rafay.co/gitops/img/trigger/request_detail.png)

---

## Webhooks (for Azure Repos)

### Create Webhooks

- Login to the Azure Repo, navigate to your Organization -> Project
- Click **Project Settings** tab and select **Service hooks** under **General** settings

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/create%20webhook_Azure%20Repos_1.png)](https://docs.rafay.co/gitops/img/trigger/create%20webhook_Azure%20Repos_1.png)

- Create a webhook subscription, with event configure for 'Code pushed'

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/create%20webhook_Azure%20Repos_2.png)](https://docs.rafay.co/gitops/img/trigger/create%20webhook_Azure%20Repos_2.png)

- Set the Rafay generated webhook URL and secret as the URL and Basic authentication password

> **Important**
> Although configuration of Basic authentication password is shown as optional, it must be set with the Rafay generated webhook secret to pass validation

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/create%20webhook_Azure%20Repos_3.png)](https://docs.rafay.co/gitops/img/trigger/create%20webhook_Azure%20Repos_3.png)

- Click **Finish** to complete the configuration or click on **Test** to create a mock event

### Edit/Delete Webhooks

- Existing webhook configuration can be updated by choosing **Edit** from the drop down Options

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/create%20webhook_Azure%20Repos_4.png)](https://docs.rafay.co/gitops/img/trigger/create%20webhook_Azure%20Repos_4.png)

### Verify Webhooks

To verify whether the Bitbucket Webhook process is successful or failed, perform the below steps:

- Login to the Azure Repo, navigate to your Organization -> Project
- Click on **Project Settings** tab and select **Service hooks** under **General** Settings
- Select the configured webhook, click **Hisory** to view the webhook events

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/verify%20webhook_Azure%20Repos_1.png)](https://docs.rafay.co/gitops/img/trigger/verify%20webhook_Azure%20Repos_1.png)

- All events with status (Successful or Failed) are listed. Click on an event to view details such as Request, Response, Summary

[![Webhook Trigger](https://docs.rafay.co/gitops/img/trigger/verify%20webhook_Azure%20Repos_2.png)](https://docs.rafay.co/gitops/img/trigger/verify%20webhook_Azure%20Repos_2.png)

---
