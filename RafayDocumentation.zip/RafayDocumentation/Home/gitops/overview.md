---
title: "Integrated GitOps Pipelines"
source: https://docs.rafay.co/gitops/overview/
category: Home
---

# Overview

At its core, the GitOps operating model is centered around using a version control system (e.g. Git) for a Kubernetes deployment and leveraging automation to deploy changes to the clusters. GitOps is an operating model specifically well suited for Kubernetes because it centralizes every aspect of the process for managing both operations and development.

---

## Why GitOps

The GitOps operating model provides a number of significant benefits as described below.

### Familiarity

- The exact same process already in use to merge code using "pull or merge" requests is used to drive workload deployments to Kubernetes clusters.

### Increased Velocity

- Deployments are performed in near real time
- Time to deployment to Kubernetes clusters takes seconds from the time the artifact repository is updated

### Increased Agility

- By slashing the cost and operational burden of performing a deployment, application teams can focus on moving fast with as many releases as required to support the business.

### Consistency

- Aligns developers and operations teams by managing operational workflows for Kubernetes using a single, unified version control system such as Git

### Better Security

- Zero manual intervention with Kubernetes clusters means no opportunity for inadvertent, manual errors
- A guarantee that "desired state" expressed in the version control system (Git) is enforced on Kubernetes clusters
- Inadvertent or malicious action resulting in drift from desired state on Kubernetes clusters is instantly detected and optionally blocked.
- Reduces compliance burden by centralizing Git as the source of truth for artifact versions, changes and audits.

### Cost Savings

- Eliminates unnecessary manual processes making application teams effective and efficient.

> **Important**
> Users must run the pipeline manually in Rafay UI for the first time to sync the clusters from System to Git

---
