---
title: "KOP GitOps - Benefits"
source: https://docs.rafay.co/gitops/benefits/
category: Home
---

# Benefits

There are a number of standalone GitOps tools available. This document describes the benefits of an integrated, GitOps continuous delivery capability in the Controller.

---

## Benefits

### Low Cost

- Leverage the same platform that you use for Kubernetes management for GitOps
- Eliminates the license and operational costs by eliminating the need for yet another tool just for GitOps

### Instant Start

- Sign in and build a multi-stage deployment pipeline to deploy applications to your clusters in under 5 minutes (not weeks or months)
- No need to develop, test and maintain complex application deployment scripts

### Zero Learning Curve

- Focus on building and improving your pipelines and applications
- No need to learn, train, install and maintain a separate GitOps tool

### Seamless, Integrated Experience

- Intuitive user experience makes developers and operational personnel extremely effective and productive
- Critical operational data available instantly eliminating the need for users to straddle multiple products to do their jobs

### High Security Model

- Implement and standardize on a zero trust security model for your cluster and application operations
- Uses the exact same RBAC you already use for isolation, strong authentication, zero trust security and audits for your cluster and workload operations
- Leverage your existing corporate IdP to streamline and manage access for users
- Instantly detect and remediate accidental or malicious configuration drifts

### Simplify

- Simplify and streamline the operational complexity for your developers and operational personnel
- New users can learn and become experts in minutes

---
