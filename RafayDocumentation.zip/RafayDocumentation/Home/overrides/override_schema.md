---
title: "Overrides Schema"
source: https://docs.rafay.co/overrides/override_schema/
category: Home
---

# Override Schema

Cluster Override configuration
