---
title: "KOP Dashboard - Configuration"
source: https://docs.rafay.co/dashboard/config/
category: Home
---

# Configuration

Clicking on the "Configuration" tab on the Cluster Dashboard allows the Infrastructure Admin to view critical "static" and "dynamic" metadata associated with the cluster.

Depending on the type of cluster, different metadata will be presented.

## Static Metadata

- Type (On-Prem, Imported, Amazon EKS)
- Location
- Auto Provisioned (Yes/No)
- GPU
- Provider

## Dynamic Metadata

- Ingress IPs (if configured)
- Blueprint (default if not customized)
- Blueprint Sync Status
- Approve Nodes Automatically (ON/OFF)

---

## MKS, Upstream k8s Cluster

An example of configuration for an "On-Premises" cluster

[![Cluster Configuration](https://docs.rafay.co/dashboard/img/configuration/onpremises.png)](https://docs.rafay.co/dashboard/img/configuration/onpremises.png)

---

## Amazon EKS Cluster

An example of configuration for a controller provisioned "Amazon EKS" cluster

[![Cluster Configuration](https://docs.rafay.co/dashboard/img/configuration/eks.png)](https://docs.rafay.co/dashboard/img/configuration/eks.png)

Clicking on "View More" will display additional EKS and AWS specific metadata is display for Amazon EKS clusters.

[![Cluster Configuration](https://docs.rafay.co/dashboard/img/configuration/eks_viewmore.png)](https://docs.rafay.co/dashboard/img/configuration/eks_viewmore.png)

---
