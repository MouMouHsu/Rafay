---
title: "KOP Dashboard - My Clusters"
source: https://docs.rafay.co/dashboard/my_clusters/
category: Home
---

# My Clusters

Users with Project Admin/read only, Namespace Admin/read only and Workspace Admin/read only roles are allowed to view/read-only the clusters they have access to through **My Clusters** page. List of clusters associated with the user along with the cluster type and status, kubernetes resources operational on a given cluster, and utilizations are available in this page.

[![Org Dashboard](https://docs.rafay.co/dashboard/img/myclusters/my_clusters.png)](https://docs.rafay.co/dashboard/img/myclusters/my_clusters.png)

---

## Resources

Select the required cluster and click **Resources** to view each of the cluster resource details

[![Org Dashboard](https://docs.rafay.co/dashboard/img/myclusters/resources_view.png)](https://docs.rafay.co/dashboard/img/myclusters/resources_view.png)

Users are directed to the Web Console that provides a detailed view of all [Kubernetes Resources](https://docs.rafay.co/dashboard/k8sresources/) operational on a given Kubernetes cluster.

[![Org Dashboard](https://docs.rafay.co/dashboard/img/myclusters/resource_list.png)](https://docs.rafay.co/dashboard/img/myclusters/resource_list.png)

---

## Utilization

Select the required cluster and click **Utilization** to view the project limit, namespace limit and utilization of each resource type associated with the cluster

[![Org Dashboard](https://docs.rafay.co/dashboard/img/myclusters/utilization_view.png)](https://docs.rafay.co/dashboard/img/myclusters/utilization_view.png)

Utilization page appears with a list of resources types, [resource quotas](https://docs.rafay.co/security/tenancy/resource_quotas/) (project and namespace limit) and the limit utilized by each resourceoperational on a given Kubernetes cluster.

[![Org Dashboard](https://docs.rafay.co/dashboard/img/myclusters/utilization_list.png)](https://docs.rafay.co/dashboard/img/myclusters/utilization_list.png)

---
