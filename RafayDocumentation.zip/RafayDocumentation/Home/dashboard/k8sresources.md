---
title: "KOP Dashboard - Kubernetes Resources"
source: https://docs.rafay.co/dashboard/k8sresources/
category: Home
---

# View/Edit/Delete

The Web Console also provides users with a detailed view into **All Kubernetes Resources** operational on a given Kubernetes cluster.

Users may wish to sort and view the data based on criteria that makes most sense for them. The Console provides a number of filters to make this easy for them. Also, users can view the resource(s) count displayed at the top.

- View By Cluster
- View by Namespace
- View by Workloads
- View by Helm Releases
- View by Addons

---

### Namespaces

Namespaces are created and managed by the Controller on clusters. The Controller is responsible for the lifecycle of these namespaces. Users can view the count of Namespace in the table heading and all the namespaces are listed in the table as shown below.

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/namespace_types.png)](https://docs.rafay.co/dashboard/img/k8sresources/namespace_types.png)

---

### Kubernetes Events

Kubernetes events are a resource type in Kubernetes that are automatically created when resources have state changes, errors, or other messages that should be broadcast to the system. Events are an invaluable resource when debugging issues in your Kubernetes cluster.

[![View by Workload](https://docs.rafay.co/dashboard/img/k8sresources/k8_event.png)](https://docs.rafay.co/dashboard/img/k8sresources/k8_event.png)

---

### View by Workload

Aimed at users that leverage workload configuration and deployments. The biggest benefit to users is that all Kubernetes resources associated with the workload are automatically filtered and presented. This means users no longer have to guess what resources are part of their application.

[![View by Workload](https://docs.rafay.co/dashboard/img/k8sresources/view_by_workload.png)](https://docs.rafay.co/dashboard/img/k8sresources/view_by_workload.png)

---

### View by Helm Releases

The biggest benefit to users is that all helm deployments to the cluster either using workload configuration or using helm client are automatically displayed.

[![View by Workload](https://docs.rafay.co/dashboard/img/k8sresources/viewby_helm_release.png)](https://docs.rafay.co/dashboard/img/k8sresources/viewby_helm_release.png)

---

## Column Selectors

A number of attributes are tracked for every Kubernetes resource type. Users that wish to view the attributes that are outside the "default" set of filters can use the Column Selector to select their preferred set of attributes.

[![Column Selector](https://docs.rafay.co/dashboard/img/k8sresources/columns_selector.png)](https://docs.rafay.co/dashboard/img/k8sresources/columns_selector.png)

---

### Namespaces

The list of active namespaces on the cluster and the state of health of resources in it.

- Green indicates that all resources in the namespace are healthy
- Red indicates that some/all resources in the namespace are unhealthy

---

### Deployment Resources

- Pods
- Deployments
- ReplicaSets
- StatefulSets
- DaemonSets
- Jobs
- CronJobs

The **Controlled By** column highlights the relationship between the pods and other K8s resources.

[![Controlled By](https://docs.rafay.co/dashboard/img/k8sresources/controlled_by.png)](https://docs.rafay.co/dashboard/img/k8sresources/controlled_by.png)

### Load Balancers

- Ingress
- Services

### Config and Storage

- Secrets
- PVCs
- ConfigMaps
- HorizontalPodAutoscalers

### Access Control

- Roles
- RoleBindings
- Service Accounts

### Custom Resources

- CustomResourceDefinitions

[![All k8s Resources](https://docs.rafay.co/dashboard/img/k8sresources/resources_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/resources_list.png)

The "total count" for every type of Kubernetes resource is displayed on the dashboard. In addition, for Kubernetes resources that can have "state", the data is presented organized by "state" i.e. Healthy or Unhealthy.

---

## View by

Users can filter and view the list of Kubernetes resources either by

- Cluster
- Namespaces
- Workloads
- Helm Releases
- Addons

The view by namespace is the default filter.

---

## Pod/Container Diagnostics

Developers are provided with the facility to quickly investigate and debug issues associated with their running Pods and Containers.

---

## Actions

Administrators are provided with a number of contextual actions that they can perform on pods right on the integrated k8s resources dashboard.

[![Actions](https://docs.rafay.co/dashboard/img/k8sresources/resource_actions.png)](https://docs.rafay.co/dashboard/img/k8sresources/resource_actions.png)

**Actions Availability**

The below table shows the actions availability for each resources:

| Resources | Edit yaml | Describe | Download | Events | Shell and Logs | Delete |
| --- | --- | --- | --- | --- | --- | --- |
| **Clusters** |  |  |  |  |  |  |
| Role/RoleBindings/StorageClasses/PersistentVolumes | YES | YES | YES | N/A | N/A | YES |
| PSP | N/A | N/A | N/A | N/A | N/A | N/A |
| **Events** | N/A | N/A | N/A | N/A | N/A | N/A |
| **Deployment Resources** |  |  |  |  |  |  |
| Pods | YES | YES | YES | YES | YES | YES |
| Deployments/ReplicaSets/StatefulSets/DaemonSets/Jobs/Cron Jobs | YES | YES | YES | N/A | N/A | YES |
| **Load Balancers** |  |  |  |  |  |  |
| Ingress/Services | YES | YES | YES | N/A | N/A | YES |
| **Config & Storage** |  |  |  |  |  |  |
| Secrets/ConfigMaps/HorizontalPodAutoscalers | YES | YES | YES | N/A | N/A | YES |
| PVC | N/A | N/A | N/A | N/A | N/A | N/A |
| **Access Control** |  |  |  |  |  |  |
| Roles/ Role Bindings/Service Accounts | YES | YES | YES | N/A | N/A | YES |
| **Custom Resources** |  |  |  |  |  |  |
| CustomResourceDefinitions | YES | YES | YES | N/A | N/A | YES |

---

### Edit Yaml

Administrators can edit the running resource yaml file using the **Edit Yaml** option

[![Edit Yaml](https://docs.rafay.co/dashboard/img/k8sresources/edit-yamlicon.png)](https://docs.rafay.co/dashboard/img/k8sresources/edit-yamlicon.png)

A yaml config file appears on the right pane. You can update a few parameters that are allowed and click **Update**. For scenarios where a parameter is not allowed to update, an error message appears as shown in the below example

[![Error message](https://docs.rafay.co/dashboard/img/k8sresources/yaml_editpage.png)](https://docs.rafay.co/dashboard/img/k8sresources/yaml_editpage.png)

---

### Describe

For scenarios where the developer may need to view the details of a resource to investigate issues. For a resource, click **Describe** under Actions.

[![Describe Pod](https://docs.rafay.co/dashboard/img/k8sresources/describe_pod.png)](https://docs.rafay.co/dashboard/img/k8sresources/describe_pod.png)

This will show the details describing the resource operational on the remote cluster.

[![Describe Pod](https://docs.rafay.co/dashboard/img/k8sresources/describe_pane.png)](https://docs.rafay.co/dashboard/img/k8sresources/describe_pane.png)

---

### Download

To download the resource yaml file to your system, click **Download**. On successful download, a success message appears as shown in the below example.

[![Success Download](https://docs.rafay.co/dashboard/img/k8sresources/dwnload_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/dwnload_yaml.png)

---

### Events

Developers are provided the facility to quickly view the **events** associated with their Pod. Click **Events** from the Actions list.

[![Success Download](https://docs.rafay.co/dashboard/img/k8sresources/resource_event.png)](https://docs.rafay.co/dashboard/img/k8sresources/resource_event.png)

This action performs a **live retrieval** of pre-filtered list of events associated with this pod.

[![Success Download](https://docs.rafay.co/dashboard/img/k8sresources/events_info.png)](https://docs.rafay.co/dashboard/img/k8sresources/events_info.png)

---

### Container Logs

Administrator are provided the facility to retrieve and view the logs associated with a specific container in a single click. This enables them to investigate issues quickly and efficiently.

For a pod, click **Shell and Logs** under Actions and select **Logs** icon.

[![Logs and Exec](https://docs.rafay.co/dashboard/img/k8sresources/containers_execlog.png)](https://docs.rafay.co/dashboard/img/k8sresources/containers_execlog.png)

This will open a real time, zero trust kubernetes access (ztka) shell to the running container and present the administrator with the Logs.

[![Logs and Exec](https://docs.rafay.co/dashboard/img/k8sresources/pod_log.png)](https://docs.rafay.co/dashboard/img/k8sresources/pod_log.png)

---

### Exec to Container

There are scenarios where the administrator may need to **exec** to a specific container so that they can investigate issues faster.

For a pod, click **Shell and Logs** under Actions and select **Exec** icon.

[![Logs and Exec](https://docs.rafay.co/dashboard/img/k8sresources/container_exec_logs.png)](https://docs.rafay.co/dashboard/img/k8sresources/container_exec_logs.png)

This will open a real time, zero trust kubernetes access (ztka) shell to the running container.

[![Logs and Exec](https://docs.rafay.co/dashboard/img/k8sresources/execu_screen.png)](https://docs.rafay.co/dashboard/img/k8sresources/execu_screen.png)

---

### Delete Pod

Useful for scenarios where the developer may need to "delete" a pod on a remote cluster

[![Delete Pod](https://docs.rafay.co/dashboard/img/k8sresources/delete_pod.png)](https://docs.rafay.co/dashboard/img/k8sresources/delete_pod.png)

For a pod, click on "Delete" under Actions.

---
