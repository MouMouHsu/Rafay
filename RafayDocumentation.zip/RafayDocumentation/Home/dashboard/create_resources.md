---
title: "KOP Dashboard - Create K8s Resources"
source: https://docs.rafay.co/dashboard/create_resources/
category: Home
---

# Create

Users with appropriate roles are allowed to create k8s resources from the **K8s Resources** dashboard. An intuitive workflow is available in the console to create these resources quickly and efficiently.

## Deployment Resources

### Deployments

To create Deployments, perform the following steps:

- Select a cluster and click the Resources tab
- Select **Deployments** under the **Deployment Resources** and click **Create Deployment**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/deployment_create.png)](https://docs.rafay.co/dashboard/img/k8sresources/deployment_create.png)

**Deployment : Create** screen appears

- By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a Deployment

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/deployment_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/deployment_yaml.png)

- **Form** allows to select and enter the required data
- Select the **Namespace** and enter the **Resource Name**
- Optionally, enter the **Description**
- Enter the **Replicas** count and optionally, add container(s). Each deployment can have one or more container(s). On adding two or more containers, users can select one container initially and provide the required details followed by other containers
- Select the type of container for each container, either **[Init Container](https://kubernetes.io/docs/concepts/workloads/pods/init-containers/)** (or) **Standard Container**. **Standard Container** is selected by default

**General**

- In the **General** tab, enter the **Container Image** value of the container selected in the above step
- To pull images from private registry, select from **Pull Secret** drop-down and optionally, provide the other details

Below is an example of Init Container

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/deploy_general.png)](https://docs.rafay.co/dashboard/img/k8sresources/deploy_general.png)

- The **service account(s)** associated with the selected namespaces are listed here and the user can select the required one

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/general_securityacc.png)](https://docs.rafay.co/dashboard/img/k8sresources/general_securityacc.png)

**Labels & Annotations**

- In the **Labels & Annotations** tab, enter the **Pod Labels** and optionally, provide the other details

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/deploy_labeles_annot.png)](https://docs.rafay.co/dashboard/img/k8sresources/deploy_labeles_annot.png)

**Storage**

> Note: It is recommended to provide the storage details though its optional

- Select the **Storage Type** from the drop-down
- Based on the storage type selection, **[Persistent Volume Claim (PVC)](https://kubernetes.io/docs/concepts/storage/persistent-volumes/)**, **[Config Map](https://kubernetes.io/docs/concepts/configuration/configmap/)**, and **[Secret](https://kubernetes.io/docs/concepts/configuration/secret/)** created in that specific namespace are listed and the input field varies for each type

Below is an example of PVC type, where the **Volume Name**, **PVC**, and **Mount Point** values are provided

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/deploy_storage.png)](https://docs.rafay.co/dashboard/img/k8sresources/deploy_storage.png)

Optionally, the user can provide the values for **Networking**, **Resources**, **Scaling & Upgrade Policy**, **Node Scheduling**, **Pod Scheduling**, and **[Security Context](https://kubernetes.io/docs/tasks/configure-pod-container/security-context/)**

- Once the required values are provided, click **Create**
- On successful creation, you can view the deployment as shown below

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/deployment_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/deployment_list.png)

For more details, refer [Deployments](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/)

---

### Create StatefulSet

To create StatefulSet, perform the following steps:

- Select a cluster and click the Resources tab
- Select **StatefulSets** under the **Deployment Resources** and click **Create StatefulSet**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/statefulset_general.png)](https://docs.rafay.co/dashboard/img/k8sresources/statefulset_general.png)

**StatefulSet : Create** screen appears

By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a StatefulSet

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/stateful_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/stateful_yaml.png)

**Form** allows to select and enter the required data

- Select the Namespace and enter the Resource Name
- Optionally, enter the Description
- Enter the Replicas count and select the **Service Name** from the drop-down. The services associated with this specific namespace are listed here
- Select the Container Type, either Init Container (or) Standard Container. Standard Container is selected by default

Similar to **Create Deployments**, provide all the mandatory values and optionally, enter the required details.

- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/stateful_general.png)](https://docs.rafay.co/dashboard/img/k8sresources/stateful_general.png)

On successful creation, you can view the StatefulSet as shown below

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/stateful_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/stateful_list.png)

For more details, refer [StatefulSets](https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/)

---

### Create DaemonSets

To create DaemonSets, perform the following steps:

- Select a cluster and click the Resources tab
- Select **DaemonSets** under the **Deployment Resources** and click **Create DaemonSet**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/daemonset_create.png)](https://docs.rafay.co/dashboard/img/k8sresources/daemonset_create.png)

**DaemonSet : Create** screen appears

By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a DaemonSet

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/daemon_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/daemon_yaml.png)

**Form** allows to select and enter the required data

- Select the Namespace and enter the Resource Name
- Optionally, enter the Description
- Select the Container Type, either Init Container (or) Standard Container. Standard Container is selected by default

Similar to Create Deployments, provide all the mandatory values and optionally, enter the required details.

- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/daemon-general.png)](https://docs.rafay.co/dashboard/img/k8sresources/daemon-general.png)

On successful creation, you can view the DaemonSet as shown below

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/daemon-list.png)](https://docs.rafay.co/dashboard/img/k8sresources/daemon-list.png)

For more details, refer [DaemonSets](https://kubernetes.io/docs/concepts/workloads/controllers/daemonset/)

---

### Create Jobs

To create Jobs, perform the following steps:

- Select a cluster and click the Resources tab
- Select **Jobs** under the **Deployment Resources** and click **Create Job**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create-job.png)](https://docs.rafay.co/dashboard/img/k8sresources/create-job.png)

**Job : Create** screen appears

By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a job

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/job_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/job_yaml.png)

**Form** allows to select and enter the required data

- Select the Namespace and enter the Resource Name
- Optionally, enter the Description
- Select the Container Type, either Init Container (or) Standard Container. Standard Container is selected by default

Similar to Create DaemonSets, provide all the mandatory values and optionally, enter the required details.

- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/form_job.png)](https://docs.rafay.co/dashboard/img/k8sresources/form_job.png)

On successful creation, you can view the Job as shown below

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/job-list.png)](https://docs.rafay.co/dashboard/img/k8sresources/job-list.png)

For more details, refer [Jobs](https://kubernetes.io/docs/concepts/workloads/controllers/job/)

---

### Create CronJobs

To create CronJobs, perform the following steps:

- Select a cluster and click the Resources tab
- Select **CronJobs** under the **Deployment Resources** and click **Create CronJob**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create_cj.png)](https://docs.rafay.co/dashboard/img/k8sresources/create_cj.png)

**CronJob : Create** screen appears

By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a cronjob

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/cj_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/cj_yaml.png)

**Form** allows to select and enter the required data

- Select the Namespace and enter the Resource Name
- Optionally, enter the Description
- Enter the **Schedule** to run the job in a specific time interval. For example, **0 0 13 * 5**: task must be started every Friday at midnight, as well as on the 13th of each month at midnight
- Select the Container Type, either Init Container (or) Standard Container. Standard Container is selected by default

Similar to Create Jobs, provide all the mandatory values and optionally, enter the required details.

- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/cj_form.png)](https://docs.rafay.co/dashboard/img/k8sresources/cj_form.png)

On successful creation, you can view the CronJob as shown below

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/cj_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/cj_list.png)

For more details, refer [CronJob](https://kubernetes.io/docs/concepts/workloads/controllers/cron-jobs/)

---

## Load Balancers

### Create Ingress

To create Ingress, perform the following steps:

- Select a cluster and click the Resources tab
- Select **Ingress** under the **Load Balancers**
- Click **Create Ingress**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create_ingress.png)](https://docs.rafay.co/dashboard/img/k8sresources/create_ingress.png)

**Ingress : Create** screen appears

By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create an Ingress

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/ingress_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/ingress_yaml.png)

**Form** allows to select and enter the required data

- Select the **Namespace** and enter the **Resource Name**
- Optionally, enter the **Description**
- Optionally add **Rules**
  - Enter the **Request Host** details. If a host is provided, the rules is applied only to that specific host (or) rule gets applied to all inbound HTTP traffic through the IP address specified
  - Click **Add Path** and select the required **Path Type** from the drop-down. Each path has an associated backend defined with a `service.name` and a `service.port.name` or `service.port.number`. You can add one or more paths. Both the host and path must match the content of an incoming request before the load balancer directs traffic to the referenced Service

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/ingress_rules.png)](https://docs.rafay.co/dashboard/img/k8sresources/ingress_rules.png)

- Optionally, add **Default Backend**. The Default Backend is conventionally a configuration option of the Ingress controller. Select the required Target Service from the drop-down and Port.

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/ingress_defaultbackend.png)](https://docs.rafay.co/dashboard/img/k8sresources/ingress_defaultbackend.png)

- Optionally add **Certificates** (if available) for security purpose
- Optionally add **Labels**, and **Annotations**
- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/cert_lab_annot.png)](https://docs.rafay.co/dashboard/img/k8sresources/cert_lab_annot.png)

- On successful creation, the resource is displayed in the Ingress list

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/ingress_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/ingress_list.png)

For more details, refer [Ingress - K8s Resource](https://kubernetes.io/docs/concepts/services-networking/ingress/)

---

### Create Services

To create Services, perform the following steps:

- Select a cluster and click the Resources tab
- Select **Services** under the **Load Balancers**
- Click **Create Service**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create_services.png)](https://docs.rafay.co/dashboard/img/k8sresources/create_services.png)

**Service : Create** screen appears. Five (5) secret templates are available, allowing the users to select the required template

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/service_templates.png)](https://docs.rafay.co/dashboard/img/k8sresources/service_templates.png)

Here is an illustrative example of one template to create a Cluster IP

**Cluster IP**

- By default, Yaml config screen appears. You can directly add the required parameters to this config file and create a Cluster IP

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/service_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/service_yaml.png)

- Form allows to select and enter the required data
  - Select the **Namespace** and enter the **Resource Name**
  - Provide the required details
- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/cluster_ip.png)](https://docs.rafay.co/dashboard/img/k8sresources/cluster_ip.png)

- On successful creation, the resource is displayed in the Services List

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/service_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/service_list.png)

For more details, refer [Service - K8s Resource](https://kubernetes.io/docs/concepts/services-networking/service/)

---

## Config & Storage Resources

### Create Secret

A Secret is a Kubernetes object designed to hold small amounts of sensitive data, like passwords, tokens, or keys. By utilizing Secrets, users can avoid embedding confidential information directly into your application code.

To create Secrets, perform the following steps:

- Select a cluster and click the Resources tab
- Select **Secrets** under the **Config & Storage**
- Click **Create Secret**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create_secret.png)](https://docs.rafay.co/dashboard/img/k8sresources/create_secret.png)

**Secret : Create** screen appears. Five (5) secret templates are available, allowing the users to select the required template

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/secret_templates.png)](https://docs.rafay.co/dashboard/img/k8sresources/secret_templates.png)

Here is an illustrative example of one template to create a secret

**Opaque**

Opaque is the default Secret type and the users can create the secrets in two ways using the Opaque template

- By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a secret

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/opaque-yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/opaque-yaml.png)

- **Form** allows to select and enter the required data
  - Select the **Namespace** and enter the **Resource Name**
  - Provide one or more Data
  - Optionally, add Labels and Annotations
- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/form_opaque.png)](https://docs.rafay.co/dashboard/img/k8sresources/form_opaque.png)

- On successful creation, the resource is displayed in the Secrets list

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/secret_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/secret_list.png)

Refer [Types of Secret](https://kubernetes.io/docs/concepts/configuration/secret/#secret-types) for more information on each template

---

### Create PVCs

A PersistentVolumeClaim (PVC) is a storage request, resembling a Pod's resource request for node allocation.

To create PVCs, perform the following steps:

- Select a cluster and click the Resources tab
- Select **PVCs** under the **Config & Storage**
- Click **Create PersistentVolumeClaim**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create_pvc.png)](https://docs.rafay.co/dashboard/img/k8sresources/create_pvc.png)

**PersistentVolumeClaim : Create** screen appears.

- By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a PVC

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/pvc_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/pvc_yaml.png)

- **Form** allows to select and enter the required data
  - Select the **Namespace** and enter the **Resource Name**
  - Provide the **Volume Claim** details (Storage Class and Request Storage)
  - Click **Customize** and select the required **Access Mode(s)

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/pvc_form.png)](https://docs.rafay.co/dashboard/img/k8sresources/pvc_form.png)

- Click **Create**
- On successful creation, the resource is displayed in the PersistentVolumeClaims list

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/pvc_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/pvc_list.png)

For more details, refer [Persistent Volume Claim (PVC) - K8s Resource](https://kubernetes.io/docs/concepts/storage/persistent-volumes/)

---

### Create ConfigMap

A ConfigMap is used to store non-confidential data in key-value pairs.

To create ConfigMap resource, perform the following steps:

- Select a cluster and click the Resources tab
- Select **ConfigMaps** under the **Config & Storage**
- Click **Create ConfigMap**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create_configmap.png)](https://docs.rafay.co/dashboard/img/k8sresources/create_configmap.png)

**ConfigMap : Create** screen appears

- By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a ConfigMap

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/yam_configmap.png)](https://docs.rafay.co/dashboard/img/k8sresources/yam_configmap.png)

- **Form** allows to select and enter the required data
  - Select the **Namespace** and enter the **Resource Name**
  - Provide one or more Data
  - Optionally, add Labels and Annotations
- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/form-configmap.png)](https://docs.rafay.co/dashboard/img/k8sresources/form-configmap.png)

- On successful creation, the resource is displayed in the ConfigMaps list

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/configmap_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/configmap_list.png)

---

### Create HorizontalPodAutoscalers

HorizontalPodAutoscaler is to automatically adjust a workload resource, such as a Deployment or StatefulSet, in response to changes in demand. Its goal is to ensure that the workload dynamically scales up or down to match the current demand efficiently.

To create HorizontalPodAutoscalers, perform the following steps:

- Select a cluster and click the Resources tab
- Select **HorizontalPodAutoscalers** under the **Config & Storage**
- Click **Create HorizontalPodAutoscalers**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/hpa_create.png)](https://docs.rafay.co/dashboard/img/k8sresources/hpa_create.png)

**HorizontalPodAutoscalers : Create** screen appears

- By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a HorizontalPodAutoscalers

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/hpa_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/hpa_yaml.png)

- **Form** allows to select and enter the required data
  - Select a **Target Reference** and provide minimum/maximum replicas
  - Provide the required metrics (source, resource name, type, and quantity)
  - Optionally, add Labels and Annotations
- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/hpa_form.png)](https://docs.rafay.co/dashboard/img/k8sresources/hpa_form.png)

- On successful creation, the resource is displayed in the HorizontalPodAutoscaler list

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/hpa_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/hpa_list.png)

---

## Access Control Resources

### Roles

To create roles, perform the following steps:

- Select a cluster and click the Resources tab
- Select **Roles** under the **Access Control**
- Click **Create Role**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create_role.png)](https://docs.rafay.co/dashboard/img/k8sresources/create_role.png)

**Role : Create** screen appears

- By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a role

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/yaml_role.png)](https://docs.rafay.co/dashboard/img/k8sresources/yaml_role.png)

- **Form** allows to select and enter the required data
  - Select the **Namespace** and enter the **Resource Name**
  - Provide one or more Resource Data with API Groups
- Click **Create**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/fill_roles.png)](https://docs.rafay.co/dashboard/img/k8sresources/fill_roles.png)

- On successful creation, the resource is displayed in the Roles list

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/resource_new.png)](https://docs.rafay.co/dashboard/img/k8sresources/resource_new.png)

---

### RoleBindings

To create RoleBindings, perform the following steps:

- Select a cluster and click the Resources tab
- Select **RoleBindings** under the **Access Control**
- Click **Create RoleBinding**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/create_rb.png)](https://docs.rafay.co/dashboard/img/k8sresources/create_rb.png)

**RoleBinding : Create** screen appears

- **Yaml** config screen appears. You can directly add the required parameters to this config file and create a RoleBinding

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/rbs_yaml.png)](https://docs.rafay.co/dashboard/img/k8sresources/rbs_yaml.png)

- Click **Create**
- On successful creation, the resource is displayed in the RoleBindings list

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/rb_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/rb_list.png)

---

### ServiceAccounts

To create ServiceAccounts, perform the following steps:

- Select a cluster and click the Resources tab
- Select **ServiceAccounts** under the **Access Control**
- Click **Create ServiceAccount**

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/sa_create.png)](https://docs.rafay.co/dashboard/img/k8sresources/sa_create.png)

**ServiceAccount : Create** screen appears

- By default, **Yaml** config screen appears. You can directly add the required parameters to this config file and create a ServiceAccount

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/yaml_sacc.png)](https://docs.rafay.co/dashboard/img/k8sresources/yaml_sacc.png)

- **Form** allows to select and enter the required data   [![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/sa_form.png)](https://docs.rafay.co/dashboard/img/k8sresources/sa_form.png)
  - Select a **Namespace** and enter a name
  - Optionally, enable the **Automount Service Account Token**
  - Select one or more Image Pull Secret
  - Optionally, add Labels and Annotations
- Click **Create**
- On successful creation, the resource is displayed in the ServiceAccounts list

[![Namespace Types](https://docs.rafay.co/dashboard/img/k8sresources/sa_list.png)](https://docs.rafay.co/dashboard/img/k8sresources/sa_list.png)

---
