---
title: "KOP Dashboard - Kubernetes Events"
source: https://docs.rafay.co/dashboard/events/
category: Home
---

# Kubernetes Events

When required, administrators can view Kubernetes events as they are generated on the cluster using the integrated Cluster Dashboard's capabilities.

---

## Direct Access

The Console provides a convenience feature that cluster administrators can use to instantly view the Kubernetes Events.

- Simply click on the "Events" on the cluster card.

[![k8s Events Cluster Card](https://docs.rafay.co/dashboard/img/events/clusters_events.png)](https://docs.rafay.co/dashboard/img/events/clusters_events.png)

This will take the user directly to the Resources page prefiltered with the events view. An illustrative example is shown below

[![Kubernetes Events](https://docs.rafay.co/dashboard/img/events/k8s_events.png)](https://docs.rafay.co/dashboard/img/events/k8s_events.png)

---
