---
title: "Rafay Platform Documentation"
source: https://docs.rafay.co/
category: Home
---

# 👋 The Three Pillars of the Rafay Platform

- 🚀 Cloud-Native Automation (CNA) Manage the lifecycle of cloud infrastructure and services at scale. CNA enables teams to automate Kubernetes and infrastructure provisioning, enforce governance, and implement self-service workflows.   [**Get Started**](https://docs.rafay.co/learn/overview/)
  - [Environment Workflow Automation](https://docs.rafay.co/env_manager/overview/)
  - [Kubernetes Cluster Lifecycle](https://docs.rafay.co/clusters/clusters/)
  - [Standardization, Governance & Policies](https://docs.rafay.co/services/overview/)
  - [Common Use Cases](https://docs.rafay.co/usecases/overview/)
  - [Releases](https://docs.rafay.co/releasenotes/release_information/)
  - [Public Roadmap](https://github.com/orgs/RafaySystems/projects/3/views/1)
- 🧠 GPU PaaS for AI/ML & GenAI Rapidly transform your infrastructure into a GPU-powered, multi-tenant platform for AI, ML, and GenAI workloads. Create SKUs for AI Infrastructure and AI/ML tooling and provide users with a self service experience.   [**Get Started**](https://docs.rafay.co/learn/overview/)
  - [Overview](https://docs.rafay.co/aiml/gpupaas/overview/)
  - [AI Infrastructure](https://docs.rafay.co/aiml/overview/#ai-infrastructure-skus)
  - ![🛠](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/1f6e0.svg) [AI/ML Tools, MLOps, LLMOps](https://docs.rafay.co/aiml/overview/#aiml-app-skus)
  - [PaaS API](https://docs.rafay.co/aiml/gpupaas/api/gpu_api.html)
  - [Integrations](https://docs.rafay.co/aiml/gpupaas/integrations/)
  - ![🛒](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/1f6d2.svg) [App Marketplace](https://docs.rafay.co/aiml/overview/#app-marketplace)
  - ![🖌](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/1f58c.svg) [White Labeling](https://docs.rafay.co/aiml/gpupaas/csp/overview/)
  - [Releases](https://docs.rafay.co/releasenotes/gpu_release_information/)
- 🧱 Core Platform The foundation for everything: robust APIs, automation, integrations, and full-stack lifecycle support with enterprise-grade controls and flexibility.   [**Start Here**](https://docs.rafay.co/intro/architecture/)
  - [Developer Tools](https://docs.rafay.co/automation/overview/)
  - [Integrations](https://docs.rafay.co/integrations/overview/)
  - [Validated Solutions](https://docs.rafay.co/recipes/overview/)
  - [Security](https://docs.rafay.co/security/overview/)
  - [Support Matrix](https://docs.rafay.co/supportmatrix/support_matrix/)
  - [Self Hosted Platform](https://docs.rafay.co/selfhosted/overview/)
