---
title: "Environment Manager - Security Scanning"
source: https://docs.rafay.co/env_manager/security/
category: Home
---

# Security Scanning

Security scanning for infrastructure resources can be included in Environment Manager through the use of [tfsec](https://aquasecurity.github.io/tfsec/latest/) as a hook within EM Resource Templates.

---

## Create Image

You will first need to create a custom tfsec container image that will be run within your Environment Manager Agent during Environment build operations. This container will be used to scan the infrastructure terraform code for vulnerabilities. This image is based off of the official tfsec image.

Save the following script as **security.sh**

```
cd /tmp
curl -H "X-Engine-Helper-Token:$DOWNLOAD_TOKEN" -o ./job.tar.zst $DOWNLOAD_URL
unzstd ./job.tar.zst
mkdir terraform
tar -xf job.tar -C ./terraform
ls -al ./terraform
tfsec ./terraform/$TF_PATH
```

Save the following docker file as **Dockerfile**

```
FROM aquasec/tfsec:latest

USER root

COPY security.sh /

RUN chmod +x /security.sh

RUN apk add zstd

RUN apk add curl

ENTRYPOINT ["ash","/security.sh"]
```

Use the Docker CLI to build the image

```
docker build -t <docker hub username>/security:1.0 .
```

Push the image to a repository. The below command pushes to Docker Hub

```
docker push <docker hub username>/security:1.0
```

---

## Configure Hooks

You will add a hook to each resource in the environment where security scanning is needed

In the Rafay console:

- Navigate to **Environments -> Resource Templates**
- Locate and select the resource template for the resource where the hook will be added
- Click **New Version**
- Navigate to **Hooks -> Terraform Hooks -> Plan**
- Click **Add Hook**
- Enter **security** for the name
- Select **Before**
- Select **Container** for the hook type
- Enter **100** for the CPU limit
- Enter the image location of the image you pushed earlier
- Enter **500** for the memory limit
- Enter **/security/** for the working directory path
- Enter the following success condition

```
if #status.container.exitCode == 0 {
                            success: true
                        }
                        if #status.container.exitCode != 0  {
                            failed: true
                        }
```

- Click **Add Environment Variable**
- Enter **DOWNLOAD_TOKEN** for the key
- Enter **(resource."<resource template name>".artifact.workdir.token)** for the value being sure to update the resource template name
- Click **Add Environment Variable**
- Enter **DOWNLOAD_URL** for the key
- Enter **(resource."<resource template name>".artifact.workdir.url)** for the value being sure to update the resource template name
- Click **Add Environment Variable**
- Enter **TF_PATH** for the key
- Enter the path of the Terraform code of the resource for the value (ex. aws/resources/vpc-ec2)
- Click **Save Changes**

[![Hook](https://docs.rafay.co/env_manager/img/security/hook1.png)](https://docs.rafay.co/env_manager/img/security/hook1.png)

- Click **Save as Active Version**

---

## Verify Configuration

You can view the security scan results of a resource by viewing the tfsec activity of the resource in the run of an environment the resource is part of. An illustrative example is shown below.

[![Scan Results](https://docs.rafay.co/env_manager/img/security/scan.png)](https://docs.rafay.co/env_manager/img/security/scan.png)

---
