---
title: "Environment Fleet Management - Fleet Plans"
source: https://docs.rafay.co/env_manager/fleet_plan/
category: Home
---

# Environments

The Environment Fleet Management feature provides a way to perform bulk operations across multiple environments in parallel. It is designed for scenarios where users manage many active environments and need consistent updates, visibility, and control at scale. Using fleet plans, users can define environment targets through filters (projects, templates, and labels), configure common actions such as variable updates, template version changes, or resource operations, and schedule these updates with controlled concurrency. This enables reliable, efficient, and trackable management of large environment fleets without manual intervention on individual environments.

---

## New Fleet Plan

Use the Fleet Plans page to create and configure a new plan for managing multiple environments in parallel.

- In the left navigation pane, select **Fleet Plans -> Environments**
- Click **New Fleet Plan**
- In the dialog box:
  - **Name**: Enter a unique identifier for the fleet plan (e.g., `env-fleet`)
  - **Resource Type**: Select Environment
- Click **Create** to proceed

[![Service Mesh Dashboard](https://docs.rafay.co/env_manager/img/env_fleets.png)](https://docs.rafay.co/env_manager/img/env_fleets.png)

### General Information

This section displays the basic details of the fleet plan provided during creation.

- Name: The unique identifier of the fleet plan (e.g., env-fleet).
- Resource Type: The selected resource type. For environment fleet plans, this is fixed to environments.

[![Service Mesh Dashboard](https://docs.rafay.co/env_manager/img/fleet_general.png)](https://docs.rafay.co/env_manager/img/fleet_general.png)

---

## Operation Workflow

The **Operation Workflow** defines the sequence of operations or tasks that a fleet plan will execute on the selected environments. Operations can be configured step by step and support different lifecycle actions such as upgrading template versions, updating variables, or managing resources.

### Step 1: Access the Operation Workflow Section

- From the Fleet Plan, select the **Operation Workflow** tab and click **+ Operation Workflow** to create a new operation.

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/opsw_1.png)](https://docs.rafay.co/env_manager/img/opsw_1.png)

- Select the **Operation Type**

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/ops_act_2.png)](https://docs.rafay.co/env_manager/img/ops_act_2.png)

#### Available Operation Types

The following operation types are supported:

- **Update Environment Template Version**: Switches the selected environments to a different version of their template. ***Example***: If environments are based on template **T1**, this action allows updating them to a newer version of **T1**.

> Note: Available only when all selected environments are derived from the same template.

- **Update Input Variables**: Updates the values of environment input variables defined within the template.
  - Multiple variables can be updated in a single operation.
  - Supported value types: **Text**, **JSON**, **HCL**, and **Expression**.

> Note: Available only when all selected environments are derived from the same template.

- **Redeploy**: Re-deploys all resources that belong to the selected environments. Works for environments derived from **single** or **multiple** templates.
- **Destroy**: Destroys all resources that belong to the selected environments. Works for environments derived from **single** or **multiple** templates.

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/ops_types.png)](https://docs.rafay.co/env_manager/img/ops_types.png)

#### Single-Template vs Multi-Template Operations

- **Single-template operations**:
  - Update Environment Template Version
  - Update Input Variables

These operations can only be executed when all target environments are based on a single template and version.

- **Multi-template operations**:
  - Redeploy
  - Destroy

These operations work regardless of whether environments are based on one or multiple templates.

### Step 2: Operation Configuration

Each operation supports the following fields:

- **Operation Name**: Identifier for the operation.
- **Description**: Optional details about the operation.
- **Continue on Failure**: If enabled, the workflow proceeds even if this operation fails. If disabled, execution stops at the point of failure.
- **Configuration**: Operation-specific parameters such as:
  - **Version** (for Template Version Update) [![Operation Workflow tab](https://docs.rafay.co/env_manager/img/temps_ver.png)](https://docs.rafay.co/env_manager/img/temps_ver.png)
  - **Variable Key, Value, and Value Type** (for Input Variable Update) [![Operation Workflow tab](https://docs.rafay.co/env_manager/img/envmnt_vars.png)](https://docs.rafay.co/env_manager/img/envmnt_vars.png)

After saving, operations appear in the Operation Workflow list. [![Operation Workflow tab](https://docs.rafay.co/env_manager/img/op_list.png)](https://docs.rafay.co/env_manager/img/op_list.png)

---

## Environment Filters

This section allows you to define which environments are included in the fleet plan by applying filters. The filtering works at three levels:

- **Projects (Mandatory)** – You must select at least one project.
- **Labels (Mandatory)** – You must also apply label filters to further narrow down environments.
- **Templates (Optional)** – You can add a template filter to refine the selection.

> ⚠️ Note: The operations list supports only a single environment template (ET)–based operation. This means only one template filter can be applied at a time.

Once the filters are selected:

- All matching environments appear under **Target Environments**.
- If multiple projects are chosen, the list aggregates environments from all of them.
- Applying labels further narrows down the target set.
- Adding a template filter (if used) restricts results to environments created from that specific template and version.

The **Target Environments** table displays the final computed list of environments based on the applied filters, along with their labels, template name, and version.

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/env_filters.png)](https://docs.rafay.co/env_manager/img/env_filters.png)

---

## Adding a Schedule

You can configure schedules for your fleet plan using the **Add Schedule** wizard. A schedule allows you to automatically deploy environments based on a defined frequency.

### General

- **Name**: Enter a unique name for the schedule.
- **Description**: (Optional) Provide a description to identify the schedule’s purpose.

### Frequency

Define how often the schedule should run:

- **One Time**: The schedule will run once.
  - **Time to Live (TTL)**: Specify how long (in hours/days) the deployed environment should remain active.
  - **Time Zone**: Specify the time zone for the schedule.
- **Recurring**: The schedule will repeat at the defined interval.
  - **Cron Expression**: You can specify a cron expression for fine-grained scheduling.
  - **Time Zone**: Select the time zone for the recurrence.

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/fleet_schedule.png)](https://docs.rafay.co/env_manager/img/fleet_schedule.png)

Click **Save**

> ⚠️ Important:
> The system automatically uses a default batch size of 5 environments when processing deployments.

**YAML and Form Options**

In the Fleet Plan page, you can choose between two modes to define or update configurations:

- **Form** – Provides a structured, guided UI to input values.
- **YAML** – Allows direct editing of the YAML definition for advanced users.

When you click **YAML**, the editor opens up the raw YAML view of the Fleet Plan

***Error Handling Between YAML and Form***

If a user inputs incorrect or invalid information directly in the YAML, those errors may not automatically translate into the Form view.

In such cases, when switching back to the Form, a dialog box will appear indicating that the YAML contains errors that are not compatible with the form view.

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/fleet_yaml.png)](https://docs.rafay.co/env_manager/img/fleet_yaml.png)

Once operations are defined, click **Save and Review Changes**

---

## Properties Page

Once a Fleet Plan is **saved**, users are redirected to the **Properties** page. This page provides a summary of the configuration defined in the plan.

The following details are displayed:

- **Projects**: The selected project(s) associated with the fleet plan
- **Resources**: The resources linked to the fleet plan
- **Labels**: Labels applied to the fleet plan for identification and filtering
- **Operations**: The configured operation(s). This includes the number of operations defined in the workflow
- **Template**: The template used, if applicable
- **Schedules**: Displays the recurring schedules, if any. If no schedules are defined, it will show *“No recurring schedules.”*

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/fleets-completed.png)](https://docs.rafay.co/env_manager/img/fleets-completed.png)

---

## Run the Fleet

Click the **Run** button to start a fleet job. The job will then appear in the list with its execution details.

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/jobs_list.png)](https://docs.rafay.co/env_manager/img/jobs_list.png)

### Job Overview

Clicking the eye icon in the Actions column opens the Job Overview page. This view provides detailed insights into the selected job run. The job execution summary provides a snapshot of resource statuses, including the total number of resources and their state. Supported states include:

- **Success** – The resource completed execution successfully.
- **Failed** – The resource execution failed.
- **Pending** – The resource is queued and awaiting execution.
- **Waiting** – The resource is waiting for available capacity to execute.
- **In Progress** – The resource is currently being executed.
- **Skipped** – The resource execution was skipped.
- **Cancelled** – The resource execution was cancelled.

A pie chart visualization and counters show the distribution across these states.

[![Operation Workflow tab](https://docs.rafay.co/env_manager/img/action_status.png)](https://docs.rafay.co/env_manager/img/action_status.png)

Once a job is successfully executed, the associated environments are updated based on the operations defined in the job. Users can then verify the Environments page to confirm the status of each applied action.

---
