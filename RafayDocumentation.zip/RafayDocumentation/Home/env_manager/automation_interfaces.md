---
title: "KOP Environment Manager - Automation Interfaces"
source: https://docs.rafay.co/env_manager/automation_interfaces/
category: Home
---

# Overview

In addition to UI, Environment Manager Lifecycle can be managed through other methods.

- [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/environment)
- [GitOps](https://docs.rafay.co/env_manager/gitops_v3spec/)
- [Swagger API](https://console.rafay.dev/openapi-explorer#/Environment%20List)
- [CLI](https://docs.rafay.co/env_manager/cli/)

---

- For more information on Rafay's Terraform Provider, refer [here](https://registry.terraform.io/providers/RafaySystems/rafay/latest)
- For more information on Rafay's Swagger APIs, refer [here](https://docs.rafay.co/gitops/stages/system_sync/)
- For more information on GitOps System Sync capability, refer [here](https://docs.rafay.co/automation/api/apis/)
- For more information on RCTL CLI capability, refer [here](https://docs.rafay.co/cli/overview/)
