---
title: "Day-2 Operations for Template-Based Clusters"
source: https://docs.rafay.co/env_manager/day-2-ops/
category: Home
---

# Manage Template-Based Clusters

## Cluster Dashboard Behavior for Template-Based Clusters

Clusters provisioned using **Environment Templates** are visually distinguished in the Rafay Console to help platform admins and field users identify operational constraints and supported actions.

Clusters launched through the Environment Manager are tagged with a `Template` label next to the cluster type in the **Cluster Dashboard**. These template-based clusters follow a restricted operational model to maintain configuration consistency.

Key differences from traditionally managed clusters:

- Basic **Day-2 operations** such as editing labels, modifying system components, and updating blueprints are blocked from the Cluster page UI. However, these operations can still be performed through the Environment Manager, maintaining full control via the environment template flow.
- **Cluster Configuration** downloads are disabled.
- Only the associated **Environment Configuration** can be downloaded for reference or audit purposes.

This design ensures a consistent and predictable state by relying exclusively on template-driven management.

---

## UI Behavior for Template-Based Clusters

Template-based clusters are identified in the dashboard with a dedicated `Template` tag. The available actions for these clusters differ from standard clusters.

- In the cluster card, the `Template` tag appears next to the cluster type (e.g., Azure AKS).
- From the **Settings** menu, only the following limited options are available for clusters created using the template-based method:
- **Download Env Config**
- **Download ZTKA Config**
- **Alerts Settings**

Other Day-2 operation options such as **Update Blueprint**, **Edit Labels**, **Download Cluster Config**, **Add/Remove Nodes**, **Upgrade K8s Version**, and others (as seen in non-template-based clusters) are not available.

Below is an example screenshot of a template-based cluster in the UI:

[![Template-Based Cluster Dashboard](https://docs.rafay.co/env_manager/img/template_clusters.png)](https://docs.rafay.co/env_manager/img/template_clusters.png)

> ⚠️ Important Note
> - These restrictions are applied to avoid configuration drift and ensure that all lifecycle operations are driven via the defined environment template flow.
> - This behavior applies to all clusters provisioned through templates, regardless of the underlying cloud provider (e.g., AKS, EKS, GKE).
> - These restrictions are enforced across all interfaces: UI, RCTL, API, and Terraform.

---
