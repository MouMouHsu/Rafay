---
title: "KOP Environment Manager - Workflow"
source: https://docs.rafay.co/env_manager/workflow/
category: Home
---

# Workflow

The typical workflow for Environment Manager is as outlined below:

[![Environment Manager](https://docs.rafay.co/env_manager/img/workflow.png)](https://docs.rafay.co/env_manager/img/workflow.png)

## Step 1

- Platform Team creates [Resource Blueprints/Templates](https://docs.rafay.co/env_manager/templates/resource_templates/) in a central project. A resource blueprint/template is a templatized resource IaC (e.g. RDS resource). The resource blueprint/template will point to the IaC artifact in the Git repository

> **Info**
> Refer to the instructions [here](https://docs.rafay.co/integrations/repositories/overview/) to create a repository object within Rafay

## Step 2

- Platform team then creates an [Environment Blueprint/Template](https://docs.rafay.co/env_manager/templates/environment_templates/). Environment Blueprint/Template can include one or more Resource Blueprints/Templates and/or Static Resources

## Step 3

- Platform team shares environment blueprints/templates as appropriate with downstream projects (which developers or SREs) will have access to with [Environment Template User role](https://docs.rafay.co/env_manager/envmgr_rbac/)

## Step 4

- Developers/SREs provision full stack operating environments for applications as required

## Note:

- An [Agent](https://docs.rafay.co/integrations/repositories/agents/) needs to be associated as part of the Resource Blueprint/Template, Environment Blueprint/Template and/or Environment configuration. Deploy the agent on machines/systems where execution needs to run
- Use [Static Resources](https://docs.rafay.co/env_manager/templates/static_resource/) if existing resource(s) need to be referenced in an environment blueprint/template
- Use [Context](https://docs.rafay.co/env_manager/templates/contexts/) to define variables that are used across resource blueprint/templates and/or environment blueprints/templates

---
