---
title: "KOP Environment Manager - Terraform Enterprise/Cloud integration"
source: https://docs.rafay.co/env_manager/tfe_tfc_integration/
category: Home
---

# HCP Terraform integration

Environment Manager offers seamless 'out of box' integration with Terraform Enterprise/Cloud through the **HCP Terraform** provider option. This allows platform teams to leverage their existing investments in Terraform IaC and Terraform Enterprise/Cloud deployments while enabling a "self service" experience for internal users to provision operating environments for their applications.

With this integration, Platform team can:

- Define Templates (Resource Templates/Environments Templates) that are necessary to bring up full stack operating environments within Rafay. The templates can also include the required guardrails/policies
- Expose a self-service service interface for downstream users (e.g. developers) to consume the environment templates through Rafay
- Manage versioning of resource/environment templates and necessary environment updates (Day 2 Ops) through Rafay
- Configure integration with HCP Terraform so that infrastructure provisioning (based on the environment template) is handled by HCP Terraform and state is also stored within HCP Terraform

End users (e.g. Developers, SREs, Data Scientists) can provision environments (as necessary) for their applications with the required overrides (e.g. region or instance type) that are allowed by the platform team.

---

## Platform Team

```
sequenceDiagram
autonumber
    actor P as Platform Team
    participant R as Rafay
    participant T as HCP Terraform
    Note over P,T: Configure integration
    T->>P: Retrieve credentials
    P->>R: Configure HCP details (Credentials, Project, Workspace)
    P->>R: Publish Environment Template
```

---

## End Users

```
sequenceDiagram
autonumber
    actor D as Developer/SRE/Data Scientist
    participant R as Rafay
    participant T as HCP Terraform
    participant C as Cloud Provider
    D->>R: Provision Environment <br> (Select Env Template, Provide Overrides)
    Note over T: Project/Workspace
    R->>T: IaC
    T->>C: Provision Infrastructure <br> (Using Agent Pool)
    T->>T: Store Terraform State
    T->>R: Infrastructure Ready
    R->>D: Environment provisioned
```

---

## Configuring HCP Terraform integration

To leverage Terraform Enterprise/Cloud to provision infrastructure and as a state store, follow the steps outlined below:

- Select **HCP Terraform** provider option in the resource template and supply the Workflow Handler details

For instructions on building a workflow handler for HCP Terraform, please refer [here](https://docs.rafay.co/env_manager/templates/resource_templates/)

- Add the **Cloud** block to your Terraform integration. You can define it's arguments in the configuration file or supply them as environment variables

### Note

- Pre and post hook operations for TF plan step is not supported
- Interactive approval of plan before TF apply is not supported

---
