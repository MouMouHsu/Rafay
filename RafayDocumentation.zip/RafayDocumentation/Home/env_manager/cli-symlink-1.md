---
title: "KOP Environment Manager - CLI"
source: https://docs.rafay.co/env_manager/cli-symlink-1/
category: Home
---

# CLI

Users can use RCTL to automate the lifecycle of operations associated with Resource Blueprints/Templates, Environment Blueprints/Templates, Contexts, and Environments.

---

## Context

### Create Context

To create a config context, use the below command.

```
./rctl apply -f <demo-context.yaml>
```

Below is an example of a Context Config YAML file:

```
apiVersion: eaas.envmgmt.io/v1
kind: ConfigContext
metadata:
  name: demo-context
  project: defaultproject
  description: demo-description
spec:
  envs:
  - key: RCTL_REST_ENDPOINT
    options:
      description: demo-description
      override:
        restrictedValues:
        - qc-console.stage.rafay.dev
        - console-user1-env1.dev.rafay-edge.net
        - console.stage.rafay.dev
        - console.rafay.dev
        type: restricted
      required: true
      selectors:
        - selector1
        - selector2
    value: qc-console.stage.rafay.dev
  - key: RCTL_API_KEY
    options:
      override:
        type: allowed
      required: true
      sensitive: true
    value: rctl_api_key
  - key: RCTL_API_SECRET
    options:
      override:
        type: notallowed
      sensitive: true
    value: rctl_api_secret
  - key: DRIVER_DEBUG
    options:
      override:
        restrictedValues:
        - "true"
        - "false"
        type: restricted
    value: "false"
  files:
  - data: dmFsdWU=
    name: config.json
    options:
      description: config file
      override:
        type: allowed
      required: true
  variables:
  - name: rafay_config_file
    value: config.json
    valueType: text
```

### Get Config Context

Use the below command to retrieve/list the Config Contexts in the current project.

```
./rctl get configcontext
```

***Example***

```
./rctl get configcontext   
+--------------------+--------------------------------+---------+
| CONFIGCONTEXT NAME | MODIFIED AT                    | SHARING |
+--------------------+--------------------------------+---------+
| config-context-1   | 2024-06-20 09:28:40.441923     | -       |
|                    | +0000 UTC                      |         |
+--------------------+--------------------------------+---------+
| demo-context-1   | 2024-06-20 08:28:40.441923       | -       |
|                    | +0000 UTC                      |         |
+--------------------+--------------------------------+---------+
```

**Get Specific Config Context**

Use this command to retrieve a specific config context detailed information.

```
./rctl get configcontext <context_name>
```

***Example***

```
./rctl get configcontext demo-context-1
+--------------------+--------------------------------+---------+
| CONFIGCONTEXT NAME | MODIFIED AT                    | SHARING |
+--------------------+--------------------------------+---------+
| demo-context-1     | 2024-06-20 08:28:40.441923     | -       |
|                    | +0000 UTC                      |         |
+--------------------+--------------------------------+---------+
```

### Delete Config Context

Use the below command to delete a specific config context

```
./rctl delete configcontext <demo-context>
```

---

## Resource Template

### Create Resource Template

To create a resource template, use the below command.

```
./rctl apply -f <resource-template.yaml>
```

Below is an example of a Resource Template YAML file:

```
apiVersion: eaas.envmgmt.io/v1
kind: ResourceTemplate
metadata:
  description: This is a resource template
  name: demo-resource-temp
  project: demo-project
spec:
  agents:
  - name: sp-agent1
  contexts:
  - name: demo-context
  provider: opentofu
  providerOptions:
    workflowHandler:
      name: demo-WorkflowHandler
    openTofu:
      backendConfigs:
      - key=tmp3
      - bucket=demo-eaas1
      - region=us-west-2
      - encrypt=true
      backendType: custom
  repositoryOptions:
    branch: main
    directoryPath: terraform-guides/infrastructure-as-code/aws-ec2-instance
    name: demo-envmgr
  version: v1
```

#### Resource Template with Overrides

Overrides in resource templates allow specific fields to be customized while maintaining the integrity of system-provided configurations. This is particularly useful when users need to provide custom values for components such as repository settings or backend configurations without altering the base resource template.

The override capability is governed by the `allowedPaths` field, which defines **JSONPath** fields that can be overridden. These can include both specific fields (for example, `providerOptions.terraform.backendType`) and parent fields (such as `repositoryOptions`) within the resource template specification. Only the paths specified in `allowedPaths` are eligible for overrides from environment templates, and these values are merged with the underlying resource template specification at runtime during environment provisioning.

The following resource template fields (including their child fields) are supported for override:

- `artifactWorkflowHandler`
- `providerOptions` (limited to the chosen provider; for example, overrides for `terraform` cannot be applied to `opentofu`)
- `repositoryOptions`
- `hooks`

***Example***

```
apiVersion: eaas.envmgmt.io/v1
kind: ResourceTemplate
metadata:
  name: demo-rt1
  description: Test resource template for null provider with overrides
  project: defaultproject
spec:
  version: v1
  provider: terraform
  providerOptions:
    terraform:
      backendType: custom
  repositoryOptions:
    name: test-terraform
    branch: main
    directoryPath: demo-directory
  versionState: draft
  overrides:
    allowedPaths:
    - repositoryOptions
    - providerOptions.terraform.backendType
```

In this example:

- The `repositoryOptions` and `providerOptions.terraform.backendType` fields are marked as overrideable.
- When this resource template is used within an environment template, only these fields can be overridden during provisioning.
- Any attempt to override fields not listed in `allowedPaths` will result in validation failure.
- For parent fields such as `repositoryOptions`, overrides must provide the complete object that matches the required schema structure, including fields like `name`, `branch`, and `directoryPath`. Partial or incorrectly structured overrides will cause errors.

> Note
> - Only paths defined in allowedPaths are eligible for override.
> - Override values are optional. If no override is provided in the environment template, the resource template defaults will be applied.
> - When overriding parent fields, ensure the structure fully aligns with the schema expected in the resource template.

**Limitations**

- **Inline container workflow handler files**:
  - Files or node selectors with a `.` in their names cannot be overridden for inline workflow handlers
- **Inline container workflow handler tolerations**:
  - If the toleration operator is changed from `equal` to `exists`, there is no way to leave the toleration value empty through the UI
  - When the operator is `exists`, specifying a toleration value always causes an error during environment deployment

### Get Resource Templates

Use the below command to retrieve/list the resource templates in the current project.

```
./rctl get resourcetemplate
```

***Example***

```
./rctl get resourcetemplate   
+--------------------------+-----------------------+------------------+--------------------------------+---------+
| RESOURCE TEMPLATE NAME   | LATEST ACTIVE VERSION | RESOURCE TYPE    | MODIFIED AT                    | SHARING |
+--------------------------+-----------------------+------------------+--------------------------------+---------+
| sample-resource-template | version-1             | ResourceTemplate | 2024-06-20 09:33:57.615714     | -       |
|                          |                       |                  | +0000 UTC                      |         |
+--------------------------+-----------------------+------------------+--------------------------------+---------+
| demo-resource-template   | version-2             | ResourceTemplate | 2024-06-20 08:33:57.615714     | -       |
|                          |                       |                  | +0000 UTC                      |         |
+--------------------------+-----------------------+------------------+--------------------------------+---------+
```

**Get a Specific Resource Template**

Use this command to retrieve a specific resource template detailed information.

```
rctl get resourcetemplate <resourcetemp_name>
```

***Example***

```
./rctl get resourcetemplate sample-resource-template
+--------------------------+-----------------------+------------------+--------------------------------+---------+
| RESOURCE TEMPLATE NAME   | LATEST ACTIVE VERSION | RESOURCE TYPE    | MODIFIED AT                    | SHARING |
+--------------------------+-----------------------+------------------+--------------------------------+---------+
| sample-resource-template | version-1             | ResourceTemplate | 2024-06-20 09:33:57.615714     | -       |
|                          |                       |                  | +0000 UTC                      |         |
+--------------------------+-----------------------+------------------+--------------------------------+---------+
```

### Delete Resource Template

Use the below command to delete a specific Resource Template

```
./rctl delete resourcetemplate <demo-resource-temp>
```

---

## Environment Template

### Create Environment Template

To create an environment template, use the below command.

```
./rctl apply -f <environment-template.yaml>
```

Below is an example of an Environment Template YAML file:

```
apiVersion: eaas.envmgmt.io/v1
kind: EnvironmentTemplate
metadata:
  name: envmgr-1
  project: defaultproject
  description: This is an environment template
  displayName: demo-environment-template
  annotations:
    eaas.envmgmt.io/category: AWS,Nvidia,AI/ML
    envmgmt.io/project-limits: "2"
  labels:
    env: qc
    release: stable
spec:
  agentOverride:
    required: true
    restrictedAgents:
    - sp-scale
    - sp-agent1
    type: restricted # Supported values are allowed, notallowed and restricted
  agents:
  - name: sp-scale
  contexts:
  - name: sp1
  - name: sp2
  hooks:
    onFailure:
    - agents:
      - name: sp-agent1
      workflowHandler:
        name: sp-art
      name: onfailure-workflowHandler
      onFailure: continue
      timeoutSeconds: 3600
      type: workflowHandler
    onInit:
    - agents:
      - name: sp-agent1
      name: oninit-approval
      onFailure: continue
      options:
        approval:
          type: internal
      timeoutSeconds: 3600
      type: approval
    - agents:
      - name: sp-agent1
      dependsOn:
      - oninit-approval
      name: oninit-container
      onFailure: continue
      options:
        container:
          arguments:
          - -refresh=false
          - --log-level=2
          commands:
          - /bin/sh
          - -c
          cpuLimitMilli: "512"
          envvars:
            DOWNLOAD_TOKEN: "token"
            DOWNLOAD_URL: "url"
          image: docker.io/demouser569/security:1.1
          memoryLimitMB: "1024"
          successCondition: |-
            if #status.http.statusCode == 200 {
              success: true
            }
            if #status.http.statusCode != 200 {
              failed: true
              reason: "url not reachable"
            }
          workingDirPath: /security/
      timeoutSeconds: 3600
      type: container
    onSuccess:
    - agents:
      - name: sp-agent1
      name: onsuccess-http
      onFailure: continue
      options:
        http:
          body: <h1>This is a heading</h1>
          endpoint: https://httpbin.org
          headers:
            Content-type: application/json
            X-TOKEN: 1234
          method: GET
          successCondition: |-
            if #status.http.statusCode == 200 {
              success: true
            }
            if #status.http.statusCode != 200 {
              failed: true
              reason: "url not reachable"
            }
      timeoutSeconds: 3600
      type: http
  iconURL: iconurl
  readme: |-
    This is an
    environment template
    with all options
  resources:
  - kind: resourcetemplate
    name: sp-rt-hcp
    resourceOptions:
      dedicated: true
      version: v1
    type: dynamic
  - kind: resource
    name: sp-stat
    type: static
  - kind: environment
    name: sp-env
    type: static
  - kind: resourcetemplate
    name: sp-tf1
    resourceOptions:
      version: v1
    type: dynamic
  - dependsOn:
    - name: tf1
    kind: resourcetemplate
    name: sp-rt-tf
    resourceOptions:
      version: v1
    type: dynamic    
  variables:
  - name: cluster_details
    options:
      description: Enter one or more cluster name(s)
      override:
        type: allowed
      required: false
    value: 'cluster1,cluster2'
    valueType: text
  - name: aws_cloud_provider_name
    options:
      description: Enter the cloud credential name
      override:
        type: allowed
      required: true
    value: '[sp]'
    valueType: hcl
  - name: aws_cloud_provider_access_key
    options:
      override:
        type: allowed
      sensitive: true
    value: accesskey
    valueType: text
  - name: aws_cloud_provider_secret_key
    options:
      override:
        type: notallowed
      sensitive: true
    value: secretkey
    valueType: text
  - name: eks_cluster_project
    options:
      override:
        restrictedValues:
        - sp
        - defaultproject
        - sp-git-sync
        type: restricted
    value: defaultproject
    valueType: text
  - name: eks_blueprint
    options:
      override:
        type: allowed
    value: '{"default"}'
    valueType: json
  - name: rafay_config_file
    options:
      override:
        type: notallowed
    value: config.json
    valueType: text
  - name: eks_cluster_name
    options:
      override:
        type: allowed
    value: $(environment.name)$
    valueType: expression    
  version: v1
  sharing:
    enabled: true
    projects:
    - name: a1
```

#### Override Resource Configuration in Environment Templates

System provided environment templates use resource templates with locked configurations to ensure consistency and supportability. However, some fields in these resource templates can be overridden directly from the environment template. This provides flexibility when specific values need to be changed without modifying the original resource template.

This is useful when:

- A different backend type needs to be used for a Terraform provider
- The directory path of a Git repository needs to be updated
- Any other supported fields must be customized while continuing to use system templates

Below is a sample configuration where two resource templates are associated with an environment template. Each resource uses the `overrides.values` field to change specific parts of its configuration.

```
apiVersion: eaas.envmgmt.io/v1
kind: EnvironmentTemplate
metadata:
  name: demo-et1
  project: defaultproject
  createdAt: '2025-03-14T09:49:17.109625Z'
  modifiedAt: '2025-03-14T11:27:21.868522Z'
  createdBy:
    id: 7dkgjkx
    username: [email protected]
  modifiedBy:
    id: 7dkgjkx
    username: [email protected]
spec:
  version: v2
  resources:
    - type: dynamic
      kind: resourcetemplate
      name: demo-resource1
      resourceOptions:
        version: v1
      overrides:
        values:
          repositoryOptions.directoryPath: null-provider
    - type: dynamic
      kind: resourcetemplate
      name: demo-resource2
      resourceOptions:
        version: v1
      overrides:
        values:
          repositoryOptions:
            name: demo-terraform
            branch: main
            directoryPath: null-provider
          providerOptions.terraform.backendType: system
  versionState: draft
```

In the above configuration:

- For the first resource, the directory path of the repository is changed
- For the second resource, both the repository values and the backend type for the Terraform provider are overridden

> Note
> - Only explicitly listed paths in allowedPaths can be overridden.
> - Override values are optional. If not provided in the environment template, the values from the resource template are used.
> - Each override path must match the expected structure and data type. Invalid paths or mismatched types will result in an error.

### Get Environment Template

Use the below command to retrieve/list the Environment Templates in the current project.

```
./rctl get environmenttemplate
```

***Example***

```
./rctl get environmenttemplate
+---------------------------+-----------------------+----------------+--------------------------------+---------+
| ENVIRONMENT TEMPLATE NAME | LATEST ACTIVE VERSION | RESOURCE COUNT | MODIFIED AT                    | SHARING |
+---------------------------+-----------------------+----------------+--------------------------------+---------+
| sample-test-template      | v1                    | 1              | 2024-06-20 04:46:31.130737     | -       |
|                           |                       |                | +0000 UTC                      |         |
+---------------------------+-----------------------+----------------+--------------------------------+---------+
| demo-template             | v2                    | 1              | 2024-06-20 03:46:31.130737     | -       |
|                           |                       |                | +0000 UTC                      |         |
+---------------------------+-----------------------+----------------+--------------------------------+---------+
```

Get a Specific Environment Template

Use this command to retrieve a specific environment template detailed information.

```
./rctl get environmenttemplate <envtemp_name>
```

***Example***

```
./rctl get environmenttemplate demo-template
+---------------------------+-----------------------+----------------+--------------------------------+---------+
| ENVIRONMENT TEMPLATE NAME | LATEST ACTIVE VERSION | RESOURCE COUNT | MODIFIED AT                    | SHARING |
+---------------------------+-----------------------+----------------+--------------------------------+---------+
| demo-template             | v2                    | 1              | 2024-06-20 03:46:31.130737     | -       |
|                           |                       |                | +0000 UTC                      |         |
+---------------------------+-----------------------+----------------+--------------------------------+---------+
```

### Delete Environment Template

Use the below command to delete a specific Environment Template

```
./rctl delete environmenttemplate <demo-env-temp>
```

---

## Workflow Handler

To create a Workflow Handler, use the below command

```
./rctl create workflowhandler -f workflow-handler.yaml
```

(or)

```
./rctl apply -f workflow-handler.yaml
```

Below is an example of a Workflow Hanlder YAML file of **Container** type:

```
apiVersion: eaas.envmgmt.io/v1
kind: WorkflowHandler
metadata:
  name: workflowhandler-container
  project: default
spec:
  config:
    type: container
    container:
      arguments:
      - -h
      - -v
      commands:
      - /bin/bash
      cpuLimitMilli: "200"
      memoryLimitMb: "512"
      envVars:
        ENV_VAR1: "env1"
        ENV_VAR2: "env2"
      image: alpine
      imagePullCredentials:
        registry: ecr.example.com
        username: [email protected]
        password: password
      files:
        config.ini: cmVwb3J0aW5nLWRpc2FibGVkID0gdHJ1ZQpiaW5kLWFkZHJlc3MgPSAiOjgwODgiCgpbbWV0YV0KICBkaXIgPSAiL3Zhci9saWIvZGF0YS9tZXRhIgogIHJldGVudGlvbi1hdXRvY3JlYXRlID0gdHJ1ZQogIGxvZ2dpbmctZW5hYmxlZCA9IHRydWU=
      kubeConfigOptions:
        outOfCluster: true
        kubeConfig: "apiVersion: v1\nclusters:\n- cluster:\n    certificate-authority-data: LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUMvakNDQWVhZ0F3SUJBZ0lCQURBTkJna3Foa2lHOXcwQkFRc0ZBREFWTVJNd0VRWURWUVFERXdwcmRXSmwKY201bGRHVnpNQjRYRFRJeU1EY3lNREV4TXpZd05Wb1hEVE15TURjeE56RXhNell3TlZvd0ZURVRNQkVHQTFVRQpBeE1LYTNWaVpYSnVaWFJsY3pDQ0FTSXdEUVlKS29aSWh2Y05BUUVCQlFBRGdnRVBBRENDQVFvQ2dnRUJBTUhYCmlmbFp5SSt4aCtteHNQd3RQdWV0UDhQaUNwOW9MclBTQ3VwWjZybFg5TnJZZVlqWCtxVSsxZHVwQzlpcGlzcU0KNGJvcUxqNDU5aVJFOFBuQ0JUVVZEY3RsUTFGLzUvbVFwbHQvbU5yNmxiVG94NWdmeFpsSUIyS2l2bmtxWXhQSgowUklCQVhkSS9xS3B1Z1duajNjeSt6ZDhBNXpqak9IUmdrcG5xMFVWUm1lWXh5U01hellCelZ2MjM3ZCtwemRlCkNMVldNd2t2clZKOVNoNm5yUzN0T2FyU0liOUwwVGdMSjRDRytReHg5eHIzSzRwd01jMTFwbjhxMkpobDJJUEcKUUZEaVllSGFFUTF1Tzd6RHJEWlloYWxTaHJzcnB1RU04UDJZb2lXdmIwZnoySys0WlM0aWhvYkJnUnQ4UmUwcgphY29UV3o0R1FTKzdOeVcwU2dVQ0F3RUFBYU5aTUZjd0RnWURWUjBQQVFIL0JBUURBZ0trTUE4R0ExVWRFd0VCCi93UUZNQU1CQWY4d0hRWURWUjBPQkJZRUZFSUNkRGpjNlF4YlNUQlpPRUFXeEpxSGtLU1ZNQlVHQTFVZEVRUU8KTUF5Q0NtdDFZbVZ5Ym1WMFpYTXdEUVlKS29aSWh2Y05BUUVMQlFBRGdnRUJBSER2Mi85QkU2SGVoTVZCUDRPcgo4Zm15a0NtbmhBUjhHUkNOV2Zkc3BkYzVWczBuMnVCTFE4M0FoREtwc0lxZTFZNTZ3ZHBreHpucElTN0J0L2pFCnVmYzZSeFJZMUhFQzBEcS9TdklTMFRSZ01wK2U4eTR4STJSVkFIVVBsMUdpQWYrTEpQNjlyZ0doZ1dwdkk0aU0KR0V3OXVQbGM1UXZMTjRSbE1MNTUyOFJtWWtRM1FtRzBsZ0NFZHpVNDZNRE1qL3NJOWdqOTNpN0lLSDlJYUhZZQpNaUhwZTc0bFBKcStKR3BoU3NPTk8vSUk1MmZjODRnVlNjZWJvNnd2Njh3OFRESnpIVlFIVkkzeHJiaVI5V3Z4CncvSEhteUtpZjViRFlMSzRFcC92S0cwbVRXaVgxdmZyYjc0MTl4aHdONzhob0JzVXhDOU1xTmFlMlIwbE1LYkMKczhnPQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCg==\n    server: https://example-cluster-name.dev.example.com\n  name: example-cluster-name.dev.example.com\ncontexts:\n- context:\n    cluster: example-cluster-name.dev.example.com\n    user: [email protected]@example-cluster-name.dev.example.com\n  name: [email protected]@example-cluster-name.dev.example.com\ncurrent-context: [email protected]@example-cluster-name.dev.example.com\nkind: Config\npreferences: {}\nusers:\n- name: [email protected]@example-cluster-name.dev.example.com\n  user:\n    exec:\n      apiVersion: client.authentication.k8s.io/v1beta1\n      args:\n      - token\n      - -i\n      - costmgmt-dashboard\n      command: aws-iam-authenticator\n      env:\n      - name: STS_REGIONAL_ENDPOINTS\n        value: regional\n      - name: DEFAULT_REGION\n        value: us-west\n      provideClusterInfo: false\n"
      kubeOptions:
        labels:
          email: [email protected]
          region: us-west
        namespace: default
        nodeSelector:
          kubernetes.io/os: linux
        serviceAccountName: alpine-svc
        tolerations:
        - effect: NoSchedule
          key: region
          operator: Equal
          value: us-east
        - effect: NoExecute
          key: region
          operator: Equal
          value: us-east
          tolerationSeconds: 3600
        - effect: PreferNoSchedule
          key: kubernetes.io/arch
          operator: Equal
          value: arm64
      volumes:
      - mountPath: /mnt/volume1
        usePVC: false
      workingDirPath: /user/ubuntu/
```

Below is an example of a Workflow Hanlder YAML file of **HTTP** type:

```
apiVersion: eaas.envmgmt.io/v1
kind: WorkflowHandler
metadata:
  name: workflowhandler-http
  project: default
spec:
  config:
    type: http
    http:
      endpoint: "/api/v1/object"
      method: POST
      body: ""
```

Below is an example of a Workflow Hanlder YAML file of **Function** type:

```
apiVersion: eaas.envmgmt.io/v1
kind: WorkflowHandler
metadata:
  name: workflowhandler-function
  project: default
spec:
  config:
    type: function
    function:
      language: python
      source: "import os\nimport logging\n\n# Set up logging\nlogging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')\n\n# Read environment variable\nmy_env_var = os.getenv('MY_ENV_VAR', 'default_value')  # Default value if the env var is not set\n\n# Log and print messages\nlogging.info('Starting the script...')\nlogging.debug(f'Read environment variable MY_ENV_VAR: {my_env_var}')\n\n# Example of using the environment variable in your code\nif my_env_var == 'some_value':\n    logging.info('The environment variable has the expected value.')\nelse:\n    logging.warning('The environment variable does not have the expected value.')\n\n# Print to console\nprint(f'The environment variable MY_ENV_VAR is: {my_env_var}')"
      languageVersion: "3.13"
      cpuLimitMilli: "50"
      memoryLimitMb: "128"
      maxConcurrency: 10
      numReplicas: 1
      skipBuild: {}
```

> ℹ️ Important Note:
> Users who have been using drivers in the specification must update their configuration to use workflow_handlers instead, as drivers will be deprecated soon.

### Get Workflow Handler

Use the below command to retrieve/list the Workflow Handlers in the current project.

```
./rctl get workflowhandler
```

***Example***

```
./rctl get workflowhandler
+-----------------------------+-----------------------+-----------------------------------------------------------------------+
| WORKFLOW HANDLER NAME       | WORKFLOW HANDLER TYPE | WORKFLOW HANDLER DETAILS                                              |
+-----------------------------+-----------------------+-----------------------------------------------------------------------+
| workflowhandler-function    | function              | language:"python"  source:"import                                     |
|                             |                       | os\nimport logging\n\n# Set up                                        |
|                             |                       | logging\nlogging.basicConfig(level=logging.DEBUG,                     |
|                             |                       | format='%(asctime)s - %(levelname)s                                   |
|                             |                       | - %(message)s')\n\n# Read environment                                 |
|                             |                       | variable\nmy_env_var = os.getenv('MY_ENV_VAR',                        |
|                             |                       | 'default_value')  # Default value if the                              |
|                             |                       | env var is not set\n\n# Log and print                                 |
|                             |                       | messages\nlogging.info('Starting the                                  |
|                             |                       | script...')\nlogging.debug(f'Read environment                         |
|                             |                       | variable MY_ENV_VAR: {my_env_var}')\n\n#                              |
|                             |                       | Example of using the environment variable in                          |
|                             |                       | your code\nif my_env_var == 'some_value':\n                           |
|                             |                       |    logging.info('The environment variable                             |
|                             |                       | has the expected value.')\nelse:\n                                    |
|                             |                       | logging.warning('The environment variable                             |
|                             |                       | does not have the expected value.')\n\n#                              |
|                             |                       | Print to console\nprint(f'The environment                             |
|                             |                       | variable MY_ENV_VAR is: {my_env_var}')"                               |
|                             |                       | languageVersion:"3.13"  cpuLimitMilli:"50"                            |
|                             |                       |  memoryLimitMb:"128"  skipBuild:{}                                    |
|                             |                       | maxConcurrency:10  numReplicas:1                                      |
+-----------------------------+-----------------------+-----------------------------------------------------------------------+
| workflowhandler-http        | http                  | endpoint:"/api/v1/upload"                                             |
|                             |                       |  method:"POST"                                                        |
|                             |                       | headers:{key:"API-KEY"                                                |
|                             |                       | value:""}                                                             |
+-----------------------------+-----------------------+-----------------------------------------------------------------------+
| workflowhandler-container   | container             | image:"alpine"  arguments:"-h"  arguments:"-v"                        |
|                             |                       |  commands:"/bin/bash"  envVars:{key:"ENV_VAR1"                        |
|                             |                       |  value:""}  envVars:{key:"ENV_VAR2"                                   |
|                             |                       |  value:""}  files:{key:"config.ini"                                   |
|                             |                       | value:""}  workingDirPath:"/user/ubuntu/"                             |
|                             |                       |  cpuLimitMilli:"200"  memoryLimitMb:"512"                             |
|                             |                       |  kubeConfigOptions:{outOfCluster:true}                                |
|                             |                       |  kubeOptions:{namespace:"default"                                     |
|                             |                       |  serviceAccountName:"alpine-svc"                                      |
|                             |                       | labels:{key:"email"  value:"[email protected]"}                       |
|                             |                       |  labels:{key:"region"  value:"us-west"}                               |
|                             |                       |  nodeSelector:{key:"kubernetes.io/os"                                 |
|                             |                       | value:"linux"}  tolerations:{key:"region"                             |
|                             |                       |  operator:"Equal"  value:"us-east"                                    |
|                             |                       | effect:"NoSchedule"}  tolerations:{key:"region"                       |
|                             |                       |  operator:"Equal"  value:"us-east"                                    |
|                             |                       | effect:"NoExecute"  tolerationSeconds:3600}                           |
|                             |                       |  tolerations:{key:"kubernetes.io/arch"                                |
|                             |                       |  operator:"Equal"  value:"arm64"                                      |
|                             |                       |  effect:"PreferNoSchedule"}}                                          |
|                             |                       | imagePullCredentials:{registry:"ecr.example.com"                      |
|                             |                       |  username:"[email protected]"}                                         |
|                             |                       | volumes:{usePVC:{}  mountPath:"/mnt/volume1"}                         |
+-----------------------------+-----------------------+-----------------------------------------------------------------------+
```

**Get a Specific Workflow Handler**

Use this command to retrieve details of a specific workflow handler.

```
./ rctl get workflowhandler <workflowhandler-name>
```

***Example***

```
./ rctl get workflowhandler workflowhandler-http
+-----------------------------+-----------------------+-----------------------------------------------------------------------+
| WORKFLOW HANDLER NAME       | WORKFLOW HANDLER TYPE | WORKFLOW HANDLER DETAILS                                              |
+-----------------------------+-----------------------+-----------------------------------------------------------------------+
| workflowhandler-http        | http                  | endpoint:"/api/v1/upload"                                             |
|                             |                       |  method:"POST"                                                        |
|                             |                       | headers:{key:"API-KEY"                                                |
|                             |                       | value:""}                                                             |
+-----------------------------+-----------------------+-----------------------------------------------------------------------+
```

### Delete Workflow Handler

To delete a workflow handler, use the command below

```
./rctl delete workflowhandler <workflowhandler-name>
```

---

## Environment

### Create Environment

To create an environment, use the below command

```
./rctl apply -f environment.yaml
```

Below is an example of an Environment YAML file:

```
apiVersion: eaas.envmgmt.io/v1
kind: Environment
metadata:
  description: This is an environment
  name: demo-env
  project: defaultproject
spec:
  template:
    name: demo-env1
    version: v1
```

### Partial resource deployment

By default, when an environment is deployed or redeployed, all resources defined in the environment template are processed. In use cases like failover, where only specific resources (e.g., DNS) need to be updated, this leads to increased execution time.

To optimize this, use the `reconcile_resources` field in the environment spec to specify only the resources that should be reconciled.

> ⚠️ Note: This configuration option is currently accessible only via CLI, Swagger API, and Terraform. UI support will be available in an upcoming release.

***Key behavior***:

- If `reconcile_resources` is specified, only those resources (and their dependent resources) are reconciled
- If left empty or omitted, all resources will be processed
- During destroy, all resources are always destroyed, regardless of this field

Below is an example of an environment spec using the `reconcile_resources` field to specify resources for reconciliation:

```
apiVersion: eaas.envmgmt.io/v1
kind: Environment
metadata:
  name: demo-environment
  project: defaultproject
spec:
  template:
    name: demo-template
    version: v8
  agents:
  - name: demo-agent
  reconcile_resources:
  - name: demo-resource1
```

### Get Environment

Use the below command to retrieve/list the Environments in the current project.

```
./rctl get environment
```

***Example***

```
./rctl get environment                             
+----------------------------+----------------------+------------------+----------+
| ENVIRONMENT NAME           | ENVIRONMENT TEMPLATE | TEMPLATE VERSION | STATUS   |
+----------------------------+----------------------+------------------+----------+
| eks-em-testing             | sample-test-template | v5               | StatusOK |
+----------------------------+----------------------+------------------+----------+
| demo-env                   | demo-template        | v4               | StatusOK |
+----------------------------+----------------------+------------------+----------+
```

**Get a Specific Environment**

Use this command to retrieve an environment detailed information.

```
./rctl get environment <env_name>  
```

***Example***

```
./rctl get environment eks-em-testing                           
+----------------------------+----------------------+------------------+----------+
| ENVIRONMENT NAME           | ENVIRONMENT TEMPLATE | TEMPLATE VERSION | STATUS   |
+----------------------------+----------------------+------------------+----------+
| eks-em-testing             | sample-test-template | v5               | StatusOK |
+----------------------------+----------------------+------------------+----------+
```

### Deploy Environment

To deploy an environment created using the template(s) and other configurations, use the command below

```
./rctl deploy environment <demo-env>
```

### Destroy Environment

Use the command below to remove the environment resources; however, this will not delete the environment

```
./rctl destroy environment demo-env
```

### Delete Environment

To delete an environment completely, use the command below

```
./rctl delete environment demo-env
```

---
