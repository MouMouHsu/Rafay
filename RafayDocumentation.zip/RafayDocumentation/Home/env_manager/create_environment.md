---
title: "KOP Environment Manager - Create Environment"
source: https://docs.rafay.co/env_manager/create_environment/
category: Home
---

# Create

> **Did you know ?**
> Environments can be managed using the following methods:
>
> - UI
> - CLI

Create an environment from a template.

## Launch Environment

- Navigate to **Environments -> Environments** within a project to access the environment templates
- Click on the **Launch** button corresponding to the desired template

[![Driver](https://docs.rafay.co/env_manager/img/env_launch.png)](https://docs.rafay.co/env_manager/img/env_launch.png)

- Enter a name and an optional description for the environment template
- Choose an **Environment Version** from the available options

## Add Agent

- Click **Add Agent** and select the required agent if no agents have been added to the Environment Template or Resource Template
- Add one or more [Agent Pool(s)](https://docs.rafay.co/gitops/gitops_agentpool/) from the drop-down

[![Driver](https://docs.rafay.co/env_manager/img/env_temp_config.png)](https://docs.rafay.co/env_manager/img/env_temp_config.png)

- Click **Add Label** to add additional labels to the environment. By default, labels from the selected environment template are displayed if they were defined during environment template creation
- Fill in the **Parameters**. Additional Parameters can be added as needed. Users can override the existing information

[![Driver](https://docs.rafay.co/env_manager/img/save_continue.png)](https://docs.rafay.co/env_manager/img/save_continue.png)

> 🔔 Important Information: Form-Based Parameter Configuration
> For input variables configured with Value Type set to JSON or HCL in the associated Environment Template, parameters can be edited using the Edit icon during environment creation.
> When a JSON schema is defined for such variables:
> 
> Selecting the Edit icon opens a form-based editor
> The form displays only the fields defined in the JSON schema
> Field types such as dropdowns, toggles, and add/remove controls are rendered based on the schema
> 
> 
> After making the required changes in the form-based editor, click Update to apply the updated values.
> If a JSON schema is not defined for a JSON or HCL parameter:
> 
> Selecting the Edit icon opens the raw JSON or HCL editor
> Parameters follow the existing manual input behavior
> 
> For parameters configured with Value Type set to Text or Expressions:
> 
> Selecting the Edit icon opens the raw input editor
> No form-based rendering is available
> 
> Form-based rendering occurs only when a valid JSON schema is present and strictly reflects the structure and default values defined in the environment template.

Refer below for details on each field

| Setting | Description |
| --- | --- |
| Name | Enter a name for the environment |
| Description | Enter a description for the environment |
| Environment Template | Select an environment template to use to create an environment |
| Environment Template Version | Select the version to use to create an environment |
| Agents | Select one or more agents for running the environment provisioning tasks |
| Labels | Add labels to the environment, along with any labels defined during environment template creation |
| Parameters | Provide the environment parameters (example: instance configuration parameters such as disk type, disk size, and region) |

> 🔔 Important Note:  
> Input variables are organized into sections according to the Grouping Section settings defined in the Environment Template Input Variables. The order of these sections follows the Order/Weight value, with lower numbers appearing first.  
> Input Variables that are added but not assigned an Order/Weight or Section will be placed under the "Others" category.

- Once all the required parameters are provided, click **Save & Deploy**. Alternatively, click **Save & Continue later** to provide some parameters later or continue the deployment at a later time.

### Schedules

If the schedules are defined in the associated environment template, they will be available on the environment page, allowing users to opt out of these scheduled actions. The table displays the scheduled actions associated with the current environment. It includes the following details for each scheduled action:

- Task Name: The name of the scheduled action, such as "Destroy-ec2-instance" or "Create-ec2-instance." This describes the operation that will be performed
- Next Scheduled Trigger: Indicates the exact time and date when the next action will be triggered. The time is displayed based on the local timezone, which may vary depending on the region
- Action Link: A clickable option to allow the user to opt out of the scheduled task. By selecting "Do you want to opt out?", the user can prevent the specific action from being triggered at the scheduled time

[![Driver](https://docs.rafay.co/env_manager/img/schedules_env.png)](https://docs.rafay.co/env_manager/img/schedules_env.png)

To modify specific scheduled actions, click **Do you want to opt out?** next to the desired schedule in the environment configuration. This option allows you to delay the scheduled tasks, providing flexibility in managing the schedule associated with your environment.

- Select the required duration and click **Opt Out**

The configuration context attached to the schedules will appear under environment input variables when the schedules are triggered.

[![Driver](https://docs.rafay.co/env_manager/img/input_variables.png)](https://docs.rafay.co/env_manager/img/input_variables.png)

- Click **Deploy**

The scheduled action will be deferred for the specified duration, preventing it from being triggered within that period.

[![Driver](https://docs.rafay.co/env_manager/img/edit_schedules.png)](https://docs.rafay.co/env_manager/img/edit_schedules.png)

> Note: If the environment template does not include any schedules, the opt-out options will not be displayed, and the status will be shown as "Not scheduled"

The deployment section indicates the current status and upcoming scheduled actions related to the environment, with the next schedule displaying the immediate action (e.g., "Destroy-ec2-instance") and its trigger time, typically within the next 24 hours. Users can opt out of this immediate action if needed.

- View the status **In Progress**

[![Driver](https://docs.rafay.co/env_manager/img/env_deploying.png)](https://docs.rafay.co/env_manager/img/env_deploying.png)

- Once the deployment is complete, the status changes to **Success**

[![Driver](https://docs.rafay.co/env_manager/img/envment_success.png)](https://docs.rafay.co/env_manager/img/envment_success.png)

Once the environments are deployed, they will be listed in the right pane along with the activities performed on them. The activity section displays the events executed by various users.

[![Driver](https://docs.rafay.co/env_manager/img/env_list.png)](https://docs.rafay.co/env_manager/img/env_list.png)

## Filtering Environments by Status

The **My Environments** page includes a comprehensive filter panel that allows narrowing down environments based on multiple criteria. These filter options help streamline environment management by displaying only those that match the selected criteria:

- **Status**: Filter environments by their current state. Available options include `Active`, `Deleted`, `Inactive`, `Deleted Failed`, `Destroy Failed`, and `Deploy Failed`
- **Environment Template**: Select a specific environment template to view environments created using that template
- **Labels**: Filter environments based on associated labels
- **Versions**: Filter by the version of the environment template used

These filter options help streamline environment management by displaying only those that match the selected criteria.

[![Environment Status Filter](https://docs.rafay.co/env_manager/img/envn_status.png)](https://docs.rafay.co/env_manager/img/envn_status.png)

---

## Selective Resource Reconciliation

During **day 2** operations, redeploying an environment traditionally triggers the redeployment of all associated resources, even if no changes exist. This can result in longer update or failover times.

Selective resource reconciliation enables the redeployment of only specific resources within an environment by specifying the `reconcile_resources` field in the environment specification. This allows targeted redeployment of resources that actually require changes, leaving other resources untouched.

For example, in a failover scenario where only a DNS change is required, it is possible to reconcile just the DNS resource instead of redeploying the entire environment. If no resources are specified in `reconcile_resources`, the system redeploys all resources by default.

This functionality is supported both in the UI and through environment YAML specifications.

### Reconcile Resources in the UI

- From the environment page, select the required environment and click **Edit**.
- In the configuration page, locate the **Reconcile Resources** section.
- Use the drop-down to select the required resource templates for reconciliation.
- Click **Done** to confirm the selection, and then redeploy the environment.

If no resources are selected in this section, the system will deploy all available resources by default.

[![Reconcile Resources](https://docs.rafay.co/env_manager/img/reconciling_1.png)](https://docs.rafay.co/env_manager/img/reconciling_1.png)

### YAML Specification

Selective resource reconciliation can also be configured directly in the environment YAML specification using the `reconcile_resources` field. Specify the resources that need to be reconciled during day 2 operations.

**Example:**

```
apiVersion: eaas.envmgmt.io/v1
kind: Environment
metadata:
  name: test-env
  project: defaultproject
spec:
  template:
    name: test-np-et
    version: with-action
  agents:
    - name: docker-2502
  reconcile_resources:
    - name: test-np-rt
```

> Note: If a full redeployment is needed later, resources listed under Reconcile Resources must be removed manually before executing the Deploy action again.

---

## Force Unlock for Terraform Resource Templates

When using a **Resource Template** defined with Terraform or Tofu within an **Environment Template**, and this environment is published, a series of activities are triggered, where all these activities are executed by the **CD Agent**.

### Execution Flow

1. During environment publication, Terraform is used to apply the resource configurations
2. As part of the `terraform apply` process, Terraform first acquires a **state lock** to prevent concurrent modifications
3. Once the lock is acquired, Terraform begins provisioning the defined resources (e.g., an EC2 instance in AWS)

If the Terraform activity is interrupted for any reason (e.g., network issues, process termination, or unexpected errors):

- Terraform may acquire the lock but fail to complete the provisioning
- This can cause Terraform to exit abruptly, leaving the lock on hold
- On subsequent attempts to publish the environment, Terraform will try to acquire the lock again but will fail, resulting in an error

> ❗ Note: If the user encounter a lock-related error during publishing, refer to the specific error message for details. In such cases, you may need to manually remove the stale lock using terraform force-unlock icon.

### Force Unlock

To force unlock,

- Navigate to the **Environments** page in the UI
- Click on the **expand icon** next to the environment to view the execution logs and actions

[![Driver](https://docs.rafay.co/env_manager/img/expan_icon.png)](https://docs.rafay.co/env_manager/img/expan_icon.png)

- Select the required Environment and click on the **Force Unlock** icon to manually clear the Terraform state lock

[![Driver](https://docs.rafay.co/env_manager/img/unlocks.png)](https://docs.rafay.co/env_manager/img/unlocks.png)

A side panel titled Unlock Status appears, where users need to select the resource templates that are currently locked.

- Choose the appropriate resource templates from the dropdown and click **Save**. This will initiate the release lock process

[![Driver](https://docs.rafay.co/env_manager/img/select_restemp.png)](https://docs.rafay.co/env_manager/img/select_restemp.png)

- To view the status of a force lock release, select the desired environment and click **View All Runs**
- A list of recent lock release runs, along with their statuses, will be displayed

[![Driver](https://docs.rafay.co/env_manager/img/view_run.png)](https://docs.rafay.co/env_manager/img/view_run.png)

After the Release Lock run is complete, publish the environment again.

---

## Destroy or Delete an Environment

An environment can be **destroyed**, which removes the provisioned resources from the cloud provider but retains the environment record in the Environment Manager, or **deleted**, which removes both the resources and the environment metadata completely.

The delete (trash) icon is enabled only for environments in the **Active** or **Deleted Failed** status.

- For environments with **Active** status, deleting the environment will remove all resources, including any partially provisioned ones, and delete the environment record.

[![Delete Environment Confirmation](https://docs.rafay.co/env_manager/img/delete_envs.png)](https://docs.rafay.co/env_manager/img/delete_envs.png)

- For environments with **Deleted Failed** status, the deletion process allows removing only the environment object from the Environment Manager while leaving resources intact, which should be used cautiously.

[![Delete Environment Confirmation](https://docs.rafay.co/env_manager/img/deleted_fail.png)](https://docs.rafay.co/env_manager/img/deleted_fail.png)

Click the trash icon next to the environment name to begin the delete process. In the confirmation dialog, review the details and enter the environment name to confirm deletion. Then select **Delete this Environment** to proceed.

> 🔔 Important Note: Retention of Deleted Environments
> When an environment is deleted, it is initially soft deleted. The environment record, its associated events, runs, and activities, and related files are retained in the database and simply marked as deleted.
> Soft deleted environments that are older than 1 year are automatically and permanently hard deleted on a recurring database cleanup cycle. Hard deletion removes all associated data and cannot be undone or recovered.
> As a result, environments soft deleted more than 1 year ago will no longer appear on the My Environments page under the Deleted status filter.

---
