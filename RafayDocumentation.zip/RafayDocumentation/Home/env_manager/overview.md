---
title: "Environment Manager - Overview"
source: https://docs.rafay.co/env_manager/overview/
category: Home
---

# Overview

Environment Manager enables a self-service model for Development and DevOps teams to create environments while providing the ability for the Central Ops/Platform teams to enforce security, cost, governance guardrails, and standardization.

---

## How does Environment Manager work?

- Using Infrastructure as Code such as Terraform, platform teams can define resource templates and associated configurations such as an EKS Cluster, Redis Cache, S3 Bucket etc.
- Platform teams can then stitch those resource templates together into full-stack templates that contain all the dependencies, policies, and configurations needed to define and deploy applications
- Developers or DevOps teams can use any interface they want such as Rafay UI, GitHub Actions or Backstage to select from these templates and rapidly deploy environments to test applications

[![Environment Manager](https://docs.rafay.co/env_manager/img/env_manager_1.png)](https://docs.rafay.co/env_manager/img/env_manager_1.png)

> **Info**
> It is possible to expose environment blueprints/templates created through Environment Manager to application teams and enable developer self-service through Rafay's Backstage Plugin. More details available [here](https://docs.rafay.co/backstage/overview/)

---

## How does Environment Manager help?

### Typical Workflow in Organizations

For some organizations, it can take months to test and deploy new apps to production because of the overhead involved in the platform teams actioning on requests for environments from the development teams.

- Developers are ready to test new code/application changes but don’t have access to an environment to test them
- Developer has to go through the organization's ticketing process to request for a resource, for example a namespace on an EKS Cluster and a RDS instance
- DevOps has to go back to the developer and find out their needs, why they need the stack, whether it will work with their code or some changes need to be made
- DevOps has to make changes to IaC scripts and validate that with platform and security ops teams, for example to open a port or make some changes to support the developer app
- Eventually, the developer gets access to the infrastructure but has no idea how to use it and refer to certain constructs. For example, if they need to authenticate to a database, what mechanism should be used? There is no golden path and the developer has to spend time getting familiar with infrastructure constructs rather than building and testing code

### Workflow with Environment Manager

With Environment Manager, it is possible to implement the workflow outlined below:

1. **Platform Engineering** defines IaC and Environment Blueprints/Templates:
  - Platform teams define infrastructure and environment blueprints declaratively and make updates via Git. The blueprints are typically located in a central infrastructure project where all the templates are managed, continuously updated, vetted, etc.
  - These templates contain different IaC and Kubernetes manifests in whatever syntax the platform team wants to use - Terraform, RCTL Spec, etc.
  - They include things such as governance policies, input variables needed, etc. The goal is to build templates that define a golden path and meet standards but can also be flexible/reusable to meet different developer needs.
2. **Share Templates With Different Developer Teams** once the templates are created.
  - Platform teams can then offer up these templates to different development teams i.e. different developer projects in Rafay.
  - Developers can deploy environments and point their code to these environments

---

## What does a typical environment stack look like?

| Resource | Description |
| --- | --- |
| Compute | An environment could have the following forms of compute: |
|  | **Shared Cluster / Namespace per Environment**: Developers will deploy environments to a shared cluster that is managed by the Platform Engineering team in the Console with the appropriate isolation and security policies defined. In this context, typically every developer environment is deployed to its own namespace. |
|  | **Dedicated Cluster**: Some Platform Engineering teams may want each developer to have their own dedicated cluster. This can be enabled using Environment Manager. |
| Cache | Example: Redis cache |
| Queue | Example: Kafka queue |
| Object storage | Example: S3 bucket |
| State storage | Use a remote backend configuration to store data state files. If a state is lost, the environment will not know of provisioned resources and the destroy/re-apply command will not work |
| Load balancer | Example: Elastic load balancer |

---
