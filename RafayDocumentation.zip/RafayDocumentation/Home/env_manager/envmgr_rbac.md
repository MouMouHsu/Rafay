---
title: "KOP Environment Manager - RBAC"
source: https://docs.rafay.co/env_manager/envmgr_rbac/
category: Home
---

# RBAC

Properly assigning permissions to users based on their role is a key component for environment management. Creating roles and assigning users to those roles is less prone to error than assigning permissions to individual users.

There are two main personas:

- **Platform Engineers** whose goal is to allow their development and QA teams to move faster and reduce complexity to building and testing apps by providing them with whatever tools, capabilities, and platforms necessary to do so.
- **Developers** whose goal is to deliver value to their customers through new cutting-edge applications. Developers should not be burdened with learning DevOps, cloud infrastructure, or dependency management to deliver their applications. They should be able to write code and point their code to a testbed or environment without worrying about infrastructure.

Environment Manager provides the following role-based access controls.

- Environment Template User
  - Can provision and deprovision environments based on existing environment templates.
  - They cannot create environment templates or resource templates. These are defined by the Infra Admin or Org Admin.
- Infra Admin
  - Responsible for creating environment and resource templates. The overall governance and management of IaC is the Infra Admin's responsibility.
  - Cannot share templates. Sharing templates is done by an Org Admin.
- Org Admin
  - Share environment and resource templates between different projects within the organization.

| Permission | Org Admin | Infra Admin | Env Template User |
| --- | --- | --- | --- |
| Resource and Environment Template Sharing | Yes | No | No |
| Environment Provisioning | Yes | Yes | Yes |
| Environment and Resource Template Creation | Yes | Yes | No |
| Provisioning Workload to Environment | Yes | Yes | No |

---
