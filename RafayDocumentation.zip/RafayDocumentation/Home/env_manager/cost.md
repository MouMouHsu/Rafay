---
title: "Environment Manager - Cost Estimation"
source: https://docs.rafay.co/env_manager/cost/
category: Home
---

# Cost Estimation

Cost Estimation for infrastructure resources can be included in Environment Manager through the use of [Infracost](https://www.infracost.io/) as a hook within EM Resource Templates.

---

## Create Image

You will first need to create a custom Infracost container image that will be run within your Environment Manager Agent during Environment build operations. This container will be used to estimate the infrastructure costs of the EM environment resources. This image is based off of the official Infracost image.

Save the following script as **cost.sh**

```
cd /tmp
curl -H "X-Engine-Helper-Token:$DOWNLOAD_TOKEN" -o ./job.tar.zst $DOWNLOAD_URL
unzstd ./job.tar.zst
mkdir terraform
tar -xf job.tar -C ./terraform
ls -al ./terraform
infracost breakdown --path ./terraform/$TF_PATH
```

Save the following docker file as **Dockerfile**

```
FROM infracost/infracost:ci-0.10

COPY cost.sh /
RUN chmod +x /cost.sh

RUN apk add zstd

ENTRYPOINT ["ash","/cost.sh"]
```

Use the Docker CLI to build the image

```
docker build -t <docker hub username>/infracost:1.0 .
```

Push the image to a repository. The below command pushes to Docker Hub

```
docker push <docker hub username>/infracost:1.0
```

---

## Create Infracost Context

You will need to create a configuration context in Environment Manager to store your Infracost API key. The API key will be stored securely and passed to the Infracost container as needed.

In the Rafay console:

- Navigate to **Environments -> Contexts**
- Click **New Config Context**
- Enter **infracost** for the name
- Click **Create**

[![Context](https://docs.rafay.co/env_manager/img/infracost/context1.png)](https://docs.rafay.co/env_manager/img/infracost/context1.png)

- Navigate to **Environment Variables**
- Click **Add Environment Variable**
- Enter **INFRACOST_API_KEY** for the environment key
- Enter your API key for the value
- Select **Sensitive**
- Click **Save**

[![Context](https://docs.rafay.co/env_manager/img/infracost/context2.png)](https://docs.rafay.co/env_manager/img/infracost/context2.png)

Your API key can be obtained under **Org Settings** in your Infracost account.

---

## Configure Hooks

You will add a hook to each resource in the environment where cost estimation is needed

In the Rafay console:

- Navigate to **Environments -> Resource Templates**
- Locate and select the resource template for the resource where the hook will be added
- Click **New Version**
- Navigate to **Hooks -> Terraform Hooks -> Plan**
- Click **Add Hook**
- Enter **infracost** for the name
- Select **Before**
- Select **Container** for the hook type
- Enter **100** for the CPU limit
- Enter the image location of the image you pushed earlier
- Enter **500** for the memory limit
- Enter **/infracost/** for the working directory path
- Enter the following success condition

```
if #status.container.exitCode == 0 {
                            success: true
                        }
                        if #status.container.exitCode != 0  {
                            failed: true
                        }
```

- Click **Add Environment Variable**
- Enter **DOWNLOAD_TOKEN** for the key
- Enter **(resource."<resource template name>".artifact.workdir.token)** for the value being sure to update the resource template name
- Click **Add Environment Variable**
- Enter **DOWNLOAD_URL** for the key
- Enter **(resource."<resource template name>".artifact.workdir.url)** for the value being sure to update the resource template name
- Click **Add Environment Variable**
- Enter **TF_PATH** for the key
- Enter the path of the Terraform code of the resource for the value (ex. aws/resources/vpc-ec2)
- Click **Save Changes**

[![Hook](https://docs.rafay.co/env_manager/img/infracost/hook1.png)](https://docs.rafay.co/env_manager/img/infracost/hook1.png)

- In the resource template, navigate to **Config Contexts**
- Click **Add Config Context**
- Select the previously created **infracost** context
- Click **Save as Active Version**

[![Hook](https://docs.rafay.co/env_manager/img/infracost/hook2.png)](https://docs.rafay.co/env_manager/img/infracost/hook2.png)

---

## Verify Configuration

You can view the cost estimation of a resource by viewing the Infracost activity of the resource in the run of an environment the resource is part of. An illustrative example is shown below.

[![Cost Estimate](https://docs.rafay.co/env_manager/img/infracost/estimate.png)](https://docs.rafay.co/env_manager/img/infracost/estimate.png)

---
