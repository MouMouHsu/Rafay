---
title: "KOP Environment Manager - Environment Schedules"
source: https://docs.rafay.co/env_manager/schedules_optout/
category: Home
---

# Environment Schedules

Similar to scheduling jobs at the Environment Template level, users can configure scheduled jobs directly for individual environments. These schedules dictate when actions such as deployment, teardown, or resource destruction should occur for the specific environment, ensuring that operations are automated according to a predefined cadence.

> **Did you know ?**
> Schedule Jobs can be managed through various methods:
>
> - [UI](https://docs.rafay.co/env_manager/create_environment/#schedules)
> - [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/environment)
> - [API](https://docs.rafay.co/env_manager/schedules_optout/#api-configuration-for-scheduling-tasks)
> - [CLI](https://docs.rafay.co/env_manager/schedules_optout/#config-specification)

Like environment templates, environments also allow for schedule opt-outs, providing flexibility to pause or adjust operations for a limited time. Users can define specific durations for opt-outs, but it's important to note that the same duration cannot be reused consecutively without modification. This ensures that changes are made to the schedule or the opt-out duration before it is reapplied.

## API Configuration for Scheduling Tasks

The API example below demonstrates how an environment can be configured with a schedule opt-out, allowing the user to control the timing of key actions such as instance destruction.

```
{
    "apiVersion": "eaas.envmgmt.io/v1",
    "kind": "Environment",
    "metadata": {
        "name": "demo-environment",
        "project": "defaultproject",
        "modifiedAt": "2024-08-21T09:23:52.678883Z",
        "createdAt": "2024-08-20T07:30:16.834067Z"
    },
    "spec": {
        "template": {
            "name": "demo-environmenttemplate",
            "version": "v1",
            "versionState": "draft"
        },
        "schedule_optouts": [
            {
                "name": "destroy-ec2-instance",
                "duration": "45m"
            }
        ]
    }
}
```

> **Info**
> **Schedule opt-out duration** will not be enforced when the duration value is unchanged for Environments. For example, if a duration of 45 minutes is set, it cannot be reused for the subsequent opt-out unless the value is modified. However, after a different duration has been applied, the 45-minute value can be used again

Refer to [Environment Template Schedules](https://docs.rafay.co/env_manager/templates/cron_jobs/) to learn how to schedule jobs at the Environment Template level.

---

## Config Specification

The following YAML configuration defines an environment that utilizes the **schedule opt-out** feature. This feature allows users to exclude certain actions, like destroying instances, from the automated scheduling system for a specified duration. The configuration includes an agent and a schedule opt-out for the action `destroy-np-instance`, which will be excluded for 1 hour from the schedule.

```
apiVersion: eaas.envmgmt.io/v1
kind: Environment
metadata:
  name: test-env-np-with-schds
  project: default
spec:
  template:
    name: test-np-et-with-schds
    version: v2
    versionState: draft
  agents:
  - name: envmgr-agent-sep
  schedule_optouts:
  - name: destroy-np-instance
    duration: 1h
```

---
