---
title: "KOP CLI - Agents"
source: https://docs.rafay.co/cli/agents_v2/
category: Home
---

# Agents

> **This is a legacy version**
> For the latest Agents CLI information, see the [Agents CLI](https://docs.rafay.co/cli/agents/) topic.

The repo agent is a service that you deploy and operate in the local network or VPC and therefore, the controller can securely connect to the artifact repositories.

The table below describes the list of actions that can be performed on "repository" using the RCTL CLI Utility.

| Resource | Create | Get | Delete |
| --- | --- | --- | --- |
| Agent | YES | YES | YES |

---

## Create Agent

Both "imperative" and "declarative" approaches are supported for management of agents.

---

### Kubernetes Deployment Type

To create a agent with Kubernetes Deployment Type, use the below command

```
./rctl create agent -f dev-cluster-agent.yaml
```

---

## List Agents

Use this command to retrieve the list of agents in the configured Project. The name of the agents, the type of agent and health status are returned. An illustrative example is shown below where RCTL retrieves the list of agents in the project "Demo".

```
./rctl get agent --project Demo
```

```
+---------------+--------------+---------------+------------------------------+
| AGENT NAME    | TYPE         | HEALTH STATUS | CREATE AT                    |
+---------------+--------------+---------------+------------------------------+
| dev           | ClusterAgent | HEALTHY       | Thu Jan  7 22:37:16 UTC 2021 |
+---------------+--------------+---------------+------------------------------+
| test          | ClusterAgent | HEALTHY       | Sat Mar  6 08:31:48 UTC 2021 |
+---------------+--------------+---------------+------------------------------+
| demo          | ClusterAgent | HEALTHY       | Sat Mar  6 09:00:56 UTC 2021 |
+---------------+--------------+---------------+------------------------------+
```

---

## Get Specific Agent Info

Use this command to retrieve a specific agent's details in the configured project.

```
./rctl get agent <agent-name>
```

Below is the illustrative example for the agent called "demo"

```
./rctl get agent demo
```

```
+---------------+--------------+---------------+------------------------------+
| AGENT NAME    | TYPE         | HEALTH STATUS | CREATE AT                    |
+---------------+--------------+---------------+------------------------------+
| demo          | ClusterAgent | HEALTHY       | Sat Mar  6 09:00:56 UTC 2021 |
+---------------+--------------+---------------+------------------------------+
```

Or you can use below command to get more information of the agent in json or yaml format

```
./rctl get agent <agent-name> -o json
```

```
./rctl get agent <agent-name> -o yaml
```

---

## Delete Agent

You can delete an agent in the configured project.

```
./rctl delete agent <agent-name>
```

---
