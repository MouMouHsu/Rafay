---
title: "KOP CLI - Cluster Overrides"
source: https://docs.rafay.co/cli/overrides/
category: Home
---

# Overrides

The table below describes the list of actions that can be performed on "Cluster Overrides" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Cluster Overrides | YES | YES | YES | YES |

---

### Create Cluster Override for Add-ons/Workloads

Use the following command to create/update a cluster override.

```
./rctl apply -f <overridefile_name.yaml>
```

#### Helm & Local File type

An example of a helm type workload cluster override spec is shown below that uses **AddonOverride**, **Helm type**, and **local file** artifact type.

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: addon-helm
  project: defaultproject
spec:
  placement:
    labels:
      - key: rafay.dev/clusterName
        value: minikube
  resource:
    selector:
      name: helm-addon
      version: v1
    type: Addon
  sharing:
    enabled: true
    projects:
    - name: demo-project1
  type: Helm
  valuesPath:
    name: file://artifact/helm.yaml
```

#### Helm & Pull from Git type

An example of a helm type workload cluster override spec is shown below that uses **Override** (WorkloadOverride), **Helm type**, and **pull from git** artifact type.

```
apiVersion: apps.k8smgmt.io/v3
kind: Override
metadata:
  name: workload-helm-repo
  project: defaultproject
spec:
  placement:
    labels:
      - key: rafay.dev/clusterName
        value: minikube
  repo:
    path:
      name: /test/test.yaml
    repository: pvt-sync
    revision: main
  resource:
    selector:
      name: helm-workload
      version: v1
    type: Workload
  sharing:
    enabled: true
    projects:
    - name: demo-project1
  type: Helm
```

#### Yaml & Pull from Git type

An example of a helm type workload cluster override spec is shown below that uses **AddOnOverride**, **Yaml type**, and **pull from git** artifact type.

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  name: addon-yaml-repo
  project: defaultproject
spec:
  placement:
    labels:
      - key: rafay.dev/clusterName
        value: minikube
  repo:
    path:
      name: /test/test-w.yaml
    repository: pvt-sync
    revision: main
  resource:
    selector:
      name: yaml-addon
    type: Addon
  sharing:
    enabled: true
    projects:
    - name: demo-project1
  type: Yaml
```

#### Yaml & Local File type

An example of a helm type workload cluster override spec is shown below that uses **Override** (WorkloadOverride), **Yaml type**, and **local file** artifact type.

```
apiVersion: apps.k8smgmt.io/v3
kind: Override
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: workload-yaml
  project: defaultproject
spec:
  placement:
    labels:
      - key: rafay.dev/clusterName
        value: minikube
  resource:
    selector:
      name: yaml-workload
    type: Workload
  sharing:
    enabled: true
    projects:
    - name: demo-project1
  type: Yaml
  valuesPath:
    name: file://artifact/yaml.yaml
```

### Configuring Readiness Check Retries Using RCTL

#### Add-On Readiness Retry

The following configuration spec example demonstrates how to set the readiness check retry limit for an addon using RCTL. By specifying the retry limit in a separate settings file and referencing it in the addon specification, users can control the maximum number of retries during blueprint synchronization, ensuring addons are retried only up to the defined threshold before being marked as failed.

```
apiVersion: infra.k8smgmt.io/v3
kind: AddonOverride
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: addon-setting
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: dev4
  resource:
    selector:
      name: demo1
    type: AddonSetting
  valuesPath:
    name: file://setting.yaml
```

In the `setting.yaml` file, define the retry limit:

```
maxRetries: 4
```

#### Workload Readiness Retry

The following configuration spec example demonstrates how to set the readiness check retry limit for a workload using RCTL. By defining the retry limit in a separate settings file and linking it to the workload specification, users can control workload readiness checks, ensuring workloads are retried only up to the configured threshold before failing.

```
apiVersion: apps.k8smgmt.io/v3
kind: Override
metadata:
  labels:
    rafay.dev/overrideScope: clusterLabels
    rafay.dev/overrideType: valuesFile
  name: workload-setting
  project: defaultproject
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: dev4
  resource:
    selector:
      name: nginx-yaml-workload
    type: WorkloadSetting
  valuesPath:
    name: file://setting.yaml
```

In the `setting.yaml` file, define the retry limit:

```
maxRetries: 4
```

### List Cluster overrides

Use this command to retrieve the list of cluster overrides in the configured Project. The name of the override, override and artifact type, and value file are returned.

```
./rctl get cluster-override --v3
```

***Example***

```
./rctl get cluster-override --v3
+-----------------------------------+---------------+---------------+---------------------------------------------------------------------------------+------------+
| CLUSTEROVERRIDE NAME       | OVERRIDE TYPE | ARTIFACT TYPE | VALUE FILE                                   | REPOSITORY |
+-----------------------------------+---------------+---------------+---------------------------------------------------------------------------------+------------+
| busyboxov1            | Workload   | Yaml     | file://busyboxov1/busyboxov1.yaml                        |      |
+-----------------------------------+---------------+---------------+---------------------------------------------------------------------------------+------------+
| demo-override           | Workload   | Helm     |                                         |      |
+-----------------------------------+---------------+---------------+---------------------------------------------------------------------------------+------------+
| demo-override-a          | Workload   | Helm     | file://demo-override-a/demo-override-a.yaml                   |      |
+-----------------------------------+---------------+---------------+---------------------------------------------------------------------------------+------------+
| demohelmoverride         | Workload   | Helm     | file://demohelmoverride/demohelmoverride.yaml                  |      |
+-----------------------------------+---------------+---------------+---------------------------------------------------------------------------------+------------+
```

**Type Add-On**

To get a list of cluster overrides of type Add-On, use the below command in the configured Project.

```
./rctl get co --type ClusterOverrideTypeAddon
```

***Example***

```
./rctl get co --type ClusterOverrideTypeAddon  
+-----------------------------------+--------------------------------+----------------------------------------------------------------------------------+--------------------------+---------------+-----------------+-----------+
| OVERRIDE NAME           | CLUSTER SELECTOR        | RESOURCE SELECTOR                                | TYPE           | ARTIFACT TYPE | OVERRIDE VALUES | OWNERSHIP |
+-----------------------------------+--------------------------------+----------------------------------------------------------------------------------+--------------------------+---------------+-----------------+-----------+
| connector-override-temp      | venus=flytrap         | rafay.dev/system=true,rafay.dev/component=v2-infra                | ClusterOverrideTypeAddon | Helm     |         | self   |
+-----------------------------------+--------------------------------+----------------------------------------------------------------------------------+--------------------------+---------------+-----------------+-----------+
| prometheus-helm-exporter-override | rafay.dev/clusterName in    | rafay.dev/system=true,rafay.dev/component=rafay-prometheus            | ClusterOverrideTypeAddon | Helm     |         | self   |
|                  | (nikhildemonewv3c1)      |                                         |             |        |         |      |
+-----------------------------------+--------------------------------+----------------------------------------------------------------------------------+--------------------------+---------------+-----------------+-----------+
```

**Type Workload**

To get a list of cluster overrides of type Workload, use the below command in the configured Project.

```
./rctl get co --type ClusterOverrideTypeWorkload
```

***Example***

```
./rctl get co --type ClusterOverrideTypeWorkload
+-------------------------+--------------------------------+-----------------------------+-----------------------------+---------------+-----------------+-----------+
| OVERRIDE NAME      | CLUSTER SELECTOR        | RESOURCE SELECTOR      | TYPE            | ARTIFACT TYPE | OVERRIDE VALUES | OWNERSHIP |
+-------------------------+--------------------------------+-----------------------------+-----------------------------+---------------+-----------------+-----------+
| demohelmoverride    | a=apple            |               | ClusterOverrideTypeWorkload | Helm     |         | self   |
+-------------------------+--------------------------------+-----------------------------+-----------------------------+---------------+-----------------+-----------+
| demoyamloverride    |                |               | ClusterOverrideTypeWorkload | Yaml     |         | self   |
+-------------------------+--------------------------------+-----------------------------+-----------------------------+---------------+-----------------+-----------+
| demo-override      |                |               | ClusterOverrideTypeWorkload | Helm     |         | self   |
+-------------------------+--------------------------------+-----------------------------+-----------------------------+---------------+-----------------+-----------+
```

### Delete Cluster Override

Delete a cluster override in the configured project using the below command.

```
./rctl delete cluster-override --v3 -f <overridefilename.yaml>
```

---

[Cluster Overrides for Blueprints](https://docs.rafay.co/blueprints/overrides/)

[Cluster Overrides for Workloads](https://docs.rafay.co/workloads/overrides/)
