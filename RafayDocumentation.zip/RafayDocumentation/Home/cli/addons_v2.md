---
title: "KOP CLI - AddOns"
source: https://docs.rafay.co/cli/addons_v2/
category: Home
---

# Addons

> **This is a legacy version**
> For the latest Add-Ons CLI information, see the [Add-Ons CLI](https://docs.rafay.co/cli/addons/) topic.

The table below describes the list of actions that can be performed on "addons" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Addon | YES | YES | YES | YES |

---

Both imperative and declarative approach is available to manage the addons. This is strongly recommended backed by the addon payloads version controlled in your SCM/Git repository.

---

## Declarative

You can also create an addon in the controller based on a version controlled addon spec that you can store in a Git repository. This enables users to develop automation for reproducible infrastructure.

```
./rctl create addon version -f addon-spec.yml
```

An illustrative example of the addon spec YAML file is shown below

```
kind: Addon
metadata:
  # set addon name
  name: kubeless
  # set project name
  project: defaultproject
spec:
  # addon namespace
  namespace: kubeless
  # type helm or yaml
  type: yaml
```

---

### Helm Add-Ons from Different Repos

Below is an example config file to create an add-on with Helm Chart and values from different repositories

```
kind: AddonVersion
metadata:
  name: v1
  project: project1
  description: description for v1
spec:
  addon: demorctladdon-new4
  namespace: rctl
  template:
    type: Helm3
    repository_ref: default-bitnami
    repo_artifact_meta:
      helm:
        chartName: apache
        tag: 8.5.4
    value_repository_ref: testrepo1
    additional_reference:
      git:
        revision: main
        repoArtifactFiles:
        - name: apache-values
          relPath: apache-values.yaml
          fileType: HelmValuesFile
```

---

## Imperative

### Helm Add-On Example

In the example below, we are using the following command to create an addon for New Relic with the following information in the currently configured "project" context. If the command was successful, authorized users in the project will be able to view the corresponding addon details in the web console as well.

- Helm Chart: nri-bundle-1.7.1.tgz
- Values File: nri-bundle-custom-values.yaml
- Namespace: newrelic
- Version Name: v1.7.1

```
./rctl create addon version newrelic v1.7.1 --chart-file nri-bundle-1.7.1.tgz --values-file nri-bundle-custom-values.yaml
```

---

### k8s YAML Add-On Example

For example, use the following command to create an addon for [Kubeless](https://kubeless.io/) from the official k8s YAML file into an existing namespace called "kubeless" providing the version name to publish the addon after creation

```
./rctl create addon version kubeless <version-name> --yaml-input kubeless.yaml
```

---

## List Add-Ons

Use this command to retrieve the list of addons in the configured Project. The name of the addons, the type of payload and publish status are returned. An illustrative example is shown below where RCTL retrieves the list of addons in the project "Demo".

```
./rctl get addon --project Demo
```

```
+-----------------------------+-----------------------+------------------------------+---------------------+
| NAME                        | TYPE                  | MODIFIED AT                  | NAMESPACE           |
+-----------------------------+-----------------------+------------------------------+---------------------+
| nginxplus                   | Helm                  | Fri Sep 11 19:38:25 UTC 2020 | gitlab              |
+-----------------------------+-----------------------+------------------------------+---------------------+
| alert-opsgenie-demo         | System [Alertmanager] | Tue Nov 10 22:22:18 UTC 2020 | rafay-infra         |
+-----------------------------+-----------------------+------------------------------+---------------------+
| cert-manager                | NativeYaml            | Thu Sep 10 01:52:36 UTC 2020 | cert-manager        |
+-----------------------------+-----------------------+------------------------------+---------------------+
| custom-alert                | System [Alertmanager] | Mon Nov  2 22:20:17 UTC 2020 | rafay-infra         |
+-----------------------------+-----------------------+------------------------------+---------------------+
| custom-alertmanager         | System [Alertmanager] | Mon Nov  2 23:46:04 UTC 2020 | rafay-infra         |
+-----------------------------+-----------------------+------------------------------+---------------------+
| datadog                     | Helm                  | Wed Jun  3 00:51:16 UTC 2020 | datadog             |
+-----------------------------+-----------------------+------------------------------+---------------------+
| datadog-helm3               | Helm3                 | Sun Oct 18 18:05:54 UTC 2020 | datadog             |
```

---

## Get Specific Add-On Info

Use this command to retrieve a specific add-on's details in the configured project.

```
./rctl get addon <addon-name>
```

Below is the illustrative example for the add-on called "datadog-helm3"

```
./rctl get addon datadog-helm3
```

```
+--------------+------------------------------+
| VERSION NAME | CREATED AT                   |
+--------------+------------------------------+
| v1           | Mon Jun 29 04:41:11 UTC 2020 |
+--------------+------------------------------+
```

Or you can use below command to get more information of the addon in json or yaml format

```
./rctl get addon <addon-name> -o json
```

```
./rctl get addon <addon-name> -o yaml
```

---

## Create/Update Add-On

In order to update an add-on (excluding add-on labels), you create a new version of an existing add-on. For example, if you have a v1 version for the add-on, to update you will now create a v2 version. For declarative models, ensure that you specify the version number for your addon in the specification file.

```
./rctl create addon version -f <addon-spec.yaml>
```

For example, the version for this addon update is highlighted below.

```
kind: AddonVersion
metadata:
  # version name
  name: v0.9.1
  # project name. optional
  project: defaultproject
spec:
  # addon name
  addon: vault-server
  # template for different addon types
  template:
    # type of addon
    type: helm3
    chartFile: addon/examples/vault-0.9.1.tgz
    # values file is optional
    valuesFile: addon/examples/vault-values.yaml
```

---

## Delete Add-On

You can delete an add-on in the configured project. Note that add-ons in active use in a cluster blueprint cannot be deleted and the caller will be provided with an error message.

```
./rctl delete addon <addon-name>
```

---

## Share Add-Ons

Use the below command to share an addon with one or more project(s)

- Share with all Projects

```
./rctl share addon addon_name --all-projects
```

- Share with specific project(s)

```
./rctl share addon addon_name --projects prj1,prj2
```

---

## Unshare Add-Ons

Use the below command to unshare an addon with one or more project(s)

- Unshare with all Projects

```
./rctl share addon addon_name --none
```

- Unshare with specific project(s)

```
./rctl share addon addon_name --unassign-projects prj1,prj2
```

---

## Download Add-On Artifacts

- Use the below command to download the add-on artifacts of any version

```
./rctl download addon <addon-name> <version>
```

- To download the artifacts in a specific folder, use the below command

```
./rctl download addon <addon-name> <version>  --output-dir dir-name
```

> **Important**
> The above commands can be used for any type of add-on where the files are manually updated for artifact type. This cannot be used when artifact type pull files from repository is selected. Artifacts are downloaded as a zip file that contains all the value files except for **Managed System Add-Ons**, all the components are downloaded as separate files,

- Use the below command to download a particular file associated with an add-on

```
./rctl download addon <addon-name>  --file <file-name>
```

(or)

```
./rctl  download addon <addon-name>  --file <file-name>  --output-dir dir-name
```
