---
title: "KOP CLI - Projects"
source: https://docs.rafay.co/cli/projects_v2/
category: Home
---

# Projects

> **This is a legacy version**
> For the latest Projects CLI information, see the [Projects CLI](https://docs.rafay.co/cli/projects/) topic.

The RCTL utility provides the means to manage the lifecycle of projects of an organization. The following operations can be performed on projects managed by the controller.

| Resource | Create | Get | Delete |
| --- | --- | --- | --- |
| Projects | YES | YES | YES |

---

## Create Project

### Declarative

```
.rctl create project -f <filename.yaml>
```

Below is an example of project yaml file

```
apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
  description: demo_project
  name: Demo-Project
spec:
  default: false
```

---

### Imperative

Use the below command to create a project

```
./rctl create project <project-name>
```

---

## List Project(s)

The below command is to retrieve/list all projects

```
./rctl get projects
```

***Example Output***

```
./rctl get projects
NAME
demo-project-1
Demo-Project
infraadmin
clustureadmin
demo-project
project1
defaultproject
```

The below command is to retrieve a specific project

```
./rctl get project <project-name>
```

***Example Output***

```
./rctl get project demo-project
Name: demo-project
Created-at: Tue, 10 Aug 2021 07:46:15 UTC
Modified-at: Tue, 10 Aug 2021 07:46:15 UTC
```

---

## Delete Project

Use the below command to delete a project

```
./rctl delete project -f <filename.yaml>
```

---
