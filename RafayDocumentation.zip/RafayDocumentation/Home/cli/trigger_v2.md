---
title: "KOP CLI - Trigger"
source: https://docs.rafay.co/cli/trigger_v2/
category: Home
---

# Trigger

> **This is a legacy version**
> For the latest Trigger CLI information, see the [Trigger CLI](https://docs.rafay.co/cli/trigger/) topic.

The table below describes the list of actions that can be performed on "triggers" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Triggers | YES | YES | YES | YES |

---

## Create Triggers

A declarative approach to lifecycle management of triggers is strongly recommended backed by the pipeline manifests (YAML files) that are version controlled in your Git repository.

---

### Declarative

You can create a trigger in the project in your Organization based on a version controlled pipeline spec that you can store in a Git repository. This enables users to develop automation for reproducible infrastructure.

> **Important**
> A trigger can be either a webhook or periodic.

```
./rctl create trigger -f trigger.yaml
```

An illustrative example of the webhook trigger version spec YAML file is shown below

```
kind: Trigger
apiVersion: pipeline.rafay.dev/v2
metadata:
  name: trigger-1
  project: sample-project
spec:
  triggerType: WebhookTrigger
  pipelineRef: sample-pipeline
  repositoryRef: sample-repo
  triggerConfig:
    webhook:
      configType: Github
  repositoryConfig:
    git:
      paths:
      - src/cmd.go
      revision: master
```

An illustrative example of the periodic trigger version spec YAML file is shown below

```
kind: Trigger
apiVersion: pipeline.rafay.dev/v2
metadata:
  name: sample-trigger-2
  project: sample-project
spec:
  triggerType: PeriodicSCMTrigger
  pipelineRef: sample-pipeline
  repositoryRef: sample-repo
  repositoryConfig:
    helm:
      revision: master
      chartName: nginx/values.yaml
  triggerConfig:
    periodicSCM:
      cronExpression: */5 * * * *
```

---

## Update Trigger

Use this command to update an already configured trigger.

```
./rctl update trigger -f trigger.yaml
```

---

## List Triggers

Use this command to retrieve the list of triggers in the configured Project. An illustrative example is shown below where RCTL retrieves the list of triggers in the project "qa".

```
./rctl get trigger -p qa
```

```
+--------------+----------------+--------------------+----------------------+------------------------------+
| TRIGGER NAME | TYPE           | PIPELINE REFERENCE | REPOSITORY REFERENCE | CREATE AT                    |
+--------------+----------------+--------------------+----------------------+------------------------------+
| gittrigger   | WebhookTrigger | nginx              | qa                   | Sun Dec 20 23:12:18 UTC 2020 |
+--------------+----------------+--------------------+----------------------+------------------------------+
| multitenant  | WebhookTrigger | multitenant        | qa                   | Mon Dec 21 19:53:43 UTC 2020 |
+--------------+----------------+--------------------+----------------------+------------------------------+
```

---

## Get The Specific Trigger's Info

Use this command to retrieve a specific trigger's details in the configured project.

```
./rctl get trigger <trigger-name> -p <project-name>
```

Below is the illustrative example for the pipeline called "gittrigger"

```
./rctl get trigger gittrigger
```

```
+--------------+----------------+--------------------+----------------------+------------------------------+
| TRIGGER NAME | TYPE           | PIPELINE REFERENCE | REPOSITORY REFERENCE | CREATE AT                    |
+--------------+----------------+--------------------+----------------------+------------------------------+
| gittrigger   | WebhookTrigger | nginx              | qa                   | Sun Dec 20 23:12:18 UTC 2020 |
+--------------+----------------+--------------------+----------------------+------------------------------+
```

Or you can use below command to get more information of the addon in json or yaml format

```
./rctl get trigger <trigger-name> -o json
```

```
./rctl get trigger <trigger-name> -o yaml
```

---

## Delete Trigger

You can delete a trigger in the configured project.

```
./rctl delete trigger <trigger-name>
```

---
