---
title: "KOP CLI - Projects"
source: https://docs.rafay.co/cli/projects/
category: Home
---

# Projects

The RCTL utility provides the means to manage the lifecycle of projects of an organization. The following operations can be performed on projects managed by the controller.

| Resource | Create | Get | Delete |
| --- | --- | --- | --- |
| Projects | YES | YES | YES |

---

## Create/Update Project

### Declarative

Use the below command to create/update a project

```
./rctl apply -f project-spec.yml
```

Below is an example of project yaml file

```
apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
  description: demo_project
  name: demo_project
spec:
  clusterResourceQuota:
    pods: "1000"
  defaultClusterNamespaceQuota:
    pods: "1"
  driftWebhook:
    enabled: true
  syncExcludedNamespaces:
  - ns1
  - ns2
  - ns3
```

---

### Imperative

Use the below command to create a project

```
./rctl create project <project-name> --v3
```

---

## List Project(s)

The below command is to retrieve/list all projects

```
./rctl get projects --v3
```

***Example Output***

```
./rctl get projects --v3
NAME
demo-project-1
Demo-Project
infraadmin
clustureadmin
demo-project
project1
defaultproject
```

The below command is to retrieve a specific project

```
./rctl get project <project-name> --v3
```

***Example Output***

```
./rctl get project demo-project --v3
Name: demo-project
Created-at: Tue, 10 Aug 2021 07:46:15 UTC
Modified-at: Tue, 10 Aug 2021 07:46:15 UTC
```

---

## Delete Project

Use the below command to delete a project

```
./rctl delete project -f <filename.yaml> --v3
```

---

## Templating

Users can also create multiple projects with a set of defined configurations. The template file contains a list of objects that helps to create multiple project(s) from a single template.

Users can either specify the number of projects in the respective value yaml file (or) create a separate a value yaml file with a list of project names

### Method 1

Below is an example of a project config template. Users can either add/remove one or more object(s) from this template as per the requirement

```
# Generated: {{now.UTC.Format "2006-01-02T15:04:05UTC"}}
#      With: {{command_line}}
{{ $p := . }}{{ range $count := IntSlice .StartIndex .Count }}
apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
  name: {{ $p.Name }}-{{ $count }}
spec:
  clusterResourceQuota:
    configMaps: "{{ $p.ClusterQuota.ConfigMaps }}"
    cpuLimits: {{ $p.ClusterQuota.CpuLimits }}
    cpuRequests: {{ $p.ClusterQuota.CpuRequests }}
    memoryLimits: {{ $p.ClusterQuota.MemoryLimits }}
    memoryRequests: {{ $p.ClusterQuota.MemoryRequests }}
    storageRequests: {{ $p.ClusterQuota.StorageRequests }}
  default: false
  defaultClusterNamespaceQuota:
    configMaps: "{{ $p.NamespaceQuota.ConfigMaps }}"
    cpuLimits: {{ $p.NamespaceQuota.CpuLimits }}
    cpuRequests: {{ $p.NamespaceQuota.CpuRequests }}
    memoryLimits: {{ $p.NamespaceQuota.MemoryLimits }}
    memoryRequests: {{ $p.NamespaceQuota.MemoryRequests }}
    storageRequests: "{{ $p.NamespaceQuota.StorageRequests }}"
---
{{end}}
```

Users can create one or more projects using the below value file based on the configuration defined in the template file. Below is an example of a project value file with the count of 10 projects. This value file creates 10 projects with the same resource configuration in the name format **project name-**

```
Name: devops-project
StartIndex: 1
Count: 10
ClusterQuota:
  ConfigMaps: "1000.000000"
  CpuLimits: 5000.000000m
  CpuRequests: 5000.000000m
  MemoryLimits: 5000.000000Mi
  MemoryRequests: 5000.000000Mi
  StorageRequests: "100.000000"
NamespaceQuota:
  ConfigMaps: "100.000000"
  CpuLimits: 1000.000000m
  CpuRequests: 1000.000000m
  MemoryLimits: 1000.000000Mi
  MemoryRequests: 1000.000000Mi
  StorageRequests: "1.000000"
```

> **Important**

Only the objects defined in the template must be present in the value files

Use the command below to create project(s) with the specified configuration once the value file(s) are prepared with the necessary objects

```
 ./rctl apply -t project.tmpl --values value.yaml
```

where, - ***project.tmpl***: template file - ***value.yaml***: value file

**Output**

You can expect the below output for the example provided

```
# Generated: 2022-08-07T17:02:49UTC
#      With: rctl apply -t ./project.tmpl --values ./values.yaml

apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
  name: devops-project-1
spec:
  clusterResourceQuota:
    configMaps: "1000"
    cpuLimits: 5000.000000m
    cpuRequests: 5000.000000m
    memoryLimits: 5000.000000Mi
    memoryRequests: 5000.000000Mi
    storageRequests: 100
  default: false
  defaultClusterNamespaceQuota:
    configMaps: "100"
    cpuLimits: 1000.000000m
    cpuRequests: 1000.000000m
    memoryLimits: 1000.000000Mi
    memoryRequests: 1000.000000Mi
    storageRequests: "10"
---

apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
  name: devops-project-2
spec:
  clusterResourceQuota:
    configMaps: "1000"
    cpuLimits: 5000.000000m
    cpuRequests: 5000.000000m
    memoryLimits: 5000.000000Mi
    memoryRequests: 5000.000000Mi
    storageRequests: 100
  default: false
  defaultClusterNamespaceQuota:
    configMaps: "100"
    cpuLimits: 1000.000000m
    cpuRequests: 1000.000000m
    memoryLimits: 1000.000000Mi
    memoryRequests: 1000.000000Mi
    storageRequests: "10"
---

......

apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
  name: devops-project-10
spec:
  clusterResourceQuota:
    configMaps: "1000"
    cpuLimits: 5000.000000m
    cpuRequests: 5000.000000m
    memoryLimits: 5000.000000Mi
    memoryRequests: 5000.000000Mi
    storageRequests: 100
  default: false
  defaultClusterNamespaceQuota:
    configMaps: "100"
    cpuLimits: 1000.000000m
    cpuRequests: 1000.000000m
    memoryLimits: 1000.000000Mi
    memoryRequests: 1000.000000Mi
    storageRequests: "10"
---
```

### Method 2

Users can create a separate a value yaml file with a list of projects on which the project configuration (objects in the template) has to be applied. Below is an example of a project value file with two (2) project names

```
ProjectNames:
- Project-1
- Project-2
```

On creating a separate value file, run the below command

```
./rctl apply -t project.tmpl --values project_list.yaml value.yaml
```

where, - ***project.tmpl***: template file - ***project_list.yaml***: project list - ***value.yaml*** - value file

```
# Generated: 2022-08-07T17:02:49UTC
#      With: rctl apply -t project.tmpl --values project_list.yaml value.yaml

apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
  name: Project-1
spec:
  clusterResourceQuota:
    configMaps: "1000"
    cpuLimits: 5000.000000m
    cpuRequests: 5000.000000m
    memoryLimits: 5000.000000Mi
    memoryRequests: 5000.000000Mi
    storageRequests: 100
  default: false
  defaultClusterNamespaceQuota:
    configMaps: "100"
    cpuLimits: 1000.000000m
    cpuRequests: 1000.000000m
    memoryLimits: 1000.000000Mi
    memoryRequests: 1000.000000Mi
    storageRequests: "10"
---

apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
  name: Project-2
spec:
  clusterResourceQuota:
    configMaps: "1000"
    cpuLimits: 5000.000000m
    cpuRequests: 5000.000000m
    memoryLimits: 5000.000000Mi
    memoryRequests: 5000.000000Mi
    storageRequests: 100
  default: false
  defaultClusterNamespaceQuota:
    configMaps: "100"
    cpuLimits: 1000.000000m
    cpuRequests: 1000.000000m
    memoryLimits: 1000.000000Mi
    memoryRequests: 1000.000000Mi
    storageRequests: "10"
---
```

**Multiple Value Files**

You can also add multiple value files using the same template to append one or more K8s resources to the required projects

Assume an example with three (3) value files to create ten (10) projects

- value-1.yaml for project
- value-2.yaml for add-ons
- value-3.yaml for blueprint

Run the below command to create 10 projects with the specified add-ons and blueprint configuration

```
 ./rctl apply -t project.tmpl --values values-1.yaml values-2.yaml values-3.yaml
```

Refer [Templating](https://docs.rafay.co/cli/templating_overview/) for more details on Templating flags and examples Refer [here](https://docs.rafay.co/cli/projects_v2/) for the deprecated RCTL commands

---
