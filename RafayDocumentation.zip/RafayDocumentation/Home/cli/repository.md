---
title: "KOP CLI - Repository"
source: https://docs.rafay.co/cli/repository/
category: Home
---

# Repository

The table below describes the list of actions that can be performed on "repository" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Repository | YES | YES | YES | YES |

---

## Declarative

A declarative approach to lifecycle management of repository is strongly recommended backed by the pipeline manifests (YAML files) that are version controlled in your Git repository.

> **Important**
> A repository can be either a Helm or Git repository type. A number of public repositories are provided by default in every project.

---

### Create/Update Repository

You can create/update a repository in the project in your Organization based on a version controlled repository spec that you can store in a Git repository. This enables users to develop automation for reproducible infrastructure.

```
./rctl apply -f repository.yaml
```

An illustrative example of the repository version spec YAML file is shown below

```
apiVersion: integrations.k8smgmt.io/v3
kind: Repository
metadata:
  name: demo-repo
  project: default-project
spec:
  agents:
  - {}
  credentials:
    password: sealed://credentials.password
    username: [email protected]
  endpoint: https://github.com/demouser1/pipeline-test.git
  secret:
    name: file://artifacts/demo-repo/sealed-secret.yaml
  sharing: {}
  type: Git
```

---

## Share Repository

Users are allowed to share the existing repository with one or more projects

- Update the config spec with the sharing parameters and run the apply command

```
./rctl apply -f repository.yml
```

An illustrative example of a spec is given below that shares a repo with all the projects

```
apiVersion: integrations.k8smgmt.io/v3
kind: Repository
metadata:
  name: demo-repo
  project: default-project
spec:
  agents:
  - name: demo-agent
  credentials:
    password: secrets
    username: [email protected]
  endpoint: https://github.com/demo-rafay/test-repo
  sharing:
    enabled: true
    projects:
    - name: '*'
  options: {}
  type: Git
```

- Run the apply command to share the repository with other projects

```
./rctl apply -f filepath.yaml --v3
```

---

## Validate Repository

Validating a public repository ensures its integrity, checks dependencies, and verifies security, while also confirming that the configuration adheres to standards. Use the below command to validate a repository.

```
./rctl validate repository <repo_name>
```

As a repository can be linked to multiple agents, the validation process is conducted through each agent, generating one row per agent along with its respective result. In the event of a validation failure, the "Reason" column will be populated with the specific failure reason.

***Example Output***

```
./rctl validate repository demorepo
+------------+-------------------+--------------------------------+
| AGENT NAME | VALIDATION RESULT | REASON                         |
+------------+-------------------+--------------------------------+
| agent1     | Successful        |                                |
+------------+-------------------+--------------------------------+
| agent2     | Failed            | Unable to connect to agent     |
|            |                   | agent2: getting connections       |
|            |                   | failed for given cd agents     |
|            |                   | {"agent2":"context deadline       |
|            |                   | exceeded"}                     |
+------------+-------------------+--------------------------------+
```

To obtain more information on repository validation in JSON or YAML format, use the following command:

```
./rctl validate repository <repo_name> -o yaml
```

***Example Output***

```
./rctl validate repository demorepo -o yaml
isvalidated: false
comment: Repository validation failed
resultbyagent:
  agent1:
    isagentconnected: true
    isrepovalidated: true
  agent2:
    isagentconnected: false
    isrepovalidated: false
    comment: 'Unable to connect to agent agent2: getting connections failed for
      given cd agents {"hub-leak-2":"context deadline exceeded"}'
```

---

## List Repositories

Use the below command to retrieve the list of repositories

```
./rctl get repository <repository_name> --v3
```

Use this command to retrieve the list of repositories in the configured Project. An illustrative example is shown below where RCTL retrieves the list of repositories in the project "qa".

```
./rctl get repository -p qa --v3
+----------------------+-------------------+------+-------------------------------------------------------------+
| NAME                 | PROJECT           | TYPE | ENDPOINT                                                    |
+----------------------+-------------------+------+-------------------------------------------------------------+
| default-stable-helm  | qa                | Helm | https://charts.helm.sh/stable                               |
+----------------------+-------------------+------+-------------------------------------------------------------+
| default-bitnami      | qa                | Helm | https://charts.bitnami.com/bitnami                          |
+----------------------+-------------------+------+-------------------------------------------------------------+
| default-cert-manager | qa                | Git  | https://github.com/jetstack/cert-manager.git                |
+----------------------+-------------------+------+-------------------------------------------------------------+
| test                 | qa                | Git  | https://github.com/gajanan-rafay/test-repo                  |
+----------------------+-------------------+------+-------------------------------------------------------------+
```

---

## Get Specific Repository Info

Use this command to retrieve a specific repository's details in the configured project.

```
./rctl get repository <repository-name> --v3
```

Below is the illustrative example for the repository called "demo-repo"

```
./rctl get repository demo-repo --v3
+----------------------+-------------------+------+-------------------------------------------------------------+
| NAME                 | PROJECT           | TYPE | ENDPOINT                                                    |
+----------------------+-------------------+------+---------+---------------------------------------------------+
| demo-repo            | prod-test          | Git  | https://github.com/gajanan-rafay/test-repo                  |
+----------------------+-------------------+------+-------------------------------------------------------------+
```

Or you can use below command to get more information of the repository in json or yaml format

```
./rctl get repository <repository-name> -o json
```

```
./rctl get repository <repository-name> -o yaml
```

---

## Delete Repository

You can delete a repository in the configured project.

```
./rctl delete repository <repository-name> --v3
```

> **Important**

Refer [here](https://docs.rafay.co/cli/repository_v2/) for the deprecated RCTL commands

---
