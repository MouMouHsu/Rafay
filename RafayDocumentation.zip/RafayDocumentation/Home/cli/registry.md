---
title: "KOP CLI - Registry"
source: https://docs.rafay.co/cli/registry/
category: Home
---

# Registry

A registry is a centralized storage system for container images. It serves as a repository where container images can be stored, versioned, and easily distributed to various environments.

The table below describes the list of actions that can be performed on "registries" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Registry | YES | YES | YES | YES |

---

## Create Registry

Use the below command to You can create/update a registry

```
./rctl create container-registry -f <registry-file.yaml> --v3
```

(or)

```
./rctl apply -f <registry-spec.yaml>
```

## Registry Config Specification

The supported image registries are Azure Container Registry, Amazon Elastic Container Registry (ECR), and Docker Hub. These registries allow developers to push and pull container images, making it convenient to share and deploy applications.

### ACR

Here's an illustrative example of the ACR Registry spec YAML file

```
apiversion: integrations.k8smgmt.io/v3
kind: ContainerRegistry
metadata:
  name: demoacr
  description: ""
  labels: {}
  annotations: {}
  project: demo-project
  id: ""
  projectid: ""
  createdat: null
spec:
  provider: ACR
  endpoint: abc.azurecr.io
  secret: null
  credentials: null
```

### Docker Hub

Here's an illustrative example of the Docker Hub Registry spec YAML file

```
apiversion: integrations.k8smgmt.io/v3
kind: ContainerRegistry
metadata:
  name: demo-docker
  description: ""
  labels: {}
  annotations: {}
  project: demo-project
  id: ""
  projectid: ""
  createdat: null
spec:
  provider: DockerHub
  endpoint: index.docker.io
  secret: null
  credentials: null
```

### ECR

Here's an illustrative example of the ECR Registry spec YAML file

```
apiversion: integrations.k8smgmt.io/v3
kind: ContainerRegistry
metadata:
  name: demo-ecr-registry
  description: ""
  labels: {}
  annotations: {}
  project: demo-project
  id: ""
  projectid: ""
  createdat: null
spec:
  provider: ECR
  endpoint: 679196758854.dkr.ecr.us-west-1.amazonaws.com
  secret: null
  credentials: null
```

---

## Update Registry

To update an image registry, use the below command

```
./rctl update container-registry -f <registry-file.yaml> --v3
```

---

## Get Registry

To get the list of all image registries, use the below command

```
./rctl get container-registry
```

***Example***

```
./rctl get container-registry
+-------------------------------+-----------------------------+
| CONTAINER REGISTRY NAME       | CONTAINER REGISTRY PROVIDER |
+-------------------------------+-----------------------------+
| system-default-registry       | System                      |
+-------------------------------+-----------------------------+
| public-docker-hub-registry    | DockerHub                   |
+-------------------------------+-----------------------------+
| gajanan-acr                   | ACR                         |
+-------------------------------+-----------------------------+
| rauto-automation-ecr-registry | ECR                         |
+-------------------------------+-----------------------------+
| gajanan-docker                | DockerHub                   |
+-------------------------------+-----------------------------+
| gajanan-acr12                 | ACR                         |
+-------------------------------+-----------------------------+
| acr1234                       | ACR                         |
+-------------------------------+-----------------------------+
| rakshith                      | DockerHub                   |
+-------------------------------+-----------------------------+
```

To view a specific registry details, use the command

```
./rctl get container-registry <registry-name>
```

---

## Delete Registry

To delete a registry, use the command

```
./rctl delete container-registry <registry-name>
```

---
