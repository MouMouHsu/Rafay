---
title: "KOP CLI - Trigger"
source: https://docs.rafay.co/cli/trigger/
category: Home
---

# Trigger

The table below describes the list of actions that can be performed on "triggers" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Triggers | YES | YES | YES | YES |

---

## Create Triggers

A declarative approach to lifecycle management of triggers is strongly recommended backed by the pipeline manifests (YAML files) that are version controlled in your Git repository.

---

### Declarative

You can create/update a trigger in the project in your Organization based on a version controlled pipeline spec that you can store in a Git repository. This enables users to develop automation for reproducible infrastructure.

> **Important**
> A trigger can be either a webhook or periodic

```
./rctl apply -f trigger-spec.yml
```

An illustrative example of the webhook trigger version spec YAML file is shown below

```
apiVersion: gitops.k8smgmt.io/v3
kind: Pipeline
metadata:
  name: demo1
  project: project1
spec:
  active: true
  sharing:
    enabled: false
  stages:
  - config:
      approvers:
      - userName: [email protected]
      timeout: 2m0s
      type: Email
    name: stage1
    next:
    - name: stage2
    type: Approval
  - config:
      workload: test1demogitops
    name: stage2
    next:
    - name: stage3
    type: DeployWorkload
  - config:
      workload: testhemlrepi
    name: stage3
    type: DeployWorkload
  triggers:
  - config:
      repo:
        provider: Github
        repository: testrepo1
        revision: main
    name: trigger
    type: Webhook
```

An illustrative example of the periodic trigger version spec YAML file is shown below

```
apiVersion: gitops.k8smgmt.io/v3
kind: Pipeline
metadata:
  name: system
  project: project1
spec:
  active: false
  sharing:
    enabled: false
  stages:
  - config:
      destinationRepo: {}
      gitToSystemSync: true
      includedResources:
      - name: '*'
      sourceAsDestination: true
      sourceRepo:
        path:
          name: stage02
        repository: gitops
        revision: main
      systemToGitSync: true
    name: sync
    type: SystemSync
  triggers:
  - config:
      cronExpression: '*/1 * * * *'
      repo:
        paths:
        - name: stage02
        repository: gitops
        revision: main
    name: test
    type: Cron
```

---

## List Triggers

Use this command to retrieve the list of triggers in the configured Project. An illustrative example is shown below where RCTL retrieves the list of triggers in the project "qa".

```
./rctl get trigger -p qa
```

```
+--------------+----------------+--------------------+----------------------+------------------------------+
| TRIGGER NAME | TYPE           | PIPELINE REFERENCE | REPOSITORY REFERENCE | CREATE AT                    |
+--------------+----------------+--------------------+----------------------+------------------------------+
| gittrigger   | WebhookTrigger | nginx              | qa                   | Sun Dec 20 23:12:18 UTC 2020 |
+--------------+----------------+--------------------+----------------------+------------------------------+
| multitenant  | WebhookTrigger | multitenant        | qa                   | Mon Dec 21 19:53:43 UTC 2020 |
+--------------+----------------+--------------------+----------------------+------------------------------+
```

---

## Get The Specific Trigger's Info

Use this command to retrieve a specific trigger's details in the configured project.

```
./rctl get trigger <trigger-name> -p <project-name>
```

Below is the illustrative example for the pipeline called "gittrigger"

```
./rctl get trigger gittrigger
+--------------+----------------+--------------------+----------------------+------------------------------+
| TRIGGER NAME | TYPE           | PIPELINE REFERENCE | REPOSITORY REFERENCE | CREATE AT                    |
+--------------+----------------+--------------------+----------------------+------------------------------+
| gittrigger   | WebhookTrigger | pipeline         | test                 | Sat Nov 19 06:23:37 UTC 2022 |
```

Or you can use below command to get more information of the trigger in json or yaml format

```
./rctl get trigger <trigger-name> -o json
```

```
./rctl get trigger <trigger-name> -o yaml
```

---

## Delete Trigger

You can delete one or more trigger(s) from the configured project.

```
./rctl delete trigger <trigger-1><trigger-2><trigger-3>
```

Refer [here](https://docs.rafay.co/cli/trigger_v2/) for the deprecated RCTL commands

---
