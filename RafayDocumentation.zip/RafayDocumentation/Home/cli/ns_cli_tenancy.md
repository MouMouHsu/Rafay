---
title: "CLI"
source: https://docs.rafay.co/cli/ns_cli_tenancy/
category: Home
---

# CLI

The RCTL utility provides the means to manage the lifecycle of namespaces across the fleet of managed clusters. The following operations can be performed on namespaces managed by the controller on the fleet of clusters.

| Resource | Create | Get | Update | Delete | Status | Publish |
| --- | --- | --- | --- | --- | --- | --- |
| Namespace | YES | YES | YES | YES | YES | YES |

---

## Managed Namespaces

As a multi cluster operations platform, the Controller creates/deletes namespaces on managed Kubernetes clusters.

For immediate operations on a namespace on a cluster, use the Zero Trust KubeCTL to manage these directly.

---

## Create Namespace

Create a new "managed" namespace in the current Project using the YAML config spec.

### Declarative

To create/update a namespace with the declarative method, use the below command

```
./rctl apply -f namespace.yaml
```

**Namespace with Labels, Annotations, and Placement Type**

Below is an example of a YAML file with labels, annotations, 'namespace type' as Wizard, and 'placement type' as specific clusters.

```
apiVersion: infra.k8smgmt.io/v3
kind: Namespace
metadata:
  annotations:
    annotation1: annovalue1
    annotation2: ""
  labels:
    key1: keyvalue1
    key2: ""
  name: testnamespace
  project: demoproject
spec:
  limitRange:
    container:
      default:
        cpu: 1u
        memory: 200Mi
      defaultRequest:
        cpu: 1u
        memory: 100Mi
      max:
        cpu: 1u
        memory: 1Gi
      min:
        cpu: 1u
        memory: 6Mi
      ratio:
        cpu: 1
        memory: 4
    pod:
      max:
        cpu: 1u
        memory: 1Gi
      min:
        cpu: 1u
        memory: 6Mi
      ratio:
        cpu: 1
        memory: 4
  placement:
    labels:
    - key: rafay.dev/kubernetesProvider
      value: EKS
  resourceQuotas:
    configMaps: "14"
    cpuLimits: 4m
    cpuRequests: 1m
    memoryLimits: 4Mi
    memoryRequests: 1Mi
    persistentVolumeClaims: "4"
    pods: "4"
    replicationControllers: "20"
    secrets: "20"
    services: "10"
    servicesLoadBalancers: "2"
    servicesNodePorts: "2"
```

> **Important**
> Avoid upper case characters for the name because Kubernetes does not support it.

**Namespace Resource Quota Overrides**

To override resource quotas such as `ephemeralStorageLimits` and `ephemeralStorageRequests`, use the following YAML spec and apply it with the `rctl` CLI:

```
apiVersion: infra.k8smgmt.io/v3
kind: Namespace
metadata:
  name: demo-namespace
  project: demo-project
spec:
  resourceQuotas:
    ephemeralStorageLimits: 20Mi
    ephemeralStorageRequests: 15Mi
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: demo-cluster
```

> Note: Overrides for ephemeralStorageLimits and ephemeralStorageRequests can be configured only through rctl, API, or Terraform.

---

## List Namespace

The below command is to retrieve/list all "managed namespaces" in the currently specified "Project".

```
./rctl get namespace --v3
+-------------------------+----------+--------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-------------+
| NAME                    | TYPE     | PLACEMENT DETAILS                                      | LABELS                                                                                                                                                                                                                                                                 | ANNOTATIONS |
+-------------------------+----------+--------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-------------+
| new-ns                  | Wizard   | rafay.dev/clusterName:new-prod-eks                     |                                                                                                                                                                                                                                                                        |             |
+-------------------------+----------+--------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-------------+
| ns-1                    | Wizard   | rafay.dev/clusterName:new-prod-eks                     |                                                                                                                                                                                                                                                                        |             |
+-------------------------+----------+--------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-------------+
```

The below command is to retrieve a specific namespace from a project. When viewing a specific namespace, labels and annotations associated with the namespace are also shown.

```
./rctl get namespace nov-ns --v3
+--------+--------+----------------------------------------+--------+-------------+
| NAME   | TYPE   | PLACEMENT DETAILS                      | LABELS | ANNOTATIONS |
+--------+--------+----------------------------------------+--------+-------------+
| nov-ns | Wizard | rafay.dev/clusterName:prod-eks         |        |             |
+--------+--------+----------------------------------------+--------+-------------+
```

Or you can use the below commands to get more information of the namespace in json or yaml format.

```
./rctl get namespace <namespace-name> -o json
```

```
./rctl get namespace <namespace-name> -o yaml
```

***Example:***

```
./rctl get namespace demo-ns -o yaml
apiVersion: infra.k8smgmt.io/v3
kind: Namespace
metadata:
  annotations:
    annotation1: value1
    annotation2: ""
  labels:
    key1: value1
    key2: ""
  name: ns2
  project: project1
spec:
  placement:
    labels:
    - key: rafay.dev/clusterName
      value: demo-agent
```

---

## Namespace Label Configuration Specification

The Namespace Labels feature enables the definition and management of key-value labels for all namespaces at a project level. This functionality allows users to specify multiple namespace-label combinations, streamlining the organization and consistency of resource management across clusters. Labels can be configured manually through various interfaces, including the [Terraform](https://docs.rafay.co/automation/tf/overview/), [API](https://docs.rafay.co/automation/api/apis/), and [RCTL](https://docs.rafay.co/cli/namespaces/#namespace-label-configuration-specification), ensuring ease of use and adaptability. Users can track modifications via audit logs, making the feature robust and user-friendly.

> 📌 Note:
> - Namespace labels applied through this feature will only be reflected in the UI if sync is enabled. If sync is not enabled, users must query the cluster directly to view the labels for a particular namespace
> - Default Rafay labels cannot be configured or updated
> - Namespace associations are not applicable to clusters shared across projects. They are effective only on clusters within their parent project.

This enhancement is particularly beneficial for users by automating the application of namespace labels, eliminating the need for manual scripting after cluster provisioning. It supports efficient Day 2 operations by enabling updates to namespace labels and providing workflows that can be utilized for various use cases, such as chargebacks and resource tracking. Additionally, users can consistently apply labels across all namespaces, enhancing operational efficiency.

Below is the configuration specification for applying namespace labels:

```
apiVersion: tags.k8smgmt.io/v3
kind: ProjectTagsAssociation
metadata:
  name: "demo-association"
  project: "defaultproject"
spec:
  associations:
    - tagKey: "demo-key"
      tagType: "namespacelabel"
      tagValue: "demo-value"
      resource: "demo-namespace"
```

### RCTL Commands for Namespace label Association

- Create Association

```
./rctl apply -f <spec_path>
```

***Example***:

```
./rctl apply -f namespacelabelassoc.yaml
```

- Get Project Association

```
./rctl get projtagassoc
```

**Get Specific Project Association**

```
./rctl get projtagassoc <association_name>
```

***Example***:

```
./rctl get projtagassoc demo-association
┌──────────────────────────────┬──────────────────────────────────────────────────────────────────┐
│ PROJECT-TAG-ASSOCIATION NAME │                            TAGS-ASSOC                            │
│                              ├────────────────┬──────────────┬────────────────┬─────────────────┤
│                              │ TAG-ASSOC-TYPE │    TAG-KEY   │ TAG-VALUE      │ RESOURCE NAME   │
├──────────────────────────────┼────────────────┼──────────────┼────────────────┼─────────────────┤
│       demo-association       │ namespacelabel │ demo-key     │ demo-value     │ demo-namespace  │
└──────────────────────────────┴────────────────┴──────────────┴────────────────┴─────────────────┘
```

- Delete Association

```
./rctl delete projtagassoc <association_name>
```

***Example***:

```
./rctl delete projtagassoc demo-association
```

---

## Delete Namespace

Delete a "managed namespace" in the current project context using the following command. Users are allowed to delete one or more namespaces at once. Below is an example of multiple namespace deletion. Deleting a namespace will also delete the namespace from the clusters where the namespace is published.

```
./rctl delete namespace -f config.yaml --v3
```

> **Important**
> Managed namespaces cannot be deleted if they are in active use by workloads or blueprints

---

## Namespace Status

To know the status of a namespace, use the below command

```
./rctl status namespace <ns-name> --v3
```

***Output***

```
+---------+------+----------------+------------------+------------------+----------------+
| NAME    | TYPE | PUBLISHPENDING | ASSIGNEDCLUSTERS | DEPLOYEDCLUSTERS | FAILEDCLUSTERS |
+---------+------+----------------+------------------+------------------+----------------+
| demo    | Repo | false          | demo-cluster     | demo-ckuster     |                |
+---------+------+----------------+------------------+------------------+----------------+
```

> **Note**
> For help commands, append -h or --help after any of these commands. Example: `.rctl get namespace -h` or `.rctl get namespace --help`

---

## Templating

Users can also create multiple namespaces with a set of defined configurations. The template file contains a list of objects that helps to create multiple namespace(s) from a single template.

Below is an example of a namespace config template

```
# Generated: {{now.UTC.Format "2006-01-02T15:04:05UTC"}}
#      With: {{command_line}}
{{ $envName := environment "PWD" | basename}}
{{ $glbCtx := . }}{{ range $i, $project := .ProjectNames }}
{{ $ctxNS := $glbCtx }}{{ range $j, $ns := $glbCtx.Namespaces }}
apiVersion: infra.k8smgmt.io/v3
kind: Namespace
metadata:
  project: {{$envName}}-{{$project}}
  name: {{ $ns.Name }}
  labels:{{$q := $ctxNS}}{{range $k, $label := $ns.Labels}}
    {{ $label.Key }}: {{ $label.Value }}{{end}}
    environment: {{$envName}}
spec:
  drift:
    enabled: false
  placement:
    labels:{{$c := $ctxNS}}{{range $l, $cluster := $ctxNS.ClusterNames}}
      - key: rafay.dev/clusterName
        value: {{$envName}}-{{$project}}-{{ $cluster }}{{end}}
  resourceQuotas:
    configMaps: "{{ $c.ResourceQuota.ConfigMaps }}"
    cpuLimits: {{ $c.ResourceQuota.CpuLimits }}
    cpuRequests: {{ $c.ResourceQuota.CpuRequests }}
    memoryLimits: {{ $c.ResourceQuota.MemoryLimits }}
    memoryRequests: {{ $c.ResourceQuota.MemoryRequests }}
    storageRequests: {{ $c.ResourceQuota.StorageRequests }}
---{{end}}
{{end}}
```

Users can create one or more namespace(s) with the required configuration defined in the template file. Below is an example of an namespace value file. This file helps to create namespace with the specified objects

```
Namespaces:
  - Name: ns-frontend
    Labels:
      - Key: component
        Value: frontend
      - Key: app
        Value: service-xyz
  - Name: ns-backend
    Labels:
      - Key: component
        Value: backend
      - Key: app
        Value: service-xyz
  - Name: ns-database
    Labels:
      - Key: component
        Value: database
      - Key: app
        Value: service-xyz
ResourceQuota:
  ConfigMaps: "100.000000"
  CpuLimits: 500.000000m
  CpuRequests: 500.000000m
  MemoryLimits: 500.000000Mi
  MemoryRequests: 500.000000Mi
  StorageRequests: "1.000000"
```

> **Important**
> Only the objects defined in the template must be present in the value files

Use the command below to create namespace(s) with the specified configuration once the value file(s) are prepared with the necessary objects

```
 ./rctl apply -t namespace.tmpl --values values.yaml
```

where,

- ***namespace.tmpl***: template file
- ***value.yaml***: value file

Refer [Templating](https://docs.rafay.co/cli/templating_overview/) for more details on Templating flags and examples

> **Important**
> Refer [here](https://docs.rafay.co/cli/namespaces_v2/) for the deprecated RCTL commands

---
