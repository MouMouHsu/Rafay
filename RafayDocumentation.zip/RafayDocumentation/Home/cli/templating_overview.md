---
title: "KOP RCTL - Templating"
source: https://docs.rafay.co/cli/templating_overview/
category: Home
---

# Templating

The customers can now use RCTL in their automation pipeline to bring up the platform resources. The command `rctl apply -f file.yaml` helps to apply multiple resource YAML spec, rather than writing specs for each resource and relies on external scripting such as shell-script to generate spec files from templates. With this RCTL templating feature, users can avoid involving in complex, fragile scripts or automation in an attempt to parameterize input across 100s of YAML files.

To know more about the list of resources and its templating information, refer to the below links:

- [Add-Ons](https://docs.rafay.co/cli/addons/)
- [Blueprints](https://docs.rafay.co/blueprints/bp_cli/)
- [Namespace](https://docs.rafay.co/cli/namespaces/)
- [Projects](https://docs.rafay.co/cli/projects/)
- [Workloads](https://docs.rafay.co/workloads/wl_cli/)

---

## Templating Flags

| Flags | Purpose |
| --- | --- |
| --config-file string | Use this flag to create/update all-pipeline using a YAML file |
| --dry-run | Dry Run |
| --help | help for apply |
| --templates strings | Specify template file(s) |
| --test-template | Template Test (do not apply) |
| --values strings | Specify values file(s) |
| --write string | Specify file to write rendered spec |

---

## Examples

### Test Template

Below is an illustrative example of output on applying `--test-template`. This flag helps to test the templates and performs a pre-check YAML spec generation using the template, but it does not apply.

```
./rctl apply -t prjcreate.tmpl --values prjval.yaml --values prjname.yaml --test-template
 # Generated: 2022-09-03T07:01:49UTC
#   With: rctl apply -t prjcreate.tmpl --values prjval.yaml --values prjname.yaml --test-template
apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
 name: rctl-amd64
spec:
 clusterResourceQuota:
  configMaps: "1000"
  cpuLimits: 5000.000000m
  cpuRequests: 5000.000000m
  memoryLimits: 5000.000000Mi
  memoryRequests: 5000.000000Mi
  storageRequests: 100
 default: false
 defaultClusterNamespaceQuota:
  configMaps: "100"
  cpuLimits: 1000.000000m
  cpuRequests: 1000.000000m
  memoryLimits: 1000.000000Mi
  memoryRequests: 1000.000000Mi
  storageRequests: "1"
---
apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
 name: rctl-amd64
spec:
 clusterResourceQuota:
  configMaps: "1000"
  cpuLimits: 5000.000000m
  cpuRequests: 5000.000000m
  memoryLimits: 5000.000000Mi
  memoryRequests: 5000.000000Mi
  storageRequests: 100
 default: false
 defaultClusterNamespaceQuota:
  configMaps: "100"
  cpuLimits: 1000.000000m
  cpuRequests: 1000.000000m
  memoryLimits: 1000.000000Mi
  memoryRequests: 1000.000000Mi
  storageRequests: "1"
---
```

### Write Template

Below is an illustrative example of output on applying `--write string`. This flag helps to store the output in the specified path ***/tmp/o.yaml***

```
./rctl apply -t prjcreate.tmpl --values prjval.yaml --values prjname.yaml --write /tmp/o.yaml
 # Generated: 2022-09-03T07:08:14UTC
#   With: rctl apply -t prjcreate.tmpl --values prjval.yaml --values prjname.yaml  --write /tmp/o.yaml
apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
 name: rctl-amd64
spec:
 clusterResourceQuota:
  configMaps: "1000"
  cpuLimits: 5000.000000m
  cpuRequests: 5000.000000m
  memoryLimits: 5000.000000Mi
  memoryRequests: 5000.000000Mi
  storageRequests: 100
 default: false
 defaultClusterNamespaceQuota:
  configMaps: "100"
  cpuLimits: 1000.000000m
  cpuRequests: 1000.000000m
  memoryLimits: 1000.000000Mi
  memoryRequests: 1000.000000Mi
  storageRequests: "1"
---
apiVersion: system.k8smgmt.io/v3
kind: Project
metadata:
 name: rctl-amd64
spec:
 clusterResourceQuota:
  configMaps: "1000"
  cpuLimits: 5000.000000m
  cpuRequests: 5000.000000m
  memoryLimits: 5000.000000Mi
  memoryRequests: 5000.000000Mi
  storageRequests: 100
 default: false
 defaultClusterNamespaceQuota:
  configMaps: "100"
  cpuLimits: 1000.000000m
  cpuRequests: 1000.000000m
  memoryLimits: 1000.000000Mi
  memoryRequests: 1000.000000Mi
  storageRequests: "1"
---
```
