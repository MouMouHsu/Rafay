---
title: "KOP CLI - Backup and Restore"
source: https://docs.rafay.co/cli/backup_cli/
category: Home
---

# Backup

## Backup and Restore CLI

Included in the Kubernetes Operation Platform is a fully integrated cluster backup and restore capability. Administrators can configure backups for their clusters and workloads.

With this capability, administrators can:

- Quickly recover clusters from disasters, like hardware failures.
- Migrate clusters from one environment to another, like on-prem to cloud.
- Recover data for specific workload namespaces to the last known, good configuration in case of data corruption.

**Topic Links**

- [RCTL for Backup Location](#nestedblock--backup_location)
- [Credentials](#nestedblock--credentials)
- [RCTL for Data Agents](#nestedblock--data_agent)
- [RCTL for Backup Policy](#nestedblock--backup_policy)
- [RCTL for Backup Job](#nestedblock--backup_job)
- [RCTL for Restore Policy](#nestedblock--restore_policy)
- [RCTL for Restore Job](#nestedblock--restore_job)

---

## RCTL for Data Agents

Users can also create/update/delete/deploy/un-deploy a data agent through RCTL to their clusters with the below commands

**Create Data Agents of Version v1.9.3**

```
 ./rctl create dp-agent <name> --cloud-credentials <cloudcredentials>
```

**Create Data Agents (Enabling Volume Backups for On-prem Clusters) of Version v1.9.3**

```
./rctl create dp-agent <name> --cloud-credentials <cloud-credentials> --enable-onprem
```

**Create Data Agents (Enabling Volume Backups for On-prem Clusters) of Version v1.15.1**

```
./rctl create dp-agent <name> --cloud-credentials <cloudcredentials> --version <version> --customer-key <sse-c customer key> --enable-onprem --optional-features <comma separated list>
```

**Upgrade Data Agents**

To upgrade a data agent deployed across all clusters, use the following command:

```
./rctl upgrade dp-agent <agent-name> --version v1.15.1
```

To upgrade data agent deployed in specific clusters, use the following command:

```
./rctl upgrade dp-agent <agent-name> --version v1.15.1 --dp-clusters "cluster-1,cluster-2,cluster-3"
```

**Delete Data Agents**

```
./rctl delete dp-agent <name>
```

**Fetch Data Agents**

```
./rctl get dp-agent
```

An illustrative example is shown below where RCTL retrieves the list of agents

```
/rctl get dp-agent
+--------------------------+---------+-------------------+----------+------------------------------+
| NAME                     | VERSION | CLOUD CREDENTIALS | CLUSTERS | CREATED AT                   |
+--------------------------+---------+-------------------+----------+------------------------------+
| test-dp                  | v1.15.1 | aws-creds   | 1        | Fri Mar 14 19:40:20 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test-bkp                 | v1.15.1 | aws-creds   | 0        | Mon Mar 10 10:15:52 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test090                  | v1.15.1 |                   | 0        | Tue Mar 18 13:22:38 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test-bkp-1-5-3           | v1.15.1 | aws-creds   | 0        | Mon Mar 10 10:37:16 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test                     | v1.15.1 | aws-creds   | 0        | Fri Mar 14 12:46:18 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test-1-9-3               | v1.9.3  | aws-creds   | 0        | Tue Mar 25 08:49:07 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test-1-15                | v1.15.1 |                   | 0        | Tue Mar 25 08:55:58 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test-dp-19               | v1.15.1 | aws-creds   | 0        | Tue Mar 25 08:59:30 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test-1-9-3-with-clusters | v1.15.1 | aws-creds   | 0        | Tue Mar 25 08:51:55 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
| test-rctl                | v1.9.3  | aws-creds   | 1        | Tue Mar 25 09:02:48 UTC 2025 |
+--------------------------+---------+-------------------+----------+------------------------------+
```

Use the below command to retrieve a specific agent's details

```
./rctl get dp-location <agent-name>
```

**Update Data Agents**

```
./rctl update dp-agent <name> --cloud-credentials <cloudcredentials>
```

**Update Data Agents (If Volume Backups for On-prem Clusters is enabled)**

```
./rctl update dp-agent <name> --cloud-credentials <cloud-credentials> --enable-onprem
```

**Deploy Data Agents**

```
./rctl deploy dp-agent <agent-name> --cluster-name <cluster-name>
```

**Un-deploy Data Agents**

```
./rctl undeploy dp-agent <agent-name> --cluster-name <clustername>
```

> **Important**
> Agent deletion is not supported

---

## RCTL for Backup Location

### Amazon S3 Storage/S3 Compatible Storage

Users can also define a location to store the backup snapshots through RCTL with the below commands

**Create Control Plane Backup Location of Version 1.9.3 with Amazon Target Type**

```
 ./rctl create dp-location <name> --backup-type <controlplanebackup> --target-type <amazon> --region <region> --bucket-name <bucketname>
```

**Create Control Plane Backup Location of Version 1.9.3 with S3 Compatible Endpoint Target Type**

```
./rctl create dp-location <name> --backup-type <controlplanebackup> --target-type <s3compatible> --url <url> --bucket-name <bucketname>
```

**Create Control Plane Backup Location of Version 1.15.1 with Amazon Target Type**

```
 ./rctl create dp-location <name> --backup-type <controlplanebackup> --target-type <amazon> --region <region> --bucket-name <bucketname> --skip-tls-verify  --enable-sse-c --kms-key-id <KMS key ID> --encryption-type <server-side encryption algorithm>
```

**Create Control Plane Backup Location of Version 1.15.1 with S3 Compatible Endpoint Target Type**

```
./rctl create dp-location <name> --backup-type <controlplanebackup> --target-type <s3compatible> --region <region> --bucket-name <bucketname> --skip-tls-verify  --enable-sse-c --kms-key-id <KMS key ID> --encryption-type <server-side encryption algorithm>
```

**Create Volume Backup Location with Amazon Target Type**

```
./rctl create dp-location <name> --backup-type <volumebackup> --target-type <amazon> --region <region> --bucket-name <bucketname>
```

**Create Volume Backup Location with S3 Compatible Endpoint Target Type**

```
./rctl create dp-location <name> --backup-type <volumebackup> --target-type <s3compatible> --url <url> --bucket-name <bucketname>
```

**Update Location objects with Amazon Target Type**

```
./rctl update dp-location <name> --backup-type <backup-type> --target-type <amazon> --region <region> --bucket-name <bucketname>
```

**Update Location objects with S3 Compatible Endpoint Target Type**

```
./rctl update dp-location <name> --backup-type <backup-type> --target-type <s3compatible> --url <url> --bucket-name <bucketname>
```

### Azure Storage Account

For AKS clusters, users can define a location to store the backup snapshots through RCTL with the below commands

**Create Control Plane Backup Location with Azure Target Type**

```
./rctl create dp-location <name> --backup-type <controlplanebackup> --target-type <azure> --bucket-name <bucketname> --resource-group <resource-group> --storage-account <storage-account>
```

**Create Volume Backup Location with Azure Target Type**

```
./rctl create dp-location <name> --backup-type <volumebackup> --target-type <azure> --resource-group <resource-group>
```

**Update Control Plane Backup Location with Azure Target Type**

```
./rctl update dp-location <name> --backup-type <controlplanebackup> --target-type <azure> --bucket-name <bucketname> --resource-group <resource-group> --storage-account <storage-account>
```

**Update Volume Backup Location with Azure Target Type**

```
./rctl update dp-location <name> --backup-type <volumebackup> --target-type <azure> --resource-group <resource-group>
```

---

### Fetch / Delete Location

**Delete Location**

```
./rctl delete dp-location <name>
```

**Fetch Location objects**

```
./rctl get dp-location
```

An illustrative example is shown below where RCTL retrieves the list of location objects

```
+-------------------+----------------------+------------------------------+
| NAME              | TYPE                 | CREATED AT                   |
+-------------------+----------------------+------------------------------+
| demo-cpb          | Control Plane Backup | Fri Sep 17 09:26:19 UTC 2021 |
+-------------------+----------------------+------------------------------+
| demo-controlplane | Control Plane Backup | Fri Sep 17 09:25:53 UTC 2021 |
+-------------------+----------------------+------------------------------+
| demo-volume       | Volume Backup        | Fri Sep 17 09:26:06 UTC 2021 |
+-------------------+----------------------+------------------------------+
```

Use the below command to retrieve a specific location's details

```
./rctl get dp-location <location-name>
```

---

## Credentials

Credentials are required to access the backup location and perform backup/restore operations. Refer to the below table for more details on each provider credentials.

> Note: Credentials are created in the provider's console.

| S. No | Provider | Reference |
| --- | --- | --- |
| 1 | AWS | [AWS S3 Credentials](https://docs.rafay.co/backup/credentials_aws/) |
| 2 | MINIO | [S3 Compatible Credentials](https://docs.rafay.co/backup/credentials_s3/) |
| 3 | AZURE | [Azure Credentials](https://docs.rafay.co/backup/credentials_azure/) |

---

## RCTL for Backup Policy

Administrators can also create a backup policy through RCTL using the below commands to specify how, when and what needs to be backed up

**Create Backup Policy**

```
.rctl create dp-policy <name> --type <backup> --location <location> --snapshot-location <snapshot-location> --retention-period <period> --include-namespace <include-ns> --exclude-namespace <exclude-ns> --label-selector <key:value,key:"",key:value>
```

**Delete Policy**

```
.rctl delete dp-policy <name>
```

**Fetch Policy**

```
.rctl get dp-policy
```

An illustrative example is shown below where RCTL retrieves the list of policies

```
+--------------+---------+------------------------------+
| NAME         | TYPE    | CREATED AT                   |
+--------------+---------+------------------------------+
| demo-backup  | Backup  | Fri Sep 17 09:26:45 UTC 2021 |
+--------------+---------+------------------------------+
| demo-restore | Restore | Fri Sep 17 09:27:08 UTC 2021 |
+--------------+---------+------------------------------+
| demo-bp      | Backup  | Fri Sep 17 09:27:19 UTC 2021 |
+--------------+---------+------------------------------+
```

Use the below command to retrieve a specific policy details

```
.rctl get dp-policy <policy-name>
```

**Update Backup Policy**

```
.rctl update dp-policy <name> --type <backup> --location <location> --snapshot-location <snapshot-location> --retention-period <period> --include-namespace <include-ns> --exclude-namespace <exclude-ns> --label-selector <key:value,key:"",key:value>
```

---

## RCTL for Backup Job

Users can also create or schedule backup jobs through RCTL for the clusters

**Create Backup Jobs**

```
./rctl create dp-job --policy <policy> --cluster <clustername>
```

**Schedule Backup Jobs**

```
./rctl create dp-job --policy <policy> --cluster <clustername> --schedule <'*/5****'>
```

> 🚀  Note: Time zone can now be specified in the --schedule parameter using CRON_TZ=<TimeZone>, allowing backups to run at a configured time zone instead of UTC.
> Example:
> ./rctl create dp-job --policy <policy> --cluster <clustername> --schedule <'CRON_TZ=Asia/Kolkata 42 1 * * *'>
> This capability is available only in the latest version of the backup agent v1.15.1

**Fetch Backup Jobs**

```
./rctl get dp-job
```

An illustrative example is shown below where RCTL retrieves the list of jobs

```
+-----------------------------------------+---------+----------+-----------+------------------------------+------------------------------+
| NAME                                    | TYPE    | CLUSTER  | STATUS    | STARTED AT                   | COMPLETED AT                 |
+-----------------------------------------+---------+----------+-----------+------------------------------+------------------------------+
| demo-restore-1pm95i35-4qkolkn-rx28oml   | Restore | rctl1bp1 | Completed | Fri Sep 17 09:35:06 UTC 2021 | Fri Sep 17 09:35:36 UTC 2021 |
+-----------------------------------------+---------+----------+-----------+------------------------------+------------------------------+
| demo-backup-m84n5d56-4qkolkn-rctlbp2    | Backup  | rctl1bp1 | Completed | Fri Sep 17 09:34:13 UTC 2021 | Fri Sep 17 09:34:13 UTC 2021 |
+-----------------------------------------+---------+----------+-----------+------------------------------+------------------------------+
| demo-backup-m84n5d56-4qkolkn-rctlbp2    | Backup  | rctlbp2  | Completed | Fri Sep 17 09:33:13 UTC 2021 | Fri Sep 17 09:33:16 UTC 2021 |
+-----------------------------------------+---------+----------+-----------+------------------------------+------------------------------+
```

> **Important**
> Job deletion is not supported

---

## RCTL for Restore Policy

Administrators can also create a restore policy through RCTL using the below commands to specify the rules a restore job has to comply with when it performs a restore operation

### Create Restore Policy

```
./rctl create dp-policy <name> --type <restore> --restore-pvs --include-namespace <include-ns> --exclude-namespace <exclude-ns> --label-selector <key:value,key:"",key:value>
```

### Fetch Policy

```
./rctl get dp-policy <name>
```

### Update Restore Policy

```
./rctl update dp-policy <name> --type <restore> --restore-pvs --include-namespace <include-ns> --exclude-namespace <exclude-ns> --label-selector <key:value,key:"",key:value>
```

### Delete Policy

```
./rctl delete dp-policy <name>
```

---

## RCTL for Restore Job

Users can also restore job through RCTL with the below commands

**Restore Jobs**

```
./rctl create dp-job --policy <policy> --cluster <cluster-name> --source-cluster <source-cluster> --restore-from-backup <backup> --restoreType <DisasterRecovery, Cloning>
```

**Get Restore Jobs**

```
./rctl get dp-job
```

---
