---
title: "KOP CLI - Cloud Credentials"
source: https://docs.rafay.co/cli/credentials_v2/
category: Home
---

# Credentials

> **This is a legacy version**
> For the latest Credentials CLI information, see the [Cloud Credentials CLI](https://docs.rafay.co/cli/credentials/) topic.

The RCTL utility provides the means to manage the lifecycle of credentials. The following operations can be performed on credentials managed by the controller in projects inside your organization.

| Resource | Create | Get | Update | Delete | Publish | Unpublish |
| --- | --- | --- | --- | --- | --- | --- |
| Credentials | YES | YES | NO | YES | N/A | N/A |

---

> **Important**
> An IAM Role must be created in the AWS Console per the following instructions. Be sure to set the Account ID and External ID as a trusted entity which gives the controller permission to assume the role.

[IAM Roles and Policies - AWS-EKS](https://docs.rafay.co/clusters/eks/credentials/)

---

## Create Credential (AWS)

Create a new "managed" credential in the current Project in the Controller.

### Imperative

Use this to create a credential which will be used to provision clusters.

```
 ./rctl create credential aws my-cloud-credential --cred-type cluster-provisioning --external-id 35ba1eac-76eb-4f30-b872-d84b8e270eec --role-arn arn:aws:iam::679196758854:role/my_iam_role
```

> **Important**
> Avoid upper case characters for the name because Kubernetes does not support it.

---

## Data Backup/Restore using IRSA via RCTL

Use the below command to create a cloud credential using arn role

```
./rctl create credential aws <name> --cred-type <data-backup> --role-arn <role_arn>
```

Use the below command to update an existing cloud credential using arn role

```
./rctl update credential aws <name> --cred-type <data-backup> --role-arn <new_role_arn>
```

---

## List Credentials

Use this to retrieve/list all "managed credentials" in the currently specified "Project". An illustrative example is shown below.

```
./rctl get credentials
+-----------------------+-------+------------------------------+------------------------------+-----------+
| NAME                  | CLOUD | CREATED AT                   | MODIFIED AT                  | OWNERSHIP |
+-----------------------+-------+------------------------------+------------------------------+-----------+
| my-full-iam-role      | AWS   | Tue Jun 29 22:33:04 UTC 2021 | Tue Jun 29 22:33:04 UTC 2021 | self      |
+-----------------------+-------+------------------------------+------------------------------+-----------+
| minio                 | MINIO | Tue Jun 20 22:16:07 UTC 2021 | Tue Apr 20 22:16:07 UTC 2021 | self      |
+-----------------------+-------+------------------------------+------------------------------+-----------+
```

---
