---
title: "KOP CLI - Cloud Credentials"
source: https://docs.rafay.co/cli/credentials/
category: Home
---

# Cloud Credentials

The RCTL utility provides the means to manage the lifecycle of credentials. The following operations can be performed on credentials managed by the controller in projects inside your organization.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Credentials | YES | YES | NO | YES |

---

## Cloud Provider Credentials

Use the Controller to configure cloud credentials for a Project. Use the following links for information about cloud platform credentials.

- [IAM Roles and Policies - AWS-EKS](https://docs.rafay.co/clusters/eks/credentials_clusterprovisioning/#step-2-create-iam-role)
- [IAM Roles and Policies - GCP-GKE](https://docs.rafay.co/clusters/gke/gcp_setup/)
- [Azure-AKS](https://docs.rafay.co/clusters/aks/azure_setup/)
- [MinIO](https://docs.rafay.co/recipes/backup/velero/creds_minio_vault/)

> **Important**
> For Amazon EKS and Google GKE, an IAM role must be created in the cloud platform console. Use the following links for instructions.
>
> For Amazon EKS, be sure to set the Account ID and External ID as a trusted entity which gives the controller permission to assume the role.

---

## Create Credential

Create a new "managed" credential in the current Project using the Controller.

- See [CLI Setup](https://docs.rafay.co/cli/config/#set-project) for setting the current Project.
- See [YAML Examples](https://docs.rafay.co/cli/credentials/#yaml-examples) for credential config files, based on the cloud platform.

Use this to create a credential which will be used to provision clusters.

```
./rctl apply -f <filename.yaml>
```

---

## Update Credential

To update a credential, make the required changes in the existing credential config file and use the below command

```
./rctl apply -f <filename.yaml>
```

---

## List Credentials

Use this to retrieve/list all "managed credentials". An illustrative example is shown below.

```
./rctl get credentials --v3
+-----------------------+-------+------------------------------+------------------------------+-----------+
| NAME                  | CLOUD | CREATED AT                   | MODIFIED AT                  | OWNERSHIP |
+-----------------------+-------+------------------------------+------------------------------+-----------+
| my-cred      | AWS   | Tue Jun 29 22:33:04 UTC 2021 | Tue Jun 29 22:33:04 UTC 2021          | self      |
+-----------------------+-------+------------------------------+------------------------------+-----------+
| minio                 | MINIO | Tue Jun 20 22:16:07 UTC 2021 | Tue Apr 20 22:16:07 UTC 2021 | self      |
+-----------------------+-------+------------------------------+------------------------------+-----------+
```

To retrieve a specific credential details, use the below command

```
./rctl get credentials my-cred --v3
+-----------------------+-------+------------------------------+------------------------------+-----------+
| NAME                  | CLOUD | CREATED AT                   | MODIFIED AT                  | OWNERSHIP |
+-----------------------+-------+------------------------------+------------------------------+-----------+
| my-cred      | AWS   | Tue Jun 29 22:33:04 UTC 2021 | Tue Jun 29 22:33:04 UTC 2021          | self      |
+-----------------------+-------+------------------------------+------------------------------+-----------+
```

---

## Delete Credentials

Use the below command to delete a credential.

```
./rctl delete credential <credential_name>
```

> **Note**
> Shared credentials cannot be deleted. Update the credential with sharing disabled, then delete the credential.

## Deprecated Commands

Refer [here](https://docs.rafay.co/cli/credentials_v2/) for the deprecated RCTL Commands.

---

## YAML Examples

The following YAML file examples are specific for each cloud provider. In each example, change the `name` and `project` to match your environment.

For `spec.type`, supported values are `ClusterProvisioning`, `DataBackup`, or `CostManagement`.

### AWS EKS Access ID and Secret Key

```
apiVersion: infra.k8smgmt.io/v3
kind: Credentials
metadata:
  name: test-credentials
  project: defaultproject
spec:
  sharing:
      enabled: false
  type: ClusterProvisioning
  provider: aws
  credentials:
    type: AccessKey
    accessId: <access_id>
    secretKey: <secret_key>
```

### AWS EKS Role ARN

```
apiVersion: infra.k8smgmt.io/v3
kind: Credentials
metadata:
  name: test-credentials
  project: defaultproject
spec:
  sharing:
    enabled: false
  type: ClusterProvisioning
  provider: aws
  credentials:
    type: Role
    arn: <role_arn>
    accountId: "<account_id>"
    externalId: "<external_id>"
```

### Microsoft Azure AKS

```
apiVersion: infra.k8smgmt.io/v3
kind: Credentials
metadata:
  name: test-credentials
  project: defaultproject
spec:
  sharing:
      enabled: false
  type: ClusterProvisioning
  provider: azure
  credentials:
    tenantId: <tenant_id>
    subscriptionId: <subscription_id>
    clientId: <clientId>
    clientSecret: <clientSecret>
```

### Google GCP GKE

> **Note**
> For the credentials file, covert your GCP Service Account Key to Base64, then use it with the example below.

```
apiVersion: infra.k8smgmt.io/v3
kind: Credentials
metadata:
  name: test-credentials
  project: defaultproject
spec:
  sharing:
      enabled: false
  type: ClusterProvisioning
  provider: gcp
  credentials:
    file: dvacICJ0eXBlIjogInNlcnZpY2VfYWNjb3VudCIsCiAgInByb2plY3RfaWQiOiAiY2FwaS1nY3AtdGVzdDEiLAogICJwcml2YXRlX2tleV9pZCI6ICI1OWM2YzIyN2MyNWY5MWQyYTJmYmM1OWNiMmQ0NDllZThjMGYyNDY0IiwKICAicHJpdmF0ZV9rZXkiOiAiLS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tXG5NSUlFdkFJQkFEQU5CZ2txaGtpRzl3MEJBUUVGQUFTQ0JLWXdnZ1NpQWdFQUFvSUJBUURacVBuWkZ4bG95MFNpXG44WWNRUzlITUp1ZENZZzA0N05oMUdwSUw1cU1pV2RHTjdNWkNkUVo1ck8ydTB0Z0ExVG1kaDR2MUV1MEx0U1ZEXG5rcHJIcHp0bnZOam9JaXZyWExUYmxrdHNObmdtWTZvdlZaaWttcU9rOTJrT044SDhzNVJjNWYwOC9VSnQ2ajAvXG5oRUFoRXZlOFk0aG1FOFQ3ZGZuMDBrajcvUVBBMnFVWE1iekdHRUsyZ3VlbDNoTlE4RzNZVGJCRTZuSjVTMzlrXG5RRTFZK002ZU9NMDk3aFFxaERJZGNaOFBpeHpMWjFodTVmN2tEVnNpMlBRNk1SZzlVWUlXY00wZkI5dDRXWGN6XG55MjkwN1AyZXppcDNnSm9FanNkd0VzUlhLRktyRmdkQ1FvL2x4QzNVL1htbVFNQ05iZkQ4eVpuNSt3aXJJZHcxXG5jMzBCWkF5SEFnTUJBQUVDZ2dFQUcrVnZ6RGFOTDZTcHNkYVIwSEZmUExLWnZpVFIvQU5EQk5NNGQ2VUNNSU5oXG5lN2FtZkZzQ1R2THViWk1oVXc0QStlTW0rV3lKREJDVjY1Q3RITHlldlA5enIyQzl6MGNNK1AzTXdkeERUdXhFXG5JaGZ1M2QzaDdtRTFTamkwT0o2TmU5Q1FRZEpWd3IrY1JQayt2TjV3K09pcTBTWmtmelFTS3FJTzc1andjN1YxXG5kNkF0ZFZqTGljMkxuUEh2aG92aEg1ZU5iUFhPUmk1V0IwSDNHVElDNkIvdmZyOHRzUy9xSCH0b1BMQ2UwMWNIXG5sQTBNU2FmV2FjT0tIaExFVDd5dENEdFowOUpGSFEzRm5Vak1oTlg5QTMxbndIeVROUGV2NFBUc1dNUTk5eVlHXG5iRTRlVUtFZ1BtR0VjSkF3b3Q5aHNMbEMybXZCdnNNdGJQZnFOR2dPM1FLQmdRRCtwMVVZSUdMbkNWNkJISHF3XG5kTFlOUHoxbTg1OVhaMk9ZWnhiZ21UTys2aGhxeWpDeUNxQXpRTjZ2d3JUNTN2cjI0bUgxZGowNlhhSkh3dENXXG5udWF0QkE0OTlreENiZUdKUDdtMmJmeGloOENiOVVEVlVNZ1BDWThkODFBNTVkKzQ5TmFVWis2RFFmbkFIVHV2XG5EcjFxaVh2ajVZZ2NsY0ZKL2RzQjhtUzlLd0tCZ1FEYXo1TGFkSm5EaHZOaEZOYS9Eb2p0NFN0UjRha2ZqUFViXG5ycm9UNm9NSEV2NTlTRTJuSFpuN3phVUF6SmJnL0U2THFzTG5FdlJKdnJVOHV3TGR2UXhQMHlXT1FUZ0tuMTlNXG5VNnFIdlhVSmp1a0JsTy80bHZwUEhCdTE4WGtEZURXeHNrV3l4MWx4RzVnQmRmdDZGKzZ5eXUzbXU0TEFIazlFXG41NytFaXUyWUZRS0JnQ3h5cXBDbWZuelREdEs4Vk5IZDNUVGN0K3Z6VS9tZWl5eTd1YXVFTWhyOW96dG9oUzFlXG5XMjMyd2FldDlZYXptOXhoMFRWVjZRUDUrZXhLbmJ2Y2ltamlqMVhUV3FZeHBhOGVGMTAzUDFrM1ZyQWlFNm5vXG5Dck5OT05UQ2RsdFV1MEwrUVVId0RocU05bm5JNEhVQ3ZwOE0xam9HQTBieUFLWFlrRlI3cVllM0FvR0FNbVE5XG5pTXZ6b1lFUnlkalh2L1pqK0l5endrNjYrVVlvS0xEcnI2eUJjbjZnVjAvd2VqMHAra0NZOEg4dGZERC9FZEZJXG53NWlzNDlMa3dGQzlUejI3ZVNMQ2NtbDRzNUdTaSt4MHlJQU1WU0F4YnlqU3Z5aGVDeHdKRWJURHp0Vy9YK1lUXG5nU0hCNm5lVllUaS9xcFdhWmxpdncwU0p6eDdyMkkyYW9MYXlFeVVDZ1lCcUNUdkNvcW1QdjBnRE52eDhBcU1NXG53MFBXT2lqV3VNYnVRb1NUSC8rcDFCU1VsOEI1bmV0Y21WQm1YL3F0WjByNFlwSG1BcXJLWExEZkZpRklOTVY1XG5IWmNaUDZUZEQwbm1ZZitLVm5KZFFic0NwTTBLeHdIK1lQejJIem01bjY3elhGNTM2VXR0azh4Ykp1blBZL3lyXG5SNnA2dzNSdDhZUUp2NDVpaCtKRkpnPT1cbi0tLS0tRU5EIFBSSVZBVEUgS0VZLS0tLS1cbiIsCiAgImNsaWVudF9lbWFpbCI6ICJna2UtYWRtaW4tYWNjZXNzQGNhcGktZ2NwLXRlc3QxLmlhbS5nc2VydmljZWFjY291bnQuY29tIiwKICAiY2xpZW50X2lkIjogIjExNTM3OTg5OTY0NTk3OTAwNTgzMSIsCiAgImF1dGhfdXJpIjogImh0dHBzOi8vYWNjb3VudHMuZ29vZ2xlLmNvbS9vL29hdXRoMi9hdXRoIiwKICAidG9rZW5fdXJpIjogImh0dHBzOi8vb2F1dGgyLmdvb2dsZWFwaXMuY29tL3Rva2VuIiwKICAiYXV0aF9wcm92aWRlcl94NTA5X2NlcnRfdXJsIjogImh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL29hdXRoMi92MS9jZXJ0cyIsCiAgImNsaWVudF94NTA5X2NlcnRfdXJsIjogImh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL3JvYm90L3YxL21ldGFkYXRhL3g1MDkvZ2tlLWFkbWluLWFjY2VzcyU0MGNhcGktZ2NwLXRlc3QxLmlhbS5nc2VydmljZWFjY291bnQuY29tIgp7Bh==
```

### MKS Cloud Credential

```
apiVersion: infra.k8smgmt.io/v3
kind: Credentials
metadata:
  name: mks-ssh-credentials
  project: defaultproject
spec:
  type: ClusterProvisioning
  provider: mks
  credentials:
    agents:
      - name: mks-gitops-agent
    username: ubuntu
    port: '22'
    privateKey: "sample-ssh-key"
```

> **Important**
> Ensure to update the GitOps agent to version r2.8.0 or later.

### VMware vSphere

```
apiVersion: infra.k8smgmt.io/v3
kind: Credentials
metadata:
  name: test-credentials
  project: defaultproject
spec:
  sharing:
      enabled: false
  type: ClusterProvisioning
  provider: vsphere
  credentials:
    gatewayId: <gateway_id>
    vsphereServer: <vsphere_server>
    username: <user_name>
    password: <password>
```

### MinIO

> **Note**
> MinIO does DataBackup only.

```
apiVersion: infra.k8smgmt.io/v3
kind: Credentials
metadata:
  name: test-credentials
  project: defaultproject
spec:
  sharing:
      enabled: false
  type: DataBackup
  provider: minio
  credentials:
    accessId: <access_id>
    secretKey: <secret_key>
```

---
