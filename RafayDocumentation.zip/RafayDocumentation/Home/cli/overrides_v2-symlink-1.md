---
title: "KOP CLI - Cluster Overrides"
source: https://docs.rafay.co/cli/overrides_v2-symlink-1/
category: Home
---

# v2 Specifications (Legacy)

The table below describes the list of actions that can be performed on "Cluster Overrides" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Cluster Overrides | YES | YES | YES | YES |

---

## Create Cluster Override for Add-ons/Workloads

> **Important**
> Examples below are shown for an addon. To define overrides for a workload you would use the type "ClusterOverrideTypeWorkload".

An example of a helm type workload cluster override spec is shown below. The example is using multiple cluster labels as the selector.

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: override-test-env-clusters-with-inline-values
spec:
  clusterSelector: rafay.dev/clusterType in (aws-eks),rafay.dev/monitoring in (enabled)
  resourceSelector: rafay.dev/name=override-workload
  type: ClusterOverrideTypeWorkload
  overrideValues: |
    replicaCount: 1
    image:
      repository: nginx
      pullPolicy: Always
      tag: "1.19.8"
    service:
      type: ClusterIP
      port: 8080
```

### Declarative (Inline)

Use the following command to create a cluster override for your addon named "aws-lb-controller" using inline values

```
./rctl create co -f cluster-override-addon-spec.yml
```

**Helm Type**

An illustrative example of the cluster override spec file of **Helm Type** is shown below

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: co-with-inline-values-my-cluster-name
spec:
  clusterSelector: rafay.dev/clusterName in (my-cluster-name)
  resourceSelector: rafay.dev/name=aws-lb-controller
  type: ClusterOverrideTypeAddon
  overrideValues: |
    clusterName: my-cluster-name
```

**Yaml Type**

For Yaml Type override, an additional parameter **artifactType** is mandatory. An illustrative example of the cluster override spec file of **YAML Type** is shown below

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: co-with-inline-values-my-cluster-name
spec:
  artifactType: NativeYAML
  clusterSelector: rafay.dev/clusterName in (my-cluster-name)
  resourceSelector: rafay.dev/name=aws-lb-controller
  type: ClusterOverrideTypeAddon
  overrideValues: |
    clusterName: my-cluster-name
```

(or)

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: co-with-inline-values-my-cluster-name
spec:
  artifactType: GitRepoWithNativeYAML
  clusterSelector: rafay.dev/clusterName in (my-cluster-name)
  resourceSelector: rafay.dev/name=aws-lb-controller
  type: ClusterOverrideTypeAddon
  overrideValues: |
    clusterName: my-cluster-name
```

---

### Declarative (local file)

Use the following command to create a cluster override for your addon named "aws-lb-controller" using values defined in a local file.

```
./rctl create co -f co-addon-spec-local.yml
```

An illustrative example of the Helm Type cluster override spec is shown below.

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: co-with-local-values-my-cluster-name
spec:
  clusterSelector: rafay.dev/clusterName in (my-cluster-name)
  resourceSelector: rafay.dev/name=aws-lb-controller
  type: ClusterOverrideTypeAddon
  valuesFile: ./override-values.yaml
```

An example of the valuesFile "override-values.yaml" used above.

```
clusterName: my-cluster-name
```

An illustrative example of the YAML Type cluster override spec is shown below.

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: payment-deployment
spec:
  artifactType: NativeYAML
  clusterPlacement:
    placementType: ClusterSpecific
    clusterLabels:
      - key: rafay.dev/clusterName
        value: test-cluster
  resourceSelector: rafay.dev/name=override-workload
  type: ClusterOverrideTypeWorkload
  overrideValues: |
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: nginx
    patch:
    - op: replace
      path: /spec/replicas
      value: 4
```

---

### Declarative (Git)

Use the following command to create a cluster override for your addon named "aws-lb-controller" using a values file stored in your Git repo.

```
./rctl create co -f co-addon-spec-git.yml
```

An illustrative example of the Helm Type cluster override spec is shown below.

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: co-with-git-values-my-cluster-name
spec:
  clusterSelector: rafay.dev/clusterName in (my-cluster-name)
  resourceSelector: rafay.dev/name=aws-lb-controller
  type: ClusterOverrideTypeAddon
  valuesRepoRef: my-git-repo
  valuesRepoArtifactMeta:
    git:
      revision: main
      repoArtifactFiles:
      - name: override-values.yaml
        relPath: override-values.yaml
        fileType: K8sYAMLFile
```

An example of the valuesFile "override-values.yaml" used above.

```
clusterName: my-cluster-name
```

An illustrative example of the YAML Type cluster override spec is shown below.

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: payment-deployment
spec:
  artifactType: GitRepoWithNativeYAML
  clusterPlacement:
    placementType: ClusterSpecific
    clusterLabels:
      - key: rafay.dev/clusterName
        value: test-cluster
  resourceSelector: rafay.dev/name=override-workload
  type: ClusterOverrideTypeWorkload
  overrideValues: |
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: nginx
    patch:
    - op: replace
      path: /spec/replicas
      value: 4
```

---

## List Cluster Overrides

Use this command to retrieve the list of cluster overrides in the configured Project. The name of the override, cluster selector, resource selector, type, and the override values are returned.

```
./rctl get co --type ClusterOverrideTypeAddon
```

```
+---------------------------------------+--------------------------------+----------------------------------+--------------------------+------------------------------+
| OVERRIDE NAME                         | CLUSTER SELECTOR               | RESOURCE SELECTOR                | TYPE                     | OVERRIDE VALUES              |
+---------------------------------------+--------------------------------+----------------------------------+--------------------------+------------------------------+
| co-with-inline-values-my-cluster-name | rafay.dev/clusterName in       | rafay.dev/name=aws-lb-controller | ClusterOverrideTypeAddon | clusterName: my-cluster-name |
|                                       | (my-cluster-name)              |                                  |                          |                              |
+---------------------------------------+--------------------------------+----------------------------------+--------------------------+------------------------------+
```

---

## Update Cluster Override

Use this command to update a cluster override in the configured project.

```
./rctl update co -f cluster-override-addon-spec-update.yaml
```

An illustrative example of the cluster override update spec YAML file is shown below. T

```
kind: ClusterOverride
apiVersion: config.rafay.dev/v2
metadata:
  name: co-with-inline-values-my-cluster-name
spec:
  clusterSelector: rafay.dev/clusterName in (my-cluster-name)
  resourceSelector: rafay.dev/name=aws-lb-controller
  type: ClusterOverrideTypeAddon
  overrideValues: |
    clusterName: my-cluster-name
    replicaCount: 2
    enableCertManager: true
    terminationGracePeriodSeconds: 10
```

Use the command below to verify the updates have been applied to the cluster override.

```
./rctl get co --type ClusterOverrideTypeAddon
```

```
+---------------------------------------+--------------------------------+----------------------------------+--------------------------+--------------------------------+
| OVERRIDE NAME                         | CLUSTER SELECTOR               | RESOURCE SELECTOR                | TYPE                     | OVERRIDE VALUES                |
+---------------------------------------+--------------------------------+----------------------------------+--------------------------+--------------------------------+
| co-with-inline-values-my-cluster-name | rafay.dev/clusterName in       | rafay.dev/name=aws-lb-controller | ClusterOverrideTypeAddon | clusterName: my-cluster-name   |
|                                       | (my-cluster-name)              |                                  |                          | replicaCount: 2                |
|                                       |                                |                                  |                          | enableCertManager: true        |
|                                       |                                |                                  |                          | terminationGracePeriodSeconds: |
|                                       |                                |                                  |                          | 10                             |
+---------------------------------------+--------------------------------+----------------------------------+--------------------------+--------------------------------+
```

---

## Delete Cluster Override

You can delete a cluster override in the configured project.

```
./rctl delete co co-with-inline-values-my-cluster-name --type ClusterOverrideTypeAddon
```

---

[Cluster Overrides for Blueprints](https://docs.rafay.co/blueprints/overrides/)

[Cluster Overrides for Workloads](https://docs.rafay.co/workloads/overrides/)
