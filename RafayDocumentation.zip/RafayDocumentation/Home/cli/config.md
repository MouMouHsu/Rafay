---
title: "KOP CLI - Config"
source: https://docs.rafay.co/cli/config/
category: Home
---

# Setup

The RCTL utility needs to be initialized with credentials and other information before it can interact with the Controller. At a given time, RCTL can be initialized with only one configuration. It can always be reinitialized if it needs to be bound to a different Org/Tenant.

At a given time, RCTL can be initialized with only one configuration. Note that the RBAC associated with the user's credentials is automatically enforced.

---

## Initialize

RCTL supports both a "config file" as well as "dynamic config" model. The latter is well suited for automation pipelines where the configuration is provided dynamically and there is no need to permanently bind RCTL to an Org or Project.

### Config File

- Navigate to the "My Tools" page in the Web Console
- Click on **Download CLI Config** to download the configuration file.

[![CLI Tools Page](https://docs.rafay.co/cli/img/clitool_page.png)](https://docs.rafay.co/cli/img/clitool_page.png)

- Configure the validity period. The default value will be the org wide setting (or) the expiry duration specifically configured for the user (whichever is a higher number). The configured validity period cannot exceed the default value

[![CLI Tools Page](https://docs.rafay.co/cli/img/set_hours.png)](https://docs.rafay.co/cli/img/set_hours.png)

- Click **Download** and save the configuration file on your system

> **Warning**
> A new configuration file is dynamically generated everytime the download button is clicked. To delete older credentials in the config, click on **Manage Keys** to identify keys not in use and delete them.

```
./rctl config init <full path to config file>
```

### ENV Variables

Automation tools and pipelines can dynamically provide the required RCTL configuration via ENV variables instead of a configuration file. You can generate and access your API key and secret using instructions [here](https://docs.rafay.co/security/rbac/users/#api-keys-settings).

```
RCTL_REST_ENDPOINT="console.rafay.dev"
RCTL_OPS_ENDPOINT="console.rafay.dev"
RCTL_API_KEY="xxxxxxxx"
RCTL_PROJECT="defaultproject"
```

> **Note**
> - If configured, ENV variables will take precedence over a config file.
> - API keys beginning with `ra2` (for example, `ra2.456*******`) and older API keys beginning directly with a number (for example, `456*******`) are both supported. If you are using an older API key, authentication requires an additional environment variable, `RCTL_API_SECRET`: 
> 
> ```
> RCTL_REST_ENDPOINT="console.rafay.dev"
> RCTL_OPS_ENDPOINT="console.rafay.dev"
> RCTL_API_KEY="xxUSERAPIKEYxx"
> RCTL_API_SECRET="xxUSERSECRETKEYxx"
> RCTL_PROJECT="defaultproject"
> ```

---

## Setting Path

After installing the RCTL CLI, follow the steps below to add it to your OS's PATH environment variable.

### macOS and Linux

export PATH=$PATH:

### Windows

- Press the Windows key and enter environment variables.
- From the list of suggestions, choose Edit environment variables for your account.
- Choose PATH, and then choose Edit.
- Add the path you found in the first step into the Variable value field, for example, C:\rctl\rctl.exe.
- Choose OK twice to apply the new settings.
- Close any running command prompts and reopen the command prompt window.

---

## View Config

You can view the current configuration for RCTL by using the "config show" command.

```
./rctl config show

Profile:                                                                    prod
REST Endpoint:                                                 console.rafay.dev
OPS Endpoint:                                                      ops.rafay.dev
API Key:                                                            <Masked>
API Secret:                                                         <Masked>
Project:                                                          defaultproject
```

---

## Projects

Projects are a way to implement multi tenancy within an Organization and implement true isolation boundaries. Read more about [Projects](https://docs.rafay.co/security/tenancy/projects/).

> **Note**
> Creation and Deletion of Projects are privileged operations. This is typically performed by an Org Admin using the Web Console because RBAC assignments also need to be implemented along with this.

---

### Default Project

By default, the RCTL config points to the "defaultproject". You can verify this by viewing the config.

```
rctl config show
```

---

### Set Project

If you are using a custom project, ensure that you set the project context before you can perform operations in this project. For example, to set the project context to a project called "Demo"

```
rctl config set project Demo
```

Once the project context has been successfully set, ensure you verify this in your local config file.

> **Note**
> The name of the project is case-sensitive
