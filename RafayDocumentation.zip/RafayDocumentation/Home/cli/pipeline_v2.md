---
title: "KOP CLI - Pipelines"
source: https://docs.rafay.co/cli/pipeline_v2/
category: Home
---

# Pipeline

> **This is a legacy version**
> For the latest Pipeline CLI information, see the [Pipeline CLI](https://docs.rafay.co/cli/pipeline/) topic.

The table below describes the list of actions that can be performed on "pipelines" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| pipeline | YES | YES | YES | YES |

---

## Create Pipeline

A declarative approach to lifecycle management of pipelines is strongly recommended backed by the pipeline manifests (YAML files) that are version controlled in your Git repository.

---

### Declarative

You can create a pipeline in the project in your Organization based on a version controlled pipeline spec that you can store in a Git repository. This enables users to develop automation for reproducible infrastructure.

```
./rctl create pipeline -f pipeline.yaml
```

An illustrative example of the pipeline spec YAML file is shown below.

```
kind: Pipeline
apiVersion: pipeline.rafay.dev/v2
metadata:
  name: sample-pipeline
  project: sample-project
spec:
  stages:
  - name: stage1
    stageType: ApprovalStage
    stageConfig:
      approval:
        approvalType: Email
        emails:
        - [email protected]
        timeout: 0s
      onFailure: Stop
  - name: stage2
    stageType: DeployWorkloadStage
    stageConfig:
      deployment:
        workloadRef: jhef
      onFailure: Stop
  edges:
  - source: stage1
    target: stage2
```

---

## List Pipelines

Use this command to retrieve the list of pipelines in the configured Project. An illustrative example is shown below where RCTL retrieves the list of pipelines in the project "qa".

```
./rctl get pipeline -p qa
```

```
+---------------+-----------+-------------------------------------------+--------------------------------+------------------------------+
| PIPELINE NAME | STATUS    | STAGES                                    | EDGES(SOURCE-TARGET)           | CREATE AT                    |
+---------------+-----------+-------------------------------------------+--------------------------------+------------------------------+
| nginx         | Activated | deploy_nginx_workload:DeployWorkloadStage |                                | Sun Dec 20 23:09:00 UTC 2020 |
+---------------+-----------+-------------------------------------------+--------------------------------+------------------------------+
| multitenant   | Activated | approval:ApprovalStage,                   | approval-tenant-a,             | Mon Dec 21 19:43:40 UTC 2020 |
|               |           | tenant-a:DeployWorkloadStage,             | tenant-a-tenant-b,             |                              |
|               |           | tenant-b:DeployWorkloadStage,             | tenant-b-tenant-c              |                              |
|               |           | tenant-c:DeployWorkloadStage              |                                |                              |
+---------------+-----------+-------------------------------------------+--------------------------------+------------------------------+
```

---

## Get The Specific Pipeline Info

Use this command to retrieve a specific pipeline's details in the configured project.

```
./rctl get pipeline <pipeline-name> -p <project-name>
```

Below is the illustrative example for the pipeline called "nginx"

```
./rctl get pipeline nginx
```

```
+---------------+-----------+-------------------------------------------+----------------------+------------------------------+
| PIPELINE NAME | STATUS    | STAGES                                    | EDGES(SOURCE-TARGET) | CREATE AT                    |
+---------------+-----------+-------------------------------------------+----------------------+------------------------------+
| nginx         | Activated | deploy_nginx_workload:DeployWorkloadStage |                      | Sun Dec 20 23:09:00 UTC 2020 |
+---------------+-----------+-------------------------------------------+----------------------+------------------------------+
```

Or you can use below command to get more information of the addon in json or yaml format

```
./rctl get pipeline <pipeline-name> -o json
```

```
./rctl get pipeline <pipeline-name> -o yaml
```

---

## Delete Pipeline

You can delete a pipeline in the configured project.

```
./rctl delete pipeline <pipeline-name>
```

---
