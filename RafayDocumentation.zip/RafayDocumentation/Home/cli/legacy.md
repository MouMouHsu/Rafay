---
title: "KOP CLI - Legacy Commands"
source: https://docs.rafay.co/cli/legacy/
category: Home
---

# Overview

> **Important**
> This section captures "deprecated" RCTL CLI commands. These commands are considered "Legacy" and support will be removed imminently. Users are strongly recommended to migrate to the currently supported, declarative spec based CLI commands.
