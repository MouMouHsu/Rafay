---
title: "KOP CLI - Namespaces"
source: https://docs.rafay.co/cli/namespaces_v2/
category: Home
---

# Namespaces

> **This is a legacy version**
> For the latest Namespaces CLI information, see the [Namespaces CLI](https://docs.rafay.co/cli/namespaces/) topic.

The RCTL utility provides the means to manage the lifecycle of namespaces across the fleet of managed clusters. The following operations can be performed on namespaces managed by the controller on the fleet of clusters.

| Resource | Create | Get | Update | Delete | Status | Publish | Unpublish |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Namespace | YES | YES | YES | YES | YES | YES | YES |

---

## Managed Namespaces

As a multi cluster operations platform, the Controller creates/deletes namespaces on managed Kubernetes clusters.

For immediate operations on a namespace on a cluster, use the Zero Trust KubeCTL to manage these directly.

---

## Create Namespace

Namespace can be created in three (3) types

1. Namespace Wizard
2. Repo
3. Upload

Deploying the namespace can be done for a specific cluster or by cluster labels. For placement on specific cluster use placementType: **ClusterSpecific** For labels use placementType: **ClusterLabels**

Create a new "managed" namespace in the current Project using the Yaml config spec

### Declarative

```
./rctl create ns -f <path-to-namespace-yaml>
```

Type: RafayWizard

Below is an example of namespace yaml file with the type **RafayWizard** and placementType **ClusterSpecific**

```
kind: ManagedNamespace
apiVersion: config.rafay.dev/v2
metadata:
  name: abc
  description: desc-01
  labels:
    env: dev
    priority: high
    severity: low
  annotations:
    a1: v3
    a2: v4
spec:
  type: RafayWizard
  resourceQuota:
    cpuRequests: 2
    memoryRequests: 2
    cpuLimits: 1
    memoryLimits: 2
  limitRange:
    podLimits:
      maxCpu: 3
      maxMemory: 2
      minCpu: 1
      minMemory: 1
      maxLimitRequestRatioCpu: 1
      maxLimitRequestRatioMemory: 1
    containerLimits:
      maxCpu: 2
      maxMemory: 2
      minCpu: 2
      minMemory: 2
      defaultCpu: 2
      defaultMemory: 2
      defaultRequestCpu: 2
      defaultRequestMemory: 2
      maxLimitRequestRatioCpu: 1
      maxLimitRequestRatioMemory: 1
  placement:
    placementType: ClusterSpecific
    clusterLabels:
    - key: rafay.dev/clusterName
      value: demo-cluster-01
```

**Type: Repo**

Below is an example of namespace yaml file with the type **Repo** and placementType **ClusterLabels**

```
kind: ManagedNamespace
apiVersion": config.rafay.dev/v2
metadata:
  name:rctl-repo2
spec:
  type: Repo
  repoRef:git-cred
  repoArtifactMeta:
    git:
      revision: main3
      repoArtifactFiles:
      - name: abc.yaml
        relPath: NameSpace/abc.yaml
        fileType: K8sYAMLFile
  placement:
    placementType: ClusterLabels
    clusterLabels:
    - key: rafay.dev/clusterId
      value: qweed
```

**Type: Upload**

Below is an example of namespace yaml file with the type **Upload** and placementType **ClusterSpecific**

```
kind: ManagedNamespace
apiVersion": config.rafay.dev/v2
metadata:
  name: upload-ns-03
spec:
  type: Upload
  namespaceFromFile: "/Users/Downloads/abc.yaml"
  placement:
    placementType: ClusterSpecific
    clusterLabels:
    - key: rafay.dev/clusterName
      value: xyz
```

> **Important**
> Avoid upper case characters for the name because Kubernetes does not support it

### Imperative

Use the below command to create a namespace in imperative method

```
./rctl create namespace ns_name
```

---

## List Namespace

The below command is to retrieve/list all "managed namespaces" in the currently specified "Project".

```
./rctl get namespace
```

The below command is to retrieve a specific namespace from a project. When viewing a specific namespace, labels and annotations associated with the namespace are also shown

```
./rctl get namespace demo
```

---

## Update Namespace

Use the below command to update a namespace with any changes performed in the yaml file

```
./rctl update ns <namespace-name> -f <path-to-namespace-yaml>
```

> **Note**
> namespace-name in the command should match the namespace name in the yaml file

---

## Delete Namespace

Delete a "managed namespace" in the current project context using the following command. Users are allowed to delete one or more namespaces at once. Below is an example of multiple namespace deletion Deleting a namespace will also delete the namespace from the clusters where the namespace is published.

```
./rctl delete ns <ns-name1> <ns-name2>
```

> **Important**
> Managed namespaces cannot be deleted if they are in active use by workloads or blueprints

---

## Namespace Status

To know the status of a namespace, use the below command

```
./rctl status ns <ns-name>
```

***Output***

```
+---------+------+----------------+------------------+------------------+----------------+
| NAME    | TYPE | PUBLISHPENDING | ASSIGNEDCLUSTERS | DEPLOYEDCLUSTERS | FAILEDCLUSTERS |
+---------+------+----------------+------------------+------------------+----------------+
| demo    | Repo | false          | demo-cluster     | demo-ckuster     |                |
+---------+------+----------------+------------------+------------------+----------------+
```

---

## Wait Flag

RCTL provides an option for the users to wait and block the long running operations. When an automation pipeline logic becomes extremely convoluted, enabling the **--wait** flag helps to block and keep pulling the namespace publish status (example: success/failure)

Once a namespace is created or updated and has all the placement information to publish it on the cluster, the **wait flag** helps to get the backend information of a namespace creation process flow upto the publishing stage. This get operation continues to wait and show the details and status until the publishing is successful. To view the entire operation details, use the below **wait** command

```
rctl publish ns <ns-name> --wait
```

> Note: Use the --wait flag only when publishing the namespace

***Example Output***

```
1.643112860864668e+09   debug   commands/common.go:126  Prerun
1.643112860864764e+09   info    context/context.go:58   Context: {"config_dir":"/Users/gajanan/.rafay/cli","config_file":"config.json","verbose":true,"debug":true,"structured_output":false,"v3":false}
1.643112860864789e+09   debug   config/config.go:156    Config path: /Users/gajanan/.rafay/cli/config.json
1.64311286086537e+09    info    authprofile/key_profile.go:33   creating headers
1.643112862399913e+09   debug   authprofile/key_profile.go:100  GET https://console.stage.rafay.dev/auth/v1/projects/kj3ry4m/
1.643112862400091e+09   debug   authprofile/key_profile.go:105  http response ok: {"id":"kj3ry4m","name":"test","description":"","created_at":"2021-09-01T10:19:03.070746Z","modified_at":"2021-09-01T10:19:03.070773Z","partner_id":"rx28oml","organization_id":"g29xn20","default":false}
1.643112862400206e+09   info    config/config.go:268    Config: {"profile":"staging","skip_server_cert_check":"false","rest_endpoint":"console.stage.rafay.dev","ops_endpoint":"ops.stage.rafay.dev","project_id":"kj3ry4m","project_name":"test"}
1.64311286240023e+09    debug   commands/publish_namespace.go:28    Start [%s %s]rctl publish namespacens-wait-publish-1
1.643112862400266e+09   info    authprofile/key_profile.go:33   creating headers
1.643112863502969e+09   debug   authprofile/key_profile.go:100  POST https://console.stage.rafay.dev/v2/config/project/kj3ry4m/namespace/ns-wait-publish-1/publish
1.643112863503087e+09   debug   authprofile/key_profile.go:105  http response ok: {"metadata":{"name":"ns-wait-publish-1","displayName":"ns-wait-publish-1","createdAt":"2022-01-25T12:14:06.419778Z","modifiedAt":"2022-01-25T12:14:23.676415116Z","annotations":{"a1":"v3","a2":"v4","rafay.dev/resource-hash":"5df8724b27344854b46a991381bc150af680e3df2f97c6f9b541784f95ec4797"},"organizationID":206,"partnerID":1,"projectID":18158,"namespaces":null,"id":"mpxgv52"},"spec":{"metadata":{"name":"ns-wait-publish-1","creationTimestamp":null,"annotations":{"a1":"v3","a2":"v4"}},"spec":{"namespaceMeta":{"name":"ns-wait-publish-1","creationTimestamp":null}},"resourceQuota":{},"limitRange":{},"placement":{"placementType":"ClusterSpecific","clusterSelector":"","driftAction":"DriftReconcillationActionNotSet","clusterLabels":[{"key":"rafay.dev/clusterName","value":"gajanan-test-mks-1"}],"nodeGroupingKeys":null},"type":"RafayWizard","repoArtifactMeta":{}},"status":{"generatedName":"ns-wait-publish-1","publishPending":false,"assignedClusters":null,"deployedClusters":null,"failedClusters":null,"readyClusters":null,"driftedClusters":null,"isDirty":false}}
1.643112863503128e+09   info    authprofile/key_profile.go:33   creating headers
1.643112864585084e+09   debug   authprofile/key_profile.go:100  GET https://console.stage.rafay.dev/v2/config/project/kj3ry4m/namespace/ns-wait-publish-1
1.643112864585252e+09   debug   authprofile/key_profile.go:105  http response ok: {"apiVersion":"config.rafay.dev/v2","kind":"Namespace","metadata":{"name":"ns-wait-publish-1","displayName":"ns-wait-publish-1","createdAt":"2022-01-25T12:14:06.419778Z","modifiedAt":"0001-01-01T00:00:00Z","annotations":{"a1":"v3","a2":"v4"},"organizationID":206,"partnerID":1,"projectID":18158,"namespaces":null,"id":"mpxgv52"},"spec":{"metadata":{"name":"ns-wait-publish-1","creationTimestamp":null,"annotations":{"a1":"v3","a2":"v4"}},"spec":{"namespaceMeta":{"name":"ns-wait-publish-1","creationTimestamp":null}},"resourceQuota":{},"limitRange":{},"placement":{"placementType":"ClusterSpecific","clusterSelector":"","driftAction":"DriftReconcillationActionNotSet","clusterLabels":[{"key":"rafay.dev/clusterName","value":"gajanan-test-mks-1"}],"nodeGroupingKeys":null},"type":"RafayWizard","repoArtifactMeta":{}},"status":{"generatedName":"ns-wait-publish-1","publishPending":false,"assignedClusters":[{"clusterID":"kedy6qm","clusterName":"gajanan-test-mks-1","reason":"assigned"}],"deployedClusters":null,"failedClusters":null,"readyClusters":null,"driftedClusters":null,"conditions":[{"type":"WorkloadSnapshotSchedule","status":"Success","lastUpdated":"2022-01-25T12:14:23.810665771Z","reason":"assigned"},{"type":"WorkloadSnapshotClusterDeployed","status":"Pending","lastUpdated":"2022-01-25T12:14:23.810666056Z","reason":"assigned"}],"isDirty":false}}
1.6431128818360388e+09  info    authprofile/key_profile.go:33   creating headers
1.6431128829355211e+09  debug   authprofile/key_profile.go:100  GET https://console.stage.rafay.dev/v2/config/project/kj3ry4m/namespace/ns-wait-publish-1
1.643112882935703e+09   debug   authprofile/key_profile.go:105  http response ok: {"apiVersion":"config.rafay.dev/v2","kind":"Namespace","metadata":{"name":"ns-wait-publish-1","displayName":"ns-wait-publish-1","createdAt":"2022-01-25T12:14:06.419778Z","modifiedAt":"0001-01-01T00:00:00Z","annotations":{"a1":"v3","a2":"v4"},"organizationID":206,"partnerID":1,"projectID":18158,"namespaces":null,"id":"mpxgv52"},"spec":{"metadata":{"name":"ns-wait-publish-1","creationTimestamp":null,"annotations":{"a1":"v3","a2":"v4"}},"spec":{"namespaceMeta":{"name":"ns-wait-publish-1","creationTimestamp":null}},"resourceQuota":{},"limitRange":{},"placement":{"placementType":"ClusterSpecific","clusterSelector":"","driftAction":"DriftReconcillationActionNotSet","clusterLabels":[{"key":"rafay.dev/clusterName","value":"gajanan-test-mks-1"}],"nodeGroupingKeys":null},"type":"RafayWizard","repoArtifactMeta":{}},"status":{"generatedName":"ns-wait-publish-1","publishPending":false,"assignedClusters":[{"clusterID":"kedy6qm","clusterName":"gajanan-test-mks-1","reason":"assigned"}],"deployedClusters":[{"clusterID":"kedy6qm","clusterName":"gajanan-test-mks-1","reason":"deployed"}],"failedClusters":null,"readyClusters":[{"clusterID":"kedy6qm","clusterName":"gajanan-test-mks-1","reason":"ready"}],"driftedClusters":null,"conditions":[{"type":"WorkloadSnapshotSchedule","status":"Success","lastUpdated":"2022-01-25T12:14:23.810665771Z","reason":"assigned"},{"type":"WorkloadSnapshotClusterDeployed","status":"Success","lastUpdated":"2022-01-25T12:14:40.087796077Z","reason":"deployed"},{"type":"WorkloadSnapshotClusterReady","status":"Success","lastUpdated":"2022-01-25T12:14:42.919541196Z","reason":"ready"}],"isDirty":false}}
1.6431128829358678e+09  debug   commands/publish_namespace.go:38    End [rctl publish namespace ns-wait-publish-1]
1.6431128829359019e+09  debug   output/exit.go:23   Exit 0
```

---

## Publish/Unpublish Namespace

Users can publish (or) unpublish a namespace with below commands

- Publish

```
./rctl publish ns <ns-name>
```

- Unpublish

```
./rctl unpublish ns <ns-name>
```

> Note: For help commands, append -h or --help after any of these commands.
> Example: .rctl get namespace -h or .rctl get namespace --help

---
