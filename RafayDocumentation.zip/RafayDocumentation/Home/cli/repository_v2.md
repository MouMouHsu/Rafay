---
title: "KOP CLI - Repository"
source: https://docs.rafay.co/cli/repository_v2/
category: Home
---

# Repository

> **This is a legacy version**
> For the latest Repository CLI information, see the [Repository CLI](https://docs.rafay.co/cli/repository/) topic.

The table below describes the list of actions that can be performed on "repository" using the RCTL CLI Utility.

| Resource | Create | Get | Update | Delete |
| --- | --- | --- | --- | --- |
| Repository | YES | YES | YES | YES |

---

## Create Repository

A declarative approach to lifecycle management of repository is strongly recommended backed by the pipeline manifests (YAML files) that are version controlled in your Git repository.

> **Important**
> A repository can be either a Helm or Git repository type. A number of public repositories are provided by default in every project.

---

### Declarative

You can create a repository in the project in your Organization based on a version controlled repository spec that you can store in a Git repository. This enables users to develop automation for reproducible infrastructure.

```
./rctl create repository -f repository.yaml
```

An illustrative example of the repository version spec YAML file is shown below

```
kind: Repository
apiVersion: pipeline.rafay.dev/v2
metadata:
  name: repo-name-1
  project: sample-project
spec:
  repositoryType: GitRepository
  endpoint: "https://github.com/rafay-cd-project/CD-test.git"
  insecure: false
  caCert: ""
  credentialType: SSHCredential
  credentials:
    ssh:
      sshPrivateKeyFile: "/path/to/sshKeyFile"
  agentNames:
  - agent-1
  - agent-2
```

Below is an illustrative example of repository YAML spec using username and password.

```
apiVersion: config.rafay.dev/v2
kind: Repository
metadata:
  name: demo-repo
spec:
  repositoryType: GitRepository
  endpoint: https://github.com/rafay-cd-projec/CD-test.git
  insecure: false
  caCert: ''
  credentialType: UserPassCredential
  credentials:
    userPass:
      username: [email protected]
      password: fe4fb8b12ef9a0ef67f4cb6c8bbcd55e26c7772f
  agentNames:
  - test-agent
```

---

## Update Repository

Use this command to update an already configured repo.

```
./rctl update repository -f repository.yaml
```

---

## List Repositories

Use this command to retrieve the list of repositories in the configured Project. An illustrative example is shown below where RCTL retrieves the list of repositories in the project "qa".

```
./rctl get repository -p qa
```

```
+----------------------+----------------+-------------------------------------------------+--------+------------------------------+
| REPOSITORY NAME      | TYPE           | ENDPOINT                                        | AGENTS | CREATE AT                    |
+----------------------+----------------+-------------------------------------------------+--------+------------------------------+
| default-stable-helm  | HelmRepository | https://charts.helm.sh/stable                   |        | Sat Dec 19 06:54:38 UTC 2020 |
+----------------------+----------------+-------------------------------------------------+--------+------------------------------+
| default-bitnami      | HelmRepository | https://charts.bitnami.com/bitnami              |        | Sat Dec 19 06:54:38 UTC 2020 |
+----------------------+----------------+-------------------------------------------------+--------+------------------------------+
| default-cert-manager | GitRepository  | https://github.com/jetstack/cert-manager.git    |        | Sat Dec 19 06:54:38 UTC 2020 |
+----------------------+----------------+-------------------------------------------------+--------+------------------------------+
| qa                   | GitRepository  | https://github.com/RafaySystems/gitops-demo.git |        | Sun Dec 20 17:42:13 UTC 2020 |
+----------------------+----------------+-------------------------------------------------+--------+------------------------------+
| cetic-helm-repo      | HelmRepository | https://cetic.github.io/helm-charts             |        | Thu Mar  4 04:36:21 UTC 2021 |
+----------------------+----------------+-------------------------------------------------+--------+------------------------------+
```

---

## Get Specific Repository Info

Use this command to retrieve a specific repository's details in the configured project.

```
./rctl get repository <repository-name> -p <project-name>
```

Below is the illustrative example for the repository called "qa"

```
./rctl get repository qa
```

```
+-----------------+---------------+-------------------------------------------------+--------+------------------------------+
| REPOSITORY NAME | TYPE          | ENDPOINT                                        | AGENTS | CREATE AT                    |
+-----------------+---------------+-------------------------------------------------+--------+------------------------------+
| qa              | GitRepository | https://github.com/RafaySystems/gitops-demo.git |        | Sun Dec 20 17:42:13 UTC 2020 |
+-----------------+---------------+-------------------------------------------------+--------+------------------------------+
```

Or you can use below command to get more information of the addon in json or yaml format

```
./rctl get repository <repository-name> -o json
```

```
./rctl get repository <repository-name> -o yaml
```

---

## Delete Repository

You can delete a repository in the configured project.

```
./rctl delete repository <repository-name>
```

---
