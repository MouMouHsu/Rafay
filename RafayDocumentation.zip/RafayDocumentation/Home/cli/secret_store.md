---
title: "KOP CLI - Secret Store"
source: https://docs.rafay.co/cli/secret_store/
category: Home
---

# Secret Stores

The table below describes the list of actions that can be performed on **Secret Store** using the RCTL CLI Utility.

| Resource | Create | Get | Update | Apply | Delete |
| --- | --- | --- | --- | --- | --- |
| Secret Store | YES | YES | YES | YES | YES |

---

A declarative approach (YAML files) to lifecycle management of Secret Store is strongly recommended that are version controlled in your Git repository.

## Create/Update Secret Stores

Use the below command to create/update a secret store and this creates a secret store in both UI and Git Repo

```
./rctl apply -f secretstore-spec.yml
```

### Vault Provider

An illustrative example of the secret store spec YAML file is shown below for the Vault provider

```
apiVersion: integrations.k8smgmt.io/v3
kind: SecretStore
metadata:
    name: testdemo03
    project: defaultproject
    displayName: testdemo03
spec:
    provider: Vault
    config:
        vault:
            host:
            clusters:
            - authPath: authpath01testdemo03
              clusterName: tb98cl02
              vaultNamespace: vns01testdemo03
```

---

## List Secret Stores

Use the below command to get the list of secret stores and its details

```
./rctl get secretstore --v3
+-------------------+----------+---------------------------------+------------+------------------------------+
| SECRET STORE NAME | PROVIDER | HOST                            | CLUSTER(S) | LAST MODIFIED                |
+-------------------+----------+---------------------------------+------------+------------------------------+
| testdemo02        | Vault    | https://www.testdemo01.com:8000 | 1          | Tue Mar  8 01:56:55 UTC 2022 |
+-------------------+----------+---------------------------------+------------+------------------------------+
| testdemo01        | Vault    | https://www.testdemo01.com:8000 | 1          | Mon Mar  7 07:12:26 UTC 2022 |
+-------------------+----------+---------------------------------+------------+------------------------------+
```

To view a specific secret store details, use the below command

```
./rctl get secretstore demo-ss
+-------------------+-----------------------+--------------------------------+
| SECRET STORE NAME | SECRET STORE PROVIDER | CLUSTERS                       |
+-------------------+-----------------------+--------------------------------+
| demo-ss           | Vault                 | eks-prod1,                     |
|                   |                       | vault-server                   |
+-------------------+-----------------------+--------------------------------+

NOTE: vault integration successful for cluster vault-server:

Kubernetes Host: https://192.168.149.39:443,https://192.168.97.153:443

Token Reviewer JWT: eyJhbGciOiJSUzI1NiIsImtpZCI6IjFEUkxWQWxId1ZydU9kU2dkNVowX2JabU1xYzlLZE1zdF9QUUl4Z0dkUlUifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJyYWZheS1zeXN0ZW0iLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlY3JldC5uYW1lIjoidmF1bHQtYXV0aC1zZWNyZXQiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoidmF1bHQtYXV0aCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6ImE3ZmI2NjVjLTRmMmQtNDMxNi05ZWUwLTQ5YmFlNzMxN2E2ZiIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDpyYWZheS1zeXN0ZW06dmF1bHQtYXV0aCJ9.hTA_6u2cP4saEtxNE_0eMIEUMWzD1p096gCTkxrDOcluQ9tmq_Z6oJ5T-CqW8E47A8rHWCFBgQ7a7V44ye8NJC6X-J9PTbmLxPafCon4Md_sFqEvJk2WpEjyUMPNDk4PX99xMcj6uBOOmhOFdE8nUbC1nTM_IV5Z_4COm-fg97snWd9kbh9ehuXpTlGgnvjRYRY8QyR_H2_EU9taxcb9QGVScKbcXvNa7ZP39HquZ8l4BpkcGxFJW7qagrbvJZ1ATYxGLrp9bNFhfMjubokFXRGC02CnqzknebJbDnStfyyBaoWUbGXf8ontbgeOGsS22biljKyeJmZsoSAZUVDq1g

Kubernetes CA Cert: -----BEGIN CERTIFICATE-----
MIIC/jCCAeagAwIBAgIBADANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDEwprdWJl
cm5ldGVzMB4XDTIyMTIxMDA1NTIzN1oXDTMyMTIwNzA1NTIzN1owFTETMBEGA1UE
AxMKa3ViZXJuZXRlczCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALKh
5ZK1Nugmrxz9KM5zkneOTLKQsbW0rru+1ikbZrd5vNqVsgGzZGBN1DKsAIFNPgRG
5qKxgOQxEjjrDTk7/5tPnvwby2efbFh7eJL9fk6j0rL6CDBrB6fR+r4mdDHLcx3e
FBwgizLjVldgrNOl9mdpFIDCXCAY4ihGdsov6sXNQATPx3ZqNwfSF1h/3VsCqvtL
ocyS5zixU6aDrY99AbgE69eA3GF8z0WQtyL89WU8ALBI6TGnMH66T1stXKR4t1ye
nVldkAzhpyt7TG4A0bar2nanMpd0ezMWPMgcjByz1CJ24qS0XpPBovVmGgZSNdCU
p/SmHFh/P0imxlQGdsMCAwEAAaNZMFcwDgYDVR0PAQH/BAQDAgKkMA8GA1UdEwEB
/wQFMAMBAf8wHQYDVR0OBBYEFJfwmcOaDXyXlGVsjvWwvpWWBoJWMBUGA1UdEQQO
MAyCCmt1YmVybmV0ZXMwDQYJKoZIhvcNAQELBQADggEBADBkVswDTS/gJbBjbNeY
kN+PO3qG5LhpkcbZzGR4iI7DResSG0zWxW7CRp81nwessMn42kdVkMSr/J/n5SYG
8RymDR9JG4e6ZlJtizlGg3pJzm8+id8+emtRniN7JalhdvHTN6ImsOaLdnF8Kfsw
2yvjcjMxnJg6doZFCWXy+uSpa9t8VGo0TmMuwkWoNEDBeqDjb8AP8nO/rqqjzUZD
6GvkKzlppBHAQ7olhsmppNSobfyDrTCz04tUvU/c/J8kbBuIhHdTz12Y+QyQZydS
or/kgW9kbakUvvidZlVuB2D0Twrzv/V23nASeBbZaUBGi8MEacZOMQl2fYi7AYZC
RN0=
-----END CERTIFICATE-----

NOTE: vault integration successful for cluster eks-prod1:

Kubernetes Host: https://192.168.175.36:443,https://192.168.97.223:443

Token Reviewer JWT: eyJhbGciOiJSUzI1NiIsImtpZCI6IjN5bnRDTnJ4MjFMWUZ2Z2JRTkI0UzExc0s1SUFrQ2dVYVJ4aVpoZXZERVUifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJyYWZheS1zeXN0ZW0iLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlY3JldC5uYW1lIjoidmF1bHQtYXV0aC1zZWNyZXQiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoidmF1bHQtYXV0aCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6IjkxOGE5NjdkLWI3NDEtNDE1MS04ODBmLWQwOWI3M2RkNTQzMCIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDpyYWZheS1zeXN0ZW06dmF1bHQtYXV0aCJ9.DcIPJMSAfEBoA-nDh_KSe33yI4XejokydFAt4i-fl3skJs5mJVncNdWZvWb3VdsLNQm3EtNZWT8TcYX4P9p090kBfkWU2k97HFuWl9CeeJq45xEdsjB8xAny7h_2CUjlmQNWm1mlqy5JHsld5JqFbCiSZTPlqBvXFoTXbkExfdtbTYTMvLqI4d7N_OACXVAAvFlBRgjwyeSoY5yUfUBJMcML994pLd0BrVql3lIFnC_OyGReCxbtTZn9VxS9ve2sRSSFSBNCPp4tO0g_7hZsWZPqUgpD6DYtJ7HuhKMsU9qt3aH-Z0A90ahoiKuzuQ1Yja1owgH3Fc5M6AJgMbyePQ

Kubernetes CA Cert: -----BEGIN CERTIFICATE-----
MIIC/jCCAeagAwIBAgIBADANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDEwprdWJl
cm5ldGVzMB4XDTIyMTIxMDA2MzUxM1oXDTMyMTIwNzA2MzUxM1owFTETMBEGA1UE
AxMKa3ViZXJuZXRlczCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALIf
+SH3pIO7mbVoTKG91W5AG+vnI4okwTh8pKiy4dui7isiwzmW+2xTb9eGjitJiwGZ
mbg3Jfq+whm9cunvkgcM3JS242D+7gGjckQhhxwWkoI84Znwy0sw1+Ga+oQ1NIpp
TraewKRK4mGGtEtNNI2cC1N4YxmbkRYzX36LxBVCJu3PTgRzgEGkKQ4v/VMSuzFs
T7X1IOtmAtRI+8hfySovoAf7z3txUZKgDgxWxRg702byOJvx+tG39YMyfl9QMlXI
6C2pgnhrAd0abgrAkPDImGdTWp7Y6GIw2dFHwJAfPg3ImKmw5iXxcJcNQtN6plpo
g3RBGPL+7/OjMYF3We0CAwEAAaNZMFcwDgYDVR0PAQH/BAQDAgKkMA8GA1UdEwEB
/wQFMAMBAf8wHQYDVR0OBBYEFH+xUujsM2nGB2Xma5PE9WfYg5tWMBUGA1UdEQQO
MAyCCmt1YmVybmV0ZXMwDQYJKoZIhvcNAQELBQADggEBAJVDUGWfx/Q/cqfZBwsM
1cDvYomK23bMJi6gg0ZjjZDKw8YuD2khL3wCJqr8yvD7RHnHb9oPZjD34lm2c1x9
SmzZEzoox2UG/k7FPS4DNIUSiFDgmn0qm9i2frgzGsrhmiLWr/+iNseBighfQlpQ
ZIqZBzUrW0DUkBKI5AuZGYCmq0Di1ecBCyn+3mof2oiQXRWtfPws2Uysi9BTfXyo
0Cp24u0Vz93ldasVlo9h4oMZUGpdCQKa7L3NtX1Ki1z81yJGLMbOS9j5TV/3GVCB
Zv82V7LPmBxQ0rhTtR35+8szczJQpV33STzlnXU91z0DnwmMOLNhoSDIm71yd5h4
Y3Q=
-----END CERTIFICATE-----
```

Or you can use the below commands to get more information of the secret store in json or yaml format

```
./rctl get secretstore <secretstore_name> -o json
```

```
./rctl get secretstore <secretstore_name> -o yaml
```

***Example:***

```
./rctl get secretstore dec-sanity-ss -o yaml
apiVersion: integrations.k8smgmt.io/v3
kind: SecretStore
metadata:
  name: demo-ss
  project: prod-test
spec:
  config:
    vault:
      clusters:
      - authPath: auth1
        clusterName: eks-prod1
      - authPath: vault-server
        clusterName: vault-server
      host: https://prod-demo-vault-server.dev.rafay-edge.net/
  provider: Vault
```

---

## Delete Secret Store(s)

Use the below command to delete a secret store

```
./rctl delete secretstore -f <filename.yaml> --v3
```

---
