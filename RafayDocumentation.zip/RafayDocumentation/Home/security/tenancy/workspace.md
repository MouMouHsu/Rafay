---
title: "KOP - Soft Multitenancy"
source: https://docs.rafay.co/security/tenancy/workspace/
category: Home
---

# Workspace Role

There can be scenarios where organizations may require application teams to **"share"** clusters for cost efficiency purposes. Even after sharing clusters across projects, administration of Kubernetes namespaces can still be an operational challenge. For example, it can be a cost/burden for administrators to quickly respond to requests from application teams for scenarios like

- Need a new namespace
- Need to update resource quotas on existing namespace
- Need to delete an existing namespace

A commonly used term for this soft multi-tenancy model is **Workspace as a Service**.

> **Important**
> A workspace admin can only see resources in **namespaces** created and managed by them. They cannot see/access namespaces on the cluster that are not managed by them. When a workspace admin creates a new namespace using the ZTKA kubeconfig file, project label needs to be specified as part of the namespace spec.

---

### Access Control

Organizations can assign the "Workspace Admin" role to identified users in application teams to **offload** namespace administration and quota management responsibilities.

[![Access Control](https://docs.rafay.co/security/tenancy/img/workspace/access-workspace.png)](https://docs.rafay.co/security/tenancy/img/workspace/access-workspace.png)

Developers and application owners can be assigned to specific **namespaces** that are created and managed by the Workspace Admin.

---

### Resource Quotas

Administrators can allocate a "total quota" on the shared cluster that will **span across all the namespaces** managed by the Workspace administrator. The sum of resources across ALL namespaces needs to be less/equal to the specified quota.

[![Resource Quotas](https://docs.rafay.co/security/tenancy/img/workspace/quota.png)](https://docs.rafay.co/security/tenancy/img/workspace/quota.png)

At any time, workspace admins can login and view their "total quota" and "utilization" against the quota. For example, in the utilization table for the project, the **assigned quota** for CPUs is "300 mCPUs" and **current utilization** is "50 mCPUs"

[![Resource Utilization](https://docs.rafay.co/security/tenancy/img/workspace/utilization.png)](https://docs.rafay.co/security/tenancy/img/workspace/utilization.png)

---
