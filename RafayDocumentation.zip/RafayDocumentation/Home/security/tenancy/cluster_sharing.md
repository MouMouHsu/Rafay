---
title: "Product Security - Cluster Sharing"
source: https://docs.rafay.co/security/tenancy/cluster_sharing/
category: Home
---

# Cluster Sharing

Due to isolation requirements, it is common for organizations to manage different application teams, BUs are managed as separate Projects and Groups. However, there are several scenarios where different projects may have a requirement to use the "same fleet" of clusters for workloads managed by different teams.

---

## Common Scenarios

Some common scenarios for cluster sharing across projects are described below.

### Service Provider

A service providers for an organization may wish to provide different application teams in the Organization the ability to deploy and operate their workloads on the same "managed fleet" of clusters. A dedicated fleet of clusters for every application/team may be cost prohibitive and impractical.

Application teams can be managed as separate, distinct projects in an Org. The service provider can then enable cluster sharing for select clusters across Projects.

---

### Shared/Ops Services

Shared services/Ops teams in large organizations may be responsible to provide foundational infrastructure capabilities for different BU's and/or application teams. They will want to ensure that they deliver cost effective, optimized infrastructure. A dedicated fleet of clusters for every application/team may be cost prohibitive and impractical.

As a result, they may wish to provide different application teams in an Organization the ability to deploy and operate their workloads on the same "shared fleet" of clusters. Application teams can be managed as separate, distinct projects in an Org. The shared services ops team can enable cluster sharing for select clusters across Projects.

---

### Cost Optimization/Reduction

Application teams that need to deploy and operate their applications globally across multiple clusters may have a requirement to reduce their infrastructure costs.

---

## Manage Cluster Sharing

Infrastructure Admins can initiate sharing of clusters across projects by using the following process:

- Click on Options for a Cluster (gear icon on far right of a cluster card)
- Select "Manage Cluster Sharing"

[![Enable Cluster Sharing](https://docs.rafay.co/security/tenancy/img/cluster_sharing/enable_cluster_sharing.png)](https://docs.rafay.co/security/tenancy/img/cluster_sharing/enable_cluster_sharing.png)

The infrastructure administrator will now be presented with a wizard where they can enable/disable "cluster sharing" with select projects.

[![Manage Cluster Sharing](https://docs.rafay.co/security/tenancy/img/cluster_sharing/manage_cluster_sharing.png)](https://docs.rafay.co/security/tenancy/img/cluster_sharing/manage_cluster_sharing.png)

In the example above, the cluster "demo-eksspot-east" is owned by the "default project" and has been shared with the "Infrastructure" project. Once the cluster has been shared, as seen in the image below, this is available for workloads in the "Infrastructure" project.

[![Use Shared Cluster](https://docs.rafay.co/security/tenancy/img/cluster_sharing/use_shared_cluster.png)](https://docs.rafay.co/security/tenancy/img/cluster_sharing/use_shared_cluster.png)

---
