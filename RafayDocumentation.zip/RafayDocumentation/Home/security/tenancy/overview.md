---
title: "KOP - Tenancy"
source: https://docs.rafay.co/security/tenancy/overview/
category: Home
---

# Overview

Multitenancy in Kubernetes typically means that a cluster and its control plane are shared by multiple users, workloads, or applications. Depending on the requirements, multiple types of tenancy models supported by the platform can be configured and used.

---

## Hard Tenancy

A dedicated cluster(s) per tenant. This is [implemented](https://docs.rafay.co/security/tenancy/hard_tenancy/) using a **dedicated** cluster in a completely isolated Project.

---

## Soft Tenancy

### Workspace

A dedicated [workspace](https://docs.rafay.co/security/tenancy/workspace/) per tenant. This can be implemented using a cluster **shared** across two or more projects.

### Namespace

A dedicated Kubernetes [namespace](https://docs.rafay.co/security/tenancy/namespace/) per tenant.This can be implemented using two approaches

- A namespace(s) per tenant in a dedicated cluster in a Project
- A namespace(s) per tenant in a cluster shared with a Project

---
