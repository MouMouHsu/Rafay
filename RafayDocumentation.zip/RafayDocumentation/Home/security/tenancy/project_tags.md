---
title: "KOP - Project Tags"
source: https://docs.rafay.co/security/tenancy/project_tags/
category: Home
---

# Project Tags

A tag group with one or more key-value pair(s) can be created and associated with a project. These can be used to identify certain attributes associated with a project. As an example, from a cost management perspective, these tags can be used to identify the cost center ID, business group, billing approver ID etc.

A Tag Group can be created and associated to projects via multiple methods:

- RCTL CLI
- Swagger API
- The Terraform Provider

[![Tags](https://docs.rafay.co/security/tenancy/img/projects/project_tags.png)](https://docs.rafay.co/security/tenancy/img/projects/project_tags.png)

> **Important**
> Support for doing this through UI will be added in a future release

## Step1: Tag Group

Here you have the details on how to create, update, delete and get a tag group

RCTL CLIAPI

**Create Tag Group**

Use the below v3 Spec to create a Tag Group

```
apiVersion: tags.k8smgmt.io/v3
kind: TagGroup
metadata:
  name: <string>
  project: <project-name>
spec:
  tags:
  - key: <string>
    value: <string>
  - key: <string>
    value: <string>
```

***Example:***

```
apiVersion: tags.k8smgmt.io/v3
kind: TagGroup
metadata:
  name: demo-taggroup
  project: default-project
spec:
  tags:
  - key: orgname
    value: org1
  - key: place
    value: onprem
```

Run the below command to create a tag group:

```
./rctl apply -f <taggroup_filename.yaml>
```

**Update Tag Group**

Update the existing parameter(s) or add new key-value pairs in the config file and run the apply command. For example, in the below config file, add a new key-value pair as highlighted.

***Example***

```
apiVersion: tags.k8smgmt.io/v3
kind: TagGroup
metadata:
  name: demo-taggroup
  project: default-project
spec:
  tags:
  - key: orgname
    value: org1
  - key: place
    value: onprem
  - key: user
    value: tim_1  
```

To apply the changes, run the below command

```
./rctl apply -f <taggroup_filename.yaml>
```

**Get Tag Group**

Use the below command to view the list of all tag groups

```
./rctl get taggroup
┌────────────────┬────────────────────────┐
│ TAG-GROUP NAME │        TAGS            |
│                ├────────────┬───────────┤   
│                │ TAG-KEY    │ TAG-VALUE │   
├────────────────┼────────────┼───────────┤
│ demo-taggroup  │ orgname    │ org1      │
|                ├────────────┼───────────┤ 
|                │ place      │ onprem    │
│                ├────────────┼───────────┤  
│                │ user       │ tim_1     │   
└────────────────┴────────────┴───────────┘
│ tg-qctest      │ key-test1  │ value-1   │  
│                ├────────────┼───────────┤   
│                │ key-test2  │ value-2   │      
└────────────────┴────────────┴───────────┘
│  tg-demo       │ key-test10 │ value-10  │
│                ├────────────┼───────────┤  
│                │ key-test20 │ value-20  │   
└────────────────┴────────────┴───────────┘
```

Use the below command to view a specific tag group details

```
./rctl get taggroup <taggroup_name>
```

***Example***

```
./rctl get taggroup demo-taggroup
┌────────────────┬────────────────────────┐
│ TAG-GROUP NAME │        TAGS            |
│                ├────────────┬───────────┤   
│                │ TAG-KEY    │ TAG-VALUE │   
├────────────────┼────────────┼───────────┤
│ demo-taggroup  │ orgname    │ org1      │
|                ├────────────┼───────────┤ 
|                │ place      │ onprem    │
│                ├────────────┼───────────┤  
│                │ user       │ tim_1     │   
└────────────────┴────────────┴───────────┘
```

To view a tag group config spec, use the below command

```
./rctl get taggroup demo-taggroup -o yaml  

apiVersion: tags.k8smgmt.io/v3
kind: TagGroup
metadata:
 name: demo-taggroup
 project: defaultproject
spec:
 tags:
  - key: orgname
    value: org1
  - key: place
    value: onprem
  - key: user
    value: tim_1
```

**Delete Tag Group**

Use the below command to delete a specific tag group

```
./rctl delete taggroup <taggroup_name>
```

```
./rctl delete taggroup demo-taggroup
```

Use the below command to delete all the tag groups

```
./rctl delete taggroup
```

A set of comprehensive APIs are available that enable the users to seamlessly create, update, retrieve a list, and delete tag groups. The **Tag Group Apply** API allows you to easily create new tag groups by providing the project id and resource name

[![Projects Intro](https://docs.rafay.co/security/tenancy/img/projects/tag_grp_api.png)](https://docs.rafay.co/security/tenancy/img/projects/tag_grp_api.png)

---

## Step 2: Project Tag Association

The Project Labels feature allows organizing resources using **tags (key-value pairs)** at the project level. Tags can be grouped logically and linked to resources based on predefined **association types**:

- **cost**
- **k8s**
- **[namespacelabel](https://docs.rafay.co/cli/namespaces/)** (for namespace-specific labels)

### Namespace Label Associations

This type of association supports key-value pairs for namespaces and ensures proper tagging by:

- Associating a namespace with a specific key-value pair
- Requiring a resource reference for namespace labels
- Automatically creating tag groups when needed
- Restricting reserved labels from being configured
- Syncing label changes periodically, with immediate updates for new namespaces

### Tag Support

Tags now support associating multiple values with the same key. For example, when the key is `Environment`, values such as `Development` and `Production` can be assigned. Updating an association to use a different name (e.g., changing `Environment=Development` to `Environment=Testing`) results in the creation of a **new tag group** for the key `Environment` with the updated value `Testing`. This functionality enables multiple distinct tag groups to exist under the same key, enhancing flexibility for resource categorization and filtering.

### Configuration

Tags and associations can be managed using:

- **[RCTL](https://docs.rafay.co/cli/namespaces/)**
- **Terraform**
- **[Swagger API](https://docs.rafay.co/automation/api/apis/)**

> ⚠️ Important:
> The UI displays configurations in project settings under Tags/Labels but does not allow direct modifications.

The below section captures details on how to create, update, delete and get tag group associations.

RCTL CLIAPI

Once the Tag group is created, use the below v3 Spec for project tag association.

```
apiVersion: tags.k8smgmt.io/v3
kind: ProjectTagsAssociation
metadata:
  name: <string>
  project: <project-name>
spec:
  associations:
  - tagKey: <string>
    tagType: <string - k8s, cost, namespacelabel>
    tagValue: <string>
    resource: <string>
```

> ⚠️ Important Note:
> For cost and K8s tag types, the resource field is not required

***Example***

```
apiVersion: tags.k8smgmt.io/v3
kind: ProjectTagsAssociation
metadata:
  name: demo-association
  project: default-project
spec:
  associations:
  - tagKey: "demo-key"
    tagType: "namespacelabel"
    tagValue: "demo-value"
    resource: "demo-namespace"
```

> ⚠️ Important Note:
> - If the tagValue is not provided, it will default to an empty string ("").
> - The combination of tagKey and tagValue must be unique to ensure proper tagging and resource association.
> - Necessary to provide a tagValue to associate a specific tag effectively.

Run the below command for the project tag association.

```
./rctl apply -f <projtagassoc-filename.yaml>
```

On completing this association process, a schema for project association gets created in the database. Now the users can get the project scoped Tag Group with it’s key-value pairs configured.

**Update Tag Association**

Update the existing parameter(s) in the config file and run the apply command. For example, in the below config file, modify the tagKey and tagType as highlighted

***Example***

```
apiVersion: tags.k8smgmt.io/v3
kind: ProjectTagsAssociation
metadata:
  name: demo-association
  project: default-project
spec:
  associations:
  - tagKey: "demo-key"
    tagType: "namespacelabel"
    tagValue: "demo-value-1"
    resource: "demo-namespace-1"
```

To apply the changes, run the below command

```
./rctl apply -f <projtagassoc-filename.yaml>
```

**Get Project Tag Association**

Use the below command to view the list of all Project Tag Associations.

```
./rctl get projtagassoc
┌──────────────────────────────┬──────────────────────────────────────────────────────────────────┐
│ PROJECT-TAG-ASSOCIATION NAME │                            TAGS-ASSOC                            │
│                              ├────────────────┬──────────────┬────────────────┬─────────────────┤
│                              │ TAG-ASSOC-TYPE │    TAG-KEY   │ TAG-VALUE      │ RESOURCE NAME   │
├──────────────────────────────┼────────────────┼──────────────┼────────────────┼─────────────────┤
│       demo-association       │ namespacelabel │ demo-key     │ demo-value     │ demo-namespace  │
|                              ┴────────────────┴──────────────┴────────────────┴─────────────────┘
│                              | namespacelabel │ demo-key     │ demo-value-1   │ demo-namespace-1│
└──────────────────────────────┴────────────────┴──────────────┴────────────────┴─────────────────┘
│       qc-projassoc           │ cost           │ key-test1    │ cost-report1   │     -           │
└──────────────────────────────┴────────────────┴──────────────┴────────────────┴─────────────────┘
```

Use the below command to view a specific project tag association details.

```
./rctl get projtagassoc <tagassoc_name>
```

***Example***

```
./rctl get projtagassoc demo-association
┌──────────────────────────────┬──────────────────────────────────────────────────────────────────┐
│ PROJECT-TAG-ASSOCIATION NAME │                            TAGS-ASSOC                            │
│                              ├────────────────┬──────────────┬────────────────┬─────────────────┤
│                              │ TAG-ASSOC-TYPE │    TAG-KEY   │ TAG-VALUE      │ RESOURCE NAME   │
├──────────────────────────────┼────────────────┼──────────────┼────────────────┼─────────────────┤
│       demo-association       │ namespacelabel │ demo-key     │ demo-value     │ demo-namespace  │
|                              ┴────────────────┴──────────────┴────────────────┴─────────────────┘
│                              | namespacelabel │ demo-key     │ demo-value-1   │ demo-namespace-1│
└──────────────────────────────┴────────────────┴──────────────┴────────────────┴─────────────────┘    
```

To view a project tag association config spec, use the below command

```
./rctl get projtagassoc qc-projassoc -o yaml
apiVersion: tags.k8smgmt.io/v3
kind: ProjectTagsAssociation
metadata:
  name: qc-projassoc
  project: defaultproject
spec:
  associations:
  - tagKey: key-test1
    tagType: cost
    tagValue: cost-report1
```

**Delete Project Tag Association**

Use the below command to delete a specific project tag association

```
./rctl delete projtagassoc <projtagassoc_name>
```

Use the below command to delete all the project tag association

```
./rctl delete projtagassoc
```

A set of comprehensive APIs are available that enable the users to seamlessly create, update, retrieve a list, and delete project tag association. The **ProjectTagAssociation** API allows you to easily create new tag association by providing the project id and resource name

[![Projects Intro](https://docs.rafay.co/security/tenancy/img/projects/tagassoc_api.png)](https://docs.rafay.co/security/tenancy/img/projects/tagassoc_api.png)

---
