---
title: "Network Whitelisting"
source: https://docs.rafay.co/security/whitelist/
category: Home
---

# White Listing

This section is relevant for customers that have been allocated an [Org](https://docs.rafay.co/security/rbac/orgs/) in Rafay's SaaS Controller (i.e. Control Plane hosted and managed by Rafay) available at [https://console.rafay.dev](https://console.rafay.dev/). Customers can use the information in this page to whitelist inbound (emails) and outbound (control channel destinations) in their enterprise's firewalls and proxies.

> **Important**
> If you are using Rafay's GPU Platform, please navigate to this [page](https://docs.rafay.co/security/whitelist_paas/)

---

## Emails

A 3rd Party service is used for emails sent by the SaaS Controller (i.e. for first time user activation, password resets, notifications etc). To guarantee delivery of emails from the SaaS Controller to users in the customer org, we strongly recommend that customers "whitelist" the IP address used for sending emails in their inbound email security systems.

The dedicated IP address currently used for sending emails from the Controller is **"149.72.39.92"**

---

## Network Firewall

The SaaS Controller has been specially designed so that customers can deploy and manage their **clusters** in both Internet (public IP) and on-premises (private IP) type environments.

| Deployment Model |
| --- |
| Internet Facing, Public IP |
| Non Internet Facing, Private IP |

To onboard an on-premise or cloud-based cluster onto the Controller for ongoing operations and lifecycle management

- A “Kubernetes Operator” is installed on each managed cluster.
- This establishes and maintains a "long-running" outbound TLS based control channel to the Controller (hosted in Amazon Web Services (AWS) for SaaS).
- **No Inbound Ports need to be opened on the customer's external firewall for control plane traffic.**

---

## Outbound Ports

The Kubernetes Management Operator deployed on the customer's cluster uses only "TCP Port 443, Outbound" to communicate with the SaaS Controller.

| Outbound Port | Security | Purpose |
| --- | --- | --- |
| 443/tcp | TLS with Mutual Auth | All Control Plane functionality |

---

## SaaS Controller IP

Customers that wish to lock down communication further can optionally whitelist the IP addresses of the SaaS Controller in their firewalls to ensure that outbound connectivity is only allowed to these IPs.

---

### IP Addresses

The SaaS Controller is currently deployed in a highly available manner across three availability zones (AZ) on AWS. A **pool** of load balanced IP Addresses are used for the SaaS Controller. Please add these to your firewall's whitelist if you are performing IP based filtering.

| Server | IP Address |
| --- | --- |
| IP Address 1 | 52.42.211.235 |
| IP Address 2 | 52.10.6.79 |
| IP Address 3 | 35.167.70.143 |
| IP Address 4 | 44.250.16.8 |
| IP Address 5 | 35.80.250.99 |
| IP Address 6 | 52.41.74.255 |
| IP Address 7 | 52.10.3.236 |
| IP Address 8 | 52.41.110.127 |
| IP Address 9 | 54.213.179.95 |

---

### Managed Cluster -> Controller FQDNs

The Kubernetes Management Operator components (deployed on managed clusters) will make outbound connections over port 443 to the Controller on the following FQDNs. Add these to your firewall's whitelist if necessary.

| Controller FQDNs |
| --- |
| tunnel.rafay-edge.net |
| api.rafay.dev |
| control.rafay.dev |
| fluentd-aggr.rafay-edge.net |
| influxdb01.core.rafay-edge.net |
| edge.core.rafay-edge.net |
| registry.rafay-edge.net |
| app.rafay.dev |
| console.rafay.dev |
| *.connector.kubeapi-proxy.rafay.dev |
| *.user.kubeapi-proxy.rafay.dev |
| event.core.rafay-edge.net |
| repo.rafay-edge.net |
| *.connector.cdrelay.rafay.dev |
| *.user.cdrelay.rafay.dev |
| *.connector.infrarelay.rafay.dev |
| *.user.infrarelay.rafay.dev |

---

### End User -> Controller FQDNs

Add the following to your organization's firewall or proxy whitelist if end users of your Org will be on the corporate network and need to interact with the controller from their laptops/desktops. For example, developers that need to remotely perform Kubectl operations on managed clusters using the zero trust kubectl service.

| Controller FQDNs |
| --- |
| *.user.kubeapi-proxy.rafay.dev |

---

## ECR Registry Access

Users that use the controller's [integration with AWS ECR (managed container registry)](https://docs.rafay.co/integrations/registry/overview/) will need to white list the following controller IP addresses.

| IP Address |
| --- |
| 54.244.183.118 |
| 34.208.240.165 |

The ECR integration allows the users to use the SaaS Controller to "configure, update and validate" access credentials with ECR.

---

## System Registry

The System Container Registry (RCR) is available as an option for customers to manage their container images. This is based on Docker Registry v2. It uses OAuth2 for authentication (laptops etc using the RCTL CLI).

Users are automatically redirected to an OAuth service which uses the provided credentials in docker login to authenticate and authorize the request for a resource on the registry. For successful requests, a bearer token is returned, which is used to **access** a resource on the Container Registry.

Please ensure that the network security policies implemented either in the corporate network OR the endpoint are configured to allow **outbound** connections from the RCTL CLI to the Controller on the ports listed below.

| Outbound Port | Security | Purpose |
| --- | --- | --- |
| 443/tcp | TLS (https) | Access the Controller Platform via REST APIs |

Please add the following ports if you wish to use the System Container Registry.

| Outbound Port | Security | Purpose |
| --- | --- | --- |
| 5001/tcp | TLS (https) | OAuth Authentication Service for Hosted Container Registry |
| 6000/tcp | TLS (https) | Access to Hosted Container Registry |

---
