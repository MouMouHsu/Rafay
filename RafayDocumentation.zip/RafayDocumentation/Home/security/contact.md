---
title: "Product Security - Contact"
source: https://docs.rafay.co/security/contact/
category: Home
---

# Contact

If you have questions about security about the Platform, you can contact us via email.

---

## Security White Paper

The security team publishes and maintains a Security White Paper that can be provided to customers that want a deeper understanding of security controls for the following areas.

- Service Security
- Security Controls - Org/Tenant
- Security Controls - Managed Clusters
- Security Controls - Customer Workloads/Applications

> **Info**
> For access to the white paper, please send an email to your Rafay sales/customer support person and cc "[[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#80f3e5e3f5f2e9f4f9c0f2e1e6e1f9aee3ef)". We will review your request and respond.

---

## Our Security Commitment

We ask that you do not share or publicize an unresolved vulnerability with/to third parties. If you responsibly submit a vulnerability report, the security team will use reasonable efforts to:

- Respond in a timely manner, acknowledging receipt of your vulnerability report
- Provide an estimated time frame for addressing the vulnerability report
- Notify you when the vulnerability has been fixed
- We are happy to thank every individual researcher who submits a vulnerability report helping us improve our overall security posture.

---

## Contacting Security

To report security or privacy issues that affect Rafay's products, please contact us at [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#3744525442455e434e77455651564e195458).

- Use our Product Security PGP key to encrypt sensitive information sent via e-mail.
- Please provide full details so that our security team can validate and reproduce the issue.
- For the protection of our customers, we generally do not disclose, discuss, or confirm security issues until a full investigation is complete and any necessary patches or releases are available.

---

## Encrypt Sensitive Information

When sending sensitive security information by email to the Security Team, please **ENCRYPT** it.

---

## PGP Public Key

Due to the sensitive nature of security information, we provide a method for you to:

- Verify the authenticity of security notifications
- Encrypt messages to send to us via [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#2d5e484e585f4459546d5f4c4b4c54034e42)

You can find our [PGP Public Key](https://keys.openpgp.org/search?q=security@rafay.co) here.

**User ID: [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection)**

**KeyID: 21273507**

**Fingerprint : 7C90 3260 1560 6094 08C5 9C33 F98B E992 2127 3507**

```
-----BEGIN PGP PUBLIC KEY BLOCK-----
mQINBF8w+QoBEAC+jOdf6xnhnjnDmeWcMYSHW32bVlR4YH+Gvv+XGLhqZVpQBD/k
WxBLA9TKUAN77j/rp/5eZxs+5mX7GyfV9oxJmPEz5u/iZ7202Tv4W8HgdEDxQ1qJ
KeUwCN/Gfi9tCrcpeESBHxL8LJNQgoCknNBhjZVTvJ+yl6kydmfjNBpaTh2aSh4t
oTU2Z3VQDPvKzZdzj9cVraPMk8lVTuygFIEM200WBTvxYXxPJm7fFUBAIoOv+8/g
oVl33TqyeLF/FR25NsKSBCp5h6w9mvUByigrFCsSW/kWB6TAGcK1qrF4QbHoLDT2
1TMmR3LYT1i4JCtVp8n9oSttnAXKbwTFfB25mMCmD/Qv93G+skGz7oxUyk9VEp/Y
wbI2BEvvOGElxH+VnUiHtVQ4IuxOK7Z+y6aYJdq2ghySjVTVxuyX/yc7X+hIssBZ
BS657gv2vHMupPTUi/A1smYd7P7x9MIOoXkxJWjoEEwTf/sYxzqGypeKGJ3EnDqR
eIf667jywlyvrPu9PVcuQv+F8skw5GZtdNlHQh+KOV/tlT8LCy6tzwfnomXqrQtA
kcQUmeySaOEEcpl1BpPeZ+KfYWViH1kTTwAcnCm+Tn6UNypyHh7fKMYgPIeNP4Ie
y2m0euar401lnpbHUUOzNyR7lI65OFmxYJOvSefaWBY4NQ7BVEmJ/lIa2QARAQAB
tCVzZWN1cml0eUByYWZheS5jbyA8c2VjdXJpdHlAcmFmYXkuY28+iQJUBBMBCAA+
FiEEfJAyYBVgYJQIxZwz+YvpkiEnNQcFAl8w+QoCGwMFCRLOpgAFCwkIBwIGFQoJ
CAsCBBYCAwECHgECF4AACgkQ+YvpkiEnNQebdg//R6FSw8ZTfs39MNRBhASk1wgH
tT8/NbKZHJlg7wATHzwjWlvCmXvk3HcIDA9UaRqxGMEj5OSfDHUGlNm7rRQSHqrv
P7Flqao4+uWkYcRSzSAIUiwbGAYGapb+Qalm2Q+WWWJtJNaIam4Fnl0v5YU3K2hJ
ZPJqyFdu+KhxheFwlJPmnO3fMzmvqZxjyY9Vaz6IjBJkAWVjbGPtjZYpqoroCvRB
aLk9y1nykTL/1/Yw9DO0wHt9q8TnP10ZSo0hIwJ+stujMdAbHn/OEiwPp/TmaWpO
7tA7QWBcc9el5fwuh+se79WNeh/bdleVuLmKPecBbKicoROd/EObER5mACgkMHin
698b685XI3oJH+8Rgfx//WaVFpMrLxo8ciNda05XgrQh+X0DHyUtc8UaLqfR+UEY
QXtMtaRInPrB0VPeOnRM6R8kUKre6K9IuoORYbjeFVP67o9JwmVgSCnVyx/DGStL
NW7TaO4PCnFv0zaiB07GY0zRpo76wEc6TL0yMNHKHMJBsakVptY9e2662yO5Yt4T
DZ9ETZOmLVkoEL43iUohZepkzDm4v2G6eN8r5sh5RM7pbgYc6MgmzMx03FJLMNmK
Tj7MlZo7mauCtLSMrt0ZHp91aKUpwOd7wgn6nFXBXVt/S7tjyU7VVJyn7wOOSdsg
Mg9gGZKgHZkKzDwvQpy5Ag0EXzD5CgEQAMK3uZZtqq//v7OiDgE1boPp8p/yNULj
fx9SL43X/ZXt8baX7YeqZKTL3ZC/OjdELJeNi9ksaf3NRJHbgtn/iucg1SlUefPJ
+RXztr0IdU5+Ji5+j4mq07vuDZ4WF9IYFlGFl5nswN5Tp5jCVt8/GKdcMSyGApC2
faP8kR3P75uS0chqjampTWy9OApEXEGGVXzkARHwfg3+pbzqZzkXg2rT/8GoXNXs
d3OiCYSPr7h8soaXa12o0/i/9BAZsa/Cu4fCv/JYbT0AXsM20p+yimQJA4aSNejv
orR0a6SynOt5RNVr2X1r9XHJ3DMfqM06C1I0VQ+aICBVOaFoMW4JnxmWTRvPiKfC
FiUAeaCeevsI3AhqxtYZDwF9kxhsDW3ate/BYz91LnYLcn1jgerYakgg26EWs5Gy
PCHg74xWRuQZz437tgv5kECUZQngY81Z6uVJV42c/bygY8Qrxz5Cr97Ufi+X8m3Y
hjquwRvQssHtLPbouImaGtROc9LfbTewfrRpky14fJWXrkvG15sK651lypW71BPG
CoISOqHiOLmQE4z9dfsBPGIOV5Eem4BqzKa4XgWxSmQnRRNBZUSguNPYUVo3vUJv
1sFuVzG1UeApBjvME8mLQ9rMSQqrba3eGCLHNwCl85M1KIpZnqxTlzgZhH8VaYS9
3jDK8gCfx8XVABEBAAGJAjwEGAEIACYWIQR8kDJgFWBglAjFnDP5i+mSISc1BwUC
XzD5CgIbDAUJEs6mAAAKCRD5i+mSISc1BwJOD/4wNph+jQ4N9UJQucbV1TfyhunS
3usXoCq6Ya133Y5RSp2aE8s4a9si7dveGv+aZFJSrxVOslicmOTNJu/m2Ft3+n4L
qJqGGG1r9GSpvsROyRciYZzSIeIS+V9aNr/KpzIf97nXk7tytIiHLGGkVg2DO16L
i11zmAdVK8kECMy6KELAKpBcw6fAs2QiEzg8URflJDBuH8tTBBDeclSoE+3+cceY
WIEeQGQbKwl2mBixEr28Vyu00sBPE4So2j2O4He0jxJaz2wAAxBdFCyI8jgz8HoC
6eET+XdQq5Jeqxc28gd9Dzt9fuDhIWY5tls3iMp3l1QrRjEDCkeqdQdK24WbEoHN
mH6V3uBbfWcCjpwjYxCvfx6guBulT2Qm2AonoOUdOKAFaPClPL3t8wETGq0mIAb5
TUWJJ4uZDnIu0CkNiYz4QG1CUuyVbfZkGQ14ROdi1bhdZcni6J0foTYmRpsc8NGW
7RuDHSYaCjTDt5xJENoQZkrjcA/hTBAJauX3YAuAsKs4Q4k0tS92fr7mZtPKJcT6
fGmRLcUvVmDOk3OkHR6CvE6N4k4680XcuI2PfCQswGpw1VOoe0cs07c8WGiMaA+2
QG2zXDyK9htd3UwjU+qQ+lgtI73lhydjBR7XRYDlmiMpGZmLa4zk9DH1nBPrftgX
rNG/mdo+1X8320I2BA==
=E8nm
-----END PGP PUBLIC KEY BLOCK-----
```

---
