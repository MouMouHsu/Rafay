---
title: "Custom ZTKA Access - Rules"
source: https://docs.rafay.co/security/custom_ztka/rules/
category: Home
---

# Rules

**Rules** allow specification of K8s RBAC definitions to control access to cluster resources.

---

## Create Rules

Perform the below steps to create a new rule

- Login to the console and navigate to **System → ZTKA Custom Access → Rules**

[![System Menu](https://docs.rafay.co/security/custom_ztka/img/rules/rule_menu.png)](https://docs.rafay.co/security/custom_ztka/img/rules/rule_menu.png)

- Click **New ZTKA Rule**

[![New Rule](https://docs.rafay.co/security/custom_ztka/img/rules/new_rule.png)](https://docs.rafay.co/security/custom_ztka/img/rules/new_rule.png)

- Provide a name for the rule and click **Create**. Rule New Version page appears
- Provide a **Version name**
- Provide the ClusterRole or Role YAML artifact. Role or ClusterRole represent a set of permissions. You can upload the artifact file or point to a repository

Below is an example of an artifact file with K8s **[ClusterRole](https://kubernetes.io/docs/reference/access-authn-authz/rbac/#clusterrole-example)** and **[Role](https://kubernetes.io/docs/reference/access-authn-authz/rbac/#role-example)**

---

### ClusterRole

ClusterRole is a K8s resource that is not bound to any specific namespace and it provides permissions that span across the entire cluster.

```
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: demo-purpose
rules:
- apiGroups:
  - '*'
  resources:
  - '*'
  verbs:
  - '*'
- nonResourceURLs:
  - '*'
  verbs:
  - '*'
```

**RoleBinding Creation for Namespace Admin roles**

To facilitate automatic **RoleBinding** creation in a specific user namespace with a ClusterRole YAML, you can include the label `k8smgmt.io/bindingtype: rolebinding` while defining ZTKA rules. This functionality caters to both namespace admin and namespace read only users.

For example, the following YAML represents a ClusterRole named pod-reader:

```
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: pod-reader
  labels:
    k8smgmt.io/bindingtype: rolebinding
rules:
- apiGroups: [""]
  resources: ["pods", "namespaces"]
  verbs: ["get", "watch", "list"]
```

This label ensures that RoleBindings corresponding to the ClusterRole will be automatically created in the relevant user namespace(s) whenever a Kubectl command is executed on any cluster within a project.

**RoleBinding Creation for Workspace Admin roles**

To facilitate automatic RoleBinding creation in all namespaces with the base role **Workspace Admin** and **Workspace Readonly** within a project, you can include the label **k8smgmt.io/bindingtype: rolebinding** while defining ZTKA rules with ClusterRole YAML. The custom role gets attached to a user within a project. When trying to run a Kubectl command on any cluster within this project through the console, a RoleBinding corresponding to the cluster role will be created in all the namespaces that are created in this project.

---

### Role

A Role always defines permissions within a specific namespace. Upon creating a Role, designate the namespace to which it pertains.

```
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: demo-ns
  name: pod-read-role
rules:
- apiGroups: [""] # "" indicates the core API group
  resources: ["pods"]
  verbs: ["get", "watch", "list"]
```

- Select the Project(s) for which the rule must apply
- Select the Cluster(s) for which the rule must apply. Cluster selection can be based on labels or namespace

[![ZTKA Rule](https://docs.rafay.co/security/custom_ztka/img/rules/ztka_rules.png)](https://docs.rafay.co/security/custom_ztka/img/rules/ztka_rules.png)

- Click **Save Changes**

---

## New Version

On successful Rule Creation, the first version of the rule appears. Based on the requirement, users can create multiple versions. To view the details of a specific rule version, click the **eye** icon

[![Rule version](https://docs.rafay.co/security/custom_ztka/img/rules/rule_version.png)](https://docs.rafay.co/security/custom_ztka/img/rules/rule_version.png)

---
