---
title: "Custom ZTKA - Policies"
source: https://docs.rafay.co/security/custom_ztka/policies/
category: Home
---

# Policies

**Policies** is a collection of rules that determines user access to cluster resources. You can create multiple policy versions and add one or more rules to a policy.

---

## Create Policy

Perform the below steps to create a new policy:

- Login to the console and navigate to **System → ZTKA Custom Access → Policies**
- Click **New ZTKA Policy**

[![ZTKA policy](https://docs.rafay.co/security/custom_ztka/img/policies/ztka_policy.png)](https://docs.rafay.co/security/custom_ztka/img/policies/ztka_policy.png)

- Provide a name for the policy and click **Create**
- Provide a **Version name**
- Select the required ZTKA [Rules](https://docs.rafay.co/security/custom_ztka/rules/) from the drop-down and its version. You can add one or more rules to this policy
- Click **Save Changes**

[![ZTKA policy](https://docs.rafay.co/security/custom_ztka/img/policies/add_rules.png)](https://docs.rafay.co/security/custom_ztka/img/policies/add_rules.png)

---

## New Version

On successful Policy Creation, the first version of the policy appears. Based on the requirement, users can create multiple versions. To view the details of a specific policy version, click the **eye** icon

[![Policy version](https://docs.rafay.co/security/custom_ztka/img/policies/policy_version.png)](https://docs.rafay.co/security/custom_ztka/img/policies/policy_version.png)

---
