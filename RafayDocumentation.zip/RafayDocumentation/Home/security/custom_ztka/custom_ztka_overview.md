---
title: "KOP - Custom ZTKA"
source: https://docs.rafay.co/security/custom_ztka/custom_ztka_overview/
category: Home
---

# Overview

## Overview

The base roles that the platform includes out of the box provides a certain level of access to controller and cluster resources, the details of which are outlined [here](https://docs.rafay.co/security/rbac/roles/).

There are scenarios where more fine-grained access policies (than what is included with the platform's base roles) need to be configured for users. ZTKA (Zero-Trust) Custom Access enables customers to define custom RBAC definitions to control the access that users have to the clusters in the organization.

An example could be restricting users to read only access (get, list, watch verbs) for certain resources (e.g. pods, secrets) in a certain namespace. Only **Org Admin** can configure ZTKA Custom Access rules, policies, and custom roles.

---

## Implementing ZTKA Custom Access

ZTKA Custom Access implementation involves the following three steps:

- **Step 1 - [Create Rules](https://docs.rafay.co/security/custom_ztka/rules/)**: ClusterRole or Role YAML definition files are provided as part of this step, applicability of the rule is determined based on project/cluster selection
- **Step 2 - [Create Policies](https://docs.rafay.co/security/custom_ztka/policies/)**: Policies is a collection of one or more rules that is referenced as part of Custom Roles
- **Step 3 - [Custom Roles](https://docs.rafay.co/security/rbac/custom_roles/)**: A Custom Role configuration includes selection of a base role along with the necessary overlay ZTKA Custom Access policies

> **Important**
> Custom ZTKA Access definition specified for a user for a particular project/cluster overrides the ZTKA Access definition associated with the user's base role.

---

## Scenarios

| Platform Base Role | K8s Role | K8s RoleBindings |
| --- | --- | --- |
| Workspace/Namespace Admin or Workspace/Namespace Read Only | ClusterRole and the YAML file includes the label **k8smgmt.io/bindingtype: rolebinding** | RoleBindings will be created in all the namespaces associated with the base role |
| Platform Base Roles other than Workspace/Namespace Admin and Workspace/Namespace Read Only | ClusterRole and the YAML file includes the label **k8smgmt.io/bindingtype: rolebinding** | ClusterRoleBindings will be created |
| Any Platform Base Role | ClusterRole | ClusterRoleBindings will be created |
| Any Platform Base Role | Role | RoleBindings will be created in the namespaces provided in the Role Definition file |

---

## ZTKA Custom Access workflow

The sequence diagram below captures the high level steps to create a Rules, Policies, and Custom Roles.

### Step 1: ZTKA Custom Access Rules

```
sequenceDiagram
    Note over Login to Console: Only Org Admin
    Login to Console->>Navigate to ZTKA Custom Access Rules: From System menu
    Navigate to ZTKA Custom Access Rules->>Add Rules: Create new rule version
    Add Rules->>Save Changes: Settings: Artifact File, Project Selector, and Cluster Selector    
    Save Changes->>New Version: Edit to add multiple versions
```

### Step 2: ZTKA Custom Access Policies

```
sequenceDiagram
    Navigate to ZTKA Custom Access Policies->>Add Policy: Create new policy version
    Add Policy->>Save Changes: Settings: General and ZTKA Rules
    Save Changes->>New Version: Edit to add multiple versions
```

### Step 3: Custom Roles

```
sequenceDiagram
    Navigate to Custom Roles->>Add Role: Create new role
    Add Role->>Save Changes: Settings: Name, Base Role, and ZTKA Policies    
```

---
