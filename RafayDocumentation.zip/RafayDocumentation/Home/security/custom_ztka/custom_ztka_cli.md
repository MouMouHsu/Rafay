---
title: "KOP CLI - CLI"
source: https://docs.rafay.co/security/custom_ztka/custom_ztka_cli/
category: Home
---

# Custom ZTKA Access

> **Important**
> This capability is currently available with self-hosted controller and SaaS controller.

---

The RCTL utility provides the means to manage/automate the lifecycle of OPA Gatekeeper. The following operations can be performed on OPA Gatekeeper for projects within an organization.

| **Resource** | **Create** | **Get** | **Apply** | **Update** | **Delete** |
| --- | --- | --- | --- | --- | --- |
| Custom ZTKA rule | YES | YES | YES | YES | YES |
| Custom ZTKA policy | YES | YES | YES | YES | YES |
| Custom Role | YES | YES | YES | YES | YES |

---

ZTKA Custom Access implementation involves the following three steps:

- **Step 1 - [Create Rules](https://docs.rafay.co/security/custom_ztka/rules/)**: ClusterRole or Role YAML definition files are provided as part of this step, applicability of the rule is determined based on project/cluster selection
- **Step 2 - [Create Policies](https://docs.rafay.co/security/custom_ztka/policies/)**: Policies is a collection of one or more rules that is referenced as part of Custom Roles
- **Step 3 - [Custom Roles](https://docs.rafay.co/security/rbac/custom_roles/)**: A Custom Role configuration includes selection of a base role along with the necessary overlay ZTKA Custom Access policies

---

## Create Custom ZTKA rule

Run the below command to create a custom ZTKA rule using the spec yaml file.

```
./rctl apply -f rule_filename.yaml
```

An illustrative example of the spec YAML file (Artifact upload) is shown below:

```
apiVersion: system.k8smgmt.io/v3
kind: ZTKARule
metadata:
  name: rctl-rule-all1
spec:
  artifact:
    artifact:
      paths:
        - name: file://artifacts/ztkar.yaml
    options: {}
    type: Yaml
  clusterSelector:
    selectAll: true
  projectSelector:
    matchNames:
      - z-1
      - defaultproject
  version: v1
```

An illustrative example of the spec YAML file (Git Repo based) is shown below:

```
apiVersion: system.k8smgmt.io/v3
kind: ZTKARule
metadata:
  name: rctl-rule-all1
spec:
  artifact:
    artifact:
      paths:
        - name: path/to/ztkarule/file.yaml
      project: defaultproject #project in which repo is present
      repository: some-repo
      revision: master
    options: {}
    type: Yaml
  clusterSelector:
    selectAll: true
  projectSelector:
    matchNames:
      - z-1
      - defaultproject
  version: v1
```

---

## Create Custom ZTKA policy

An illustrative example of the ZTKA Policy spec YAML file is as shown below:

```
apiVersion: system.k8smgmt.io/v3
kind: ZTKAPolicy
metadata:
  name: rctl-pol-all1
spec:
  version: v1
  ztkaRuleList:
    - name: rctl-rule-all1
      version: v1
    - name: rctl-rule-all2
      version: v2
```

---

## Create Custom Role

An illustrative example of the Custom Role spec YAML file is as shown below:

```
apiVersion: system.k8smgmt.io/v3
kind: CustomRole
metadata:
  name: rctl-ctr-all1
spec:
  baseRole: ADMIN
  ztkaPolicyList:
    - name: rctl-pol1
      version: v1
```

---

## List ZTKA Rules

Use this command to retrieve the list of ZTKA rules. An illustrative example is shown below where RCTL retrieves the list of ZTKA rules.

```
./rctl get ztkarule
+---------------------------+---------------------------+---------------+-------------------------------------------------------+------------------------+
| ZTKARULE NAME             | VERSION                   | ARTIFACT TYPE | ARTIFACT FILES                                        | REPOSITORY             |
+---------------------------+---------------------------+---------------+-------------------------------------------------------+------------------------+
| test-rctl-1              | v1                        | Yaml          | paths:{name:"file:///artifacts/ztkar_podreader.yaml"} |                        |
+---------------------------+---------------------------+---------------+-------------------------------------------------------+------------------------+
| test-rctl-2              | v1                        | Yaml          | paths:{name:"file://artifacts/ztkacr.yaml"}           |                        |
+---------------------------+---------------------------+---------------+-------------------------------------------------------+------------------------+
```

### Get Specific ZTKA Rule

Below is an example to retrieve a specific ZTKA rule.

```
./rctl get ztkarule test-rule
+---------------+---------+---------------+----------------------------------------------------+------------+
| ZTKARULE NAME | VERSION | ARTIFACT TYPE | ARTIFACT FILES                                     | REPOSITORY |
+---------------+---------+---------------+----------------------------------------------------+------------+
| test-rule     | v1      | Yaml          | paths:{name:"file://nginx_ns_pod_read_write.yaml"} |            |
+---------------+---------+---------------+----------------------------------------------------+------------+
```

---

## List ZTKA Policies

Use this command to retrieve the list of ZTKA policies. An illustrative example is shown below where RCTL retrieves the list of ZTKA policies.

```
./rctl get ztkapolicy
+--------------------+---------------------------+---------------------------+
| ZTKAPOLICY NAME    | VERSION                   | RULES                     |
+--------------------+---------------------------+---------------------------+
| test-rctl-1        | v1                        | test-rctl-1              |
|                    |                           | test-rctl-2              |
|                    |                           |                           |
+--------------------+---------------------------+---------------------------+
| test-secret-pod1   | v1                        | test-secret-cr1          |
|                    |                           | test-podreader1          |
|                    |                           |                           |
+--------------------+---------------------------+---------------------------+
| test-1             | ver1                      | test-rule1                |
|                    |                           |                           |
+--------------------+---------------------------+---------------------------+
| test-ztka-policy   | v1                        | test-swagger             |
|                    |                           | test-rctl-2              |
+--------------------+---------------------------+---------------------------+
```

### Get Specific ZTKA Policy

Below is an example to retrieve a specific ZTKA policy.

```
./rctl get ztkapolicy test-policy
+-----------------+---------+-----------+
| ZTKAPOLICY NAME | VERSION | RULES     |
+-----------------+---------+-----------+
| test-policy     | v1      | test-rule |
|                 |         |           |
+-----------------+---------+-----------+
```

---

## List Custom Roles

Use this command to retrieve the list of Custom Roles.

```
./rctl get customroles
+-------------------------+-----------------+--------------------+
| CUSTOM ROLE             | ABAC POLICY     | ZTKA POLICY        |
+-------------------------+-----------------+--------------------+
| test-role1              | test-policy1    |                    |
|                         |                 |                    |
+-------------------------+-----------------+--------------------+
| test-eks-role           | test-eks-policy |                    |
|                         |                 |                    |
+-------------------------+-----------------+--------------------+
| test-role               | test-policy     |                    |
|                         |                 |                    |
+-------------------------+-----------------+--------------------+
```

### Get Specific Custom Role

Below is an example to retrieve a specific Custom Role.

```
./rctl get customrole test-role
+-------------+-------------+-------------+
| CUSTOM ROLE | ABAC POLICY | ZTKA POLICY |
+-------------+-------------+-------------+
| test-role   |             | test-policy |
|             |             |             |
+-------------+-------------+-------------+
```

---

## Delete Commands

You can use the below commands to delete ZTKA rules, ZTKA policies and Custom Roles.

**ZTKA Rules**

```
./rctl delete zr <rule-name>
```

OR

```
./rctl delete zr -f <rule_file.yaml>
```

**ZTKA Policies**

```
./rctl delete zp <policy-name>
```

OR

```
./rctl delete zr -f <policy_file.yaml>
```

**Custom Roles**

```
./rctl delete ctr <custom-role-name>
```

OR

```
./rctl delete ctr -f <custom_role_file.yaml>
```

---
