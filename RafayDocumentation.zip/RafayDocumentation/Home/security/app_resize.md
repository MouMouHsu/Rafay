---
title: "App Resizing"
source: https://docs.rafay.co/security/app_resize/
category: Home
---

# App Resizing

## Overview

The **App Resizing** feature helps identify unused CPU and memory resources reserved by applications running in clusters. Applications are often configured with resource requests that exceed actual usage, resulting in wasted capacity.

App Resizing generates a resource utilization report based on historical usage data. The report provides visibility into actual consumption and helps administrators manually resize application resource requests to improve cluster utilization.

> Note: This feature provides usage insights only and does not automatically modify application resources.

---

## Role-Based Access

| Role | Access |
| --- | --- |
| Org Admin | Full access, including configuration, report generation, download, delete, and rerun |
| Org Read Only Admin | View configuration and download reports |

---

## Generating an App Resizing Report

> Supported Interfaces
> 
> UI
> Swagger API

### Step 1: Navigate to App Resizing

1. From the left navigation menu, select **System** and click **App Resizing**.
2. Click on **On Demand Runs**.

[![Audit Logs Console](https://docs.rafay.co/security/img/app_resize.png)](https://docs.rafay.co/security/img/app_resize.png)

### Step 2: Configure Report Settings

Provide the required configuration.

#### Basic Details

- **Name**: Name for the report configuration.
- **Description**: Optional description.
- **Period**: Number of days used for analysis. *Example: `7` analyzes resource usage for the last seven days.*
- **Project**: Select a specific project or all projects.

#### Cluster Selection

Clusters can be selected using:

- Individual cluster selection
- All clusters
- Cluster labels (for selecting multiple clusters with common labels)

Selected clusters or labels appear in the **Selected Clusters Or Labels** section.

[![Audit Logs Console](https://docs.rafay.co/security/img/appresize_inputs.png)](https://docs.rafay.co/security/img/appresize_inputs.png)

#### Namespace Selection

Namespaces can be selected using:

- Individual namespace selection
- Namespace labels

Configured namespaces are displayed under:

- **Included: Namespaces & Labels**
- **Excluded: Namespaces & Labels**

[![Audit Logs Console](https://docs.rafay.co/security/img/appresize_ns.png)](https://docs.rafay.co/security/img/appresize_ns.png)

### Step 3: Generate the Report

1. Click **Save**.
2. Report analysis runs in the backend.
3. Reports are generated based on the selected scope.

### Step 4: Download Reports

> Image Placeholder: Generated Reports table showing report entries and download option.

After report generation:

- Reports appear in the **Generated Reports** list.
- One report is generated per cluster.
- When multiple clusters are selected, reports are packaged into a single ZIP file for download.

[![Audit Logs Console](https://docs.rafay.co/security/img/appresizing_list.png)](https://docs.rafay.co/security/img/appresizing_list.png)

#### Report Contents

The generated report provides resource utilization metrics for applications running in the selected clusters and namespaces.

Each report includes the following fields:

- **Project** – Project associated with the workload.
- **Cluster** – Cluster where the application is running.
- **Namespace** – Namespace containing the workload.
- **Pod Name** – Name of the pod analyzed.
- **CPU Request (cores)** – CPU resources currently requested.
- **CPU Usage P90 (cores)** – 90th percentile CPU usage during the selected period.
- **CPU Usage P95 (cores)** – 95th percentile CPU usage during the selected period.
- **CPU Usage Peak** – Maximum CPU usage recorded.
- **Memory Request** – Memory resources currently requested.
- **Memory Usage P90** – 90th percentile memory usage during the selected period.
- **Memory Usage P95** – 95th percentile memory usage during the selected period.
- **Memory Usage Peak** – Maximum memory usage recorded.

These values help identify application resources where requested values are higher than actual utilization, enabling administrators to manually optimize resource settings.

[![Audit Logs Console](https://docs.rafay.co/security/img/report.png)](https://docs.rafay.co/security/img/report.png)

---

## Apply App Resizing

After reviewing the report, resource requests must be manually updated in the application configuration within the cluster. This applies to any resource where CPU and memory requests are defined.

To resize an application:

1. Navigate to the application or resource running in the cluster.
2. Open the associated YAML configuration.
3. Locate the `resources` section under the container specification.
4. Update the CPU and memory request values based on the report insights.
5. Save and reapply the updated configuration.

### Example

The following example shows a workload YAML where CPU and memory requests can be updated:

```
resources:
  requests:
    cpu: "100m"
    memory: "50Mi"
  limits:
    cpu: "1000m"
    memory: "524Mi"
```

This example is provided for reference. The same approach applies to any application resource that defines resource requests in its YAML specification.

[![Audit Logs Console](https://docs.rafay.co/security/img/workload_appres.png)](https://docs.rafay.co/security/img/workload_appres.png)

This approach applies to any workload or application that defines CPU and memory requests in its YAML specification.

---

## Generated Reports Actions

Each entry in the **Generated Reports** table provides the following actions:

- **View (Eye icon)**: Displays the report details and configuration information.
- **Rerun (Play icon)**: Generates a new report using the same configuration.
- **Download (Download icon)**: Downloads the generated report. If multiple clusters are included, the reports are downloaded as a ZIP file.
- **Delete (Trash icon)**: Removes the report entry from the list.

These actions allow viewing, regenerating, downloading, and managing previously generated reports.

[![Audit Logs Console](https://docs.rafay.co/security/img/options.png)](https://docs.rafay.co/security/img/options.png)

---
