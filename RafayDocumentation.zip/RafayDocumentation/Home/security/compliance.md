---
title: "Product Security - Compliance"
source: https://docs.rafay.co/security/compliance/
category: Home
---

# Compliance

## SOC 2 Type II

We are Service Organization Control (SOC) 2, Type II compliant. This provides independent validation that our security controls comply with the American Institute of Certified Public Accountants’ applicable Trust Services Principles and Criteria. This also demonstrates our commitment to the most rigorous security standards for its own operations and handling of customer data.

[![SOC 2 Type 2](https://docs.rafay.co/security/img/compliance/soc2-aicpa.png)](https://docs.rafay.co/security/img/compliance/soc2-aicpa.png)

---

### Primary Purpose

A SOC2 Type 2 report

- Is an internal controls report capturing how a company safeguards customer data and how well those controls are operating. Companies that use cloud service providers use SOC 2 reports to assess and address the risks associated with third party technology services.
- Is issued by independent third party auditors covering the principles of Security, Availability, Confidentiality, and Privacy.
- Provides an independent assessment of the provider's security and privacy control environment. The assessment includes a description of the controls, the tests performed to assess them, the results of these tests, and an overall opinion on the design and operational effectiveness of the same.

---

### Scope

The platform's SOC 2 Type 2 Report covers the AICPA’s Trust Services Principles and Criteria for Security, Availability, Confidentiality, and Privacy.

---

### Audit Frequency

Audits are performed annually by independent auditors.

---

### Copy of Report

Customers can request a copy of our SOC 2 Type II report. Contact the [security team](https://docs.rafay.co/security/contact/) for details.

---

### Primary Audience

Customers and relevant third parties with a business need.

---
