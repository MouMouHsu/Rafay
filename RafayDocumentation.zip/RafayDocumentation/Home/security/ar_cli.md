---
title: "KOP Access Reports - CLI"
source: https://docs.rafay.co/security/ar_cli/
category: Home
---

# Access Reports

Access Reports

## Declarative

Users can use RCTL to generate, list and download access reports

### Generate Report(s)

#### User or Group Type - All

Use the following command to generate a report of all user and group types in csv format

```
./rctl generate accessreport reportname --format csv --filter all
```

(or)

```
./rctl generate accessreport reportname
```

#### User Type - Local Users

Use the following command to generate a report of Local Users in json format

```
./rctl generate accessreport reportname --format json --filter users-local
```

#### User Type - IDP Users

Use the following command to generate a report of IDP Users in json format

```
./rctl generate accessreport reportname --format json --filter users-idp
```

#### Group Type - IDP Group

Use the following command to generate a report of IDP Groups in csv format

```
./rctl generate accessreport reportname --format csv --filter groups-idp
```

#### Group Type - Override Groups

Use the following command to generate a report of Override Groups in csv format

```
./rctl generate accessreport reportname --format csv --filter groups-override
```

---

### Schedule Reports

Below are examples of commands to schedule user access reports with varying frequencies and formats:

- Annually: Generates a yearly user access report in CSV format
- Monthly: Generates a monthly user access report in CSV format
- Quarterly: Generates a quarterly user access report in JSON format

#### Annual Report Generation

Schedules the generation of a user access report annually in CSV format, including all available data.

```
./rctl schedule accessreport reportName annually --format csv --filter all
```

#### Monthly Report Generation

Schedules the generation of a user access report monthly in CSV format, including all available data.

```
./rctl schedule accessreport reportName monthly --format csv --filter all
```

#### Quarterly Report Generation

Schedules the generation of a user access report quarterly in JSON format, including all available data.

```
./rctl schedule accessreport reportName quarterly --format json --filter all
```

---

### List Access Reports

To view the list of all generated access groups

```
./rctl get accessreports
```

***Example Output***

```
./rctl get accessreports                                                            12:13:45
+----------+-----------+------------------------------------------------------------------------------------------------------------------------------+--------+--------------------------------+
| REPORTID | TYPE      | FILENAME                                                                                                                     | FORMAT | GENERATEDAT                    |
+----------+-----------+------------------------------------------------------------------------------------------------------------------------------+--------+--------------------------------+
| qkog7n2  | Ad-Hoc    | demo-report_2024-07-19_05-43-45.csv                                                                                          | csv    | 2024-07-19 05:43:45.984695     |
|          |           |                                                                                                                              |        | +0000 UTC                      |
+----------+-----------+------------------------------------------------------------------------------------------------------------------------------+--------+--------------------------------+
| lk5xod2  | Scheduled | scheduled_report1_2024-07-04_18-40-00.csv                                                                                    | csv    | 2024-07-04 18:40:00.013755     |
|          |           |                                                                                                                              |        | +0000 UTC                      |
+----------+-----------+------------------------------------------------------------------------------------------------------------------------------+--------+--------------------------------+
| w2lr3n2  | Scheduled | scheduled_report1_2024-07-04_18-35-00.csv                                                                                    | csv    | 2024-07-04 18:35:00.018154     |
|          |           |                                                                                                                              |        | +0000 UTC                      |
+----------+-----------+------------------------------------------------------------------------------------------------------------------------------+--------+--------------------------------+
```

---

### Download Reports

To download an access report, use the command below. This will download a report with its original name.

```
rctl download accessreport <report_id>
```

To download a specific report with a specific name, use the following command:

```
./rctl download accessreport <report_id> --file <file-name>
```

> Note: file-name is optional

---
