---
title: "Product Security - Break Glass Access"
source: https://docs.rafay.co/security/break_glass_access/
category: Home
---

# Overview

"Break Glass Access" feature is intended to provide temporary access for users during emergencies or special scenarios. It ensures that users have access only to what is necessary and for a limited time while being able to audit all user activities. This feature enables the ability for administrators to grant access without permanently altering user roles or permissions.

[![Audit Logs Console](https://docs.rafay.co/security/img/break_glass.png)](https://docs.rafay.co/security/img/break_glass.png)

Watch a video recording of a demo of this feature below.

### User Access

Org Administrators can assign Break Glass Access to local users or IDP users directly within the platform. Access is configured by selecting the desired local/IDP user and assigning a predefined group with an explicit expiry time.

---

## Roles

Only users with the **Org Admin** role can access the Break Glass Access feature and add users to groups.

---

## Interfaces

> **Did you know ?**
> Break Glass Access can be managed through various methods:
>
> - [UI](https://docs.rafay.co/security/bga_ui/)
> - [CLI](https://docs.rafay.co/security/breakglass_cli/)
> - [API](https://docs.rafay.co/automation/api/apis/)
> - [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/user)

---
