---
title: "Product Security - Access Reports"
source: https://docs.rafay.co/security/ar_ui/
category: Home
---

# UI

## Generate Reports

To generate a report,

- Click **Generate Report**
- Provide a name for the report
- Select the **Output Format**, either CSV or JSON
- Choose the **User or Group type** from the drop-down menu. The available options are All, IDP Users, Local Users, IDP Groups - IDP Users, and Override Groups - IDP Users. The default option is **All**
- Click **Generate**

[![Audit Logs Console](https://docs.rafay.co/security/img/audit/generate_reps.png)](https://docs.rafay.co/security/img/audit/generate_reps.png)

Once the report is generated, you can view in the list as shown below.

[![Audit Logs Console](https://docs.rafay.co/security/img/audit/report_list.png)](https://docs.rafay.co/security/img/audit/report_list.png)

---

## Schedule Reports

Users can schedule the generation of an access report by clicking the **Schedule** button. This feature allows users to set up regular intervals at which the report will be automatically generated.

To generate a scheduled report,

- Click **Schedule Report**
- Provide a name for the report
- Select the **Output Format**, either CSV or JSON
- Choose the **User or Group type** from the drop-down menu. The available options are All, IDP Users, Local Users, IDP Groups - IDP Users, and Override Groups - IDP Users. The default option is **All**
- Select **Interval**, the available options through the UI are weekly, monthly, quarterly and yearly
- Click **Generate**

[![Audit Logs Console](https://docs.rafay.co/security/img/audit/schedule.png)](https://docs.rafay.co/security/img/audit/schedule.png)

---

### Download Reports

Click the **Download** icon to view the generated reports in detail. The downloaded reports will include columns such as Org Name, Access Level, Project Name, Project Description, Namespace, Username, User Type, Group Name, Group Type, Role Name, and Granted Access Timestamp. Select the required 'User Type' or 'Group Type' to create more targeted reports.

[![Audit Logs Console](https://docs.rafay.co/security/img/audit/download_icon.png)](https://docs.rafay.co/security/img/audit/download_icon.png)

Reports will be concise, avoiding redundant entries, and support output formats CSV and JSON, with CSV as the default. Timestamp will indicate when the reports are generated.

[![Audit Logs Console](https://docs.rafay.co/security/img/audit/report_detail.png)](https://docs.rafay.co/security/img/audit/report_detail.png)

> **Important**
> If the number of reports exceeds 10, older reports will be automatically deleted. Additionally, reports that are older than one year will also be automatically deleted.

---
