---
title: "CIS Benchmark - Kubernetes Clusters"
source: https://docs.rafay.co/security/cis/
category: Home
---

# CIS Benchmark

The [Center for Internet Security - CIS](https://www.cisecurity.org/) releases benchmarks for best practice security recommendations spanning a number of areas. CIS Controls are an essential **go to** resource for any data security and compliance professional. The CIS [Kubernetes Benchmark](https://www.cisecurity.org/benchmark/kubernetes/) is a set of recommendations for configuring Kubernetes to support a strong security posture. The CIS Kubernetes Benchmark is written for the open source Kubernetes distribution and intended to be as universally applicable across distributions as possible.

> **Info**
> Explore our blog for deeper insights on **CIS Benchmark for Kubernetes**, available [here](https://docs.rafay.co/blog/2023/08/24/cis-benchmark-for-kubernetes-using-rafay/)

---

## Categories

The Kubernetes CIS Benchmark contains >250 pages describing how to secure Kubernetes infrastructure. The benchmark itself is categorized into several sections as described below.

### k8s Control Plane Components

Recommendations for the configuration of the Kubernetes control plane. This includes the API Server, etcd, Controller Manager etc.

### k8s Worker Nodes

Recommendations for securing configuration files and defining specific configuration settings for the kubelet on worker nodes etc.

### Policies

Recommendations for specific policies for Kubernetes elements like RBAC, pods and the container network interface (CNI), to improve security.

> **Important**
> The CIS benchmark is tied to a specific Kubernetes version.

---

## CIS Benchmarks - By Distribution

This section provides additional details on CIS Benchmarks by Kubernetes Distribution.

### Rafay MKS Distribution

This section is focused on CIS Benchmarks for Kubernetes clusters based on [Rafay MKS Distribution](https://docs.rafay.co/clusters/upstream/baremetal_vm/overview/)

#### Cluster Provisioning

Kubernetes clusters provisioned based on the [Rafay MKS Distribution](https://docs.rafay.co/clusters/upstream/baremetal_vm/overview/) are deployed in a **secure by default** configuration. This ensures that the clusters are provisioned in compliance with the CIS Kubernetes benchmark. The primary benefit of this approach is that customers do not have to invest in reviewing and operationalizing a separate hardening guide/process.

#### False Positives

CIS compliance check tools typically implement a set of **opinionated and generalized** tests. They are not intelligent enough to automatically detect all configurations and mitigations. As a result, the scan results may incorrectly report failures which are actually "False Positives".

> **Info**
> Please [contact](https://docs.rafay.co/cdn-cgi/l/email-protection#80f3e5e3f5f2e9f4f9c0f2e1e6e1f9aee3ef) our security team if you have questions about this.

---

### Cloud Kubernetes Distributions

This section is focused on CIS Benchmarks for Kubernetes clusters based on Cloud Kubernetes Disributions (i.e. Amazon EKS, Azure AKS and Google GKE) provisioned and managed using the Rafay Platform.

#### Cluster Provisioning

With managed Kubernetes distributions (i.e. Amazon EKS, Azure AKS and Google GKE), there are recommendations (e.g. Control Plane components) that cannot be audited or remediated directly by the customer. Please refer to and implement the recommendations provided by the cloud provider.

---

### Imported Clusters

For Kubernetes clusters that are provisioned outside the Rafay platform and imported into Rafay (e.g. RedHat OpenShift), please contact your provider for questions on CIS Compliance.

---

## Ongoing CIS Compliance Checks

Users can use popular, open source tools such as [Trivy](https://github.com/aquasecurity/trivy) to test/verify whether a Kubernetes cluster is in compliance with the CIS benchmark or not. These tools highlight areas of the Kubernetes cluster that do not comply with the CIS benchmark and also provide solutions to resolve the issues.

Follow this [step-by-step documentation](https://docs.rafay.co/recipes/security/trivy/) clearly describing how to use the Trivy Operator on a fleet of Kubernetes clusters

> **Info**
> Customers can use Rafay's [Zero Trust Kubectl](https://docs.rafay.co/accessproxy/overview/) as the means to securely access their fleet of clusters to centrally aggregate CIS Benchmark reports. This ensures that the compliance team has visibility and access to every compliance report right from the birth of each cluster.

---
