---
title: "KOP IAM"
source: https://docs.rafay.co/security/rbac/iam-overview/
category: Home
---

# Overview

## About

With Identity and Access Management (IAM), you can manage a directory of "local users". You can optionally offload the user management to a corporate Identity Provider by using the built in SSO Integration.

You can specify who or what can access which service and resources. You can centrally manage fine-grained permissions (i.e. who can do what?). Specifically, you can "Set, verify, and Right-size permissions" toward least privilege.

---
