---
title: "Rafay Orgs"
source: https://docs.rafay.co/security/rbac/orgs/
category: Home
---

# Organizations

Every customer is provisioned with at least one Organization (i.e. Tenant). Customers can request for "multiple Orgs" if they require complete isolation across their Orgs. For example, a separate Org for a business unit that is in the process of being divested. Admins can access all their Orgs through the same URL and seamlessly switch between their Orgs as well via an integrated Org Switcher.

> **Important**
> It is strongly recommended that customers have at least "two" Organization Admins. This will ensure that there is a second admin user that can perform privileged actions in case the first admin is unavailable or locked out.

---

## Switch between Orgs

> **Important**
> The Org Switcher is available for **local users** assigned to multiple Orgs. For **SSO (IdP) users**, the Org Switcher is available when the partner uses **Global IdP** (common IdP for all organisations), the IdP sends a **multi-valued organisation attribute**, and the user’s session includes those organisations—roles continue to come from IdP **group** claims mapped per organisation. SSO users on **organisation-specific IdP** (non–Global IdP) keep the usual behaviour: sign out and sign in again (or use an IdP-initiated application per org) to access another org.

Customers that have been provisioned with multiple Orgs can switch between Orgs via a built in "Org Switcher" when the above applies.

- In the "Web Console", on the top right, click on your email address.
- Click on "Change Organization".

You will be shown this only if your email address is associated with "multiple Orgs".

[![Org Switcher](https://docs.rafay.co/security/rbac/img/org_switcher/org_switcher_change_org.png)](https://docs.rafay.co/security/rbac/img/org_switcher/org_switcher_change_org.png)

- Select the Org you wish to switch to

[![Org Switcher](https://docs.rafay.co/security/rbac/img/org_switcher/org_switcher_select_org.png)](https://docs.rafay.co/security/rbac/img/org_switcher/org_switcher_select_org.png)

---
