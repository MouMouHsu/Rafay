---
title: "KOP IDP Groups - CLI"
source: https://docs.rafay.co/security/rbac/cli-symlink-1/
category: Home
---

# CLI

## Declarative

Users can use RCTL to add IDP user(s) to the IDP Group(s) and view the list of groups

### Create Group(s)

Use the following command to create a new group

```
./rctl create group <group_name>
```

### Create User(s)

Use the following command to create a user for API only access

```
./rctl create user [email protected]
```

Use the following command to create a user for Console access

```
./rctl create user [email protected] --console First_Name,LastName
```

> Note: When creating a user, ensure there are no spaces between the first name and last name. If spaces are included, the system will throw an error.

### Add user to a Group

Use the following command to associate user to a group

```
./rctl create groupassociation <group_name> --associateusers <user>
```

### Assign Role to the Project

To assign a role to a project, ensure a project and a group are created.

Use the following command to assign a base role to the project

```
./rctl create groupassociation <demo_group> --associateproject <demo-project> --roles PROJECT_ADMIN
```

To assign multiple base roles, use the following command

```
./rctl create groupassociation <group_name> --associateproject <project_name> --roles PROJECT_ADMIN,INFRA_ADMIN,INFRA_READ_ONLY
```

To assign custom roles, use the following command

```
./rctl create groupassociation <group_name> --associateproject <project_name> --customroles <role_name>
```

**List of Base Roles**

Here is the list of roles that can be assigned to a user:

- ADMIN
- ADMINISTRATOR_READ_ONLY
- CLUSTER_ADMIN
- CLUSTER_TEMPLATE_USER
- ENVIRONMENT_TEMPLATE_USER
- FINOPS_ADMIN
- INFRA_ADMIN
- INFRA_READ_ONLY
- NAMESPACE_ADMIN
- NAMESPACE_READ_ONLY
- PROJECT_ADMIN
- PROJECT_READ_ONLY
- WORKSPACE_ADMIN
- WORKSPACE_READ_ONLY

### Get Group

Use the following command to get a group details

```
./rctl get groupassociation <group-name>
```

**Example Output**

```
./rctl get groupassociation demo_group
+---------------+---------------------------+
| PROJECT       | ROLES                     |
+---------------+---------------------------+
| demo_group    | ENVIRONMENT_TEMPLATE_USER |
+---------------+---------------------------+
```

### Delete User

To delete a user from a group, use the below command

```
./rctl delete groupassociation <group_name> --dissociateusers <user>
```

---
