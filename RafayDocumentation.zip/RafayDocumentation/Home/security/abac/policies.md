---
title: "ABAC - Policies"
source: https://docs.rafay.co/security/abac/policies/
category: Home
---

# Policies

ABAC **Policies** is a set of rules that determine whether to grant or deny access to specific resources based on the user roles. You can create multiple policy versions and add one or more rules to a policy.

---

## Create Policy

Perform the below steps to create a new policy:

- Login to the console and navigate to **System → Attribute Based Access → Policies**. Policies page appears
- Click **New Policy**

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/policies/policy_menu.png)](https://docs.rafay.co/security/abac/img/policies/policy_menu.png)

- Provide a name for the policy and click **Create**

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/policies/new-policy.png)](https://docs.rafay.co/security/abac/img/policies/new-policy.png)

- Provide a **Version name** and optionally **Description**
- Select the required ABAC [Rules](https://docs.rafay.co/security/abac/rules/) from the drop-down and its version. You can add one or more rules to this policy.

> **Important**
> The system inherently prevents the addition of the same rule multiple times with different versions, ensuring that such duplication is not allowed by default

- Click **Save Changes**

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/policies/add_rules.png)](https://docs.rafay.co/security/abac/img/policies/add_rules.png)

---

## New Version

On successful Policy Creation, the first version of the policy appears. Based on the requirement, users can create multiple versions. To view the details of a specific policy version, click the **eye** icon

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/policies/policy_version.png)](https://docs.rafay.co/security/abac/img/policies/policy_version.png)

---
