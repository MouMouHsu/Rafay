---
title: "ABAC - Rules"
source: https://docs.rafay.co/security/abac/rules/
category: Home
---

# Rules

**Rules** are created for the Attribute-Based Access Control (ABAC) feature to define and enforce access control policies based on various contextual attributes. These rules allows to have fine-grained control over access to resources by considering attributes like user roles and resource properties. It helps to easily customize the access control policies and determine who can access certain resources, under what conditions, and with what level of authorization.

---

## Create Rules

Perform the below steps to create a new rule

- Login to the console and navigate to **System → Attribute Based Access → Rules**. Rules page appears
- Click **New Rule**

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/rules/rule_menu.png)](https://docs.rafay.co/security/abac/img/rules/rule_menu.png)

- Provide a name for the rule and click **Create**.

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/rules/create_rule.png)](https://docs.rafay.co/security/abac/img/rules/create_rule.png)

Rule New Version page appears

- Provide a **Version name** and optionally **Description**
- Select a **Rule Effect**, Allow or Deny. The Rule Effect determines whether the rule permits or denies specific actions on the resource for the users

> **Important**
> Project Selector field is not supported for the release 1.26

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/rules/general_settings.png)](https://docs.rafay.co/security/abac/img/rules/general_settings.png)

- From the drop-down, make selections for both the Cluster Resource and the Resource Type (Amazon EKS, Azure AKS, GCP GKE, Upstream Kubernetes, Imported, and VMWare).

> **Important**
> In Release 1.26, introduced support for Cluster resource. More resources in the pipeline for the upcoming releases

- Select **Operation**. Indicate whether to perform a **Cluster-read** or a **Cluster-write** operation. The selected operation determines the specific action that will be applied to the chosen resources by the rule. On selecting **Cluster-write** operation, **Cluster-read** is selected by default
- The **Resource Filter** allows you to determine the scope of the resources to which the rule applies. You can define this scope based on the resource's name, label (if labeling is supported), or by including all resources within the selected cluster
- Click **Save Changes**

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/rules/resource_settings.png)](https://docs.rafay.co/security/abac/img/rules/resource_settings.png)

---

## New Version

On successful Rule Creation, the first version of the rule appears. Based on the requirement, users can create multiple versions. To view the details of a specific rule version, click the **eye** icon

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/rules/rule_versions.png)](https://docs.rafay.co/security/abac/img/rules/rule_versions.png)

---
