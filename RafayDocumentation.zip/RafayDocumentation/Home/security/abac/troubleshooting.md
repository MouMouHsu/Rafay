---
title: "ABAC - Troubleshooting"
source: https://docs.rafay.co/security/abac/troubleshooting/
category: Home
---

# Common Scenarios

This section outlines the behavior for scenarios where ABAC policies and custom roles have been configured for an user.

---

## Scenario 1: Publish workload in the denied cluster

If a user is assigned a custom role that denies a specific cluster write access and attempt to publish a workload in a cluster, the following error will be encountered.

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/troubleshooting/scenario_1.png)](https://docs.rafay.co/security/abac/img/troubleshooting/scenario_1.png)

---

## Scenario 2: Deploy an application thru ZTKA

If a user is assigned a custom role that denies a cluster write access and attempt to deploy an application thru ZTKA, the following error will be encountered.

[![Remove EKS Cluster](https://docs.rafay.co/security/abac/img/troubleshooting/scenario_2.png)](https://docs.rafay.co/security/abac/img/troubleshooting/scenario_2.png)

---
