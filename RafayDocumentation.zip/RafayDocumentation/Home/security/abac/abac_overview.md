---
title: "KOP ABAC"
source: https://docs.rafay.co/security/abac/abac_overview/
category: Home
---

# Overview

> **Important**
> Limited Access - This capability is enabled selectively for Orgs and is not available to all Prod Orgs.

---

## Overview

Attribute-Based Access Control (ABAC) enhances the existing roles available in the platform to meet the evolving demands of complex systems. ABAC provides a more flexible and dynamic approach to control access by considering a wide range of contextual attributes. This addresses the need for fine-grained access control and enhanced security in organizations.

Only **Org Admin** can configure ABAC rules, policies, and custom roles.

---

## Implementing Attribute-Based Access Control (ABAC)

The Attribute-Based Access Control (ABAC) implementation involves the following three steps:

- **Step 1 - [Create Rules](https://docs.rafay.co/security/abac/rules/)**: In ABAC, rules are formulated based on attributes associated with the projects, resources, and resource types. By creating rules, you define whether a specific action should be allowed or denied
- **Step 2 - [Create Policies](https://docs.rafay.co/security/abac/policies/)**: Policies is a collection of one or more rules that is referenced as part of creation of Custom Roles
- **Step 3 - [Custom Roles](https://docs.rafay.co/security/rbac/custom_roles/)**: A Custom Role configuration includes selection of a base role along with the necessary overlay ABAC policies

---

## ABAC Sequences

The sequence diagram below captures the high level steps to create an ABAC Rules, Policies, and Custom Roles

### Step 1: ABAC Roles

```
sequenceDiagram
    Note over Login to Console: Only Org Admin
    Login to Console->>Navigate to ABAC Rules: From System menu
    Navigate to ABAC Rules->>Add Rules: Create new rule version
    Add Rules->>Save Changes: Settings: General, Project Selector, and Resource
    Note over Add Rules: Mandatory: Version, Resources, and Resource Type
    Save Changes->>New Version: Edit to add multiple versions
```

### Step 2: ABAC Policies

```
sequenceDiagram
    Navigate to ABAC Policies->>Add Policy: Create new policy version
    Add Policy->>Save Changes: Settings: General and ABAC Policy Rules
    Note over Add Policy: Mandatory: Version, Rule and its versions
    Save Changes->>New Version: Edit to add multiple versions
```

### Step 3: ABAC Custom Roles

```
sequenceDiagram
    Navigate to ABAC Custom Roles->>Add Role: Create new role
    Add Role->>Save Changes: Settings: General, Base Role, and ABAC Policies
    Note over Add Role: Mandatory: Name, Base Role Selection, Policies and its versions
```

---
