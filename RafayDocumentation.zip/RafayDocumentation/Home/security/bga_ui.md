---
title: "Product Security - Break Glass Access"
source: https://docs.rafay.co/security/bga_ui/
category: Home
---

# UI

## Break Glass Access Configuration

Navigate to System -> Break Glass Access. "Local Access" Page appears by default

- Click on the **Local Access** button. A pop-up titled "Select Local User" appears, displaying a list of available local users.
- Type the username in the search bar or scroll through the list to find the desired user and select the required user
- Once the desired user is selected, click **Continue**

[![Audit Logs Console](https://docs.rafay.co/security/img/local_users.png)](https://docs.rafay.co/security/img/local_users.png)

After selecting the user, the "Break Glass Groups" screen will be displayed

- Click on the **Add Group** button to assign a group to the selected user. If no groups are currently assigned, a message stating "No Groups Assigned" will be displayed
- In the "Add Expiry Group" screen, select the Group from the drop-down and define the start date/time and expiry (in hours) for the assigned group. These settings will determine the duration of access for the selected user

[![Audit Logs Console](https://docs.rafay.co/security/img/breakglass_group.png)](https://docs.rafay.co/security/img/breakglass_group.png)

- Click **Save** to finalize the changes

Once users are added to a group, the newly added group will be visible as shown below. Users can then perform operations on the resources defined for this specific group for the specified time duration. Org Admins can edit or delete this access using the appropriate icons.

[![Audit Logs Console](https://docs.rafay.co/security/img/groups_list.png)](https://docs.rafay.co/security/img/groups_list.png)

> Note:
> - A user can be added to one or more groups based on access requirements
> - Break Glass Access can be configured for a user who is both a local and SSO user

Similar to local users, Break Glass Access can also be configured for IDP users.

[![Audit Logs Console](https://docs.rafay.co/security/img/idp_user.png)](https://docs.rafay.co/security/img/idp_user.png)

---

## Access Audit

The **Access Audits** page for Break Glass Access is designed to provide visibility into all actions and events related to break glass access within an organization. It serves as a centralized log where administrators can monitor activities such as updates to access groups or changes performed by users. This level of monitoring helps in quickly identifying any unauthorized or unexpected access, ensuring that only permitted actions are carried out.

- The ***CLEAR FILTERS***, ***REFRESH***, and ***EXPORT*** options on the Access Audits page help users manage and analyze audit logs efficiently. CLEAR FILTERS resets all filters to default, showing the full list of logs. REFRESH updates the logs to display the most recent events, ensuring data is current. EXPORT allows users to download logs in ***.csv*** for reporting, compliance, or further analysis. These features streamline the process of reviewing and managing audit data.
- The filters on the Access Audits page help users narrow down the audit logs to focus on specific events. The ***Type*** filter allows users to select logs based on different event types, such as updates or deletions. The ***User*** filter lets users view logs associated with specific individuals, while the ***Client*** filter shows logs based on the type of client used, such as a web browser. The ***Time Range*** filter allows users to specify a period to view relevant logs. Additionally, the Search Box provides a quick way to find specific entries using keywords. These filters make it easy to locate and analyze relevant audit data efficiently.

[![Audit Logs Console](https://docs.rafay.co/security/img/bga_audit.png)](https://docs.rafay.co/security/img/bga_audit.png)

---
