---
title: "Product Security - Access Reports"
source: https://docs.rafay.co/security/access_reports_overview/
category: Home
---

# Overview

## Overview

It may be a requirement in organizations that reports that detail user access be generated on an ongoing basis and shared with auditors. Access Reports makes it extremely easy to generate such reports either on-demand or on schedule. Reports can be downloaded in csv or json format.

[![Audit Logs Console](https://docs.rafay.co/security/img/audit/access_report.png)](https://docs.rafay.co/security/img/audit/access_report.png)

## Roles

**Org Admin** and **Auditor** roles are needed to generate/download user access reports. In addition to user access reports, the Auditor role also allowing viewing/downloading Audit Logs.

## Interfaces

> **Did you know ?**
> Reports can be generated through the UI or through other interfaces such as RCTL/APIs.
>
> - [UI](https://docs.rafay.co/security/ar_ui/)
> - [CLI](https://docs.rafay.co/security/ar_cli/)
> - [API](https://docs.rafay.co/automation/api/apis/)

## Audit Logs

To track actions performed on access reports, such as generating, scheduling, or downloading a report, navigate to [Audit Logs](https://docs.rafay.co/security/audit/) page. Below is an example showing both successful report generation and download logs.

[![Audit Logs Console](https://docs.rafay.co/security/img/audit/audit_logs.png)](https://docs.rafay.co/security/img/audit/audit_logs.png)

## Retention policy - Reports

If the number of reports exceeds 10, older reports will be automatically deleted. Additionally, reports that are older than one year will also be automatically deleted.

> **Note**
> If there are 1000s of users with namespace admin role privileges, generation of reports may take a few seconds.

---
