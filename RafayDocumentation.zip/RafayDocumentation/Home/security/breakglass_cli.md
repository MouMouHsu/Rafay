---
title: "KOP Break Glass Access - CLI"
source: https://docs.rafay.co/security/breakglass_cli/
category: Home
---

# CLI

Users can use RCTL to create, list, update and delete Break Glass Access

## Create Break Glass Access

Use the following command to create a Break Glass Access

```
./rctl create bga -f <test.yaml>
```

Below is an example configuration spec for Break Glass Access

```
apiVersion: system.k8smgmt.io/v3
kind: BreakGlassAccess
metadata:
  name: [email protected]
spec:
  groups:
    - groupExpiry:
        - expiry: 11
          name: grp3
        - expiry: 11
          name: grp1
          startTime: "2024-08-20T08:00:00Z"
      userType: local
    - groupExpiry:
        - expiry: 11
          name: grp2
        - expiry: 11
          name: grp1
          startTime: "2024-08-20T08:00:00Z"
      userType: sso
```

---

## Get Break Glass Access Details

Once the Break Glass Access has been created, use this command to retrieve details about the access.

```
./rctl get breakglassaccess
```

(or)

```
./rctl get bga
```

Below is an example of the list of all Break Glass Access:

```
./rctl get bga
+-------------------------------+--------------------------+--------------------------------+--------------------+
| USERNAME                      | ACTIVE GROUPS            | EXPIRED GROUPS                 | SCHEDULED GROUPS   |
+-------------------------------+--------------------------+--------------------------------+--------------------+
| [email protected]         | sso: (grp1)              |                                |                    |
+-------------------------------+--------------------------+--------------------------------+--------------------+
| [email protected] | local: (All Local Users) |                                |                    |
+-------------------------------+--------------------------+--------------------------------+--------------------+
| [email protected]         |                          | local: (Organization Read      |                    |
|                               |                          | Only)                          |                    |
+-------------------------------+--------------------------+--------------------------------+--------------------+
| [email protected]             |                          |                                | local: (grp1)      |
+-------------------------------+--------------------------+--------------------------------+--------------------+
| [email protected]         |                          | sso: (grpr4,Organization       |                    |
|                               |                          | FinOps Admin)                  |                    |
+-------------------------------+--------------------------+--------------------------------+--------------------+
```

Below is an example of Break Glass Access for a specific user:

```
./rctl get bga [email protected]
+-------------------------------+--------------------------+--------------------------------+--------------------+
| USERNAME                      | ACTIVE GROUPS            | EXPIRED GROUPS                 | SCHEDULED GROUPS   |
+-------------------------------+--------------------------+--------------------------------+--------------------+
| [email protected]          | sso: (grp1)              |                                |                    |
+-------------------------------+--------------------------+--------------------------------+--------------------+
```

Below is an example where a user is both a local and SSO user, and has Break Glass Access configured for both types:

```
./rctl get bga [email protected]
+-------------------------------+--------------------------+--------------------------------+--------------------+
| USERNAME                      | ACTIVE GROUPS            | EXPIRED GROUPS                 | SCHEDULED GROUPS   |
+-------------------------------+--------------------------+--------------------------------+--------------------+
| [email protected]          | local: (grp2)            | local: (grp1)                  | sso: (grp3)        |
|                               | sso: (grpr4)             |                                |                    |
+-------------------------------+--------------------------+--------------------------------+--------------------+
```

---

## Update Break Glass Access

Use any of the below commands to update an existing Break Glass Access

```
./rctl create bga -f file.yaml
```

(or)

```
./rctl update bga -f file.yaml
```

(or)

```
./rctl apply -f file.yaml
```

---

## Delete Break Glass Access

Use the following command to delete Break Glass Access for a specific user in a group

```
./rctl delete bga <usernamename>
```

---
