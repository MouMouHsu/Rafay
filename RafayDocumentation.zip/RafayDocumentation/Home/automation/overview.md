---
title: "Automation Options in Rafay Platform"
source: https://docs.rafay.co/automation/overview/
category: Home
---

# Supported Options for Automation

- **CLI**   Use Rafay's RCTL CLI with declarative resource specifications for turnkey automation  [Learn More](https://docs.rafay.co/cli/overview/)
- **Terraform/OpenTofu Provider**   Use Rafay's Terraform/OpenTofu Provider to automate using the Infrastructure as Code (IaC) pattern  [Learn More](https://docs.rafay.co/automation/tf/overview/)
- **GitOps**   Use Git as the single source of truth for infrastructure and application definitions  [Learn More](https://docs.rafay.co/gitops/overview/)
- **MCP**   Connect AI agents and LLMs to the platform using the Model Context Protocol (MCP) for natural-language automation  [Learn More](https://docs.rafay.co/mcp/mcp_platform/) [Skills](https://docs.rafay.co/mcp/rafay-skills/)
- **APIs**   Automate using Swagger based REST APIs using your preferred programming language  [Learn More](https://docs.rafay.co/automation/api/apis/)

---
