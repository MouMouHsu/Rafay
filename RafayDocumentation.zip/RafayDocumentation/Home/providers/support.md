---
title: "Remote Tech Support"
source: https://docs.rafay.co/providers/support/
category: Home
---

# Support

Rafay’s customer success team and our partner’s support teams are available to provide remote technical support to end customers upon request.

Every customer gets an account (aka. Rafay Org). By default, users external to a [customer’s account](https://docs.rafay.co/security/rbac/orgs/) (esp. MSPs and Rafay admins) **do not** have any form of access. For remote support purposes, customers’ administrators can provide “temporary access” to identified external users (i.e. email address) to their account for help with configuration updates etc. The level of access that the remote support person will have will depend on the **[role](https://docs.rafay.co/security/rbac/roles/)** assigned to them.

> **Note**
> Role assignments can be done either per user or at a group level.

Remote support personnel can be invited into multiple accounts at the same time. Remote support users can [seamlessly switch](https://docs.rafay.co/security/rbac/orgs/#switch-between-orgs) between the customer accounts they are supporting at any given time, enabling them to support multiple customers without having to resort to multiple credentials.

---

## Support Hierarchy

Customers utilizing the Rafay platform can request technical support in one of two ways:

1. By signing up directly with Rafay (Rafay SaaS Customer a.k.a. RSC)
2. By signing up with a Rafay partner who is delivering Rafay’s capabilities as a service (Rafay Partner’s Customer a.k.a. RPC)

[![Hierarchy](https://docs.rafay.co/providers/img/support/support-hierarchy.png)](https://docs.rafay.co/providers/img/support/support-hierarchy.png)

---

## How Rafay SaaS Customers Receive Remote Support

When remote support is needed, Rafay SaaS Customers (RSCs) can enable short-term access for Rafay personnel to log into their account for help with configuration updates, troubleshooting etc. Once the activity is completed, RSCs can disable access for Rafay personnel. More details on how to add/activate/delete are in the Recommended Best Practices section below.

### Recommended Best Practices

As a general best practice, customers are recommended that they create a **[group](https://docs.rafay.co/security/rbac/groups/)** for remote support (e.g. called remote-support-readonly) and assign a suitable **read only** role to this group. This approach:

- Provides the convenience of adding/removing specific support personnel to this group.
- Streamlines the administrative workflows to a point where admins can avoid configuration errors.

### Centralized Audit Logs

All actions performed by the administrators (i.e. add/remove remote support users) and the actions performed by the remote support users in the account are logged in the centralized audit logging system.

[![Audit Logs](https://docs.rafay.co/providers/img/support/support-audit.png)](https://docs.rafay.co/providers/img/support/support-audit.png)

---

## Onboarding Remote Support

To add a new remote support user, follow the steps below:

### Rafay SaaS Customers

- Create a new user for Rafay’s customer success team members to temporarily access your account as needed (e.g. [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#e78f828b97a7958681869ec98488)).

[![Add User](https://docs.rafay.co/providers/img/support/remotesupport-user.png)](https://docs.rafay.co/providers/img/support/remotesupport-user.png)

- Add the user to the support group (e.g. remote-support-readonly)

[![User to Group](https://docs.rafay.co/providers/img/support/remotesupport-user.png)](https://docs.rafay.co/providers/img/support/remotesupport-user.png)

> **Note**
> Please connect with your Rafay CS point of contact for the correct support user details.

### For Rafay Partner Customers

Create two new users in your account and add the users to the support group (e.g. remote-support-readonly)

1. For the Partner’s support team to temporarily access your account as needed (e.g. [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#59313c35291929382b2d373c2b68773a3634)). Please connect with your Partner’s support point of contact for the correct support user alias.
2. For Rafay’s customer success team members to temporarily access your account as needed (e.g. [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#fc9499908cbc8e9d9a9d85d29f93)). Please connect with your Rafay CS point of contact for the correct support user alias.

Once completed, the user will be authorized to access the account remotely.

---

## Off-boarding Remote Support

Once the support session is complete, the admin has three options.

### Option 1: Remove the User

Once the user is removed from the account, they will no longer be able to access anything in the account. This option is suitable for scenarios where the admin believes there is no need for continued access/support.

- Navigate to System -> Users
- Search for the user’s email address or name (e.g. [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#b8d0ddd4c8f8cad9ded9c196dbd7))
- Click on delete to remove the user from the account

[![Delete User](https://docs.rafay.co/providers/img/support/user-delete.png)](https://docs.rafay.co/providers/img/support/user-delete.png)

### Option 2: Deactivate the User

Once the user is deactivated in the account, they can no longer access the customer’s account until they are **reactivated** by an administrator. This approach is well suited for scenarios where the administrator expects the remote support user to require **ongoing access** to their account for extended support.

[![Deactivate User](https://docs.rafay.co/providers/img/support/user-deactivate.png)](https://docs.rafay.co/providers/img/support/user-deactivate.png)

### Option 3: Remove User from Support Group

Once the user has been removed from the support group, they will not have any role assignments in the customer’s account. This means they will not have access to anything in the account. This approach is also well suited for scenarios where the administrator expects the remote support user to require ongoing access to their account for extended support.

[![Remove User from Group](https://docs.rafay.co/providers/img/support/user-remove-group.png)](https://docs.rafay.co/providers/img/support/user-remove-group.png)

---

## Temporary Access Policy

> **Note**
> This feature is in early access and will roll out to all customers in Sep 2024.

Administrators can provide remote users with a timed access policy. With this approach, the administrator specifies the **start time** for access and the expiry time. Once access has expired, the user’s access privileges are automatically removed from the account. This capability automates the full lifecycle of onboarding and off-boarding the user’s access. This provides customers the benefit of automating administrative tasks that are otherwise manual and error prone.

[![Temp Access Policy](https://docs.rafay.co/providers/img/support/temp-access.png)](https://docs.rafay.co/providers/img/support/temp-access.png)

---
