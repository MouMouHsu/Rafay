---
title: "Rafay Kubernetes Management"
source: https://docs.rafay.co/services/overview/
category: Home
---

# Rafay Kubernetes Management Services

- **MCP Server**   Connect any MCP-compatible AI assistant to the Rafay platform. Query clusters, pods, namespaces, workloads, and more using plain English with real-time responses.  [**Docs**](https://docs.rafay.co/mcp/mcp_platform/)
- **Cluster Blueprints**   Centralized configuration with software add-ons and governance policies. Enforce continuous reconciliation with drift detection policies.  [**Overview**](https://docs.rafay.co/blueprints/overview/) | [**Docs**](https://docs.rafay.co/blueprints/addons/) | [**Get Started**](https://docs.rafay.co/learn/quickstart/blueprint/blueprintlifecycle/overview/)
- **Backup and Restore**   Securely backup your Kubernetes resources and volumes to protect against infrastructure loss, data corruption, and/or service outages.  [**Overview**](https://docs.rafay.co/backup/overview/) | [**Docs**](https://docs.rafay.co/backup/considerations/)
- **Catalog - System and Custom**   Create and curate custom app catalogs to meet the needs of various teams within the organization.  [**Overview**](https://docs.rafay.co/catalog/catalog_overview/) | [**Docs**](https://docs.rafay.co/catalog/manage_catalog/)
- **Monitoring & Visibility**   Automatically aggregate and visualize critical metrics from clusters operating in different regions, cloud providers, datacenters and edge locations.  [**Overview**](https://docs.rafay.co/dashboard/overview/) | [**Docs**](https://docs.rafay.co/dashboard/cluster/)
- **Cost Management**   Consolidated fine-grained visibility and reporting of all your Kubernetes clusters. Automate showback and chargeback workflows.  [**Overview**](https://docs.rafay.co/cost_management/overview/) | [**Docs**](https://docs.rafay.co/cost_management/pre-requisites/) | [**Get Started**](https://docs.rafay.co/learn/quickstart/cost_management/overview/)
- **Network Policy Manager**   Comply with security and compliance requirements for isolation and network access esp. in shared clusters. Prevent lateral movement and reduce attack surface.  [**Overview**](https://docs.rafay.co/network_policy/overview/) | [**Docs**](https://docs.rafay.co/network_policy/introduction/)
- **Policy Management**   Centrally enforce OPA Gatekeeper policies. Aggregate and view policy metrics, violations and audits in a central dashboard.  [**Overview**](https://docs.rafay.co/policy/opa_gatekeeper/overview/) | [**Docs**](https://docs.rafay.co/policy/opa_gatekeeper/installation_profiles/)
- **Secrets Management**   Secure application secrets and automate lifecycle management and delivery via turnkey integrations with HashiCorp Vault, AWS Secrets Manager and Sealed Secrets  [**Overview**](https://docs.rafay.co/integrations/secrets/overview/) | [**Docs**](https://docs.rafay.co/integrations/secrets/awssecretmgr_serviceaccount/)
- **Workloads and GitOps**   Develop and operate multi-stage pipelines for both infrastructure orchestration and application deployments through pull requests in configured Git repositories.  [**Overview**](https://docs.rafay.co/gitops/overview/) | [**Docs**](https://docs.rafay.co/gitops/benefits/) | [**Get Started**](https://docs.rafay.co/learn/quickstart/applications/workloads/overview/)
- **Zero-Trust Kube API/Kubectl**   Controlled, audited, secure access for developers, SREs and automation systems to your clusters, with just-in-time service account creation.  [**Overview**](https://docs.rafay.co/accessproxy/overview/) | [**Docs**](https://docs.rafay.co/accessproxy/architecture/) | [**Get Started**](https://docs.rafay.co/learn/quickstart/ztka/overview/)

---
