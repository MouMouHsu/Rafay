---
title: "KOP GKE Clusters - Supported Versions"
source: https://docs.rafay.co/clusters/gke/environments/
category: Home
---

# Supported Environments

Please review the information listed below to understand the supported versions.

---

## Operating Systems

Here is the list of supported operating systems for the nodes.

- Container-Optimized OS with containerd
- Container-Optimized OS with Docker
- Ubuntu with containerd
- Windows Server Long Term Servicing Channel with containerd
- Windows Server Long Term Servicing Channel with Docker

> **Important**
> In GKE version 1.24 and later, Docker-based node image types are not supported

---

### New Clusters

New GKE clusters can be provisioned using the following Kubernetes versions.

> **Important**
> Versions identified as deprecated will transition to not supported imminently. Customers are strongly recommended to upgrade their clusters to a supported version to ensure they continue to receive patches and security updates.

| Kubernetes Version | Official EOL Date | 'New Cluster' support added with Controller release version | 'In-place upgrade' support added with Controller release version |
| --- | --- | --- | --- |
| v1.35.x | Apr-2027 | v4.2 | v4.2 |
| v1.34.x | Aug-2026 | v4.1 | v4.1 |
| v1.33.x | Jun-2026 | v3.6 | v3.6 |
| v1.32.x | Apr-2026 | v3.5 | v3.5 |
| v1.31.x (EOL) | Jan-2026 | v3.3 | v3.3 |
| v1.29.x (EOL) | Mar-2025 | v2.6 | v2.6 |
| v1.28.x (EOL) | Nov-2024 | v2.3 | v2.3 |
| v1.27.x (EOL) | Aug-2024 | v2.0 | v2.1 |
| v1.26.x (EOL) | May 2024 | v1.26 | v1.26 |
| v1.25.x (EOL) | Feb 2024 | v1.26 | v1.26 |
| v1.24.x (EOL) | Oct 2023 | v1.20 | v1.20 |

Explore our blog for deeper insights on **GKE v1.28 Cluster using Rafay**, available [here](https://docs.rafay.co/blog/2024/01/17/google-gke-v128-clusters-using-rafay/)!

---
