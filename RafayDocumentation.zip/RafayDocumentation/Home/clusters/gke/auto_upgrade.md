---
title: "KOP GKE Clusters - Auto Upgrade"
source: https://docs.rafay.co/clusters/gke/auto_upgrade/
category: Home
---

# Auto Upgrade Clusters

## GKE Control Plane Auto-Upgrade Handling

Google Kubernetes Engine (GKE) now automatically upgrades control planes even for clusters that are not enrolled in a release channel (“no-channel” mode). When GKE performs an automatic upgrade, the mismatch between the actual control plane version and the desired version defined in the cluster configuration triggered repeated reconciliation attempts by the controller.

To address this issue, the following options are provided for managing GKE control plane versions:

- The controller no longer attempts to downgrade the control plane if GKE has upgraded it to a newer version.
- The **Configuration** tab displays both the **Desired Control Plane Version** and the **GKE Control Plane Version**, with the last synchronized timestamp shown for reference.
- A **SYNC VERSION** button is available next to the desired version, allowing the desired version to be updated to match the actual GKE version without triggering a redeployment. Only by using this **SYNC VERSION** button will the cluster configuration be updated to reflect the actual version.
- The control plane upgrade wizard is updated to consider the actual GKE version as the baseline, displaying only versions higher than the current GKE version as upgrade targets.

[![Cluster Configuration](https://docs.rafay.co/clusters/gke/img/gkesync_version.png)](https://docs.rafay.co/clusters/gke/img/gkesync_version.png)

The above image shows the cluster configuration screen, where the desired control plane version is displayed as `1.31` and the actual GKE control plane version is `1.32.2`. The **SYNC VERSION** button is visible, allowing the desired version to be updated to match the actual version without triggering a redeployment. The last synchronized timestamp for the actual GKE version is also shown for reference.

- The **SYNC VERSION** button will no longer appear once the desired and actual versions are in sync.

[![Cluster Configuration](https://docs.rafay.co/clusters/gke/img/synced_vers.png)](https://docs.rafay.co/clusters/gke/img/synced_vers.png)

> ⚠️ Important
> - For YAML-based clusters, synchronization can be performed by manually updating the cluster specification to reflect the current control plane version.
> - For existing clusters, update the control plane version in the cluster configuration to match the version upgraded by GKE.

### Control Plane Endpoint

Click **View** in the **Control Plane Endpoint** field to view the control plane host IP address and port for the GKE cluster.

For private clusters, the host is an internal IP address (for example, `172.x.x.x`). For public clusters, the host is a public IP address (for example, `34.x.x.x.x`).

If the cluster is unhealthy or temporarily unreachable, the control plane endpoint is displayed as **NA**.

[![Cluster Configuration](https://docs.rafay.co/clusters/gke/img/cpe_button.png)](https://docs.rafay.co/clusters/gke/img/cpe_button.png)

---
