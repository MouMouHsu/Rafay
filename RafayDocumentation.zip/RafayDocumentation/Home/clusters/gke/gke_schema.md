---
title: "V2 API Config Schema"
source: https://docs.rafay.co/clusters/gke/gke_schema/
category: Home
---

# GKE Schema

Cluster configuration for GKE clusters
