---
title: "KOP GCP GKE Clusters - Credentials"
source: https://docs.rafay.co/clusters/gke/credentials/
category: Home
---

# Credentials for GCP GKE

You can fully automate the provisioning and ongoing lifecycle management of GKE clusters in all supported Google Cloud regions.

You can have a GKE cluster operational in just a few simple steps. To do this, you need to provide credentials to GCP that will provide the controller with programmatic access using GCP's APIs.

---

### Create Cloud Credential

- Login to the Web Console and select **Cloud Credentials** under Infrastructure
- Click **New Credential** and provide a unique name
- Select the Type **Cluster Provisioning** and Provider **GCP**
- Click **Credentials File** and upload the json credentials file from your system. - Click **Save**

[![Create Cloud Credential](https://docs.rafay.co/clusters/gke/img/cred_gcp.png)](https://docs.rafay.co/clusters/gke/img/cred_gcp.png)

> **Important**
> Refer [GCP Cloud Credential Setup](https://docs.rafay.co/clusters/gke/gcp_setup/) to learn how to get the credential JSON file from the GCP console.

On successful creation, you can view the details of the newly created "cloud credential". An example is shown below.

[![Create Cloud Credential](https://docs.rafay.co/clusters/gke/img/cred_listed.png)](https://docs.rafay.co/clusters/gke/img/cred_listed.png)

---

### View Credentials

Navigate to the "Cluster->Configuration" tab to view the "cloud credential" currently being used by the cluster.

[![View Cloud Credential](https://docs.rafay.co/clusters/gke/img/existing_credential.png)](https://docs.rafay.co/clusters/gke/img/existing_credential.png)

---

## Share Credentials

Organizations can create and use "unique" cloud credentials per project. This approach can be useful if different cloud provider accounts need to be used in every project. This helps with "billing" and "isolation".

However, this approach may not be practical for scenarios where the organization's security policies may require "centralization" of cloud credentials. For scenarios like this, organizations can "share" their cloud credentials with "select" or "all projects".

- Click on the "share" menu option
- Select the projects you would like to share the cloud credential with

[![Share Cloud Credential](https://docs.rafay.co/clusters/gke/img/share_credential.png)](https://docs.rafay.co/clusters/gke/img/share_credential.png)

The downstream projects that "inherit" the shared cloud credential can view and use the inherited cloud credentials. But, they are not allowed to edit/delete them.

[![Inherited Cloud Credential](https://docs.rafay.co/clusters/gke/img/credential_inherited.png)](https://docs.rafay.co/clusters/gke/img/credential_inherited.png)

---
