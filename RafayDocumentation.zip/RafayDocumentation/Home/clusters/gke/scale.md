---
title: "KOP GKE Clusters - Scale Nodes"
source: https://docs.rafay.co/clusters/gke/scale/
category: Home
---

# Scale Nodes

Scaling nodes is changing the number of nodes within a cluster. You can scale the number of nodes up or down, depending on your needs.

1. In the Console, select the project with the cluster you want to scale nodes on
2. Select the cluster
3. Click on the **Node Pools** tab
4. Click the scale button on the existing node pool
5. Enter the desired number of nodes

[![Number of Nodes](https://docs.rafay.co/clusters/gke/img/scale_cluster1.png)](https://docs.rafay.co/clusters/gke/img/scale_cluster1.png)

1. Click **Save**

The scale operations displays in the console. This can take a few minutes.

[![Number of Nodes](https://docs.rafay.co/clusters/gke/img/scaling_in_progress.png)](https://docs.rafay.co/clusters/gke/img/scaling_in_progress.png)

---

## Add Node Pool

1. In the Console, select the project with the cluster you want to add a node pool to
2. Select the cluster
3. Click on the **Node Pools** tab
4. Click **Add Node Pool**
5. Enter a name for the node pool
6. Select the **Node K8s Version** that matches the existing node pool
7. Enter the desired number of nodes for this node pool and provide the required details. Refer [Node Pool settings](https://docs.rafay.co/clusters/gke/provisioning/#nodepools) for more details
8. Click **Save**

[![Add Node Pool](https://docs.rafay.co/clusters/gke/img/add_nodepool.png)](https://docs.rafay.co/clusters/gke/img/add_nodepool.png)

---

## Remove Node Pool

1. In the Console, select the project with the cluster you want to remove a node pool from.
2. Select the cluster.
3. Click on the **Node Pools** tab.
4. Click the delete button for the node pool you want to delete.
5. Click **Yes** to confirm the node pool deletion.

---
