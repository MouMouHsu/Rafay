---
title: "KOP GKE Clusters - Overview"
source: https://docs.rafay.co/clusters/gke/overview/
category: Home
---

# Overview

[Google's Kubernetes Engine (GKE)](https://cloud.google.com/kubernetes-engine) is a fully managed Kubernetes service provided by [Google Cloud](https://cloud.google.com/).

Users can use the controller to **provision** and **operate** GKE clusters on GCP.

---

## GKE Lifecycle Management

Users can leverage the controller's native integration with GCP to

- Provision and manage the lifecycle of GKE Clusters in all supported GCP regions.
- Create and maintain version controlled, declarative cluster specifications in their Git Repositories
- Use declarative, cluster specifications to provision GKE clusters in minutes with a high level of automation.

[![Architecture](https://docs.rafay.co/clusters/gke/img/highlevel_architecture.png)](https://docs.rafay.co/clusters/gke/img/highlevel_architecture.png)

> **Did you know ?**
> GKE Cluster Lifecycle can be managed through various methods:
>
> - [UI](https://docs.rafay.co/clusters/gke/provisioning/)
> - [CLI](https://docs.rafay.co/clusters/gke/cli/)
> - [GitOps](https://docs.rafay.co/gitops/stages/system_sync/)
> - [API](https://docs.rafay.co/automation/api/apis/)
> - [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/gke_cluster)

## Automation Options

The below matrix presents a breakdown of actions like creation, updating, deletion, publish/unpublish Kubernetes Namespaces across multiple deployment methods: Interactive UI, Declarative RCTL commands, API-driven automation, and Terraform.

| Resources | Deployment Type | Create | Upgrade/Scale | Delete |
| --- | --- | --- | --- | --- |
| Cluster | UI | [Yes](https://docs.rafay.co/clusters/gke/provisioning/#create-cluster) | [Yes](https://docs.rafay.co/clusters/gke/upgrade/#upgrade-steps) | [Yes](https://docs.rafay.co/clusters/gke/deprovision/) |
|  | CLI | [Yes](https://docs.rafay.co/clusters/gke/cli/#create-cluster-via-rctl) | [Yes](https://docs.rafay.co/clusters/gke/cli/#create-cluster-via-rctl) | [Yes](https://docs.rafay.co/clusters/gke/cli/#delete-cluster) |
|  | API Automation | No | No | No |
|  | Terraform | No | No | No |
|  | GitOps | [Yes](https://docs.rafay.co/gitops/stages/system_sync/) | [Yes](https://docs.rafay.co/gitops/stages/system_sync/) | [Yes](https://docs.rafay.co/gitops/stages/system_sync/) |
| Node pool | UI | [Yes](https://docs.rafay.co/clusters/gke/scale/#add-node-pool) | [Yes](https://docs.rafay.co/clusters/gke/day-2-ops/) | [Yes](https://docs.rafay.co/clusters/gke/scale/#remove-node-pool) |
|  | CLI | [Yes](https://docs.rafay.co/clusters/gke/cli/#node-pool-management) | [Yes](https://docs.rafay.co/clusters/gke/cli/#node-pool-management) | [Yes](https://docs.rafay.co/clusters/gke/cli/#node-pool-management) |
|  | API Automation | No | No | No |
|  | Terraform | No | No | No |

> **Important**
> Users that use an alternate approach for GKE cluster provisioning such as Terraform etc can **import** these clusters for visibility, monitoring and workload operations.

## Getting Started

We have quick start exercise to explore the platform's capabilities for "Lifecycle Management" of GKE Cluster.

[Step by Step Guide](https://docs.rafay.co/learn/quickstart/gke/clusterlifecycle/overview/)

---
