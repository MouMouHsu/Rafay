---
title: "KOP GKE Clusters -Day-2 Operations Support"
source: https://docs.rafay.co/clusters/gke/day-2-ops/
category: Home
---

# Day-2 Operations

## Day-2 Operations Support

Users are allowed to perform only the below operations on **Day 2**

## Supported Day-2 Operations

**Cluster**

- Upgrade Kubernetes version
- Update Blueprint and Blueprint version
- Update Cluster Labels
- Update Resource Labels at Cluster and Node Level
- Update CAPI (capiVersion) / CAPG (capgVersion) controller versions

**Node Pools**

- Add, scale, and delete node pools
- Upgrade node pool Kubernetes version
- Downgrade node pool Kubernetes version (RCTL and API only)
- Enable or disable node pool auto-upgrade
- Update node pool upgrade strategy
- Update node pool upgrade settings

**Storage & Networking**

- Enable or disable Compute Engine Persistent Disk CSI Driver
- Enable or disable GCP Filestore CSI Driver Add-on
- Enable or disable GCS Fuse CSI Driver
- Enable or disable HTTP Load Balancing
- Enable or disable Horizontal Pod Autoscaling
- Enable or disable Private Nodes

**Observability**

- Enable or disable Cloud Logging
- Enable or disable Cloud Monitoring
- Enable or disable Managed Service for Prometheus

**Add-ons & Security**

- Enable or disable Application Manager Beta Add-on
- Enable or disable Backup for GKE Add-on
- Enable or disable Image Streaming
- Enable or disable Legacy Authorization
- Enable or disable Google Groups for RBAC
- Enable or disable Workload Identity

## Limitation

- When updating the node pool upgrade strategy, it is not possible to reduce the batch soak duration and node pool soak duration to zero '0' on day 2
- Disabling auto-upgrade is only possible once the node pool version in the configuration matches the actual version
- When auto-upgrade is enabled, downgrading the node pool is not allowed
- CAPI and CAPG versions cannot be updated together in the same apply, only one of `capiVersion` or `capgVersion` per change
- When the target CAPG version requires a newer CAPI API contract (e.g. `v1beta2`), `capiVersion` must be updated first

---
