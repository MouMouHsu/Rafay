---
title: "KOP GKE Clusters - Reservation Affinity"
source: https://docs.rafay.co/clusters/gke/reserve_affin/
category: Home
---

# Reservation Affinity

Users who desire to reserve virtual machine (VM) capacity specifically for Google Kubernetes Engine (GKE) clusters can utilize the Reservation Affinity settings. Reservation Affinity can be managed via UI, [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/gke_cluster), and the [V3 Swagger API](https://docs.rafay.co/clusters/gke/api/).

Reservations for Compute Engine zonal resources offer assurance of resource availability, with quick VM startup, immediate resource access upon reservation creation, and cost-effective utilization, charging at on-demand rates and preventing others from using reserved resources.

- Users are allowed to select the Reservation Type based on the requirement    Important Reservations available within the same cloud project can only be utilized  [![General Settings](https://docs.rafay.co/clusters/gke/img/reserve_affin.png)](https://docs.rafay.co/clusters/gke/img/reserve_affin.png)  When using a shared reservation, i.e., a capacity reservation generated within one project in the Google Cloud Platform and then shared with another project, the format **projects/OWNER_PROJECT_ID/reservations/RESERVATION_NAME** should be used. Here, the **OWNER_PROJECT_ID** and **RESERVATION_NAME** from the Google Cloud reservation page should be provided, while **projects** and **reservations** remain static.  Here's an example showcasing the shared reservation:  [![General Settings](https://docs.rafay.co/clusters/gke/img/shared_affin.png)](https://docs.rafay.co/clusters/gke/img/shared_affin.png)
  - **None:** Indicates not to use any reserved capacity
  - **Any:** Indicates to use any available reservation that exactly matches the Zone (selected in General settings) and Machine type (selected in Configure node settings)
  - **Specific:** Indicates to use a designated reservation. When selecting this option, provide the name of the reservation created in the Google Cloud console

---
