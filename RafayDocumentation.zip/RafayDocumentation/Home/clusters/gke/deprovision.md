---
title: "KOP GKE Clusters - Deprovision"
source: https://docs.rafay.co/clusters/gke/deprovision/
category: Home
---

# Deprovision

## Remove GKE Cluster

To deprovision a provisioned GKE cluster, perform the below steps:

- Click on Settings icon on the far right of the cluster and select **Delete**
- Select **Delete Cluster Completely** to delete cluster object from Rafay controller and all associated resources from the provider
- Select **Delete Cluster Object Only** to delete cluster from Rafay controller only
- Select/enter the cluster name and click **Delete this Cluster**

[![Remove  Cluster](https://docs.rafay.co/clusters/gke/img/deleting_clusters.png)](https://docs.rafay.co/clusters/gke/img/deleting_clusters.png)

Once the delete request is submitted, the message below will be displayed and the deletion process might take up to 20 minutes.

[![Remove gke Cluster](https://docs.rafay.co/clusters/gke/img/remove_gke_cluster.png)](https://docs.rafay.co/clusters/gke/img/remove_gke_cluster.png)

Users can view the cluster deletion status on the cluster dashboard, as shown below.

[![Remove gke Cluster Progress](https://docs.rafay.co/clusters/gke/img/gke_cluster_delete.png)](https://docs.rafay.co/clusters/gke/img/gke_cluster_delete.png)

---
