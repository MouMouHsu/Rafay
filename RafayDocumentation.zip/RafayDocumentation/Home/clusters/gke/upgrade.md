---
title: "KOP GKE Clusters - Upgrade Kubernetes"
source: https://docs.rafay.co/clusters/gke/upgrade/
category: Home
---

# Upgrade K8s

Performing upgrades of Google GKE clusters by yourself can be complex and time-consuming. Using the Console makes this entire process simple and straightforward. Different strategies can be employed for upgrading Google GKE clusters.

---

## Scope of Upgrade

There are three components that need to be upgraded during a GKE Cluster upgrade.

1. GKE Control Plane
2. Attached Node Pools (both Managed and Self Managed)
3. Critical Add-Ons (coredns and kube-proxy)

The control plane always needs to be upgraded first, before the node pools and the critical add-ons.

The Controller automatically upgrades the critical cluster add-ons as part of the upgrade process, reducing the manual, operational burden for administrators.

> **Important**
> GKE cluster upgrades performed by the controller are always performed in a manner where the cluster and resident workloads never encounter any downtime.

## Upgrade Steps

A notification banner appears on the cluster when an upgrade is available for a GKE cluster. Clicking on the notification will provide additional information on the available versions.

- A red banner indicates that the cluster is multiple versions behind the latest version
- A blue banner indicates that the cluster is one version behind the latest version

[![Select Upgrade Cluster](https://docs.rafay.co/clusters/gke/img/upgrade_bar.png)](https://docs.rafay.co/clusters/gke/img/upgrade_bar.png)

1. Select the Version Upgrade Type:   [![Select Upgrade Cluster](https://docs.rafay.co/clusters/gke/img/cp_version_upgrade.png)](https://docs.rafay.co/clusters/gke/img/cp_version_upgrade.png)   [![Select Upgrade Cluster](https://docs.rafay.co/clusters/gke/img/k8s_upgrade_options.png)](https://docs.rafay.co/clusters/gke/img/k8s_upgrade_options.png)
  - Control Plane Only Upgrade - Upgrades the control plane only. The attached node pools are left untouched. Takes approximately 25-30 minutes. When upgrading the Control Plane, select the Control Plane version to upgrade to
  - Node Pool Upgrade - Upgrades the node pools only (Worker Node version). Takes approximately 10-15 minutes
2. Click **Upgrade**

**Upgrade via Cluster Settings**

Users can also upgrade the cluster via the settings icon and select **Upgrade Cluster** as shown below

[![Select Upgrade Cluster](https://docs.rafay.co/clusters/gke/img/select_upgradecluster.png)](https://docs.rafay.co/clusters/gke/img/select_upgradecluster.png)

---

## Upgrade Process

The upgrade process includes the following:

- A number of preflight checks are performed before the upgrade is attempted.
- When upgrading the control plane:
  - The GKE control plane is upgraded. This can be a time-consuming step.
  - Critical add-ons for the cluster, such as core-dns and kube-proxy, are upgraded to the required version.
- The node pools will be upgraded to the selected Kubernetes version.
- Once upgrades are complete, a round of post upgrade tests are performed to ensure that there are no loose ends and everything is as expected.

---

### Node Pool Upgrade

To upgrade a GKE Cluster node pool, perform the below steps:

1. Click on the required cluster and select **Node Pools** table
2. A notification banner appears on the node pool when an upgrade is available. Clicking on the notification will provide additional information on the available versions

[![Select Upgrade Cluster](https://docs.rafay.co/clusters/gke/img/nodepool_upgrade.png)](https://docs.rafay.co/clusters/gke/img/nodepool_upgrade.png)

- A red banner indicates that the node pool is multiple versions behind the latest version
- A blue banner indicates that the node pool is one version behind the latest version

> **Important**
> The node pool version must either match or be lower than the control plane version before upgrading. Upgrading the node pool version is feasible when it is lower than the control plane version, and it can be upgraded to match the control plane version. Conversely, downgrading the node pool version is possible from a higher version to any version that matches or is lower than the control plane version

1. Select the K8s version and click **Upgrade**

---

## Upgrade Activity

The controller maintains a list of cluster activities, including any upgrades. Click the cluster name and select the Activity tab.

[![Select Upgrade Cluster](https://docs.rafay.co/clusters/gke/img/activity.png)](https://docs.rafay.co/clusters/gke/img/activity.png)

---

## K8s Version Upgrade Pre-requisites

- Prior to upgrading the Kubernetes version of the control plane, ensure that the control plane is one level lower than the intended upgrade version. If the control plane has a version more than one level lower, the upgrade cannot proceed
- When upgrading a node pool version, the node pool can be of any version
- Following the upgrade of the control plane's Kubernetes version, it is not permissible to roll back to other versions for the control plane. Nevertheless, for the node pool, rolling back to a previous version is allowed

---
