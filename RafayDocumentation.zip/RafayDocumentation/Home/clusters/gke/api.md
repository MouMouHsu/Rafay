---
title: "KOP Providers - API"
source: https://docs.rafay.co/clusters/gke/api/
category: Home
---

# API

Authorized users can access the Swagger UI for the REST APIs directly from the Console to view the list of V3 GKE clusters by project

---

## Access to v3 APIs

To view the list of v3 API endpoints, perform the below steps

- Login to the console and click on API DOCS from the Home page
- Select **v3 APIs (Recommended)** under API Docs

[![API DOCS](https://docs.rafay.co/clusters/gke/img/api_v3.png)](https://docs.rafay.co/clusters/gke/img/api_v3.png)

Platform API screen appears

---

## List Clusters By Project

Under Cluster, use the below **GET** REST API to view the list of clusters under a project

- Provide a project name and click **Execute** to view the list of clusters

[![API DOCS](https://docs.rafay.co/clusters/gke/img/cluster_list.png)](https://docs.rafay.co/clusters/gke/img/cluster_list.png)

Below is an example of the project **defaultproject** showing all the clusters associated with the provided project name

[![API DOCS](https://docs.rafay.co/clusters/gke/img/list_example.png)](https://docs.rafay.co/clusters/gke/img/list_example.png)

---

## Create Cluster

Under Cluster, use the below **POST** REST API to create a GKE v3 Cluster under a project

- Provide a project name and provide the cluster config spec
- Click **Execute** to initiate the creation process

Here is an example of creating a new v3 cluster named **ak-v3-demo** under the project **defaultproject**:

[![API DOCS](https://docs.rafay.co/clusters/gke/img/create_v3_clus.png)](https://docs.rafay.co/clusters/gke/img/create_v3_clus.png)

An illustration of the GKE v3 Cluster Specification is given below:

```
{
    "apiVersion": "infra.k8smgmt.io/v3",
    "kind": "Cluster",
    "metadata": {
        "name": "example-cluster2",
        "description": "",
        "project": "defaultproject"
    },
    "spec": {
        "cloudCredentials": "-dev-",
        "blueprint": {
            "name": "minimal",
            "version": "latest"
        },
        "type": "Gke",
        "preBootstrapCommands": [],
        "config": {
            "name": "example-cluster2",
            "project": "dev-382813",
            "description": "My cluster",
            "location": {
                "type": "zonal",
                "zone": "us-central-a"
            },
            "controlPlaneVersion": 1.26,
            "network": {
                "name": "default",
                "nodeSubnetName": "default",
                "networkAccess": {
                    "privacy": "public"
                },
                "enableVPCNativeTraffic": true,
                "maxPodsPerNode": 110,
                "enableControlPlaneAuthorizedNetworks": []
            },
            "nodePools": [
                {
                    "name": "default-nodepool",
                    "size": 3,
                    "nodeVersion": 1.25,
                    "machineConfig": {
                        "imageType": "COS_CONTAINERD",
                        "machineType": "e2-medium",
                        "bootDiskType": "pd-standard",
                        "bootDiskSize": 100
                    },
                    "management": {
                        "autoUpgrade": true
                    },
                    "upgradeSettings": {
                        "strategy": "BLUE_GREEN",
                        "config": {
                            "batchNodeCount": 1,
                            "batchSoakDuration": "1s",
                            "nodePoolSoakDuration": "3600s"
                        }
                    }
                }
            ],
            "security": {
                "enableWorkloadIdentity": true,
            },
            "feature": {
                "enableCloudLogging": false,
                "enableCloudMonitoring": false,
                "enableManagedServiceforPrometheus": false,
                "enableApplicationManagerBeta": false,
                "enableBackupforGKE": false,
                "enableComputeEnginePersistentDiskCSIDriver": true,
                "enableFilestoreCSIDriver": false,
                "enableImageStreaming": false
            }
        }
    }
}
```

---

## Cluster Detail

To view the detail of a specific v3 cluster, use the below **GET** REST API

- Provide the required Project name and Cluster name
- Click **Execute** to get the cluster detail

Here is an example detailing the cluster named **ak-v3-test5** under the project **defaultproject**:

[![API DOCS](https://docs.rafay.co/clusters/gke/img/cluster_detail.png)](https://docs.rafay.co/clusters/gke/img/cluster_detail.png)

---

## Update CAPI / CAPG Controller Deployment

Use the below POST REST API to update the CAPI or CAPG controller version running on an existing v3 cluster. This is a day-2 operation, it does not apply at cluster creation. Send exactly one of `capiVersion` or `capgVersion` per request; sending both, or neither, returns a `400`.

`POST /apis/infra.k8smgmt.io/v3/projects/{project}/clusters/{cluster}/updatecontrollerdeployment`

1. Provide the Project name and Cluster name
2. Provide the request body with the field to update
3. Click Execute

Example request body to update CAPI:

```
{
  "capiVersion": "v1.13.1"
}
```

Example request body to update CAPG:

```
{
  "capgVersion": "v1.1.1-gke.16"
}
```

Equivalent curl calls:

```
# CAPI
curl -sS -X POST \
  "${CONSOLE}/apis/infra.k8smgmt.io/v3/projects/${PROJECT}/clusters/${CLUSTER}/updatecontrollerdeployment" \
  -H "Content-Type: application/json" \
  -H "X-RAFAY-API-KEYID: ${RCTL_API_KEY}" \
  -d '{"capiVersion":"v1.13.1"}'

# CAPG
curl -sS -X POST \
  "${CONSOLE}/apis/infra.k8smgmt.io/v3/projects/${PROJECT}/clusters/${CLUSTER}/updatecontrollerdeployment" \
  -H "Content-Type: application/json" \
  -H "X-RAFAY-API-KEYID: ${RCTL_API_KEY}" \
  -d '{"capgVersion":"v1.1.1-gke.16"}'
```

A successful call returns `202 Accepted` (e.g. `CAPG deployment update is being processed.`). See [CLI](https://docs.rafay.co/clusters/gke/cli/#update-capi-capg-controller-version) for the equivalent RCTL/GitOps workflow, including the CAPI-before-CAPG ordering rule.

---
