---
title: "V3 API Config Schema"
source: https://docs.rafay.co/clusters/gke/gkev3_schema/
category: Home
---

# GKE Schema

V3 Cluster configuration for GKE clusters
