---
title: "KOP Red Hat Openshift Clusters - Openshift Blueprint"
source: https://docs.rafay.co/clusters/openshift/blueprint/
category: Home
---

# Blueprints

Learn more about [cluster blueprints](https://docs.rafay.co/blueprints/overview/).

---

## Default Openshift Blueprint

A specially tuned and optimized "default" cluster blueprint is available for Openshift environments.

[![Default Blueprint for Openshift](https://docs.rafay.co/clusters/openshift/img/blueprint_openshift.png)](https://docs.rafay.co/clusters/openshift/img/blueprint_openshift.png)

The default cluster blueprint for Openshift provides a number of managed addons providing critical capabilities required for Kubernetes Operations.

- Remote k8s cluster management
- Zero Trust Kubectl
- Visibility and Monitoring
- Log Aggregation
- Managed Ingress

[![Default Openshift Blueprint Details](https://docs.rafay.co/clusters/openshift/img/blueprint_openshift_details.png)](https://docs.rafay.co/clusters/openshift/img/blueprint_openshift_details.png)

---

## Custom Cluster Blueprint

Just like with any Kubernetes cluster, users can create and manage "custom" cluster blueprints for their Openshift clusters. To ensure guaranteed compatibility, they are recommended to use either the "minimal blueprint" or the "default openshift blueprint" as their base blueprints.

[![Custom Blueprint for Openshift](https://docs.rafay.co/clusters/openshift/img/openshift_base_bp.png)](https://docs.rafay.co/clusters/openshift/img/openshift_base_bp.png)

---
