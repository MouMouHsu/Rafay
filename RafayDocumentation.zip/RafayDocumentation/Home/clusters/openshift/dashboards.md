---
title: "KOP Red Hat Openshift Clusters - Dashboards"
source: https://docs.rafay.co/clusters/openshift/dashboards/
category: Home
---

# Dashboards

Users benefit from the integrated visibility and monitoring for their Openshift clusters. With the "default openshift" blueprint as the base blueprint, managed addons for metrics aggregation are automatically deployed to the Openshift clusters. Metrics are scraped and aggregated in a centralized time series database and presented to users via intuitive dashboards.

> **Note**
> Some illustrative examples of dashboards shown below. Available dashboards are identical to that of other cluster types providing users with a consistent experience for heterogeneous environments.

---

## Cluster Dashboard

The [cluster dashboard](https://docs.rafay.co/dashboard/cluster/) provides a bird's eye view of the Openshift Cluster.

[![Openshift Cluster Dashboard](https://docs.rafay.co/clusters/openshift/img/openshift_cluster.png)](https://docs.rafay.co/clusters/openshift/img/openshift_cluster.png)

---

## Node Dashboard

The [Node dashboard](https://docs.rafay.co/dashboard/nodes/) provides a view of all the nodes in the Openshift Cluster.

[![Openshift Node Dashboard](https://docs.rafay.co/clusters/openshift/img/openshift_nodes.png)](https://docs.rafay.co/clusters/openshift/img/openshift_nodes.png)

Click on "Overview" to view the dashboard for a specific node.

[![Openshift Node Dashboard](https://docs.rafay.co/clusters/openshift/img/openshift_node.png)](https://docs.rafay.co/clusters/openshift/img/openshift_node.png)

---

## k8s Resources

Users can use the integrated [Kubernetes resources dashboard](https://docs.rafay.co/dashboard/k8sresources/) to view all the resources organized by namespaces in the Openshift cluster. In addition to viewing the resources, users can also perform actions on k8s resources operating on remote Openshift clusters.

[![Openshift k8s Resources](https://docs.rafay.co/clusters/openshift/img/k8s-dashboard.png)](https://docs.rafay.co/clusters/openshift/img/k8s-dashboard.png)

---
