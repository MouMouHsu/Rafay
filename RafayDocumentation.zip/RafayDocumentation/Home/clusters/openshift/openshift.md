---
title: "KOP Red Hat Openshift Clusters - Quick Start"
source: https://docs.rafay.co/clusters/openshift/openshift/
category: Home
---

# Import

A typical organization needs to address four critical capabilities (automation, visibility, security and governance) for their Kubernetes clusters. The platform addresses these requirements for Red Hat Openshift clusters.

## Prerequisites

- You have access to an Org with Org Admin or Infra Admin privileges.
- You have already installed and deployed a Red Hat Openshift cluster in a supported environment and configured and have kubectl access to the cluster
- Ensure that your cluster is healthy and has sufficient resources available to accommodate additional resources

> **Important**
> You can also automate the entire process using the RCTL CLI or Swagger based APIs or a Terraform Provider.

---

## Create Cluster

- Navigate to the project in your Org where you would like to import the Openshift cluster
- Click on New Cluster and select the option to "Import Existing Kubernetes Cluster"

[![Create Cluster](https://docs.rafay.co/clusters/openshift/img/import_cluster.png)](https://docs.rafay.co/clusters/openshift/img/import_cluster.png)

---

## Select Type

- Select "Datacenter/Edge" for operating environment and "RedHat Openshift" for Kubernetes distribution

[![Operating Environment](https://docs.rafay.co/clusters/openshift/img/select_openshift.png)](https://docs.rafay.co/clusters/openshift/img/select_openshift.png)

---

## Configure Details

This step mostly contains "optional" configurations that are sometimes required for specialized environments or requirements.

- Optionally, specify location (if you plan to use location based policies)
- Select a custom blueprint and version if you created one.
- Optionally, specify proxy configuration if your environment requires a forward proxy for the Kubernetes management operator to connect to the controller.

[![Configure Cluster](https://docs.rafay.co/clusters/openshift/img/configure.png)](https://docs.rafay.co/clusters/openshift/img/configure.png)

---

## Install Operator

- Download the bootstrap YAML file
- Apply the bootstrap file on your Openshift cluster using kubectl

This step will deploy the Kubernetes mgmt operator on your Openshift cluster, start downloading the required container images and establish connectivity with the controller. This step can take 2-3 minutes and depends on the resources available on the cluster and network download speeds to download the required container images.

[![Create Cluster](https://docs.rafay.co/clusters/openshift/img/download_bootstrap.png)](https://docs.rafay.co/clusters/openshift/img/download_bootstrap.png)

---

## Verify Import

After the previous step is complete, you can verify if the resources are operational by using the "zero trust kubectl" channel from the web console. Click on "Kubectl" on the web console and type the following command.

```
kubectl get ns
```

You should see something like the following on your Openshift cluster.

```
NAME                                               STATUS   AGE
default                                            Active   65m
kube-node-lease                                    Active   66m
kube-public                                        Active   66m
kube-system                                        Active   66m
openshift                                          Active   57m
openshift-apiserver                                Active   59m
openshift-apiserver-operator                       Active   65m
openshift-authentication                           Active   59m
openshift-authentication-operator                  Active   65m
openshift-cloud-credential-operator                Active   65m
openshift-cluster-csi-drivers                      Active   65m
openshift-cluster-machine-approver                 Active   65m
openshift-cluster-node-tuning-operator             Active   65m
openshift-cluster-samples-operator                 Active   65m
openshift-cluster-storage-operator                 Active   65m
openshift-cluster-version                          Active   66m
openshift-config                                   Active   64m
openshift-config-managed                           Active   64m
openshift-config-operator                          Active   65m
openshift-console                                  Active   54m
openshift-console-operator                         Active   54m
openshift-console-user-settings                    Active   54m
openshift-controller-manager                       Active   59m
openshift-controller-manager-operator              Active   65m
openshift-dns                                      Active   59m
openshift-dns-operator                             Active   65m
openshift-etcd                                     Active   66m
openshift-etcd-operator                            Active   65m
openshift-host-network                             Active   60m
openshift-image-registry                           Active   65m
openshift-infra                                    Active   65m
openshift-ingress                                  Active   56m
openshift-ingress-canary                           Active   56m
openshift-ingress-operator                         Active   65m
openshift-insights                                 Active   65m
openshift-kni-infra                                Active   65m
openshift-kube-apiserver                           Active   66m
openshift-kube-apiserver-operator                  Active   66m
openshift-kube-controller-manager                  Active   66m
openshift-kube-controller-manager-operator         Active   66m
openshift-kube-scheduler                           Active   66m
openshift-kube-scheduler-operator                  Active   65m
openshift-kube-storage-version-migrator            Active   59m
openshift-kube-storage-version-migrator-operator   Active   65m
openshift-kubevirt-infra                           Active   65m
openshift-machine-api                              Active   64m
openshift-machine-config-operator                  Active   66m
openshift-marketplace                              Active   65m
openshift-monitoring                               Active   64m
openshift-multus                                   Active   60m
openshift-network-diagnostics                      Active   60m
openshift-network-operator                         Active   65m
openshift-node                                     Active   57m
openshift-oauth-apiserver                          Active   59m
openshift-openstack-infra                          Active   65m
openshift-operator-lifecycle-manager               Active   65m
openshift-operators                                Active   64m
openshift-ovirt-infra                              Active   64m
openshift-sdn                                      Active   60m
openshift-service-ca                               Active   59m
openshift-service-ca-operator                      Active   65m
openshift-user-workload-monitoring                 Active   64m
openshift-vsphere-infra                            Active   64m
rafay-infra                                        Active   14m
rafay-system                                       Active   15m
```

---

Congratulations! You have successfully imported your Red Hat Openshift cluster. You can now leverage the various capabilities provided by the Kubernetes Operations Platform on your Openshift cluster.

---
