---
title: "KOP Red Hat Openshift Clusters - Overview"
source: https://docs.rafay.co/clusters/openshift/overview/
category: Home
---

# Overview

[Red Hat Openshift](https://www.redhat.com/en/technologies/cloud-computing/openshift) is an enterprise-ready Kubernetes container platform with full-stack automated operations to manage hybrid cloud, multi-cloud, and edge deployments.

Red Hat OpenShift’s full-stack automated operations, consistent experience—across all environments—and self-service provisioning for developers lets teams work together to more efficiently move ideas from development to production.

---
