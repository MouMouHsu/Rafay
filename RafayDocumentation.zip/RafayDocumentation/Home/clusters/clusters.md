---
title: "Home"
source: https://docs.rafay.co/clusters/clusters/
category: Home
---

# Public Cloud Kubernetes Distributions

- **Amazon EKS**   Provision and Manage Lifecycle of Amazon EKS Clusters  [**Overview**](https://docs.rafay.co/clusters/eks/overview/) |  [**Get Started Guides**](https://docs.rafay.co/learn/eks/)
- **Azure AKS**   Provision and Manage Lifecycle of Azure AKS Clusters  [**Overview**](https://docs.rafay.co/clusters/aks/overview/) |  [**Get Started Guides**](https://docs.rafay.co/learn/aks/)
- **Google GKE**   Provision and Manage Lifecycle of Google GKE Clusters  [**Overview**](https://docs.rafay.co/clusters/gke/overview/) |  [**Get Started Guides**](https://docs.rafay.co/learn/gke/)

---

# On-Premises Environments

- **Bare Metal & VMs**   Provision and Manage Lifecycle of Rafay MKS (Upstream Kubernetes) on Bare Metal Servers and VMs  [**Overview**](https://docs.rafay.co/clusters/upstream/baremetal_vm/overview/) |  [**Get Started Guides**](https://docs.rafay.co/learn/mks/)
- **VMware**   Provision and Manage Lifecycle of Rafay MKS (Upstream Kubernetes) on VMware vSphere with vCenter.  [**Overview**](https://docs.rafay.co/template_catalog/vsphere-mks/overview/) |  [**Get Started Guides**](https://docs.rafay.co/template_catalog/get_started/vsphere_mks_guide/)
- **Nutanix**   Provision and Manage Lifecycle of Rafay MKS (Upstream Kubernetes) on Nutanix AHV with Prism  [**Overview**](https://docs.rafay.co/template_catalog/nutanix/overview/) |  [**Get Started Guides**](https://docs.rafay.co/template_catalog/get_started/nutanix_guide/)

---

# Imported Clusters

- **RedHat OpenShift**   Import RedHat OpenShift Clusters into the Rafay Platform  [**Overview**](https://docs.rafay.co/clusters/openshift/overview/)
- **Any Kubernetes**   Import Other CNCF Compliant Kubernetes Clusters (e.g. Rancher, Tanzu etc) into the Rafay Platform  [**Overview**](https://docs.rafay.co/clusters/import/overview/)

---
