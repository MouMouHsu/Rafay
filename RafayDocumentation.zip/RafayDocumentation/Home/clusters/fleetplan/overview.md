---
title: "KOP Fleet Plan - Overview"
source: https://docs.rafay.co/clusters/fleetplan/overview/
category: Home
---

# Overview

A Fleet Plan on clusters refers to a strategic approach for managing and coordinating resources across multiple clusters. It involves creating a comprehensive plan to streamline operations on bunch of clusters available within one or more fleet(s), and ensure efficient utilization of cluster resources. With Fleet Plan, users can effortlessly perform a wide range of operations such as upgrades, backups, patch, and scaling across their clusters. The base roles **Infra admin** and **Org Admin** are allowed to create and run the fleet plan

## Benefits

Users Benefit from Fleet Plan in the following Ways:

- **Cluster Management**: Oversee and control multiple clusters simultaneously
- **Upgrade**: Simplifies the process of upgrading clusters within the fleet
- **Backups**: Conveniently manage and schedule backups for their clusters
- **Patching**: Streamlines the patch management process for clusters within the fleet
- **Scaling**: Easily scale their clusters up or down to accommodate changing workload demands

> **Did you know ?**
> An Org Admin/ Infra Admin can create Cluster Fleet Plans via three methods:
>
> - [UI](https://docs.rafay.co/clusters/fleetplan/create_fp/)
> - [CLI](https://docs.rafay.co/clusters/fleetplan/automation/)
> - [Swagger API](https://docs.rafay.co/automation/api/apis/)

---

## Supported Cluster Types

Fleet Plan is supported for the following cluster types:

- Amazon EKS
- Azure AKS
- Google GKE

> **Note**
> Fleet Plans are cluster-type specific. EKS, AKS, and GKE clusters cannot be combined into the same Fleet Plan. A separate Fleet Plan must be created for each cluster type.

---

## Pre-requisites

- Fleet plan refers to labels to target the clusters
- GitOps agent is required for executing the hooks in fleet plan when Runner type is configured as Agent in the hook configuration
- Container image is necessary for hooks (pre and post hook configuration)

---

## UI Process Flow Diagram

The image below describes the typical steps that are performed in a sequence.

```
sequenceDiagram
    participant User as User
    participant Create_Fleet_Plan as "Create Fleet Plan"
    participant New_Operations as "New Operations"
    participant Add_Pre_Post_hook_Config as "Add Pre/Post-hook Config"
    participant Select_Labels_Projects as "Select Labels & Projects"
    participant Add_Agents as "Add Agents"
    participant Trigger_the_job as "Trigger the job"
    Note over User, Create_Fleet_Plan: Login as Org Admin/Infra Admin
    User->>Create_Fleet_Plan: Add one or more Operations
    Create_Fleet_Plan->>New_Operations: 
    New_Operations->>Add_Pre_Post_hook_Config: Pre/Post-hook checks for the operations
    Note over Add_Pre_Post_hook_Config: Optional
    Add_Pre_Post_hook_Config->>Select_Labels_Projects: Select one or more projects
    Select_Labels_Projects ->>Add_Agents: Add one or more GitOps CD Agents
    Add_Agents->>Trigger_the_job: Apply the operations on the targets (clusters)
    Note over Add_Agents: Mandatory when Runner type is Agent in Hook config
```

---
