---
title: "KOP Fleet Plan - Demonstrations"
source: https://docs.rafay.co/clusters/fleetplan/examples/
category: Home
---

# Config Samples

Below are some examples of the cluster fleet plan designed to enable users to have hands-on experience:

---

## Operation

There are three named actions available for the fleet plan: **Control Plane Upgrade**, **Node Group and Control Plane Upgrade**, and **Node Groups Upgrade**

Here is an example specification featuring the named action `nodeGroupsAndControlPlaneUpgrade`, including a pre-hook (kubent), a post-hook, and Tolerations.

```
kind: FleetPlan
apiVersion: infra.k8smgmt.io/v3
metadata:
  name: fleetplan-sample
  project: qa-project
spec:
  fleet:
    kind: clusters
    labels:
      role: qa
      user: rafay-user
    projects:
      - name: dev-project
      - name: qa-project
      - name: ops-project
  operationWorkflow:
    operations:
      - name: scale-ng-operation
        prehooks:
          - description: check api depreciation before upgrade
            inject:
              - KUBECONFIG
            name: kubent-prehook
            containerConfig:
              runner:
                type: cluster
                tolerations:
                  - key: key
                    operator: Equal
                    value: value
                    effect: NoSchedule
                nodeSelector:
                  ng-label: managed-ng1
              image: ghcr.io/doitintl/kube-no-trouble:latest
              arguments:
                - '-o'
                - json
                - '-e'
              commands:
                - /app/kubent
              cpuLimitMilli: '10'
              memoryLimitMb: '100'
            timeoutSeconds: 300
        action:
          type: nodeGroupsAndControlPlaneUpgrade
          description: upgrade k8s of cluster
          name: upgrade-cluster
          nodeGroupsAndControlPlaneUpgradeConfig:
            version: '1.25'
        posthooks:
          - description: check api depreciation after upgrade
            inject:
              - KUBECONFIG
            name: kubent-posthook
            containerConfig:
              runner:
                type: cluster
                tolerations:
                  - key: key
                    operator: Equal
                    value: value1
                    effect: NoSchedule
                nodeSelector:
                  ng-label: managed-ng1
              image: ghcr.io/doitintl/kube-no-trouble:latest
              arguments:
                - '-o'
                - json
                - '-e'
              commands:
                - /app/kubent
              cpuLimitMilli: '10'
              memoryLimitMb: '100'
            timeoutSeconds: 300
```

The provided example specification includes a **Named** action with both a pre-hook and a post-hook:

### Operation

- **Named Action:** Node Groups And Control Plane Upgrade
- **Pre-hook:** Verify API deprecation status prior to the upgrade
- **Post-hook:** Verify API deprecation status after the upgrade

Before initiating the upgrade, the pre-hook is executed, which involves checking the API deprecation status. After the upgrade, the post-hook is triggered to verify the API deprecation status once again

---

## Fleet Plan Patch

### Blueprint Name and Version Update

1. To update a blueprint name and version in the fleet plan, retrieve the blueprint **path** highlighted from the below v3 cluster config

### Reference v3 Cluster Config

```
{
  "apiVersion": "infra.k8smgmt.io/v3",
  "kind": "Cluster",
  "metadata": {
    "name": "eks-privatep",
    "labels": {
      "role": "qa",
      "user": "team-rafay"
    },
    "project": "fleetproj4"
  },
  "spec": {
    "sharing": {
      "enabled": true
    },
    "blueprintConfig": {
      "name": "minimal",
      "version": "1.25.0"
    },
    "cloudCredentials": "eks_cred",
    "type": "aws-eks",
    "proxyConfig": {},
    "config": {
      "managedNodeGroups": [
        {
          "amiFamily": "AmazonLinux2",
          "desiredCapacity": 2,
          "iam": {
            "withAddonPolicies": {
              "autoScaler": true
            }
          },
          "instanceTypes": [
            "t3.xlarge"
          ],
          "maxSize": 28,
          "minSize": 0,
          "name": "ng-ce4f4fed",
          "version": "1.25",
          "volumeSize": 80,
          "volumeType": "gp3"
        }
      ],
      "metadata": {
        "name": "eks-privatep",
        "region": "us-west-2",
        "tags": {
          "email": "[email protected]",
          "env": "qa"
        },
        "version": "1.25"
      },
      "nodeGroups": [
        {
          "amiFamily": "AmazonLinux2",
          "desiredCapacity": 1,
          "iam": {
            "withAddonPolicies": {
              "autoScaler": true,
              "imageBuilder": true
            }
          },
          "instancesDistribution": {
            "instanceTypes": [
              "t3.xlarge"
            ]
          },
          "maxSize": 2,
          "minSize": 1,
          "name": "selfmangng1",
          "tags": {
            "email": "[email protected]",
            "env": "qa"
          },
          "volumeSize": 80,
          "volumeType": "gp3"
        }
      ],
      "vpc": {
        "cidr": "192.168.0.0/16",
        "clusterEndpoints": {
          "privateAccess": true,
          "publicAccess": false
        },
        "nat": {
          "gateway": "Single"
        }
      },
      "network": {
        "cni": {
          "name": "aws-cni"
        }
      }
    }
  }
}
```

- The retrieved path to update the blueprint name: ***.spec.blueprintConfig.name***
- The retrieved path to update the blueprint version: ***.spec.blueprintConfig.version***
- Now provide this path in the below fleet plan config file with the desired value.
- Value for Blueprint name: **default**
- Value for Blueprint version: **latest**

The provided example specification includes a **Patch** action with both a pre-hook and a post-hook:

### Operation

- **Patch Action:** Blueprint update
- **Pre-hook:** Verify API deprecation status prior to the upgrade
- **Post-hook:** Verify API deprecation status after the upgrade

```
kind: FleetPlan
apiVersion: infra.k8smgmt.io/v3
metadata:
  name: fleetplan-bpupdate
  project: qa-project
spec:
  fleet:
    kind: clusters
    labels:
      role: qa
      user: rafay-user
    projects:
      - name: dev-project
      - name: qa-project
      - name: ops-project
  operationWorkflow:
    operations:
      - name: bp-update-operation
        prehooks:
          - description: check api depreciation before update
            inject:
              - KUBECONFIG
            name: kubent-prehook
            containerConfig:
              runner:
                type: cluster
                nodeSelector:
                  ng-label: managed-ng1
              image: ghcr.io/doitintl/kube-no-trouble:latest
              arguments:
                - '-o'
                - json
                - '-e'
              commands:
                - /app/kubent
              cpuLimitMilli: '10'
              memoryLimitMb: '100'
            timeoutSeconds: 300
        action:
          type: patch
          description: blueprint update
          name: blueprint-update
          patchConfig:
            - op: replace
              path: .spec.blueprintConfig.name
              value: default
            - op: replace
              path: .spec.blueprintConfig.version
              value: latest
        posthooks:
          - description: check api depreciation before update
            inject:
              - KUBECONFIG
            name: kubent-posthook
            containerConfig:
              runner: cluster
              image: ghcr.io/doitintl/kube-no-trouble:latest
              arguments:
                - '-o'
                - json
                - '-e'
              commands:
                - /app/kubent
              cpuLimitMilli: '10'
              memoryLimitMb: '100'
            timeoutSeconds: 300
```

1. Run the apply command to update the fleet plan

```
./rctl apply -f <fleetplan_filename.yaml>
```

UI Patch operation for Blueprint version update is shown below

[![New Cluster Template](https://docs.rafay.co/clusters/fleetplan/img/fpex_1.png)](https://docs.rafay.co/clusters/fleetplan/img/fpex_1.png)

---

### Scale Node Group

To scale a Node Group, provide the **path** and the desired value in the config spec as given in the below example

```
patchConfig:
 - op: replace
   path: .spec.config.managedNodeGroups[0].desiredCapacity
   value: 4
```

UI Patch operation for Scale Node Group is shown below

[![New Cluster Template](https://docs.rafay.co/clusters/fleetplan/img/fpex_2.png)](https://docs.rafay.co/clusters/fleetplan/img/fpex_2.png)

---

### Update Cluster Endpoint

To update a cluster endpoint, provide the **path** and the desired value in the config spec. An illustrative example is given below.

```
patchConfig:
  - op: replace
    path: .spec.config.vpc.clusterEndpoints.privateAccess
    value: false
  - op: replace
    path: .spec.config.vpc.clusterEndpoints.publicAccess
    value: true
```

UI Patch operation for Cluster Endpoint update is shown below

[![New Cluster Template](https://docs.rafay.co/clusters/fleetplan/img/fpex_3.png)](https://docs.rafay.co/clusters/fleetplan/img/fpex_3.png)

---
