---
title: "KOP Fleet Plan - Troubleshooting"
source: https://docs.rafay.co/clusters/fleetplan/troubleshooting/
category: Home
---

# Troubleshooting

This section explains the frequently occurred errors during Fleet Plan operations

---

## Scenario 1: Instance Type Not supported

When a runner type is **Agent** and the gitops agent type is Docker, the pre-hook/post-hook fails with an error as shown below

[![Error 1](https://docs.rafay.co/clusters/fleetplan/img/tss_1.png)](https://docs.rafay.co/clusters/fleetplan/img/tss_1.png)

### Validation

Check whether Inject KUBECONFIG option is enabled or not. To execute prehook on the target cluster, API access is mandatory for the cluster and this is achievable only when KUBECONFIG is enabled

[![Error 1](https://docs.rafay.co/clusters/fleetplan/img/tss_ui_1.png)](https://docs.rafay.co/clusters/fleetplan/img/tss_ui_1.png)

---

## Scenario 2: Availability Zones

The below error is an example that might occur while executing the operation on the target cluster. This error usually occurs when a specified patch path does not exist in the target clusters spec

[![Error 2](https://docs.rafay.co/clusters/fleetplan/img/tss_2.png)](https://docs.rafay.co/clusters/fleetplan/img/tss_2.png)

### Validation

Navigate to **Operation → Action Configuration** of a fleet plan and verify the specified path. A valid path that exactly matches with config spec is mandatory

[![Error 2](https://docs.rafay.co/clusters/fleetplan/img/tss_ui_2.png)](https://docs.rafay.co/clusters/fleetplan/img/tss_ui_2.png)

---
