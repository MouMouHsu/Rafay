---
title: "KOP Edge Clusters"
source: https://docs.rafay.co/clusters/edge/overview/
category: Home
---

# Overview

## Background

Kubernetes is a key driving force for enterprises transforming into digital-first businesses. Remote edge locations represent the next frontier for accelerating innovation, and containerization is the logical choice for a variety of verticals and organizations. It is the logical next step for the multicloud landscape because:

1. Cost-savings accrued from avoiding the need to send data to clouds or datacenters for processing.
2. Great performance and user-experience by operating applications closer to consumers.

---

## Complexity

Edge locations are challenging environments relative to conventional data centers and public cloud environments. A typical edge deployment for most organizations means the existence of hundreds, or even thousands, of locations.

It is common for retail, hospitality and healthcare verticals to routinely reach those numbers. The issue is exacerbated further because of lack on-site IT personnel and unreliable Internet connectivity.

The configuration of Kubernetes clusters at those locations often is based on a single commodity server for cost reasons or, in some cases, a maximum of three servers in cases where high availability is critical.

---
