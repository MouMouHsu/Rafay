---
title: "Upstream Kubernetes on Nutanix"
source: https://docs.rafay.co/clusters/nutanix/overview/
category: Home
---

# Overview

Platform teams can use the Rafay platform to configure, provision, scale and perform in-place upgrades of Kubernetes clusters on Nutanix. The Rafay platform will automatically instantiate VMs on Nutanix to power the control plane and worker nodes for the Kubernetes cluster.

With Rafay, administrators configure and manage the Kubernetes clusters on Nutanix using version controlled Infrastructure as Code (IaC) in their Git repositories.

- The underlying automation for lifecycle management is performed using Rafay's Environment Manager and Kubernetes Manager.
- The Kubernetes clusters are based on CNCF Conformant Upstream Kubernetes based on Rafay's MKS Kubernetes Distribution.

---

## Provision Cluster

The sequence diagram below captures the high level steps that are performed to provision a Kubernetes cluster remotely on Nutanix operating in a private data center.

[![Provision Kubernetes on Nutanix](https://docs.rafay.co/clusters/nutanix/img/provision.png)](https://docs.rafay.co/clusters/nutanix/img/provision.png)

Watch a brief video showcasing the administrative experience to provision a Kubernetes cluster on Nutanix

---

## Scale Cluster

The sequence diagram below captures the high level steps that are performed to scale a Kubernetes cluster operating remotely on Nutanix operating in a private data center.

[![Scale Kubernetes on Nutanix](https://docs.rafay.co/clusters/nutanix/img/scale.png)](https://docs.rafay.co/clusters/nutanix/img/scale.png)

---

## Upgrade Cluster

The sequence diagram below captures the high level steps that are performed to upgrade a Kubernetes cluster operating remotely on Nutanix operating in a private data center.

[![Upgrade Kubernetes on Nutanix](https://docs.rafay.co/clusters/nutanix/img/upgrade.png)](https://docs.rafay.co/clusters/nutanix/img/upgrade.png)
