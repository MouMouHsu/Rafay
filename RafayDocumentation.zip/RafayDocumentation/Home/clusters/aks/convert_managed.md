---
title: "KOP Takeover - AKS Convert to Managed"
source: https://docs.rafay.co/clusters/aks/convert_managed/
category: Home
---

# Convert to Managed

After an Azure AKS cluster has been imported, you can allow the controller to takeover the lifecycle management of the AKS cluster. This allows the controller to perform all of the cluster lifecycle management functions like scale, add node pools, and upgrade. The controller retrieves information about the imported AKS clusters to make the cluster's infrastructure equivalent to the managed AKS clusters provisioned through the controller.

---

## Convert to Managed

At any time, you can convert an imported AKS cluster to a managed cluster.

- On successful import, a clickable label **Convert to Managed** is available next to the imported cluster as shown in the example below. This option provides a workflow for administrators to initiate the conversion of the cluster from "imported" to "managed".

[![Import Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_convert_managed-button.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_convert_managed-button.png)

Clicking on the label, the below screen appears

- Select the **Cloud Credentials** for the imported cluster.
- Enter the **Resource Group** name for the imported cluster.
- Select the source cluster name from the provider to link to the imported cluster.
- Click **Convert to Managed Cluster**.

[![Import Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_import_cred.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_import_cred.png)

The system shows the below message. Click **Yes** to confirm the conversion process.

[![Import Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_confirm-messsage.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_confirm-messsage.png)

The console saves the provided credentials against the cluster and changes the cluster type to "Azure AKS". The managed and imported property is set to True and a declarative cluster specification gets generated for the cluster. Once complete, the controller declares the cluster as being ready for performing "lifecycle management" operations.

- On successful conversion, you will receive a success message as shown below.

[![Import Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_converted_success.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_converted_success.png)

You can see the cluster type as **Imported + Managed** and the list of operations allowed on the clusters page.

- Click **Go To Cluster**.

[![Import Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_cluster_type.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_cluster_type.png)

---

## New Enhancements for Import and Convert to Managed

The following new enhancements have been added to the AKS import and convert to managed workflow:

| Feature | Description |
| --- | --- |
| **Private DNS Zone** | Support for private DNS zone configuration |
| **HTTP Proxy Configuration** | `http_proxy`, `https_proxy`, and `no_proxy` settings |
| **Node Image: Ubuntu** | Ubuntu-based node images |
| **Custom Kubelet Config** | Custom kubelet configuration for node pools |
| **Azure Web Application Routing Addon** | Azure managed Web Application Routing addon |
| **Azure Istio Service Mesh Addon** | Azure managed Istio service mesh addon |
| **Key Vault Secret Provider CSI Driver** | Azure Key Vault Secrets Provider for CSI Driver |
| **Snapshot ID Support** | Node pool snapshot ID support for creating node pools from snapshots |

### Example Cluster Configuration

The following is an example of how the cluster configuration looks after **importing and converting an AKS cluster to Rafay managed**:

```
apiVersion: rafay.io/v1alpha1
kind: Cluster
metadata:
  labels:
    environment: test
    purpose: demo
  name: aks-import-convert-test
  project: shobhit
spec:
  blueprint: minimal
  cloudprovider: shobhit_azure2
  clusterConfig:
    apiVersion: rafay.io/v1alpha1
    kind: aksClusterConfig
    metadata:
      name: aks-import-convert-test
    spec:
      managedCluster:
        apiVersion: "2023-11-01"
        identity:
          type: SystemAssigned
        location: centralindia
        properties:
          addonProfiles:
            azureKeyvaultSecretsProvider:
              config:
                enableSecretRotation: "false"
                rotationPollInterval: 2m
              enabled: true
          autoUpgradeProfile:
            nodeOsUpgradeChannel: NodeImage
            upgradeChannel: none
          dnsPrefix: aks-proxy--shobhit-rg-a2252e
          enableRBAC: true
          httpProxyConfig:
            httpProxy: http://10.225.0.10:443/
            httpsProxy: http://10.225.0.10:443/
            noProxy:
            - 10.0.0.0/16
            - localhost
            - 127.0.0.1
            - ingress-controller-v1-controller-admission.rafay-system.svc
            - secretstore-webhook.rafay-system.svc
            - 10.225.0.0/24
            - az-prox-26feb-dns-z9v3wwih.hcp.centralindia.azmk8s.io
            - 10.244.0.0/16
            - 10.224.0.0/12
            - 169.254.169.254
            - .hcp.centralindia.azmk8s.io
            - 168.63.129.16
            - konnectivity
            - k8master.service.consul
            - rafay-drift-v3.rafay-system.svc
            - dingdong
            - asd
          identityProfile:
            kubeletIdentity:
              resourceId: /subscriptions/<subscription_id>/resourcegroups/MC_<resource_group>_<cluster_name>_<location>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<identity_name>
          ingressProfile:
            webAppRouting:
              dnsZoneResourceIds:
              - /subscriptions/<subscription_id>/resourceGroups/<resource_group_name>/providers/Microsoft.Network/dnszones/<dns_zone_name>
              enabled: false
              identity:
                clientID: <client_id>
                objectID: <object_id>
                resourceID: /subscriptions/<subscription_id>/resourcegroups/MC_<resource_group>_<cluster_name>_<location>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/webapprouting-<cluster_name>
              nginx:
                defaultIngressControllerType: AnnotationControlled
          kubernetesVersion: 1.32.10
          linuxProfile:
            adminUsername: azureuser
            ssh:
              publicKeys:
              - keyData: |
                  ssh-rsa <your-ssh-public-key>
          networkProfile:
            dnsServiceIP: 10.0.0.10
            loadBalancerSku: standard
            networkDataplane: cilium
            networkPlugin: azure
            networkPluginMode: overlay
            networkPolicy: cilium
            podCidr: 10.244.0.0/16
            serviceCidr: 10.0.0.0/16
          nodeResourceGroup: MC_<resource_group>_<cluster_name>_<location>
          oidcIssuerProfile:
            enabled: true
          powerState:
            code: Running
          securityProfile:
            workloadIdentity:
              enabled: true
          serviceMeshProfile:
            istio:
              components:
                ingressGateways:
                - enabled: true
                  mode: Internal
                - enabled: true
                  mode: External
              revisions:
              - asm-1-27
              - asm-1-28
            mode: Istio
          windowsProfile:
            adminUsername: azureuser
            enableCSIProxy: true
        sku:
          name: Base
          tier: Free
        type: Microsoft.ContainerService/managedClusters
      nodePools:
      - apiVersion: "2023-11-01"
        location: centralindia
        name: nplogs
        properties:
          count: 2
          enableAutoScaling: false
          enableEncryptionAtHost: false
          enableNodePublicIP: false
          kubeletConfig:
            containerLogMaxFiles: 2
          maxPods: 250
          mode: User
          nodeImageVersion: AKSUbuntu-2204gen2containerd-202601.13.0
          orchestratorVersion: 1.32.0
          osDiskSizeGB: 128
          osType: Linux
          type: VirtualMachineScaleSets
          upgradeSettings:
            maxSurge: 10%
          vmSize: Standard_DS2_v2
          vnetSubnetID: /subscriptions/<subscription_id>/resourceGroups/<resource_group>/providers/Microsoft.Network/virtualNetworks/<vnet_name>/subnets/<subnet_name>
        type: Microsoft.ContainerService/managedClusters/agentPools
      - apiVersion: "2023-11-01"
        location: centralindia
        name: nodepool1
        properties:
          count: 3
          creationData:
            sourceResourceId: /subscriptions/<subscription_id>/resourceGroups/<resource_group>/providers/Microsoft.ContainerService/snapshots/<snapshot_name>
          enableAutoScaling: true
          enableEncryptionAtHost: false
          enableNodePublicIP: false
          maxCount: 20
          maxPods: 250
          minCount: 1
          mode: System
          nodeImageVersion: AKSUbuntu-2204gen2containerd-202601.13.0
          orchestratorVersion: 1.32.10
          osDiskSizeGB: 128
          osType: Linux
          type: VirtualMachineScaleSets
          upgradeSettings:
            maxSurge: 10%
          vmSize: Standard_DS2_v2
          vnetSubnetID: /subscriptions/<subscription_id>/resourceGroups/<resource_group>/providers/Microsoft.Network/virtualNetworks/<vnet_name>/subnets/<subnet_name>
        type: Microsoft.ContainerService/managedClusters/agentPools
      - apiVersion: "2023-11-01"
        location: centralindia
        name: np2
        properties:
          count: 1
          creationData:
            sourceResourceId: /subscriptions/<subscription_id>/resourceGroups/<resource_group>/providers/Microsoft.ContainerService/snapshots/<snapshot_name>
          enableAutoScaling: false
          enableEncryptionAtHost: false
          enableNodePublicIP: false
          maxPods: 250
          mode: User
          nodeImageVersion: AKSUbuntu-2204gen2containerd-202601.13.0
          orchestratorVersion: 1.32.10
          osDiskSizeGB: 128
          osType: Linux
          type: VirtualMachineScaleSets
          upgradeSettings:
            maxSurge: 10%
          vmSize: Standard_DS2_v2
          vnetSubnetID: /subscriptions/<subscription_id>/resourceGroups/<resource_group>/providers/Microsoft.Network/virtualNetworks/<vnet_name>/subnets/<subnet_name>
        type: Microsoft.ContainerService/managedClusters/agentPools
      resourceGroupName: <resource_group>
  proxyconfig:
    enabled: true
    httpProxy: http://10.225.0.10:443/
    httpsProxy: http://10.225.0.10:443/
    noProxy: 10.0.0.0/16,localhost,127.0.0.1,ingress-controller-v1-controller-admission.rafay-system.svc,secretstore-webhook.rafay-system.svc,10.225.0.0/24,az-prox-26feb-dns-z9v3wwih.hcp.centralindia.azmk8s.io,10.244.0.0/16,10.224.0.0/12,169.254.169.254,.hcp.centralindia.azmk8s.io,168.63.129.16,konnectivity,k8master.service.consul,rafay-drift-v3.rafay-system.svc,dingdong,asd
  type: aks
```

Key sections in the example above demonstrate:

- **Key Vault Secret Provider CSI Driver**: Configured under `addonProfiles.azureKeyvaultSecretsProvider`
- **HTTP Proxy Configuration**: Defined in `httpProxyConfig` with `httpProxy`, `httpsProxy`, and `noProxy` settings
- **Web Application Routing Addon**: Configured under `ingressProfile.webAppRouting`
- **Istio Service Mesh Addon**: Configured under `serviceMeshProfile` with mode set to `Istio`
- **Custom Kubelet Config**: Defined per node pool under `kubeletConfig`
- **Snapshot ID Support**: Node pools can reference snapshots via `creationData.sourceResourceId`
- **Ubuntu Node Image**: Shown in `nodeImageVersion` as `AKSUbuntu-2204gen2containerd-*`

---

> **Important**
> Effective May 1, 2023, Microsoft has removed all Windows Server 2019 Docker images from the registry. Consequently, the Docker container runtime for Windows node pools has been retired. Although existing deployed nodepool will continue to function, scaling operations on existing windows nodepools are no longer supported. To maintain ongoing support and address this issue, it is recommended to create new node pools based on Windows instead of attempting to scale the existing ones
>
> For more information, you can refer to the [AKS release notes](https://github.com/Azure/AKS/releases/tag/2023-06-04).

---

## Node Pool Availability

Once the conversion is complete, the details about the managed node pool and actions are available for the users.

[![Import Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_node_pool_avail.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/aks_node_pool_avail.png)

> **Important**
> For post conversion (**Day 2**) operations, refer [here](https://docs.rafay.co/clusters/aks/day-2-ops/)

---

## Delete Imported Managed Cluster(s)

When the user deletes the imported managed cluster, the controller deletes the following resources in the Azure account.

- Managed and self managed node pools created through controller and the underlying resources
- Managed node pools that got imported with the cluster and its underlying resources
- AKS cluster itself

The below resources are not deleted:

- The self managed node pools and their underlying resources that were **not** created through the controller
- The underlying control plane resources

---

## RCTL to Convert AKS Imported Cluster(s)

Users can use the RCTL CLI to convert imported AKS clusters to managed.

```
./rctl convert2managed cluster aks <controller-cluster-name> --source-cluster <imported-cluster> --resource-group <resource_group-name> --credential <credential_name>
```

---

## RCTL to Delete AKS Imported Cluster(s)

Users can use the RCTL CLI to delete imported AKS clusters.

```
./rctl delete cluster <imported-cluster>
```

---
