---
title: "KOP AKS Clusters - Deprovision"
source: https://docs.rafay.co/clusters/aks/deprovision/
category: Home
---

# Deprovision

## Remove AKS Cluster

Cluster Deletion UX Enhancement

To deprovision a provisioned/managed Azure AKS cluster,

- Click on Settings icon on the far right of the cluster and select **Delete**
- Select **Delete Cluster Completely** to delete cluster object from Rafay controller and all associated resources from the provider
- Select **Delete Cluster Object Only** to delete cluster from Rafay controller only
- Select/enter the cluster name and click **Delete this Cluster**

[![Remove AKS Cluster](https://docs.rafay.co/clusters/aks/img/deprovision/remove_aks_cluster.png)](https://docs.rafay.co/clusters/aks/img/deprovision/remove_aks_cluster.png)

Once the delete request is submitted, the message below will be displayed, and the deletion process might take up to 20 minutes.

[![Remove AKS Cluster](https://docs.rafay.co/clusters/aks/img/deprovision/delete_akscluster.png)](https://docs.rafay.co/clusters/aks/img/deprovision/delete_akscluster.png)

Users can view the cluster deletion status on the cluster dashboard, as shown below.

[![Remove AKS Cluster Progress](https://docs.rafay.co/clusters/aks/img/deprovision/aks_clusterdelete.png)](https://docs.rafay.co/clusters/aks/img/deprovision/aks_clusterdelete.png)

---
