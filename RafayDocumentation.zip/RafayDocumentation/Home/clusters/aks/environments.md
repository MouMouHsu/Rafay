---
title: "KOP AKS Clusters - Supported Versions"
source: https://docs.rafay.co/clusters/aks/environments/
category: Home
---

# Supported Environments

Please review the information listed below to understand the supported versions.

---

## Kubernetes Versions

The following versions of Kubernetes are currently supported. New AKS clusters can be provisioned using the following Kubernetes versions. Existing AKS clusters managed by the controller can be upgraded in-place to the following Kubernetes versions.

> **Important**
> Customers are strongly recommended to upgrade their AKS clusters to a recent supported version to ensure they continue to receive patches and security updates.

| Kubernetes Version | Official EOL Date | 'New Cluster Provisioning' & 'Convert to Managed' support added with Controller release version | 'In-place upgrade' support added with Controller release version |
| --- | --- | --- | --- |
| v1.36.x | Jun 2027 | v4.2 Update 4 | v4.2 Update 4 |
| v1.35.x | Mar 2027 | v4.2 | v4.2 |
| v1.34.x | Nov 2026 | v4.1 | v4.1 |
| v1.33.x | May 2026 | v3.7 | v3.7 |
| v1.32.x | Mar 2025 | v3.5 | v3.5 |
| v1.31.x | Nov 2025 | v3.5 | v3.5 |
| v1.29.x | Jan 2025 | v2.6 | v2.6 |
| v1.28.x | Nov 2024 | v2.3 | v2.3 |
| v1.27.x | Jul 2024 | v1.28 | v2.0 |
| v1.26.x | Mar 2024 | v1.26 | v1.26 |
| v1.25.x | Dec-2023 | v1.23 | v1.23 |
| v1.24.x | July-2023 | v1.23 | v1.23 |

---
