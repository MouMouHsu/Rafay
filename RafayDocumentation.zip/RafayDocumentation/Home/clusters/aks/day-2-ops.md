---
title: "KOP AKS Clusters - Day-2 Operations Support"
source: https://docs.rafay.co/clusters/aks/day-2-ops/
category: Home
---

# Day-2 Operations

## Day-2 Operations Support

Following are the post conversion (**Day 2**) operations supported on imported Azure AKS clusters that are converted to managed:

- Kubernetes Upgrades
  - Control Plane
  - Node pool
- Node Pools
  - Add node pools
  - Scale node pools
  - Node Auto Provisioning
- Workload Identity
  - Create or delete workload identity
  - Add or delete role assignments
  - Add or delete service accounts
  - Update workload identity tags
- Update
  - Blueprints
  - Cloud providers
  - Control plane labels
  - Control plane tags
  - Update node pool Labels and Taints
  - Rafay labels
  - Toleration, Node-Selectors, and Daemonset override
- Delete
  - Cluster
  - Node pool

---
