---
title: "V1 Config Schema"
source: https://docs.rafay.co/clusters/aks/aks_schema/
category: Home
---

# AKS Schema

Cluster configuration for AKS clusters
