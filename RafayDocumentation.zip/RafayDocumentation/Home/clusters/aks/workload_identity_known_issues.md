---
title: "KOP AKS Clusters - Workload Identity - Known Issues"
source: https://docs.rafay.co/clusters/aks/workload_identity_known_issues/
category: Home
---

# Known Issues

## Overview

This page serves as a resource for reviewing and staying updated on the known issues associated with the Workload Identity feature. We will update this page as issues are resolved to provide you with the most current information.

## Known Issues for 2.10 Release

| **Issue** | **Description** | **Workaround** |
| --- | --- | --- |
| Service Account and Workload Identity Takeover | Importing an AKS cluster into Rafay and converting it to a managed cluster does not support takeover of existing service accounts and workload identity. | No workaround available. Consider creating new service accounts and workload identity post cluster takeover. |
| Role Assignment Failure | If role assignment is misconfigured or there is a typo during cluster creation, the cluster will fail with **POST CLUSTER CREATION ACTIONS FAILED** and "unable to fetch the given role." To resolve, recreate the cluster with the correct role assignment. | Ensure correct role assignments before cluster creation. |
| Terraform Diff Issue | Ensure service account information is added at the end of existing service accounts to avoid ordering issues in Terraform diff. | Review and adjust the order of service account entries in your Terraform configuration. |
| Workload Identity Configuration | Adding existing workload identity configurations to a takeover cluster on Day 2 is not supported. | Create a new workload identity configuration instead of adding the existing one on Day 2. |
| Updating Service Account Labels and Annotations | Updating the labels or annotations of existing service accounts is not supported on Day 2 | No workaround available in Day 2. Make sure all labels and annotations are properly configured during Day 0. |

---
