---
title: "V3 Config Schema"
source: https://docs.rafay.co/clusters/aks/aksv3_schema/
category: Home
---

# AKS Schema (Recommended)

V3 Cluster configuration for AKS clusters
