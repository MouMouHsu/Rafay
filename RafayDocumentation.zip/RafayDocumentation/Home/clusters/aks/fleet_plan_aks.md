---
title: "KOP Fleet Plan - Overview"
source: https://docs.rafay.co/clusters/aks/fleet_plan_aks/
category: Home
---

# Fleet Operations

Fleet Plan enables an efficient scalable solution to perform operations across many clusters. With Fleet Plan, users can effortlessly perform a wide range of operations such as upgrades, backups, patch, and scaling. It includes in-built workflows with pre/post hooks and fine-grained cluster targeting empowering platform engineering teams to orchestrate operations in a generic manner.

> **Info**
> Learn more about Fleet Operations [here](https://docs.rafay.co/clusters/fleetplan/overview/).

---
