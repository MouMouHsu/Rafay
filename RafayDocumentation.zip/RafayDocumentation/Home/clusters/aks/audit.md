---
title: "KOP AKS Clusters - Audit"
source: https://docs.rafay.co/clusters/aks/audit/
category: Home
---

# Audit

## Audit Logs

All actions performed on the Amazon AKS cluster right from initial configuration, provisioning, nodegroup actions and deletion are AUDITED.

- Login to the Controller and click **System** drop-down from the main dashboard menubar
- Select **Audit Logs**. By default, Audit Logs page appears with the list of actions performed in the last one hour
- Users can search for the required logs using various filters such as Projects, Types, User, Client, and Time Range
- Use **Clear Filters** to remove the applied filters or **Refresh** to view the latest updates
- Use **Export** to export the audit log file in a **csv** format

[![Audit Trail Nodegroup Actions](https://docs.rafay.co/clusters/aks/img/auto_AKS/audit_logs.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/audit_logs.png)

**KUBECTL Logs** - To view the actions performed through Kubectl, click **KUBECTL** - To view the application/workload/pod that violates OPA policy, click **OPC** to view those logs

The audit trail is presented to administrators in a reverse chronological format.

---
