---
title: "AKS Clusters - Cross-Subscription Provisioning"
source: https://docs.rafay.co/clusters/aks/cross_subscription/
category: Home
---

# Cross-Subscription Provisioning

## Overview

Rafay now supports provisioning AKS clusters across multiple Azure subscriptions using a single Service Principal credential. This enables centralized identity management while deploying to different target subscriptions, so no longer need to create a separate Azure credential per subscription.

## How It Works

1. Store Service Principal credentials (`tenant_id`, `subscription_id`, `client_id`, `client_secret`) in one Azure cloud credential in Rafay. All four fields are required when creating the credential.
2. Grant the Service Principal the appropriate RBAC role (e.g., **Contributor**) in each target subscription where clusters will be provisioned.
3. When creating a cluster, set `subscriptionID` in the cluster config spec to override the credential's default subscription and deploy to a different target subscription.

If `subscriptionID` is omitted from the cluster spec, the cluster is provisioned in the subscription associated with the credential, as before. Setting it is only necessary when the credential's subscription and the target deployment subscription differ.

> **Note**
> Supported through Terraform, CLI (RCTL), and **Save & Customize** in the UI.

## Where to Set It

`subscriptionID` is a field under the AKS cluster config spec:

```
apiVersion: infra.k8smgmt.io/v3
kind: Cluster
metadata:
  name: my-aks-cluster
  project: my-project
spec:
  blueprintConfig:
    name: minimal
  cloudCredentials: my_azure_credential
  type: aks
  config:
    kind: aksClusterConfig
    metadata:
      name: my-aks-cluster
    spec:
      managedCluster:
        # ... managed cluster properties ...
      nodePools:
        # ... node pool definitions ...
      resourceGroupName: my-rg
      subscriptionID: e56d2d8d-c85b-4672-a5b6-fd9c9d94f042   # overrides the credential's subscription
```

## Key Requirement

The Service Principal used in the Azure credential must have appropriate RBAC access (e.g., **Contributor**) in the target subscription. Once granted, the `subscriptionID` set in the cluster spec correctly directs resource deployment to that subscription, rather than being limited to the credential's own subscription.

## Limitation

**Day-2 operation is not supported for this field.** Once a cluster is created, `subscriptionID` cannot be changed. To move a cluster to a different subscription, it must be recreated with the new `subscriptionID`.

## Use Case Example

An organization manages three environments, dev, staging, and prod, each isolated in its own Azure subscription for billing and access control reasons.

1. Create a single Azure Service Principal and register it once as an Azure credential in Rafay, using the subscription ID of, say, the dev subscription as the credential's default.
2. Grant that same Service Principal the Contributor role in the staging and prod subscriptions as well (in addition to dev).
3. Provision the dev cluster as usual, without setting `subscriptionID`, so it deploys into the credential's default subscription.
4. Provision the staging and prod clusters using the same credential, but set `subscriptionID` in each cluster's config spec to the staging or prod subscription ID respectively, so each cluster lands in the correct subscription.

The result is one centrally managed identity (Service Principal) controlling access across all three subscriptions, while cluster placement is controlled per-cluster via `subscriptionID`, keeping environments isolated at the subscription level without the overhead of managing a separate credential per subscription.

---
