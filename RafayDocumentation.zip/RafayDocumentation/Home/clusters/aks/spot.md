---
title: "KOP AKS Clusters - Spot Instance"
source: https://docs.rafay.co/clusters/aks/spot/
category: Home
---

# Spot Price

The cluster administrators can significantly save costs by simplifying the use of AKS Spot Instances on Azure Clusters. Specifically, users are allowed to implement and codify a number of best practices associated with using Spot Instances such as diversification, automated interruption handling, and leveraging Auto Scaling groups to acquire capacity.

---

## Overview

Spot Instance Price are spare Azure capacity that are offered at significantly lower costs compared to On-Demand instances. Spot capacity is split into pools determined by instance type, Availability Zone (AZ), and AKS Region.

Spot Instance pricing can change based on supply and demand of a particular Spot capacity pool. A Spot instance pool is a set of unused Azure instances with the same instance type (e.g. m5.xlarge), operating system and AZ.

Spot Instances can be available at up to a 90% discount. Azure publishes a ["Spot Instance Advisor"](https://docs.microsoft.com/en-us/azure/virtual-machines/spot-vms) where they publish spot instance policies, limitations and pricing for various instance types. An illustrative example shown below.

[![Spot Instance Advisor](https://docs.rafay.co/clusters/aks/img/spot_price/spot_price_policy.png)](https://docs.rafay.co/clusters/aks/img/spot_price/spot_price_policy.png)

---

## Spot Instance Price

To use Spot Instance Price, enable the check-box **Enable Spot Price** in the Node Group configuration

Users can set a Spot Max Price in scenarios where they want to set maximum budget

[![Spot Instance Advisor](https://docs.rafay.co/clusters/aks/img/spot_price/enable_spotprice.png)](https://docs.rafay.co/clusters/aks/img/spot_price/enable_spotprice.png)

> Note: Regardless of Max Price, spot instances will still be charged at the current spot market price

---

---
