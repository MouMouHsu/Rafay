---
title: "KOP AKS Clusters - Auto Upgrade"
source: https://docs.rafay.co/clusters/aks/auto_upgrade/
category: Home
---

# Auto Upgrade Clusters and Node OS

## Overview

The Auto Upgrade Settings feature simplifies the management of Kubernetes cluster and node operating system upgrades by providing customizable automation options. The Upgrade Channel enables users to choose a preferred Kubernetes upgrade strategy, such as applying patch-level upgrades, opting for rapid or stable updates, or disabling automatic upgrades entirely. Similarly, the Node OS Upgrade Channel handles operating system updates for nodes by offering options ranging from fully manual control to automated updates, including unmanaged OS patching, security patch applications, or weekly node image updates.

Users can also specify a Schedule Type for both cluster and node upgrades, ensuring that updates occur at convenient times or are left unscheduled for manual execution. This intuitive interface empowers users to tailor upgrade settings to meet their operational requirements, enhancing efficiency while ensuring cluster stability and reliability.

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/upgrade_settings.png)](https://docs.rafay.co/clusters/aks/img/provisioning/upgrade_settings.png)

> **Did you know ?**
> Workload Identity can be managed through various methods:
>
> - [UI](https://docs.rafay.co/clusters/aks/auto_upgrade/#auto-upgrade-via-ui)
> - [CLI](https://docs.rafay.co/clusters/aks/auto_upgrade/#auto-upgrade-via-rctl)
> - [Terraform - V3 and V1](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/aks_cluster_v3)
> - [GitOps](https://docs.rafay.co/gitops/stages/system_sync/)
> - [Rafay-hub APIs](https://docs.rafay.co/automation/api/apis/)

## Auto Upgrade Via UI

### Cluster Upgrade Channel

When selecting an Upgrade Channel, the following options are available:

- Disabled (Default)
- Enabled with patch (Recommended)
- Enabled with stable
- Enabled with rapid
- Enabled with node image

Users can modify these settings based on their organization's upgrade strategy, ensuring a balance between stability and access to the latest features.

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/cluster_upgrade.png)](https://docs.rafay.co/clusters/aks/img/provisioning/cluster_upgrade.png)

The Cluster Upgrade Channel offers flexible scheduling options to align updates with your operational needs. Users can choose from predefined schedules such as **Every week on Sunday, 1st of every month, First Sunday of every month, Custom, or No Schedule**.

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/cluster_schedule.png)](https://docs.rafay.co/clusters/aks/img/provisioning/cluster_schedule.png)

#### Add Maintenance Scheduler Configuration

Once a schedule type is selected, the edit/delete icon appears, allowing users to provide additional schedule information on **Add Maintenance Scheduler Configuration** page, as shown below. The configuration varies for each schedule type. Below is an example of the "Enabled with patch (Recommended)" cluster upgrade channel with the schedule type set to "1st of every month."

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/add_schedules.png)](https://docs.rafay.co/clusters/aks/img/provisioning/add_schedules.png)

Click **Save**

### Node OS Upgrade Channel

When selecting a Node OS Upgrade Channel, the following options are available:

- Disabled (Default)
- Unmanaged
- Security Patch
- Node Image

Users can modify these settings to manage node operating system updates according to their operational requirements, balancing automation and control.

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/node_options.png)](https://docs.rafay.co/clusters/aks/img/provisioning/node_options.png)

The Node OS Upgrade Channel also provides flexible scheduling options to determine when OS updates are applied. Users can choose from predefined schedules such as **Daily, Every week on Sunday, 1st of every month, First Sunday of every month, Custom, or No Schedule**.

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/node_schedule.png)](https://docs.rafay.co/clusters/aks/img/provisioning/node_schedule.png)

> ⚠️ Important: If the Node OS Upgrade Channel is configured with a schedule, the upgrade applies to all nodes in the cluster. It is not possible to set this configuration for individual nodes. This ensures a bulk upgrade for all nodes in the cluster.

#### Add Maintenance Scheduler Configuration

Once a schedule type is selected, the edit/delete icon appears, allowing users to provide additional schedule information on **Add Maintenance Scheduler Configuration** page, as shown below. The configuration varies for each schedule type. Below is an example of the "Enabled with patch (Recommended)" cluster upgrade channel with the schedule type set to "1st of every month."

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/node_sett.png)](https://docs.rafay.co/clusters/aks/img/provisioning/node_sett.png)

> ⚠️ Important: When setting the node schedule type to Date-Monthly or Day-Monthly on the Add Maintenance Scheduler Configuration page, the schedule frequency is capped at a maximum of one (1) month per Security Channel specifications and cannot be changed.

Click **Save**

---

### Save and Customize view

Once the required details are provided, clicking Save & Customize displays the configuration specification, including the maintenance configurations set in the Auto Upgrade settings page. This includes schedules for cluster upgrades and node OS upgrades, along with the autoUpgradeProfile settings, as shown in the following example:

```
autoUpgradeProfile:
  nodeOsUpgradeChannel: Unmanaged
  upgradeChannel: patch
```

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/customize_node.png)](https://docs.rafay.co/clusters/aks/img/provisioning/customize_node.png)

> ⚠️ Important: If no selections are made for the cluster and OS upgrade channels, both settings default to "Disabled", and the schedule will be set to "No schedule". In this case, the cluster specification will not include maintenance configurations, and autoUpgradeProfile will be set to none, as shown in the following example:
> autoUpgradeProfile:
>   nodeOsUpgradeChannel: None
>   upgradeChannel: none

Once all the required configurations are made, users can proceed with cluster provisioning.

### Day 2 Operations

Once the upgrade channel is set during Day 0 operations and the cluster is provisioned, users can adjust the upgrade channel and schedule for both clusters and Node OS on **Day 2** in the Cluster Configuration page. This allows them to keep the environment up-to-date based on their needs, ensuring that upgrades occur at convenient times, security patches are applied, and the system can adapt to changing requirements, all while minimizing disruptions.

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/day2_schedule.png)](https://docs.rafay.co/clusters/aks/img/provisioning/day2_schedule.png)

#### Sync Operation

The **SYNC** button on this configuration page allows syncing the Kubernetes version of clusters with the version reported by Azure. This is particularly useful when an out-of-band upgrade or auto-upgrade has occurred, as the cluster configuration does not automatically update with the upgraded Kubernetes version. By clicking the SYNC button, the upgraded version is reflected in the cluster configuration. Additionally, It is mandatory to edit the Terraform configuration to reflect the synchronized version to ensure consistency before proceeding with any further manual upgrades

[![Cluster Provisioning](https://docs.rafay.co/clusters/aks/img/provisioning/sync_button.png)](https://docs.rafay.co/clusters/aks/img/provisioning/sync_button.png)

---

## Auto Upgrade Via RCTL

Auto-upgrades can be performed as both **Day-0** and **Day-2** operations via RCTL, [Terraform](https://docs.rafay.co/automation/tf/overview/) and [GitOps](https://docs.rafay.co/gitops/overview/). Below is an example of an AKS cluster for Managed Auto-upgrade configuration.

```
apiVersion: infra.k8smgmt.io/v3
kind: Cluster
metadata:
  modifiedAt: "2024-06-23T09:32:23.454579Z"
  name: demo-aks-cluster
  project: defaultproject
spec:
  blueprintConfig:
    name: default-aks
  cloudCredentials: aks1
  config:
    kind: aksClusterConfig
    metadata:
      name: demo-aks-cluster
    spec:
      maintenanceConfigurations:
      - apiVersion: "2024-01-01"
        name: aksManagedAutoUpgradeSchedule
        properties:
          maintenanceWindow:
            durationHours: 6
            schedule:
              weekly:
                dayOfWeek: Monday
                intervalWeeks: 1
            startDate: "2024-06-23"
            startTime: "12:00"
        type: Microsoft.ContainerService/managedClusters/maintenanceConfigurations
      managedCluster:
        apiVersion: "2024-01-01"
        identity:
          type: SystemAssigned
        location: centralindia
        properties:
          apiServerAccessProfile:
            enablePrivateCluster: false
          autoUpgradeProfile:
            nodeOsUpgradeChannel: None
            upgradeChannel: patch
          dnsPrefix: demo-aks-cluster-dns
          enableRBAC: true
          kubernetesVersion: 1.27.9
          networkProfile:
            loadBalancerSku: standard
            networkPlugin: kubenet
            networkPolicy: calico
          powerState:
            code: Running
        sku:
          name: Base
          tier: Free
        type: Microsoft.ContainerService/managedClusters
      nodePools:
      - apiVersion: "2024-01-01"
        name: primary
        properties:
          count: 2
          enableAutoScaling: true
          maxCount: 2
          maxPods: 110
          minCount: 2
          mode: System
          orchestratorVersion: 1.27.9
          osType: Linux
          type: VirtualMachineScaleSets
          vmSize: Standard_B4ms
        type: Microsoft.ContainerService/managedClusters/agentPools
      resourceGroupName: demo-rg
  type: aks
```

In this example, we have configured the `maintenanceConfiguration` and `autoUpgradeProfile` (`nodeOsUpgradeChannel`, and `upgradeChannel`). Users can specify the name as either `aksManagedAutoUpgradeSchedule`, `aksManagedNodeOSUpgradeSchedule`, or `default`, as per the requirement.

**Planned Maintenance Configuration**

AKS supports scheduled auto-upgrades through planned maintenance configurations. This feature allows for automatic execution of both AKS-initiated and user-initiated maintenance operations according to a chosen cadence. While scheduled maintenance can be used to time automatic upgrades, enabling or disabling planned maintenance does not affect the availability of automatic upgrades.

**Node OS Images and K8s Version**

AKS offers multiple auto-upgrade channels for timely node-level OS security updates. These channels provide flexibility and a customized strategy for managing node-level OS security.

- `nodeOsUpgradeChannel`: The multiple auto-upgrade channels for NodeImageVersion are:
  - None: No automatic upgrades are performed
  - Unmanaged: Allows manual control over upgrades
  - NodeImage: Offers updates to the entire node image
  - SecurityPatch: Focuses on timely security updates
- `upgradeChannel`: This parameter enables simultaneous auto-upgrade of the Kubernetes version for both the control plane and attached node pools. The supported values are rapid, stable, patch, node-image, none. This ensures clusters are consistently updated with the latest features and patches from AKS.

> **Important**
> - To configure the Maintenance Configuration, the API version must be equal to or greater than `2023-05-01`
> - The SecurityPatch channel is not supported on Windows OS node pools
> - Setting the upgradeChannel to 'node-image' automatically sets the nodeOSUpgradeChannel to 'NodeImage' if the apiVersion is `2023-11-02-preview` or later
> - `nodeOsUpgradeChannel` is supported starting from API version `2023-06-01` and later
> - To perform Day 2 operations on the `autoUpgradeProfile`, please specify both `upgradeChannel` and `nodeOsUpgradeChannel`

---
