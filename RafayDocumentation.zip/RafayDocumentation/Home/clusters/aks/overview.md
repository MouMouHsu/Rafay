---
title: "KOP AKS Clusters - Overview"
source: https://docs.rafay.co/clusters/aks/overview/
category: Home
---

# Overview

Microsoft's [Azure Kubernetes Service (AKS)](https://azure.microsoft.com/en-us/services/kubernetes-service/) is a fully managed Kubernetes service provided by Microsoft.

---

## Automation Options

The below matrix presents a breakdown of actions like creation, updating, and deletion of AKS Clusters and Nodepools across multiple deployment methods: interactive UI, declarative RCTL commands, API-driven automation, and Terraform.

| Resources | Deployment Method | Create | Upgrade | Delete |
| --- | --- | --- | --- | --- |
| Cluster | UI | [Yes](https://docs.rafay.co/clusters/aks/provisioning/#create-cluster) | [Yes](https://docs.rafay.co/clusters/aks/upgrades/) | [Yes](https://docs.rafay.co/clusters/aks/deprovision/) |
|  | CLI | [Yes](https://docs.rafay.co/clusters/aks/declarative/cli/#create-cluster) | [Yes](https://docs.rafay.co/clusters/aks/declarative/cli/#cluster-upgrade) | [Yes](https://docs.rafay.co/clusters/aks/declarative/cli/#delete-cluster) |
|  | API Automation | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) |
|  | Terraform | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/aks_cluster) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/aks_cluster) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/aks_cluster) |
| Node pool | UI | [Yes](https://docs.rafay.co/clusters/aks/provisioning/#node-pools-settings-optional) | [Yes](https://docs.rafay.co/clusters/aks/upgrades/#node-pool-upgrade) | [Yes](https://docs.rafay.co/clusters/aks/upgrades/#delete-nodepool) |
|  | CLI | [Yes](https://docs.rafay.co/clusters/aks/declarative/cli/#create-nodepool_1) | [Yes](https://docs.rafay.co/clusters/aks/declarative/cli/#cluster-node-pool-upgrade) | [Yes](https://docs.rafay.co/clusters/aks/declarative/cli/#delete-nodepool) |
|  | API Automation | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) |
|  | Terraform | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/aks_cluster) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/aks_cluster) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/aks_cluster) |

---

## AKS Lifecycle Management

Users can leverage the native integration with Microsoft Azure to

- Provision and manage the lifecycle of their AKS Clusters in any Azure region right from the Controller.
- Create and maintain version controlled cluster specifications in your Git Repositories.
- Use the declarative, cluster specifications to provision AKS clusters with a high level of automation.

> **Did you know ?**
> AKS Cluster Lifecycle can be managed through various methods:
>
> - [UI](https://docs.rafay.co/clusters/aks/provisioning/#self-service-wizard)
> - [CLI](https://docs.rafay.co/clusters/aks/declarative/cli/#declarative)
> - [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/aks_cluster)
> - [GitOps](https://docs.rafay.co/gitops/stages/system_sync/)

---

## Getting Started

We have quick start exercise to explore the platform's capabilities for "Lifecycle Management" of AKS Clusters.

[Step by Step Guide](https://docs.rafay.co/learn/quickstart/aks/clusterlifecycle/overview/)

---
