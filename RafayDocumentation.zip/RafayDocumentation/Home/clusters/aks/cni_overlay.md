---
title: "KOP AKS Clusters - Azure CNI Overlay"
source: https://docs.rafay.co/clusters/aks/cni_overlay/
category: Home
---

# Azure CNI Overlay

## Overview

The traditional Azure CNI method for assigning IP addresses to pods can lead to challenges such as IP address planning, address exhaustion, and difficulties in scaling clusters. To overcome these issues, Azure CNI overlay assigns IP addresses from a separate CIDR range. This approach enhances scalability and address utilization by segregating pod IP addresses into an overlay network. It simplifies IP address management and facilitates efficient interpod communication and external traffic routing, while preventing operational overhead. Additionally, overlay pods do not use IP addresses from the virtual network subnet, freeing up space for more pods and enabling the building of larger clusters with more nodes. The overlay network address space can also be used for other clusters, allowing administrators to pack more pods into a cluster and reuse resources efficiently.

Azure CNI Overlay Cluster Lifecycle can be managed through various methods:

- [UI](https://docs.rafay.co/clusters/aks/provisioning/#cluster-settings-optional)
- [RCTL CLI](https://docs.rafay.co/clusters/aks/declarative/infra_gitops_rctl_aks_examples/)
- [Terraform](https://docs.rafay.co/automation/tf/overview/)
- [GitOps System Sync](https://docs.rafay.co/gitops/stages/system_sync/)
- [Swagger API (V1 & V3)](https://docs.rafay.co/clusters/eks/api/)

---

## Limitations

Azure CNI Overlay entails the following limitations:

- Application Gateway cannot be used as an Ingress Controller (AGIC) for an Overlay cluster
- Overlay configurations do not support Virtual Machine Availability Sets (VMAS)
- The use of DCsv2-series virtual machines in node pools is prohibited. Consider utilizing DCasv5 or DCadsv5-series confidential VMs to meet Confidential Computing requirements
- When deploying the cluster using your own subnet, ensure that the names of the subnet, VNET, and resource group containing the VNET are 63 characters or fewer. These names will be utilized as labels in AKS worker nodes and must adhere to Kubernetes label syntax rules

---
