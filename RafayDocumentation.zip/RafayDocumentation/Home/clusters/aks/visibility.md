---
title: "KOP AKS Clusters - Visibility and Monitoring"
source: https://docs.rafay.co/clusters/aks/visibility/
category: Home
---

# Visibility and Monitoring

The Controller provides an integrated dashboard that provides cluster administrators with detailed visibility and insight into the Azure AKS Cluster.

Multiple dashboards are provided to help the user manage the resources on the cluster effectively.

- Cluster Dashboard
- Node Dashboard
- Node Group Dashboard
- Kubernetes Resources Dashboard
- Pod Dashboard

---

## Dashboards

### Multi Cluster View

Navigate to the Rafay Project where the AKS Cluster is provisioned. A cluster card for all managed clusters is available to the user with "At a Glance" metrics . Note that the information in the cluster card is similar for all cluster types.

[![AKS Cluster Card](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/provisioned_akscluster.png)](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/provisioned_akscluster.png)

---

### Cluster Dashboard

Click on the cluster name to view the cluster dashboard for the Azure AKS Cluster.

The information presented in the cluster dashboard for Azure AKS Clusters is generally similar for all types of clusters. Look at [Cluster Dashboard](https://docs.rafay.co/dashboard/cluster/) for additional details about this feature.

[![AKS Dashboard](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/clus_dashboard.png)](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/clus_dashboard.png)

---

### Nodepool Dashboard

Users can view latest status and details of each AKS node pools by clicking on the node pool name. An example is shown below.

[![Node Pools Details](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/aks_nodepool_details.png)](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/aks_nodepool_details.png)

---

### Node Dashboard

Users can view latest status and details of each worker node by expanding the node's card. An example is shown below.

[![Worker Node Details](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/aks_node_details.jpg)](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/aks_node_details.jpg)

Click **Overview** for a worker node to view the Worker Node Dashboard

[![Worker Node Dashboard](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/aks_nodes_dashboard.png)](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/aks_nodes_dashboard.png)

---

### k8s Resources Dashboard

Users can view all the Kubernetes resources and their state on the cluster via an [integrated k8s resources dashboard](https://docs.rafay.co/dashboard/k8sresources/) provided on the Rafay Console.

---

### Pod Dashboard

Users can view a detailed dashboard for every pod operational on the cluster via an [integrated pod dashboard](https://docs.rafay.co/dashboard/pod_dashboard/) provided on the controller.

---

### Cluster Configuration

Once an Azure AKS cluster has been provisioned by the Controller, admins can view the cluster's configuration by selecting the **Configuration** tab.

[![Cluster Configuration](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/cluster_configuration.png)](https://docs.rafay.co/clusters/aks/img/visibility_monitoring/cluster_configuration.png)

---
