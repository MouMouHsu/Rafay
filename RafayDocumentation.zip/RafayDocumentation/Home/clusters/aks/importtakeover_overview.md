---
title: "KOP Takeover - AKS Import and Takeover"
source: https://docs.rafay.co/clusters/aks/importtakeover_overview/
category: Home
---

# AKS Import and Takeover

## Overview

Organizations often operate AKS (Azure Kubernetes Service) clusters that were provisioned outside the Rafay platform—whether manually through the Azure Portal, via scripts, or using infrastructure-as-code tools. While these clusters may be functional, they typically lack centralized governance, lifecycle automation, and operational visibility.

The **AKS Import and Takeover** feature enables platform teams to import these existing AKS clusters into the Rafay platform and bring them under full lifecycle management using **Environment Manager**. This eliminates the need to reprovision clusters and enables teams to manage both new and existing infrastructure through a single control plane.

---

## What is AKS Import and Takeover?

The **AKS Import and Takeover** feature allows users to connect to an existing AKS cluster in their Azure subscription and onboard it into the Rafay platform as a managed **Environment**.

This is accomplished using a prebuilt system template that:

- Connects securely to Azure using service principal credentials.
- Discovers the cluster’s configuration.
- Automatically creates a corresponding Environment in Rafay populated with the relevant metadata.

Once imported, the cluster is treated like any other Rafay-managed resource and can take advantage of features such as blueprint application, RBAC enforcement, logging, monitoring, and lifecycle operations.

---

## Why Use It?

The AKS Cluster Import and Takeover workflow simplifies bringing existing AKS clusters under Rafay’s centralized management. It uses predefined templates (aks-import-cluster and system-aks-takeover) to automate the discovery, setup, and finalization of the cluster, reducing manual effort.

**Key Benefits**

- Simplified Process: Automated steps for discovering and registering the AKS cluster.
- Centralized Management: Full lifecycle management of AKS clusters within Rafay.
- Customizable: Configurable parameters to meet specific infrastructure needs.
- Clear Status Tracking: Provides visibility throughout the process with status updates.
- Security: Uses secure Azure Service Principal authentication.
- Efficiency: Reduces setup time and manual effort.

This workflow enables quick and secure integration of AKS clusters into Rafay, ensuring centralized control and easier management.

---
