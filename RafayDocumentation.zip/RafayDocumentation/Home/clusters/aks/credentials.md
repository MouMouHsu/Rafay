---
title: "KOP AKS Clusters - Credentials"
source: https://docs.rafay.co/clusters/aks/credentials/
category: Home
---

To provision an AKS cluster, create credentials in the controller using the Azure configuration details.

# Prerequisites

To manage AKS (Azure Kubernetes Service) using Rafay Controller, ensure you have completed the following steps:

1. **Enable AKS Service:** Confirm that the AKS service is enabled for your Azure Subscription.
2. **Authentication parameters :** you need below authentication parameters.The Creation of Service Principal in Azure will return The Client ID,Client Secret and Tenant.
  - Azure Subscription ID
  - Tenant ID
  - Client ID
  - Client Secret
3. **Service Principal Setup:** For detailed instructions, refer to [Azure Service Setup](https://docs.rafay.co/clusters/aks/azure_setup/).

If you prefer to use a **Service Principal (SPN)** for Rafay Cloud credentials and **managed identities** for other resources, this is a more preferable and secure approach. Managed identities are automatically managed by Azure, reducing the need for explicit credential management.

### Why Managed Identity?

- No expiration date issues.
- No credential rotation hassle.

### How to Use Managed Identity

Follow this document on [Managed Identity](https://docs.rafay.co/clusters/aks/roles-identities/) and the restricted roles necessary for creating an AKS cluster.

## Step 1: Add Cloud Credential

- Login to the Console and click **Infrastructure**
- Select **Cloud Credentials** and click **New Credential**
- Provide a unique name and select the type **Cluster Provisioning**
- Select **AZURE** from the Provider drop-down
- Select **Service_Principal** from the Credential Type
- Enter the **Tenant ID**, **Subscription ID**, **Client ID**, and **Client Secret**
- Click **Save**

| Parameter | Definition |
| --- | --- |
| Subscription ID | Azure Subscription ID, associated with an Azure Subscription |
| Tenant ID | A Globally Unique Identifier (GUID) that is different than your organization name or domain. |
| Client ID | An ID used to associate your application with Azure AD at runtime |
| Client Secret | Azure Active Directory Client Secret |

[![New Cloud Credential](https://docs.rafay.co/clusters/aks/img/credentials_AKS/add_credentials.png)](https://docs.rafay.co/clusters/aks/img/credentials_AKS/add_credentials.png)

## Step 2: View Cloud credentials

On successful addition of cloud credentials, user can view the list of in the Cloud Credentials main page

[![New Cloud Credential](https://docs.rafay.co/clusters/aks/img/credentials_AKS/cloud_credentials_view.jpg)](https://docs.rafay.co/clusters/aks/img/credentials_AKS/cloud_credentials_view.jpg)

### Manage Cloud Credentials

- Click **Manage Sharing** to share this credentials with either **None** or **All Projects** or **Specific Projects**. By default, **None** is selected
- Click **Edit** icon to make any changes to the existing credentials
- Click **Validate** icon to validate the credentials based on the data provided
- Click **Delete** to delete the existing credentials
