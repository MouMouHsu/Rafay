---
title: "KOP AKS Clusters - Overview"
source: https://docs.rafay.co/clusters/aks/aks-addons/
category: Home
---

# AKS Addons

Add-ons are a fully supported way to extend Azure Kubernetes Service with additional functionality.

Add-ons can be installed to an AKS cluster using Cluster Configuration **(CTL/TF/System Sync)** or the **Save and customize** method in the UI.

## Add-ons for Azure Kubernetes Service

Explore a variety of add-ons to enhance your Azure Kubernetes Service (AKS) experience. Below are some examples:

- **azureKeyvaultSecretsProvider**
- **azurePolicy**
- **httpApplicationRouting**
- **omsAgent**

> **Important**
> The `httpApplicationRouting` add-on is no longer supported on **new clusters**. Please use the **Application Routing Add-on** instead.

For more details on these add-ons and additional options, refer to the [Azure AKS Integrations documentation](https://learn.microsoft.com/en-us/azure/aks/integrations?WT.mc_id=containers-84290-joarteir#add-ons).

## Integrating into Cluster Configuration

Refer to this sample cluster configuration to understand the format for integrating some of the above-listed add-ons into your cluster.By following a similar format, you can easily leverage the supported AKS Azure add-ons for seamless integration.

```
apiVersion: rafay.io/v1alpha1
kind: Cluster
metadata:
  name: azure-demo-aks
  project: ankurp
spec:
  blueprint: default-aks
  cloudprovider: demo-ankurp-app
  clusterConfig:
    apiVersion: rafay.io/v1alpha1
    kind: aksClusterConfig
    metadata:
      name: azure-demo-aks
    spec:
      managedCluster:
        apiVersion: "2022-07-01"
        identity:
          type: UserAssigned
          userAssignedIdentities:
            ? /subscriptions/a2252eb2-7a25-432b-a5ec-e18eba6f26b1/resourcegroups/demomanaged/providers/Microsoft.ManagedIdentity/userAssignedIdentities/demo-cp
            : {}
        location: centralindia
        properties:
          addonProfiles:
            azureKeyvaultSecretsProvider:
              config:
                enableSecretRotation: "true"
                rotationPollInterval: 2m
              enabled: true
            azurePolicy:
              enabled: true
          apiServerAccessProfile:
            enablePrivateCluster: true
          dnsPrefix: azure-demo-aks-dns
          identityProfile:
            kubeletidentity:
              resourceId: /subscriptions/a2252eb2-7a25-432b-a5ec-e18eba6f26b1/resourcegroups/demomanaged/providers/Microsoft.ManagedIdentity/userAssignedIdentities/demo-kubelet
          kubernetesVersion: 1.27.1
          networkProfile:
            dnsServiceIP: 10.0.0.10
            dockerBridgeCidr: 172.17.0.1/16
            loadBalancerSku: standard
            networkPlugin: azure
            networkPolicy: azure
            outboundType: loadBalancer
            serviceCidr: 10.0.0.0/16
        sku:
          name: Basic
          tier: Free
        type: Microsoft.ContainerService/managedClusters
      nodePools:
      - apiVersion: "2022-07-01"
        location: centralindia
        name: primary
        properties:
          count: 1
          enableAutoScaling: true
          maxCount: 6
          maxPods: 110
          minCount: 1
          mode: System
          orchestratorVersion: 1.27.1
          osType: Linux
          type: VirtualMachineScaleSets
          vmSize: Standard_B4ms
          vnetSubnetID: /subscriptions/a2252eb2-7a25-432b-a5ec-e18eba6f26b1/resourceGroups/networkingrg/providers/Microsoft.Network/virtualNetworks/vnet-network-demo/subnets/demosubnet
        type: Microsoft.ContainerService/managedClusters/agentPools
      resourceGroupName: demomanaged
  proxyconfig: {}
  type: aks
```

**These add-ons can be added to the configuration file on day 1 or day 2 (after cluster creation).**

## RCTL Command to Apply the Configuration

```
./rctl apply -f <cluster config file>
```
