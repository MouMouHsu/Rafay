---
title: "KOP AKS Clusters - Stop/Start"
source: https://docs.rafay.co/clusters/aks/start_stop_clusters/
category: Home
---

# Start/Stop Clusters

The integration of start and stop support for AKS clusters directly from the console enables users to efficiently manage the lifecycle of their Kubernetes clusters. It offers the capability to halt and resume AKS clusters offers benefits such as cost savings and resource optimization. Users can utilize **[CLI (v1 and v3)](https://docs.rafay.co/clusters/aks/declarative/cli/)**, **[v3 Swagger API](https://qc-console.stage.rafay.dev/openapi-explorer)**, **[System Sync](https://docs.rafay.co/gitops/stages/system_sync/)**, and **Terraform** methods to stop and start their clusters. Overall, this enhancement improves the user experience by providing seamless control over AKS cluster operations.

The console displays the current status of clusters, indicating whether they are running or stopped. To view the duration since the cluster entered its current state, click on the Power Status **Running** (or) **Stopped**.

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/clusters_statuses.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/clusters_statuses.png)

## Stop Cluster

- To halt a running cluster, click on the Power Status **Running**. The Cluster Status indicates the time elapsed since the cluster entered its current state
- Read the provided warnings and click the checkbox to accept them
- Click **Stop**

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/cluster_status_duration.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/cluster_status_duration.png)

Now the Power Status of this cluster changes to **Cluster Stop in Progress** as shown below. The stop action takes about 10 minutes.

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/not_running.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/not_running.png)

Once the stop process is complete, the status changes to Stopped, along with the number of days since it was stopped.

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/stopped_cluster.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/stopped_cluster.png)

The original state of the AKS cluster remains unchanged when it is stopped and is preserved for a **maximum of 12 months**. After this period, it is not possible to recover the cluster state, which will display the Power Status as **Cluster State Unrecoverable**.

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/state_unrecoverable.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/state_unrecoverable.png)

> **Important**
> - For Day-2 operations, such as **scaling** or **upgrading**, start the cluster and perform the required actions
> - When a Day 2 operation, such as creating a node group, is in progress, the cluster cannot be stopped
> - A stopped cluster cannot be created or provisioned, but it can be **started** or **deleted**
> - Day-2 operations like **ClusterStart** and **ClusterDelete** are allowed on a stopped cluster

## Start Cluster

- To start a stopped cluster, read the provided warnings and click the checkbox to accept them
- Click **Start**

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/start_cluster.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/start_cluster.png)

Now the Power Status of this cluster changes to **Cluster Start in Progress** as shown below. The start action takes about 15 minutes.

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/start_in_progress.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/start_in_progress.png)

Once the start process is complete, the status changes to **Running**.

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/run_status.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/run_status.png)

> **Important**
> - Users can either stop or delete a running cluster
> - When starting a cluster, the IP address of the API server may change
> - The cluster configuration gets updated to reflect the current status only after the start/stop progress is complete

---

## Failed Operations

If the start/stop cluster operation fails, the deployed cluster configuration remains unchanged and is not updated. The system automatically retries the operation multiple times using exponential backoff for approximately 5 hours. To know the reason for failure, click on the Power status **Cluster Stop Failed**. Use **Retry (Stop)** to retry the operations manually.

[![Create AKS Cluster](https://docs.rafay.co/clusters/aks/img/auto_AKS/failed_ops.png)](https://docs.rafay.co/clusters/aks/img/auto_AKS/failed_ops.png)

Possible reasons for failure include insufficient permissions, resource constraints, network issues, configuration errors, service interruptions, and environmental factors like high system load or software bugs. If the issues cannot be resolved within this time frame, the system times out and stops progressing further.

---
