---
title: "KOP EKS Clusters - Secret Encryption"
source: https://docs.rafay.co/clusters/eks/secret_encryption/
category: Home
---

# Secret Encryption

## Overview

Enabling **secret encryption** for EKS clusters enhances security by encrypting Kubernetes secrets. This process encrypts secrets using a specified encryption key managed by AWS KMS (Key Management Service). It helps meet compliance requirements, provides fine-grained access control, and ensures that data remains protected and inaccessible without the appropriate decryption keys, even in the event of unauthorized access.

Refer to this page for detailed information on [how to create AWS KMS Keys](https://docs.aws.amazon.com/kms/latest/developerguide/create-keys.html)

---

## Pre-requisites

- `kms:ListKeys`: Permission required to list all the secret encryption keys (KMS keys) available in your AWS account
- `kms:DescribeKey`, `kms:CreateGrant`, `eks:AssociateEncryptionConfig`: Permissions necessary to use the key for secret encryption

## Enabling Secret Encryption Methods

Enabling secret encryption for EKS clusters is supported during initial setup (Day 0) and after deployment (Day 2) using various tools and interfaces including RCTL, Terraform, System Sync, and Swagger API.

### Day 0 - Operations

- **UI**: Begin by creating an EKS cluster through the console. During setup, enable the Secret Encryption option. You can choose to manually enter a custom encryption key ARN or select an existing key from the drop-down.
- **CLI**: Configure secret encryption directly in your RCTL configuration file. Here’s an example configuration snippet with secret encryption enabled:

```
kind: Cluster
metadata:
  name: demo-meta
  project: defaultproject
spec:
  blueprint: default
  blueprintversion: 2.7.0
  cloudprovider: demo-provider
  cniprovider: aws-cni
  proxyconfig: {}
  type: eks
---
apiVersion: rafay.io/v1alpha5
kind: ClusterConfig
managedNodeGroups:
- amiFamily: AmazonLinux2
  desiredCapacity: 2
  iam:
    withAddonPolicies:
      autoScaler: true
  instanceTypes:
  - t3.xlarge
  maxSize: 2
  minSize: 2
  name: ng-6e99d819
  version: "1.29"
  volumeSize: 80
  volumeType: gp3
metadata:
  name: demo-meta
  region: us-west-2
  tags:
    email: [email protected]
    env: qa
  version: "1.29"
secretsEncryption:
  keyARN: arn:aws:kms:us-west-2:<account>:key/<key>
vpc:
  cidr: 192.168.0.0/16
  clusterEndpoints:
    privateAccess: true
    publicAccess: false
  nat:
    gateway: Single
```

- **Swagger API**: Refer [this page](https://docs.rafay.co/automation/api/apis/)
- **Terraform**: Refer [this page](https://docs.rafay.co/automation/tf/overview/)

---

### Day 2 - Operations

Previously, Amazon EKS supported enabling [envelope encryption](https://aws.amazon.com/blogs/containers/using-eks-encryption-provider-support-for-defense-in-depth/) using KMS keys only during cluster creation. Now, you can enable envelope encryption for Amazon EKS clusters at any time.

- **UI**:   [![Configure EKS Cluster](https://docs.rafay.co/clusters/eks/img/auto_eks/enable_option.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/enable_option.png)
  - Select the cluster where secret encryption needs to be added, then navigate to the **Configuration** tab.
  - Click the **Enable** button as shown in the image below.
  - Either select **Custom** and enter the key manually, or choose a key from the drop-down menu. This encrypts all newly added secrets going forward. Users can also encrypt the existing secrets within the cluster by selecting the **Encrypt existing secrets option**, which is enabled by default. If encrypting existing secrets is not necessary, this option can be disabled.
  - Click **Save** to apply the changes.

[![Configure EKS Cluster](https://docs.rafay.co/clusters/eks/img/auto_eks/day2_enable.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/day2_enable.png)

- **CLI**: Configure secret encryption in your EKS Cluster configuration file. Add the below secret encryption parameters to the existing cluster config spec

```
secretsEncryption:
  keyARN: arn:aws:kms:us-west-2:<account>:key/<key>
```

- **Swagger API**: Refer [this page](https://docs.rafay.co/automation/api/apis/)
- **Terraform**: Refer [this page](https://docs.rafay.co/automation/tf/overview/)

> Read more about Using EKS encryption provider support for defense-in-depth post on the AWS containers blog.

> **Important**
> Once a key is added for secret encryption, it cannot be changed or removed and this process will take approximately 30 to 45 minutes to deploy.

---
