---
title: "KOP Providers - API"
source: https://docs.rafay.co/clusters/eks/api/
category: Home
---

# Cluster API

Authorized users can access the Swagger UI for the REST APIs directly from the Console to view the list of EKS clusters and Nodegroup AMIs by project and Organization

> **Important**
> - For additional APIs, please refer to [V3 APIs (Recommended)](https://console.rafay.dev/openapi-explorer). For resources that do not have v3 support, visit [V2/V1 APIs](https://console.rafay.dev/swagger-ui/)
> - Provide the variable details for {project_id}, {cluster_id}, and {nodegroupAmi} according to the configuration

## List Nodegroup AMIs By Organization

- Use the below **GET** REST API to view the list of Nodegroup AMIs by Organization

```
/edge/v1/nodegroupamis/
```

- Click **Execute** to view the list of Nodegroup AMIs by Organization

---

## List Clusters By Organization

To view the list of clusters by Organization associated with an AMI Identifier, perform the below steps

- Login to the console and click **API DOCS** from the Home page

[![API DOCS](https://docs.rafay.co/clusters/eks/img/auto_eks/api_link.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/api_link.png)

Platform API screen appears

- Use the below **GET** REST API and provide the AMI identifier

```
/edge/v1/nodegroupamis/{nodegroupAmi}/clusters/
```

- Click **Execute** to view the list of clusters

---

## List Nodegroup AMIs By Project

- Use the below **GET** REST API to view the list of Nodegroup AMIs by Project

```
/edge/v1/projects/{project_id}/nodegroupamis/
```

- Click **Execute** to view the list of Nodegroup AMIs

---

## List Clusters By Project

- Use the below **GET** REST API to view the list of clusters by Project, associated with an AMI Identifier

```
/edge/v1/projects/{project_id}/nodegroupamis/{nodegroupAmi}/clusters/
```

- Click **Execute** to view the list of clusters

---

## Fetching Health of a Cluster

- Use the below GET API request to the cluster ID and extract the health parameter from the response. The health parameter contains integer values that indicate the current health status, with a value of **1** representing a **healthy state**.

```
/v1/infra/projects/{project_id}/clusters/{cluster_id}/
```

In case the health status is different from **1**, indicating an **unhealthy state**, there can be various reasons for this state. To determine the specific reason, it is advisable to refer to the **reason** value. This value provides insights into the specific cause or factors contributing to the cluster's unhealthy state.

> **Health Status Mapping**
> - 1: "Healthy"
> - 2: "Unhealthy"
> - 3: "Disconnected"

---

## Pull AWS Cloud Logs and Events

Users are allowed to programmatically retrieve cloud logs and events using the API

### Add-on Events

- Use the below **Get** REST API to pull an add-on event

```
/apis/infra.k8smgmt.io/v3/projects/{project}/clusters/{name}/addons/{addon_name}/cloudevents
```

- Enter the necessary details and click **Execute** to view the event details

### Cluster Events

- Use the below **Get** REST API to pull a cluster event

```
/apis/infra.k8smgmt.io/v3/projects/{project}/clusters/{name}/cloudevents
```

- Enter the necessary details and click **Execute** to view the event details

### Cluster Provision Events

- Use the below **Get** REST API to pull a cluster provision event

```
/apis/infra.k8smgmt.io/v3/projects/{project}/clusters/{name}/provision/cloudevents
```

- Enter the necessary details and click **Execute** to view the event details

### Nodegroup Events

- Use the below **Get** REST API to pull a Nodegroup event on **Day 2**

```
/apis/infra.k8smgmt.io/v3/projects/{project}/clusters/{name}/nodegroup/{ng_name}/cloudevents
```

- Enter the necessary details and click **Execute** to view the event details

Refer to the [Troubleshooting](https://docs.rafay.co/clusters/eks/troubleshooting/) page for detailed information on EKS Cloud Logs & Events.

---

## Delete a cluster

- Use the below **Delete** REST API to delete a cluster

```
/v1/infra/projects/{project_id}/clusters{cluster_id}/
```

- Click **Execute** to complete the deletion

---
