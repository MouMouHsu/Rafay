---
title: "KOP EKS Clusters - Audit"
source: https://docs.rafay.co/clusters/eks/audit/
category: Home
---

# Audit

All actions performed on the Amazon EKS cluster right from initial configuration, provisioning, nodegroup actions and deletion are AUDITED.

The audit trail is presented to administrators in a reverse chronological format.

[![Audit Trail Nodegroup Actions](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_audit_trail.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_audit_trail.png)

---
