---
title: "KOP EKS Clusters - RCTL CLI for IRSA"
source: https://docs.rafay.co/clusters/eks/rctl_service_account/
category: Home
---

# CLI for IRSA

## RCTL CLI for IAM Service Accounts

Post cluster provisioning, user can create IAM Roles Service Accounts at pod level through CLI (Command Line Interface), enabling the users to have granular control on pods. Use the suitable commands to create, edit, and delete an service account via CLI.

---

## Create IAM Service Account via CLI

### Prerequisites

- You have CLI (RCTL) [downloaded](https://docs.rafay.co/cli/overview/) and [initialized](https://docs.rafay.co/cli/config/).

### Create IAM Service Account

Use the below command to create a service account

```
./rctl create iam-service-account <cluster-name> --name <sa-name> [--namespace <namespace>] [--policy-arn <arn> ...] [--policy-document <file>]
```

Example:

```
./rctl create iam-service-account eks-demo --name demo-serviceaccount --namespace demo-namespace --policy-arn arn:aws:iam::aws:policy/AmazonS3FullAccess
```

Output: **Request submitted successfully to create IAM service account(s)**

> **Important**
> User can either provide policy details or only the customized config file or both if required

**List IAM Service Account(s)**

To view the list of created service accounts, use the below command

```
./rctl get iam-service-account <cluster-name>
```

Example:

```
./rctl get iam-service-account eks-demo
```

Output:

```
[{"metadata":{"name":"demo-serviceaccount","namespace":"demo-namespace"},"attachPolicyARNs":["arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess"]}]
```

**Update IAM Service Account(s)** - To update the existing IAM Service Account, use the below command

```
./rctl update iam-service-account <cluster-name> --name <sa-name> --namespace <name space> --policy-arn <policy-arn>
```

Example: Below is an example to update the IAM service account with a tag

```
./rctl update iam-service-account eks-demo --name demo-serviceaccount --namespace demo-namespace --policy-arn arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess --tag name=demotags
```

Output:

**Request submitted successfully to update IAM service account(s)**

> Note: Only tags and IAM Policy ARNs can be updated

**Get IAM Service Account updates**

To get the updates performed on a service account, use the below command

```
./rctl get iam-service-account <cluster-name>
```

Example:

```
./rctl get iam-service-account eks-demo
```

Output:

```
[{"metadata":{"name":"demo-serviceaccount","namespace":"demo-namespace"},"attachPolicyARNs":["arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess", "tags":{"name": "demotags"}]}]
```

**Apply IAM Service Account(s)**

Post provision of EKS Clusters, users are allowed to download the cluster config file, update the IAM Service account details and apply the changes to the cluster using the below command

```
./rctl apply -f <cluster_configfile.yaml>
```

---

## View IAM Service Account in the controller

Once the Service Account is created or updated, login to the controller and click **Clusters**. Select a cluster and click **Service Accounts** tab to view the list of service accounts created through RCTL for this specific cluster.

[![Congif File](https://docs.rafay.co/clusters/eks/img/auto_eks/sa_success.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/sa_success.png)

## Delete IAM Service Account(s)

- Use the below command to delete a IAM Service Account and press enter

```
./rctl delete iam-service-account <cluster-name> --name <sa-name> --namespace <namespace>
```

Example:

```
./rctl delete iam-service-account eks-demo --name demo-serviceaccount -namespace demo-namespace
```

- Enter "Y" to confirm the deletion process

Output:

**Request submitted successfully to delete an IAM service account**

---
