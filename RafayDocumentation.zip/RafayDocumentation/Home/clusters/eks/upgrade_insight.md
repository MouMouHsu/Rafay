---
title: "KOP EKS Clusters - Upgrade Insights"
source: https://docs.rafay.co/clusters/eks/upgrade_insight/
category: Home
---

# Upgrade Insights

## Overview

The Upgrade Insights tab serves as a valuable resource for ensuring smooth cluster upgrades by providing insights into deprecated APIs. By highlighting potential issues beforehand, users can proactively address configuration concerns, minimizing disruptions during transitions to newer Kubernetes releases. This feature focuses on resource and application impact assessment, offers version-specific guidance, and supports efficient pre-upgrade planning.

> **Upgrade Insights Permissions**
> For upgrade insights, ensure your IAM roles have the following permissions: - `eks:ListInsights` - `eks:DescribeInsight`

## Why Upgrade Insights?

Upgrade Insights from the controller identifies any existing issues or necessary actions required prior to upgrading a cluster to the next version. It displays information about available higher versions, deprecated APIs, and their corresponding replacements. Ensuring that deprecated APIs are replaced with alternatives is crucial for a successful upgrade. If the targeted upgrade version already includes the necessary APIs, no additional actions are needed.

- Customers can conveniently access the Upgrade Insights report directly within the Controller for all their EKS clusters, streamlining efficiency and simplifying cluster management. The integration of Upgrade Insights into the upgrade process ensures a seamless experience.
- If an EKS cluster is not ready for upgrade due to a deprecated API dependency, our platform will show the error if any and proceeds However, it is recommended to see **Upgrade Insights** first before proceeding with an upgrade.

[![Upgrade History Detail](https://docs.rafay.co/clusters/eks/img/upgrade/upgrade_insight.jpg)](https://docs.rafay.co/clusters/eks/img/upgrade/upgrade_insight.jpg)

## Illustrative Scenario

Here's an example where an API is scheduled for deprecation in v1.25. When checking the Upgrade Insights page, users may notice the status displayed as **ERROR**, indicating that an API will be deprecated in the upcoming version v1.25. It's important for users to check which old APIs they're using that will be taken out in Kubernetes version 1.25. Upgrading the cluster without migrating to the updated APIs supported by v1.25 could potentially cause application impact.

Click on the insight name to get detailed information about this API deprecation.

[![Upgrade History Detail](https://docs.rafay.co/clusters/eks/img/upgrade/upgrades_error.jpg)](https://docs.rafay.co/clusters/eks/img/upgrade/upgrades_error.jpg)

In this instance, it's shown that the PSP API will be deprecated starting from v1.25. This insight informs users that policies utilizing the PSP API will affect resources. As a result, users must take the necessary action in advance and resolve the issue before upgrading to K8 v1.25.

[![Upgrade History Detail](https://docs.rafay.co/clusters/eks/img/upgrade/deprec_api.jpg)](https://docs.rafay.co/clusters/eks/img/upgrade/deprec_api.jpg)

If an update is required for the version two ahead, a **WARNING** status will be issued to the user, indicating that the upcoming version necessitates changes, such as deprecating an API or implementing other modifications.

## Making Upgrade Decisions

Before upgrading the EKS cluster, follow these steps to use Upgrade Insights in making the decision:

1. **Check Upgrade Insights:** Look into the Upgrade Insights tab either in the UI or [CLI](https://docs.rafay.co/clusters/eks/declarative/cli/#upgrade-insights-with-rctl) to check if any errors are reported.
2. **Review Insight Status:**
  - **PASSING:** No deprecated API usage detected within the last 30 days.
  - **WARNING:** No deprecated API usage detected for the current version, but detected for future versions.
  - **ERROR:** Deprecated API usage detected within the last 30 days for the current version.
3. **Fix Errors:** If errors are reported, fix them first.
4. **Wait for Report Refresh:** Wait for the Upgrade Insights report to refresh. Note that the report is refreshed once per day.
5. **Upgrade Cluster:** Once the report is clean without any errors, proceed to upgrade the cluster.

By following these steps, users can effectively utilize Upgrade Insights to assess the readiness of their EKS clusters for upgrade, ensuring a smooth transition to newer Kubernetes releases.

---
