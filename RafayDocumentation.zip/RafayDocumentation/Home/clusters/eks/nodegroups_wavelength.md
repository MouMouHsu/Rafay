---
title: "KOP EKS Clusters - Nodegroups AWS Wavelength"
source: https://docs.rafay.co/clusters/eks/nodegroups_wavelength/
category: Home
---

# Wavelength Zone

Wavelength zones are **availability zones** in an AWS region, where the compute and storage services are embedded within a telecom company’s data centers at the edge of the 5G network. Wavelength zones bring processing power and storage physically closer to 5G mobile users and wireless devices. It allows building applications that can deliver enhanced user experiences like near real-time analytics for instant decision-making or automated robotic systems in manufacturing facilities

Provisioning node groups in wavelength availability zones helps AWS EKS Clusters to use Wavelength. EKS integration enables enterprises to securely manage all their EKS clusters across all regions from a single pane of glass. For more information, refer [About AWS Wavelength](https://docs.aws.amazon.com/wavelength/latest/developerguide/what-is-wavelength.html)

Users who wish to run a specific application of a cluster that requires ultra-low latency can deploy in the nearest zone using this Wavelength Zone Node Group feature. [Watch](https://youtu.be/mcKsP-sYQhs) a video of support for AWS Wavelength and learn more.

---

## Resource Setup

**Auto Create**

- Provisioned EKS cluster with minimum one node group
- Subnet CIDR Block

**Manual**

- Provisioned EKS cluster with minimum one node group
- Subnet created in the WZ (within the VPC)
- Carrier gateway, associated with the above subnet
- A route table having a route to the carrier gateway, and associated with the subnet
- Security group with custom tcp inbound rule

---

## Add Node Group in Wavelength zone

On successful EKS Cluster provisioning, user can add node group in wavelength zone using the following procedure:

- Login to controller and click **Clusters** under **Infrastructure**
- Select the required (provisioned/healthy) EKS cluster and click **Node Group** tab

[![Nodegroup Tab](https://docs.rafay.co/clusters/eks/img/auto_eks/wl_nodegroup.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/wl_nodegroup.png)

- Enter a Node Group Name and select **Wavelength Node Group** option

[![Nodegroup Tab](https://docs.rafay.co/clusters/eks/img/auto_eks/select_wlz_ng.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/select_wlz_ng.png)

> **Important**
> Wavelength Zone do not support Managed Node Group, Spot instances, and GPU instances

Provide the required details for Wavelength Node Group and pay attention to the below points:

- If **Manual** option is selected, the user must provide the **Subnet ID**. A subnet is a range of IP addresses in your VPC and once a Subnet is created, this Subnet ID is used to create other resources
- If **Auto Create** option is selected, provide the **Subnet CIDR block**. A Subnet CIDR is a range of IPv4 or IPv6 addresses in a subnet. The following options are available. Auto Create option systematically creates the required resources (subnet, Gateway, route table, and security group) for the node groups
- The four types of Instances supported for wavelength zone node group are **t3.medium**, **t3.xlarge**, **r5.2xlarge**, and **g4dn.2xlarge**
- Node Volume Type is **gp2** by default with storage limit **30 TB** and not editable
- **Use Private IPs for worker nodes** is checked by default for wavelength node groups and not editable
- Provide one or more **Security Group ID** if Auto Create is disabled
- User can provide only **one** Availability Zone for wavelength node group

[![Nodegroup Wavelength Zone](https://docs.rafay.co/clusters/eks/img/auto_eks/provision_wlzng.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/provision_wlzng.png)

To know the list of available Wavelength Zones, refer [AWS Wavelength Zones](https://docs.aws.amazon.com/wavelength/latest/developerguide/wavelength-quotas.html)

- To view the Yaml spec file with the configuration details based on the information provided in the Add Node Group Settings page, click **Save & Customize**. Users can edit and make the required changes to the Yaml file. Below is an example of the Wavelength Node Group Yaml file

**Manual Network Configuration**

```
apiVersion: rafay.io/v1alpha5
kind: ClusterConfig
metadata:
  name: demo-eks-testing
  region: us-west-1
    version: "1.26"
nodeGroups:
- amiFamily: AmazonLinux2
  availabilityZones:
  - us-east-1-wl1-atl-wlz-1
  desiredCapacity: 2
  iam:
    withAddonPolicies:
      autoScaler: true
      imageBuilder: true
  instanceType: t3.xlarge
  maxSize: 2
  minSize: 2
  name: demo-wlzone1
  privateNetworking: true
  securityGroups:
    attachIDs:
    - test-grpid
  subnets:
  - 701d1419
  volumeSize: 80
  volumeType: gp2
```

**Automatic Network Configuration**

```
apiVersion: rafay.io/v1alpha5
kind: ClusterConfig
metadata:
  name: demo-eks-autonode
  region: us-west-2
    version: "1.26"
nodeGroups:
- amiFamily: AmazonLinux2
  availabilityZones:
  - us-west-2-wl1-phx-wlz-1
  desiredCapacity: 2
  iam:
    withAddonPolicies:
      autoScaler: true
      imageBuilder: true
  instanceType: t3.xlarge
  maxSize: 2
  minSize: 2
  name: ng-rctl-4-new
  privateNetworking: true
  subnetCidr: 192.168.206.0/24
  volumeSize: 80
  volumeType: gp2
```

- Click **Provision Node Group** to deploy the node groups. Provisioning would take ~10 minutes

Once the Node Group is deployed, wavelength node groups are created and available under **Cluster -> Node Group**. Wavelength Zone Node Groups are highlighted with an **orange** colored banner. **Availability Zones** and **DNS for Wavelength** specific to the Wavelength Node group are displayed here. This DNS is created in Route 53, targeting the Carrier IP of the nodes so that users can create a CNAME record for their application hostname to this dns name.

[![Wavelength Nodegroup Listed](https://docs.rafay.co/clusters/eks/img/auto_eks/wlzng_listed.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/wlzng_listed.png)

- Click **Nodes** tab to view the Nodes under Wavelength Zone Groups, highlighted with a green banner. For the Wavelength Zone Node group, **Carrier IP** along with wavelength zone label is shown in the Node screen and this Carrier IP is associated with the subnet

[![Wavelength Zone Nodes](https://docs.rafay.co/clusters/eks/img/auto_eks/wlznode_carrierip.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/wlznode_carrierip.png)

- To view the cluster level DNS of Wavelength Zone node groups, click **Configuration** tab to view the available DNS. All the Wavelength Node Groups IPs are aggregated and pointed to this DNS

[![Cluster Level DNS](https://docs.rafay.co/clusters/eks/img/auto_eks/config_dnswlz.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/config_dnswlz.png)

---
