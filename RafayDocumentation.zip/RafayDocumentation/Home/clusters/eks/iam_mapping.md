---
title: "KOP EKS Clusters - Identity Mapping"
source: https://docs.rafay.co/clusters/eks/iam_mapping/
category: Home
---

# Identity Mapping

## Identity Mapping

Post cluster provisioning, the Identity Mapping feature helps the users to create a static mapping between IAM Users and Roles, and Kubernetes RBAC groups. This allows users/roles to access specified EKS cluster resources in AWS Console.

---

## Create IAM Mapping

- Login to the controller and click **Clusters**
- Select the required provisioned cluster and click **Identity Mapping** tab. **IAM Mappings** tab is selected by default. You can see a list of ARNs if already created as shown in the below example
- To create a new IAM Mapping, click **New IAM Mapping**

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/new_iam_mappings.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/new_iam_mappings.png)

- To allow different users to access specified cluster resources, copy/paste the EKS Cluster Users ARN from AWS portal and provide the user name

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/awsarn_user.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/awsarn_user.png)

- To allow different roles to access the specified cluster resources, copy/paste the EKS Cluster Role ARN from the AWS portal and provide the user name

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/role_arn.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/role_arn.png)

- Select the type **system:masters** to provide access to all the resources of the cluster (or) select **Custom** to provide access only for a group of resources. Users can add one or more groups to an IAM Mapping and also can create multiple IAM mappings

Below is an example of both USER and ROLE IAM Mapping

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/create_mapping.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/create_mapping.png)

- Click **Save**

Once the mapping is successful, you can view the ARNs in the table as shown below

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/arn_list.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/arn_list.png)

Now the users can access the cluster resources via AWS Console

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/aws_console_resources.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/aws_console_resources.png)

To add IAM Mappings during cluster provisioning, refer [IAM Mapping CLI](https://docs.rafay.co/clusters/eks/declarative/cli/)

### Delete IAM Mapping

- To delete the IAM Mapping and remove the cluster access from the users/roles, click the delete icon
- Click **Yes** to complete the deletion

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/delete_mapping.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/delete_mapping.png)

---

## Accounts

**Accounts** tab allows the users to add one or more accounts. This helps to provide access to clusters available in different accounts

- Click **Add Account** to add the required account(s)

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/account_tab.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/account_tab.png)

- Enter the account(s) and click **Save**

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/add_accounts.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/add_accounts.png)

Once the accounts are added, you can view the newly added accounts in the table as shown below

[![Provide AWS IAM Policy ARN](https://docs.rafay.co/clusters/eks/img/auto_eks/accounts_list.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/accounts_list.png)

The arn of respective accounts are used to create an IAM Mapping

Use the delete icon to delete one or more account(s)

---
