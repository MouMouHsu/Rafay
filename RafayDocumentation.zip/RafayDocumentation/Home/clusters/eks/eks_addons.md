---
title: "KOP EKS Clusters - Managed Add-Ons"
source: https://docs.rafay.co/clusters/eks/eks_addons/
category: Home
---

# Managed Add-Ons

Amazon EKS add-ons provide supporting operational capabilities to Kubernetes applications. Installing add-ons to an EKS cluster can be done in the Console or using RCTL.

There are ten (10) EKS add-ons available in the Console. Some EKS add-ons are K8s version specific. For information about supported versions, see [Amazon EKS Add-Ons](https://docs.aws.amazon.com/eks/latest/userguide/eks-add-ons.html).

- [ADOT Operator](https://docs.aws.amazon.com/eks/latest/userguide/opentelemetry.html)
- [Amazon CloudWatch observability](https://docs.aws.amazon.com/eks/latest/userguide/cloudwatch.html)
- [Amazon EBS CSI Driver](https://docs.aws.amazon.com/eks/latest/userguide/ebs-csi.html)
- [Amazon EFS CSI Driver](https://docs.aws.amazon.com/eks/latest/userguide/efs-csi.html)
- [Amazon GuardDuty](https://aws.amazon.com/blogs/aws/amazon-guardduty-now-supports-amazon-eks-runtime-monitoring/)
- [Amazon VPC CNI - Recommended K8s versions](https://github.com/aws/amazon-vpc-cni-k8s/blob/master/README.md#recommended-version)
- [CoreDNS](https://docs.aws.amazon.com/eks/latest/userguide/managing-coredns.html) - Not K8s version specific
- [CSI Snapshot Controller](https://docs.aws.amazon.com/eks/latest/userguide/csi-snapshot-controller.html)
- [Kube-Proxy - K8s Compatibility](https://kubernetes.io/releases/version-skew-policy/#kube-proxy)
- [Mountpoint for S3 CSI driver](https://docs.aws.amazon.com/eks/latest/userguide/s3-csi.html)
- [EKS Pod Identity Agent](https://docs.aws.amazon.com/eks/latest/userguide/pod-id-agent-setup.html) - For more information, refer to [Pod Identity Associations](https://docs.rafay.co/clusters/eks/pod_identity/) page
- [AWS Network Flow Monitoring Agent](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch-NetworkFlowMonitor-agents-kubernetes-eks.html)

> **Important**
> - The mandatory add-ons like **Amazon VPC CNI**, **CoreDNS**, and **Kube-Proxy** will be implicitly added to the cluster if they are not specified in the cluster configuration file during EKS cluster creation
> - With AWS EKS version **1.24** and newer, the **Amazon EBS CSI Driver** is automatically included with the EKS cluster
> - The Amazon EBS CSI Driver requires **IAM permissions**

> **EBS CSI Driver IAM Permissions**
> If you are using Amazon EKS with EBS backed PersistentVolumes, make sure your EKS node roles or IAM roles are granted the following permissions: - `ec2:CreateVolume` - `ec2:AttachVolume`

---

## Install Add-Ons

### Console

1. In the Console, select the EKS cluster to install add-ons to.
2. On the Configuration tab, for **EKS Managed Addons**, click **Add**. Create EKS Managed Addon window appears
3. Select the required add-on and version from the drop-down list

[![EKS Add-Ons](https://docs.rafay.co/clusters/eks/img/addons/managed_addons.png)](https://docs.rafay.co/clusters/eks/img/addons/managed_addons.png)

1. Users are allowed to customize the addon at the time of addition. Configurable values can be utilized to tailor the add-on according to the user preferences. Click on **Optional Configuration Values** to add more configurable values. An illustrative example is given below where configuration values are added for the **ADOT** addon

[![EKS Add-Ons](https://docs.rafay.co/clusters/eks/img/addons/configure_options.png)](https://docs.rafay.co/clusters/eks/img/addons/configure_options.png)

1. Click **Save**

Here is an example where the Amazon EBS CSI Driver, Amazon VPC CNI and ADOT addons are added

[![EKS Add-Ons](https://docs.rafay.co/clusters/eks/img/addons/eks_addons.png)](https://docs.rafay.co/clusters/eks/img/addons/eks_addons.png)

To add the Guard Duty Addon, user must enable the EKS Runtime Monitoring option in the AWS Console, as illustrated below

[![EKS Add-Ons](https://docs.rafay.co/clusters/eks/img/addons/enable_monitoring.png)](https://docs.rafay.co/clusters/eks/img/addons/enable_monitoring.png)

**Required IAM Permissions for GuardDuty Managed Add-On**

In addition to the IAM permissions documented [here](https://docs.rafay.co/clusters/eks/iam_policy/), the GuardDuty managed add-on requires the following additional IAM permissions:

- ec2:DescribeVpcEndpoints
- ec2:CreateVpcEndpoint
- ec2:DeleteVpcEndpoints

**Required IAM Permissions for EKS Pod Identity Agent Add-On**

The EKS Pod Identity Agent managed add-on requires the following additional IAM permissions:

- "eks:CreatePodIdentityAssociation"
- "eks:DescribePodIdentityAssociation"
- "eks:DeletePodIdentityAssociation"
- "eks:UpdatePodIdentityAssociation"

---

### RCTL

In the EKS cluster specification file, add the 'addons' section and include the appropriate add-ons. The following is an example.

```
addons:
- name: aws-ebs-csi-driver
  serviceAccountRoleARN: arn:aws:iam::123456789012:role/demo-ebs-csi
  version: v1.16.0-eksbuild.1
- name: vpc-cni
  version: v1.12.6-eksbuild.1
- name: kube-proxy
  version: v1.23.16-eksbuild.2
```

The AWS Network Flow Monitoring Agent addon is supported via RCTL, API, and Terraform (all interfaces except the Console UI). Add it to the addons section as shown below:

> **Note**
> Console UI support for this addon will be added in an upcoming release.

```
addons:
- name: aws-network-flow-monitoring-agent
  version: latest
```

You can also specify a specific version. The supported versions depend on your EKS cluster version: - **EKS 1.34**: `v1.1.1-eksbuild.1` or `v1.1.0-eksbuild.1` - **EKS 1.33**: `v1.1.0-eksbuild.1` Example with a specific version:

```
addons:
- name: aws-network-flow-monitoring-agent
  version: v1.1.1-eksbuild.1
```

> **Important**
> In clusters where the creation of Role permissions is restricted, the addon will be generated with policies inherited from the node.

---
