---
title: "Provision & Manage Amazon EKS Clusters"
source: https://docs.rafay.co/clusters/eks/overview/
category: Home
---

# Overview

[Amazon Elastic Kubernetes Service (Amazon EKS)](https://aws.amazon.com/eks/) is a fully managed Kubernetes service provided by AWS.

[![EKS Architecture](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_architecture.svg)](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_architecture.svg)

> **Info**
> Read our [blogs](https://docs.rafay.co/blog/) on how to provision and manage EKS Auto Mode clusters. Watch a [video](https://www.youtube.com/watch?v=fCtcPULSKos) of the end to end experience.

---

> **Did you know ?**
> Amazon EKS Cluster Lifecycle can be managed through various methods:
>
> - [UI](https://docs.rafay.co/clusters/eks/overview/#self-service-ui)
> - [CLI](https://docs.rafay.co/clusters/eks/declarative/cli/)
> - [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/eks_cluster)
> - [GitOps](https://docs.rafay.co/gitops/stages/system_sync/)
> - [API](https://docs.rafay.co/automation/api/apis/)
> - [AWS EKS System Template](https://docs.rafay.co/clusters/eks/provision_via_temp/)

## Automation Options

The below matrix presents a breakdown of actions like creation, upgrading, and deletion of EKS Clusters across multiple deployment methods: interactive UI, declarative RCTL commands, API-driven automation, and Terraform.

| Action | UI | CLI | API | Terraform |
| --- | --- | --- | --- | --- |
| Create | [Yes](https://docs.rafay.co/clusters/eks/provisioning/) | [Yes](https://docs.rafay.co/clusters/eks/declarative/cli/#declarative) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/eks_cluster) |
| Upgrade | [Yes](https://docs.rafay.co/clusters/eks/upgrades/) | [Yes](https://docs.rafay.co/clusters/eks/declarative/cli/#cluster-upgrade) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/eks_cluster) |
| Delete | [Yes](https://docs.rafay.co/clusters/eks/deprovision/) | [Yes](https://docs.rafay.co/clusters/eks/declarative/cli/#delete-cluster) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/eks_cluster) |

---

## Amazon EKS Lifecycle Management

The controller provides a deep integration with Amazon EKS to ensure that users can customize and manage the full lifecycle of EKS Clusters in any AWS region right from the Controller. Two approaches for provisioning are currently supported:

## Self Service UI

A wizard style experience that is well suited for users that have limited time in getting a cluster operational quickly.

## Automation Focused

This is well suited for [automation centric operations](https://docs.rafay.co/clusters/eks/declarative/cli/) where the organization wishes to maintain version-controlled "cluster specification files" in their Git Repo for Amazon EKS. This approach also allows users to specify very advanced EKS configurations that can become difficult to visualize in the web console.

- Create and manage cluster blueprints
- Perform backup and restore of clusters
- Use the integrated dashboards for visibility and monitoring,
- Perform workload lifecycle management and
- Implement GitOps automation pipelines

> **Important**
> View and Use [**example declarative cluster specifications for Amazon EKS**](https://github.com/RafaySystems/rafay-cicd-helpers/tree/master/eks/examples).

---

## Amazon EKS on AWS Outposts

AWS Outposts is a fully managed service that extends AWS capabilities to a customer's facility providing a truly consistent hybrid experience. AWS services run locally on AWS Outposts and can be accessed using familiar AWS APIs and tooling making it ideal for workloads that require low latency access to on-premises systems, local data processing, or local data storage. AWS Outposts are connected to the nearest AWS Region to provide management and control plane services with complete management, monitoring, and lifecycle management by AWS.

Organizations can leverage the controller to streamline and simplify the provisioning and ongoing operations of EKS clusters on AWS Outposts. They can do this via both a self-service wizard and in a declarative manner using a version controlled cluster specification that can be stored in a Git repository.

Once you have created your VPC and subnets for AWS Outposts, just provide this information via the wizard or via automation to ensure it can provision the Amazon EKS cluster with the worker nodes on your AWS Outposts infrastructure.

## Getting Started

We have quick start exercise to explore the platform's capabilities for "Lifecycle Management" of Amazon EKS Clusters.

[Step by Step Guide](https://docs.rafay.co/learn/quickstart/eks/clusterlifecycle/overview/)

---
