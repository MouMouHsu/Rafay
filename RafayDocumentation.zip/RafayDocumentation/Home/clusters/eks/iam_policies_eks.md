---
title: "KOP EKS Clusters - IAM Policies"
source: https://docs.rafay.co/clusters/eks/iam_policies_eks/
category: Home
---

# Service Linked IAM Role

## Service Role ARN

A service role utilizing AWS managed and custom defined policies is required to access Amazon’s EKS. This role will be attached to the EKS Control plane during provisioning of the EKS cluster. A Role ARN will be provided as input during cluster creation in Rafay Console.

The following policies should be attached to the Service Role.

- AWS Managed Policies
  - AmazonEKSClusterPolicy
  - AmazonEKSVPCResourceController
- Customer Defined Policies ( **Required if only using the functionalities related to the associated policies** )
  - Cluster-PolicyCloudWatchMetrics 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "cloudwatch:PutMetricData"
            ],
            "Resource": "*",
            "Effect": "Allow"
        }
    ]
}
```
  - Cluster-PolicyELBPermissions 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "ec2:DescribeAccountAttributes",
                "ec2:DescribeAddresses",
                "ec2:DescribeInternetGateways"
            ],
            "Resource": "*",
            "Effect": "Allow"
        }
    ]
}
```

## Node Instance Role ARN

A node instance role utilizing AWS managed and custom defined policies is required to access Amazon’s EKS, ECS, and additional services. This role will be attached to the EKS worker nodes during provisioning. The Role ARN will be provided as input during cluster creation.

The following policies and permissions should be associated to the Node Instance Role.

- AWS Managed Policies
  - AmazonEKSWorkerNodePolicy
  - AmazonEC2ContainerRegistryPowerUser
  - AmazonEC2ContainerRegistryReadOnly
  - AmazonEBSCSIDriverPolicy
  - AmazonEKS_CNI_Policy
- Customer Defined Policies ( **Required if only using the functionalities related to the associated policies** )
  - nodegroup-PolicyAppMesh 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "servicediscovery:CreateService",
                "servicediscovery:DeleteService",
                "servicediscovery:GetService",
                "servicediscovery:GetInstance",
                "servicediscovery:RegisterInstance",
                "servicediscovery:DeregisterInstance",
                "servicediscovery:ListInstances",
                "servicediscovery:ListNamespaces",
                "servicediscovery:ListServices",
                "servicediscovery:GetInstancesHealthStatus",
                "servicediscovery:UpdateInstanceCustomHealthStatus",
                "servicediscovery:GetOperation",
                "route53:GetHealthCheck",
                "route53:CreateHealthCheck",
                "route53:UpdateHealthCheck",
                "route53:ChangeResourceRecordSets",
                "route53:DeleteHealthCheck",
                "appmesh:*"
            ],
            "Resource": "*",
            "Effect": "Allow"
        }
    ]
}
```
  - nodegroup-PolicyAutoScaling 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "autoscaling:DescribeAutoScalingGroups",
                "autoscaling:DescribeAutoScalingInstances",
                "autoscaling:DescribeLaunchConfigurations",
                "autoscaling:DescribeTags",
                "autoscaling:SetDesiredCapacity",
                "autoscaling:TerminateInstanceInAutoScalingGroup",
                "ec2:DescribeLaunchTemplateVersions"
            ],
            "Resource": "*",
            "Effect": "Allow"
        }
    ]
}
```
  - nodegroup-PolicyAWSLoadBalancerController 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "iam:CreateServiceLinkedRole"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "iam:AWSServiceName": "elasticloadbalancing.amazonaws.com"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:DescribeAccountAttributes",
                "ec2:DescribeAddresses",
                "ec2:DescribeAvailabilityZones",
                "ec2:DescribeInternetGateways",
                "ec2:DescribeVpcs",
                "ec2:DescribeVpcPeeringConnections",
                "ec2:DescribeSubnets",
                "ec2:DescribeSecurityGroups",
                "ec2:DescribeSecurityGroupRules",
                "ec2:DescribeInstances",
                "ec2:DescribeNetworkInterfaces",
                "ec2:DescribeTags",
                "ec2:GetCoipPoolUsage",
                "ec2:DescribeCoipPools",
                "elasticloadbalancing:DescribeLoadBalancers",
                "elasticloadbalancing:DescribeLoadBalancerAttributes",
                "elasticloadbalancing:DescribeListeners",
                "elasticloadbalancing:DescribeListenerCertificates",
                "elasticloadbalancing:DescribeSSLPolicies",
                "elasticloadbalancing:DescribeRules",
                "elasticloadbalancing:DescribeTargetGroups",
                "elasticloadbalancing:DescribeTargetGroupAttributes",
                "elasticloadbalancing:DescribeTargetHealth",
                "elasticloadbalancing:DescribeTags"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "cognito-idp:DescribeUserPoolClient",
                "acm:ListCertificates",
                "acm:DescribeCertificate",
                "iam:ListServerCertificates",
                "iam:GetServerCertificate",
                "waf-regional:GetWebACL",
                "waf-regional:GetWebACLForResource",
                "waf-regional:AssociateWebACL",
                "waf-regional:DisassociateWebACL",
                "wafv2:GetWebACL",
                "wafv2:GetWebACLForResource",
                "wafv2:AssociateWebACL",
                "wafv2:DisassociateWebACL",
                "shield:GetSubscriptionState",
                "shield:DescribeProtection",
                "shield:CreateProtection",
                "shield:DeleteProtection"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:AuthorizeSecurityGroupIngress",
                "ec2:RevokeSecurityGroupIngress"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:CreateSecurityGroup"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:CreateTags"
            ],
            "Resource": "arn:aws:ec2:*:*:security-group/*",
            "Condition": {
                "StringEquals": {
                    "ec2:CreateAction": "CreateSecurityGroup"
                },
                "Null": {
                    "aws:RequestTag/elbv2.k8s.aws/cluster": "false"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:CreateTags",
                "ec2:DeleteTags"
            ],
            "Resource": "arn:aws:ec2:*:*:security-group/*",
            "Condition": {
                "Null": {
                    "aws:RequestTag/elbv2.k8s.aws/cluster": "true",
                    "aws:ResourceTag/elbv2.k8s.aws/cluster": "false"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:AuthorizeSecurityGroupIngress",
                "ec2:RevokeSecurityGroupIngress",
                "ec2:DeleteSecurityGroup"
            ],
            "Resource": "*",
            "Condition": {
                "Null": {
                    "aws:ResourceTag/elbv2.k8s.aws/cluster": "false"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "elasticloadbalancing:CreateLoadBalancer",
                "elasticloadbalancing:CreateTargetGroup"
            ],
            "Resource": "*",
            "Condition": {
                "Null": {
                    "aws:RequestTag/elbv2.k8s.aws/cluster": "false"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "elasticloadbalancing:CreateListener",
                "elasticloadbalancing:DeleteListener",
                "elasticloadbalancing:CreateRule",
                "elasticloadbalancing:DeleteRule"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "elasticloadbalancing:AddTags",
                "elasticloadbalancing:RemoveTags"
            ],
            "Resource": [
                "arn:aws:elasticloadbalancing:*:*:targetgroup/*/*",
                "arn:aws:elasticloadbalancing:*:*:loadbalancer/net/*/*",
                "arn:aws:elasticloadbalancing:*:*:loadbalancer/app/*/*"
            ],
            "Condition": {
                "Null": {
                    "aws:RequestTag/elbv2.k8s.aws/cluster": "true",
                    "aws:ResourceTag/elbv2.k8s.aws/cluster": "false"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "elasticloadbalancing:AddTags",
                "elasticloadbalancing:RemoveTags"
            ],
            "Resource": [
                "arn:aws:elasticloadbalancing:*:*:listener/net/*/*/*",
                "arn:aws:elasticloadbalancing:*:*:listener/app/*/*/*",
                "arn:aws:elasticloadbalancing:*:*:listener-rule/net/*/*/*",
                "arn:aws:elasticloadbalancing:*:*:listener-rule/app/*/*/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "elasticloadbalancing:ModifyLoadBalancerAttributes",
                "elasticloadbalancing:SetIpAddressType",
                "elasticloadbalancing:SetSecurityGroups",
                "elasticloadbalancing:SetSubnets",
                "elasticloadbalancing:DeleteLoadBalancer",
                "elasticloadbalancing:ModifyTargetGroup",
                "elasticloadbalancing:ModifyTargetGroupAttributes",
                "elasticloadbalancing:DeleteTargetGroup"
            ],
            "Resource": "*",
            "Condition": {
                "Null": {
                    "aws:ResourceTag/elbv2.k8s.aws/cluster": "false"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "elasticloadbalancing:RegisterTargets",
                "elasticloadbalancing:DeregisterTargets"
            ],
            "Resource": "arn:aws:elasticloadbalancing:*:*:targetgroup/*/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "elasticloadbalancing:SetWebAcl",
                "elasticloadbalancing:ModifyListener",
                "elasticloadbalancing:AddListenerCertificates",
                "elasticloadbalancing:RemoveListenerCertificates",
                "elasticloadbalancing:ModifyRule"
            ],
            "Resource": "*"
        }
    ]
}
```
  - nodegroup-PolicyEFS 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "elasticfilesystem:*"
            ],
            "Resource": "*",
            "Effect": "Allow"
        }
    ]
}
```
  - nodegroup-PolicyEFSEC2 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "ec2:DescribeSubnets",
                "ec2:CreateNetworkInterface",
                "ec2:DescribeNetworkInterfaces",
                "ec2:DeleteNetworkInterface",
                "ec2:ModifyNetworkInterfaceAttribute",
                "ec2:DescribeNetworkInterfaceAttribute"
            ],
            "Resource": "*",
            "Effect": "Allow"
        }
    ]
}
```
  - nodegroup-PolicyExternalDNSChangeSet 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "route53:ChangeResourceRecordSets"
            ],
            "Resource": "arn:aws:route53:::hostedzone/*",
            "Effect": "Allow"
        }
    ]
}
```
  - nodegroup-PolicyExternalDNSHostedZones 

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "route53:ListHostedZones",
                "route53:ListResourceRecordSets",
                "route53:ListTagsForResource"
            ],
            "Resource": "*",
            "Effect": "Allow"
        }
    ]
}
```

---

## Instance Profile ARN

Instance profiles are a way to pass an IAM role to an EC2 instance. As part of the cluster creation process Rafay can pass the IAM Node Instance role created above to the EKS worker nodes which are built on top of EC2 instances. Instance profiles can be created using the CLI or API and involve creating the instance profile, adding any additional tags, and then adding the Node Instance role to the instance profile. Role ARN will be provided as input during the cluster creation in Rafay Console.

[Using Instance Profiles](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_use_switch-role-ec2_instance-profiles.html)

> **Note**
> For customers who will manage their own IAM Roles and Policies and have not created an EKS cluster then you will need to create (2) additional AWS Service-linked Roles. These roles are created dynamically when an EKS cluster is launched. If a cluster has not been launched in the working account and the controller does not have the necessary IAM permissions then follow the instructions below to create the autoscaling and EKS service-linked roles

---

## Autoscaling service-linked role creation

1. Open the IAM console at [https://console.aws.amazon.com/iam/](https://console.aws.amazon.com/iam/).
2. In the left navigation pane, choose Roles and click **Create role**.

[![Create Roles](https://docs.rafay.co/clusters/eks/img/auto_eks/create_roles.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/create_roles.png)

1. Select **AWS service** for Trusted Entity Type
2. Select **EC2 Auto Scaling** from the Use cases for other AWS services drop-down and **EC2 Auto Scaling** option

[![Create Roles](https://docs.rafay.co/clusters/eks/img/auto_eks/ec2-autoscaling.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/ec2-autoscaling.png)

1. Choose **Next**. The pre-defined Autoscaling Service Role Policy appears. Users can click on the policy to view the policy details

[![Create Roles](https://docs.rafay.co/clusters/eks/img/auto_eks/autoscaling_policy.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/autoscaling_policy.png)

1. Click **Next**

> Note: You cannot attach tags to service-linked roles during creation.

1. On the Review page, leave the Role name blank to create a service-linked role with the name AWSServiceRoleForAutoScaling
2. (Optional) For Role description, edit the description for the service-linked role
3. Click **Create role**

[![Create Roles](https://docs.rafay.co/clusters/eks/img/auto_eks/create_role.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/create_role.png)

Refer [Service-linked roles for Amazon EC2 Auto Scaling](https://docs.aws.amazon.com/autoscaling/ec2/userguide/autoscaling-service-linked-role.html) for more information.

---

## EKS service-linked role creation

1. Open the IAM console at [https://console.aws.amazon.com/iam/](https://console.aws.amazon.com/iam/).
2. In the left navigation pane, choose Roles and click **Create role**. [![Create Roles](https://docs.rafay.co/clusters/eks/img/auto_eks/create_roles.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/create_roles.png)
3. Select **AWS service** for Trusted Entity Type
4. Select **EKS** from the Use cases for other AWS services drop-down [![Create Roles](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_usecase.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_usecase.png)
5. Choose **Next**. The pre-defined EKS Service Role policy appears. Users can click on the policy to view the policy details
6. Click **Next** **Note:** You cannot attach tags to service-linked roles during creation.
7. On the Review page, leave the Role name blank to create a service-linked role with the name AWSServiceRoleForAmazonEKS
8. (Optional) For Role description, edit the description for the service-linked role
9. Click **Create role**

[![Create Roles](https://docs.rafay.co/clusters/eks/img/auto_eks/create_eks_role.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/create_eks_role.png)

Refer [Service-linked roles for Amazon EKS](https://docs.aws.amazon.com/eks/latest/userguide/using-service-linked-roles.html) for more information.

> ℹ️ Note:
> 
> 
> When using a custom KMS key for EBS volume encryption in node groups, additional permissions must be granted in the KMS key policy for the AWSServiceRoleForAutoScaling role. Failure to include these permissions may result in cluster provisioning failures.
> 
> 
> For details and the required key policy statements, refer to Cluster provisioning fails when custom KMS key is used for volume encryption in the troubleshooting guide.

---
