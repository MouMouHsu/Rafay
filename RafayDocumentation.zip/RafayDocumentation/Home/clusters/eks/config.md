---
title: "KOP EKS Clusters - Cluster Config"
source: https://docs.rafay.co/clusters/eks/config/
category: Home
---

# Cluster Config

The controller maintains the EKS cluster's configuration as a "cluster specification" YAML file that can be accessed and downloaded by authorized administrators. They can download the EKS Cluster's configuration

- Either from the console or
- Using the RCTL CLI or
- Programmatically using the REST APIs.

[![Download Configuration](https://docs.rafay.co/clusters/eks/img/auto_eks/download_config%26cost.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/download_config%26cost.png)

---

## Examples

A number of examples of "cluster configuration" YAML files for common configurations are available on this public [git repo](https://github.com/RafaySystems/rafay-cicd-helpers/tree/master/eks/examples).

Customers can use these examples as building blocks for their Amazon EKS clusters.

---
