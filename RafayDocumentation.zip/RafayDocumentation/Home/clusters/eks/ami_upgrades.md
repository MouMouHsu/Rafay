---
title: "KOP EKS Clusters - AMI Upgrades"
source: https://docs.rafay.co/clusters/eks/ami_upgrades/
category: Home
---

# AMI Upgrades

If you are using an Amazon EKS optimized AMI, AWS automatically applies the latest security patches and operating system updates as part of the latest AMI release version.

The new [Amazon EKS optimized AMIs](https://docs.aws.amazon.com/eks/latest/userguide/eks-linux-ami-versions.html) are released on a frequent basis. For example, there were seven (7) EKS optimized AMI releases for k8s 1.19.6

[![EKS Optimized AMI Releases](https://docs.rafay.co/clusters/eks/img/upgrade/k8s119_ami_versions.png)](https://docs.rafay.co/clusters/eks/img/upgrade/k8s119_ami_versions.png)

It is a good practice to replace the nodes in your node group with the new AMI to ensure the underlying OS and software packages for the worker nodes are kept current, patched and up to date from a security PoV.

---

## AMI Upgrades

The controller provides a single click workflow for AMI upgrades. The workflow is identical to "k8s version upgrades" and therefore there is nothing new for the administrator to learn.

- For self managed node groups, the controller automatically checks for latest AMI
- For managed node groups, the controller automatically checks for the latest release version.

The administrator is provided with a visible notification when an updated AMI is available. Once the administrator initiates the AMI upgrade and the controller upgrades the worker node to the new AMI.

Organizations that use a "Custom AMI" can also use the same workflow to upgrade their worker nodes to an updated version of their custom AMI.

[![AMI Update Notification](https://docs.rafay.co/clusters/eks/img/upgrade/ami_upgrade.png)](https://docs.rafay.co/clusters/eks/img/upgrade/ami_upgrade.png)

An audit trail of the administrator initiated action is generated (who performed it, when was it performed) and the upgrade status and history is available for inspection and review.

[![AMI Update History](https://docs.rafay.co/clusters/eks/img/upgrade/ami_upgrade_history.png)](https://docs.rafay.co/clusters/eks/img/upgrade/ami_upgrade_history.png)

---

## View AMI ID(s)

Across the organization or the projects, users can identify the list of the AMI Images associated with the node groups of EKS clusters.

You can view the list of AMI IDs associated with the nodegroup(s) using the **Swagger based REST APIs**

- In the Controller, under the Cluster GET nodegroupamis API, enter the project id and click **Execute**

> **Important**
> Only the authorized users can access the REST APIs with an API key

[![AMI Execute](https://docs.rafay.co/clusters/eks/img/upgrade/amiid_execute.png)](https://docs.rafay.co/clusters/eks/img/upgrade/amiid_execute.png)

- The response lists the AMI ID(s) associated with each nodegroup(s) of the cluster(s)

The below example (response) shows an AMI ID **AL2_x86_64** associated with a nodegroup **test-ng-01** of the cluster **test-01**, along with the project id **rx28oml**

[![AMI Execute](https://docs.rafay.co/clusters/eks/img/upgrade/amiid_response.png)](https://docs.rafay.co/clusters/eks/img/upgrade/amiid_response.png)

---
