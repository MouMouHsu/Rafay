---
title: "KOP EKS Clusters - Node Labels"
source: https://docs.rafay.co/clusters/eks/node_labels/
category: Home
---

# Node Labels

It is a very common practice to use labels for nodes in Kubernetes clusters. One of the most common use cases of node labels is to ensure that [pods are scheduled to particular nodes](https://kubernetes.io/docs/tasks/configure-pod-container/assign-pods-nodes/) in the cluster using a _**node selector**.

---

## Manually Label Nodes

In addition to KubeCTL, administrators can use the Web Console to **manually** manage the labels for their EKS Worker Nodes. The image below shows an illustrative example.

- Select a Node
- Click on Edit Labels to add/remove custom labels

NOTE: A number of "default" labels are injected into every node in the cluster automatically.

[![Manage Node Labels](https://docs.rafay.co/clusters/eks/img/labels/manual_label.png)](https://docs.rafay.co/clusters/eks/img/labels/manual_label.png)

---

## Auto Label Nodes

Although it is possible to **manually** manage labels on worker nodes in an Amazon EKS cluster, it can be very operationally cumbersome on large clusters that are configured to automatically scale up and down using a **cluster autoscaler**.

### Cluster Autoscaler Example

In scenarios where the cluster is configured to use an auto scaler, worker nodes are added and removed dynamically. For example,the cluster may have 10 worker nodes at 8am and may automatically scale to 100 worker nodes at 2pm. It is impractical to assume that the administrator can somehow find a way to manually label the new worker nodes in a timely manner.

### Large Cluster Example

In scenarios where a large cluster with 10s or 100s of worker nodes are required, it is impractical to assume that the administrator will be able to manually label the new worker nodes.

The Controller provides turnkey automation for scenarios like this. Administrators can specify **node labels** (Key Only or Key-Value) during creation of a worker node group. When new worker nodes are added to the node group by the cluster autoscaler, they will be automatically labeled with the specified the configured labels.

In the illustrative example below, all worker nodes in the node group will be _*Automatically Labeled* with the specified node labels "type=spot".

[![Automated Node Labels](https://docs.rafay.co/clusters/eks/img/labels/auto_labels_nodegroup.png)](https://docs.rafay.co/clusters/eks/img/labels/auto_labels_nodegroup.png)

---
