---
title: "KOP EKS Clusters - Overview"
source: https://docs.rafay.co/clusters/eks/iam_policy/
category: Home
---

# Overview

## IAM Policy for EKS Provisioning

This IAM policy is required if you would like to use the Controller for "Provisioning" and "Ongoing Lifecycle Management" of Amazon EKS clusters. The same policy applies for both IAM Role and IAM User based Cloud Credentials. As new functionality is added, the IAM Policy will need to be updated as well. As a result, customers should make sure that they are using the latest version.

> **Tip**
> It is possible to use a subset of this IAM Policy for scenarios where (a) certain infra resources are directly managed by the customer or (b) certain capabilities with EKS are not required. Please contact support for details.

---

### IAM policies for EKS Control plane

Kubernetes clusters managed by Amazon EKS make calls to other AWS services to manage the resources that you use with the service. To create Amazon EKS clusters, IAM roles with a set of policies are mandatory which allows the service to access resources in other services.

Refer [Service Role ARN](https://docs.rafay.co/clusters/eks/iam_policies_eks/#service-role-arn) to view the list of policies for the EKS Control plane

---

### IAM Policies for Worker Node Groups

To launch nodes and deploy them into a cluster, the user must create an IAM role for those nodes to use when deployed. This requirement applies to nodes launched with the Amazon EKS optimized AMI or with any other node AMIs that you intend to use. It is mandatory to create an IAM role with a set of policies before creating a node.

- Refer [Node Instance Role ARN](https://docs.rafay.co/clusters/eks/iam_policies_eks/#node-instance-role-arn) to view the list of policies and permissions should be associated to the Node Instance Role
- Refer [Autoscaling service-linked role creation](https://docs.rafay.co/clusters/eks/iam_policies_eks/#autoscaling-service-linked-role-creation) to view the pre-defined policies of EKS Autoscaling
- Refer [Instance Profile ARN](https://docs.rafay.co/clusters/eks/iam_policies_eks/#instance-profile-arn) to know more about the IAM Roles and Policies

---

### IAM Policy Examples

Here are some examples of IAM Policies that customers can use and customize to suit their specific requirements.

| # | Description |
| --- | --- |
| 1 | [Required AWS resources will be automatically created by the Controller](https://docs.rafay.co/clusters/eks/full_iam_policy/) |
| 2 | [Customer creates VPC resources](https://docs.rafay.co/clusters/eks/minimal_iam_policy1/) |
| 3 | [Customer creates both VPC and IAM resources](https://docs.rafay.co/clusters/eks/minimal_iam_policy2/) |
| 4 | [Existing VPC, IAM resources are used and with restrictions on the resources](https://docs.rafay.co/clusters/eks/restricted_iam_policy/) |
| 5 | [Restricted IAM Policies on Resource Tags](https://docs.rafay.co/clusters/eks/restricted_iam_tag_policy/) |

---
