---
title: "v3 Unified Config Schema for Amazon EKS Clusters"
source: https://docs.rafay.co/clusters/eks/eks_schema_v3/
category: Home
---

# Unified EKS Schema

This is the unified EKS schema which is only supported through the GITOPS flow for now.

## Cluster YAML
