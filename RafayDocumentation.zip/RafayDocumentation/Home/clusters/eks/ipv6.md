---
title: "KOP EKS Clusters - IPv6"
source: https://docs.rafay.co/clusters/eks/ipv6/
category: Home
---

# Cluster with IPv6 Configuration

> **Important**
> Support for IPv6 is enabled selectively for customers and is not available to all organizations.

---

## IPv6 Enabled EKS Clusters

With the incorporation of IPv6 support in AWS EKS, the creation of IPv6-enabled Kubernetes clusters becomes effortlessly achievable. In an EKS cluster configured with IPv6, both pods and services are assigned unique IPv6 addresses. This configuration ensures the compatibility of older IPv4 connections with services in IPv6 clusters, and facilitates communication between pods within the cluster and external IPv4 destinations.

Follow the below restrictions when IPv6 is set:

1. Enable the managed add-ons **VPC-CNI**, **CoreDNS**, and **kube-proxy**
2. The cluster version must be 1.21 or higher
3. IPv6 clusters supports only the Managed nodegroups
4. The vpc-cni addon version must be 1.10.0 or higher
5. `vpc.NAT` and `serviceIPv4CIDR` fields are created by eksctl for IPv6 clusters and thus, are not supported configuration options
6. AutoAllocateIPv6 is not supported together with IPv6

### Required Addon Configuration

When creating an EKS cluster with IPv6, the `vpc-cni` addon requires explicit `configurationValues`. Without this, the cluster will fail to provision correctly.

Add the following addon configuration when creating an IPv6 EKS cluster:

```
addons:
  - name: vpc-cni
    version: latest
    configurationValues: '{"env":{"ENABLE_PREFIX_DELEGATION":"true","ENABLE_V6_EGRESS":"true","ENABLE_SUBNET_DISCOVERY":"false"},"init":{"env":{"ENABLE_V6_EGRESS":"true"}}}'
  - name: coredns
    version: latest
  - name: kube-proxy
    version: latest
  - name: aws-ebs-csi-driver
    version: latest
    attachPolicyARNs:
      - arn:aws:iam::aws:policy/service-role/AmazonEBSCSIDriverPolicy
```

> **Note**
> This configuration is mandatory for IPv6 clusters only. For provisioning steps, see [KOP EKS Clusters - Provision](https://docs.rafay.co/clusters/eks/provisioning/#ipv6-cluster-addon-configuration).

> Note: Only minimal blueprint is supported for now. Other blueprints will be supported in upcoming releases

When enabling IPv6 options and choosing Use your existing VPC & Subnets for IPv6 clusters, input the VPC details created with double-stack (IPv4 and IPv6) subnets. In the case of selecting Auto-create VPC & Subnets, define the VPC CIDR, and optionally, include the VPC IPv6 CIDR and IPv6 Pool. If subnets are not provided, the system randomly selects from the Amazon pool.

[![EKS Cluster Settings](https://docs.rafay.co/clusters/eks/img/auto_eks/edit_cluster_settings.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/edit_cluster_settings.png)

> **Important**
> | ``` 1 ``` | ``` Limited Access - This capability is enabled selectively for customers and is not available to all organizations. ``` |
> | --- | --- |

### IAM Policies

In addition to the current [IAM Policies](https://docs.rafay.co/clusters/eks/full_iam_policy/), ensure to have the below IAM Policies to create IPv6 enabled EKS Clusters:

- "ec2:CreateEgressOnlyInternetGateway"
- "ec2:DeleteEgressOnlyInternetGateway"
- "ec2:DisassociateVpcCidrBlock"
- "ec2:DescribeEgressOnlyInternetGateways"

### Minimal policy (Customer managed VPC and IAM)

In addition to the current [Customer Managed VPC and IAM Policies](https://docs.rafay.co/clusters/eks/minimal_iam_policy2/), ensure to have the below IAM Policies to create IPv6 enabled EKS Clusters:

- "iam:CreateOpenIDConnectProvider"
- "iam:DeleteOpenIDConnectProvider"
- "iam:CreateRole"
- "iam:DeleteRole"
- "iam:DeleteRolePolicy"
- "iam:PutRolePolicy"
- "iam:DetachRolePolicy"
- "iam:DeleteRolePolicy"
- "ec2:CreateEgressOnlyInternetGateway"
- "ec2:DeleteEgressOnlyInternetGateway"
- "ec2:DisassociateVpcCidrBlock"
- "ec2:DescribeEgressOnlyInternetGateways"

---

## Unsupported Configuration

When enabling IPv6, the below components are unsupported:

- Custom CNI
- Calico CNI
- Self-managed nodegroup
- Ubuntu nodegroup
- Windows nodegroup

Check out this [link](https://docs.aws.amazon.com/eks/latest/userguide/cni-ipv6.html) for important considerations regarding the use of the IPv6 in your cluster

---
