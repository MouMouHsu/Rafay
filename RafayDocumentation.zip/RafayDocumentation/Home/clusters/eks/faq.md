---
title: "KOP EKS Clusters - FAQ"
source: https://docs.rafay.co/clusters/eks/faq/
category: Home
---

# FAQs

This section documents many of the frequently asked questions related to Amazon EKS clusters that users may encounter.

---

## Kubernetes Versions

The default version of Kubernetes during initial cluster provisioning is updated frequently as new versions are supported by Amazon EKS. Support for older versions will be deprecated and removed once these fall off the support matrix.

---

## Exhaustion of Elastic IPs

Elastic IPs are a limited resource provided by AWS. If the AWS account has hit the upper limit for Elastic IPs, the automated infrastructure creation workflow will fail.

AWS requires their customers to submit requests for additional Elastic IPs. More information [here](https://docs.aws.amazon.com/AWSEC2/latest/WindowsGuide/elastic-ip-addresses-eip.html#using-instance-addressing-limit).

---

## Exhaustion of VPCs

AWS limits the default number of VPCs per region to 5 (five). The automated provisioning process will fail if this limit is encountered.

Customers can request additional VPCs by submitting a request. More information [here](https://docs.aws.amazon.com/vpc/latest/userguide/amazon-vpc-limits.html)

---

## Instance Launch Issues

If AWS does not have sufficient on demand instance capacity or if you have reached the limit on the number of instances you can launch in a region. More information [here](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/troubleshooting-launch.html).

---

## Pods per Node

All managed Kubernetes services such as Amazon EKS etc impose hard limits on the number of pods per node.

Amazon EKS's limits for "number of pods per node" are documented [here](https://github.com/awslabs/amazon-eks-ami/blob/master/files/eni-max-pods.txt)

## Is IPv6 configuration available for all organizations?

No, IPv6 configuration is not available for all organizations. This capability is enabled selectively for specific organizations and is not available by default. If your organization requires IPv6 configuration for EKS Clusters, please reach out to Rafay support to get it enabled.

## What type of blueprint is supported for IPv6 based EKS clusters?

IPv6-based EKS clusters only support a minimal blueprint. More comprehensive blueprints are not currently supported for IPv6-based clusters. For further assistance or to explore options regarding IPv6 configuration, please contact Rafay support.

## Why is at least one node group required for an EKS cluster?

We currently enforce a validation that requires at least one node group to exist for an EKS cluster. This is necessary for rafay operator components to function correctly and to ensure the aws-auth ConfigMap is updated with the appropriate IAM roles when users add self-managed node groups. If cost is a concern, users can scale down the node group instead of deleting it entirely.

---
