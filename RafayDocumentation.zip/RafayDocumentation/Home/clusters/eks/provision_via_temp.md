---
title: "KOP EKS Clusters - Provisioning with AWS EKS System Template"
source: https://docs.rafay.co/clusters/eks/provision_via_temp/
category: Home
---

# AWS EKS System Template

## Overview

Rafay provides multiple methods for provisioning and managing Amazon EKS clusters. In addition to the traditional provisioning approach, users can leverage the AWS EKS System Template for a streamlined and standardized cluster provisioning experience. This method integrates with AWS’s Infrastructure as Code (IaC) OpenTofu provider, supporting both initial cluster setup (Day 0) and ongoing management (Day 2).

The **AWS EKS System Template** simplifies cluster creation and lifecycle management while ensuring consistency and scalability.

> 📌 Important Note
> For detailed documentation, refer to the AWS EKS System Template

---

## About the AWS EKS System Template

The AWS EKS System Template is a predefined template that allows users to provision and manage EKS clusters efficiently. It provides built-in configurations that align with best practices, enabling users to:

- Deploy EKS clusters using **automated, repeatable configurations**
- Manage **cluster security, networking, and scaling** with minimal manual effort
- Leverage Rafay’s **infrastructure automation** capabilities for consistency and efficiency

---

## Comparison with Traditional Provisioning

| Feature | Traditional Provisioning | AWS EKS System Template |
| --- | --- | --- |
| Configuration | Manual setup via Rafay UI or CLI | Predefined automated template |
| Customizability | Requires manual adjustments | Built-in best practices with customization options |
| Automation | Partial (manual steps required) | Fully automated provisioning & management |
| Security | Requires manual role setup | Secure by default with kubeconfig and RBAC |
| Scalability | Manual scaling & updates | Automated scaling & lifecycle management |

---

## Next Steps

- 📖 Learn more about **[AWS EKS System Template](https://docs.rafay.co/template_catalog/eks/eks/)**
- 🔍 Review the **[Traditional EKS Cluster Provisioning Guide](https://docs.rafay.co/clusters/eks/provisioning/)**

---
