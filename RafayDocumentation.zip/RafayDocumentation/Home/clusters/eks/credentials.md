---
title: "KOP EKS Clusters - Credentials"
source: https://docs.rafay.co/clusters/eks/credentials/
category: Home
---

# Credentials for EKS

With the Controller, you can fully automate the provisioning and ongoing lifecycle management of Amazon EKS clusters in all supported AWS regions.

With auto-provisioning, you can have a cluster operational in just a few clicks. In order to do this, you need to provide credentials that allow programmatic access to Amazon AWS. Two types of credentials are supported.

---

## Option 1: AWS IAM Role

This option is strongly recommended. This is the more secure option because

- You do not have to create an IAM User for the controller,
- There are no secrets to be managed by the SaaS Controller and
- It is in alignment with AWS's Security best practices and recommendations

With this option, users will create a "Cloud Credential" which will be configured to use an IAM role for the Controller in your AWS account. Once created, you can reuse the cloud credential to provision as many clusters as necessary. Admins can also "share" the cloud credential with other projects.

> **Important**
> AWS's [Security Best Practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html#delegate-using-roles) recommending IAM Role over IAM User for 3rd Party Access.

---

### Create Cloud Credential

To configure an AWS IAM role, you will need the Controller's "AWS Account ID" and a "Unique External ID". You will also have to provide the Role ARN (Amazon Resource Name) for the AWS IAM Role before saving the Cloud Credential.

> **Important**
> Click [here](https://docs.rafay.co/clusters/eks/credentials_clusterprovisioning/) for step-by-step instructions on how to create an IAM Policy and IAM Role in your AWS account.

The high level workflow/sequence to create an IAM Role based cloud credential for AWS is shown below.

```
sequenceDiagram
  participant Admin
  participant AWS IAM
  participant Rafay Cloud Credential
  Admin->>AWS IAM: New Policy
  Note over Admin,AWS IAM: Paste Policy JSON
  Admin->>Rafay Cloud Credential: New Cloud Credential
  Rafay Cloud Credential->>Admin: Copy Account ID and External ID
  Admin->>AWS IAM: Create New Role
  Note over Admin,AWS IAM: Paste Account ID, External ID
  AWS IAM->>AWS IAM: Select Policy from above
  AWS IAM->>Admin: Copy Role ARN
  Admin->>Rafay Cloud Credential: Paste Role ARN
  Note over Admin,Rafay Cloud Credential: Cloud Credential Created
```

Follow the steps described below to create an IAM Role based cloud credential.

- Login to the Console and select "Cloud Credentials" under Infrastructure
- Click **New Credential** and provide a unique name
- Select the Type **Cluster Provisioning**
- Select provider **AWS** from the drop-down and credential type **Role**
- Copy the **Account ID**, and **External ID** and use these IDs to create a Role ARN

[![Create Cloud Credential](https://docs.rafay.co/clusters/eks/img/eks_creds/account_id.png)](https://docs.rafay.co/clusters/eks/img/eks_creds/account_id.png)

- Once the IAM Role is created in the AWS console, copy/paste the Role ARN over here as shown below and click **Save**

[![Create Cloud Credential](https://docs.rafay.co/clusters/eks/img/eks_creds/cloud_credential_role_create.png)](https://docs.rafay.co/clusters/eks/img/eks_creds/cloud_credential_role_create.png)

---

## Option 2: AWS IAM User

This approach is applicable for users where the use of IAM Roles is not possible. Configure an IAM user in AWS with programmatic access for the Controller in your AWS account. Enable it with programmatic access and configure the access key and secret in the Cloud Credential.

---

### Create Cloud Credential

> **Important**
> Click [here](https://docs.rafay.co/clusters/eks/credentials_clusterprovisioning/) for step-by-step instructions on how to create an IAM Policy and IAM User in your AWS account.

- Login to the Console and select "Cloud Credentials" under Infrastructure
- Click **New Credential** and provide a unique name
- Select the Type **Cluster Provisioning** and Credential Type **Access_Key**
- Copy/Paste the Access Key and Secret Access Key from the AWS Console
- Click **Save**

[![View Cloud Credential](https://docs.rafay.co/clusters/eks/img/eks_creds/create_accesskey.png)](https://docs.rafay.co/clusters/eks/img/eks_creds/create_accesskey.png)

> Note: The Credential type is displayed in the Type column

---

### Rotate Credential

It is sometimes necessary to replace an existing cloud credential with a new one. This can happen due to a variety of reasons, For example,

- Internal security policy for periodic rotation
- Need to change type of cloud credential
- Potential exposure requiring rotation

It is possible to perform an "in-place swap" of the cloud credential for an existing Amazon EKS cluster provisioned and managed by the controller.

---

### Existing Credential

Navigate to the "Cluster->Configuration" tab to view the "cloud credential" currently being used by the cluster. Both the "name" and "type" will be displayed.

[![View Cloud Credential](https://docs.rafay.co/clusters/eks/img/rotate_creds/which_creds.png)](https://docs.rafay.co/clusters/eks/img/rotate_creds/which_creds.png)

---

### Replace Credential

To swap the existing cloud credential with a new one, follow the steps below

- Create the new cloud credential
- Navigate to the "Cluster->Configuration" tab
- Click on "Edit" and select the replacement cloud credential from the dropdown

[![Swap Cloud Credential](https://docs.rafay.co/clusters/eks/img/rotate_creds/edit_creds.png)](https://docs.rafay.co/clusters/eks/img/rotate_creds/edit_creds.png)

Any subsequent operations on the managed cluster will be performed using the "new cloud credential".

---

## Sharing

Organizations can create and use "unique" cloud credentials per project. This approach can be useful if different cloud provider accounts need to be used in every project. This helps with "billing" and "isolation". However, this approach may not be practical for scenarios where the organization's security policies may require "centralization" of cloud credentials. For scenarios like this, organizations can "share" their cloud credentials with selected or all projects.

- Click on the "share" menu option
- Select the projects you would like to share the cloud credential with

[![Share Cloud Credential](https://docs.rafay.co/clusters/eks/img/share_creds/share_creds.png)](https://docs.rafay.co/clusters/eks/img/share_creds/share_creds.png)

The downstream projects that "inherit" the shared cloud credential can view and use the inherited cloud credentials. But, they are not allowed to edit/delete them.

[![Inherited Cloud Credential](https://docs.rafay.co/clusters/eks/img/share_creds/inherited_credential.png)](https://docs.rafay.co/clusters/eks/img/share_creds/inherited_credential.png)

---
