---
title: "KOP EKS Clusters - Restricted IAM Policies on Resource Tags"
source: https://docs.rafay.co/clusters/eks/restricted_iam_tag_policy/
category: Home
---

# Restricted IAM Policies on Tags

## Restricted IAM Policies on Resource Tags

With this policy example, the customer is expected to apply restrictions on Tags

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "iam:GetOpenIDConnectProvider",
                "iam:GetRole",
                "iam:GetInstanceProfile",
                "iam:GetRolePolicy",
                "iam:ListOpenIDConnectProviderTags",
                "iam:ListInstanceProfiles",
                "iam:ListInstanceProfilesForRole",
                "iam:ListRoleTags",
                "iam:ListAttachedRolePolicies",
                "iam:TagRole",
                "iam:ListPolicyVersions",
                "iam:GetPolicy",
                "iam:GetPolicyVersion"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "iam:PassRole"
            ],
            "Resource": "*",
            "Condition": {
                 "StringEquals": {
                     "iam:PassedToService": [
                         "eks.amazonaws.com",
                         "ec2.amazonaws.com"
                     ]
                 }
             }
        },
        {
            "Effect": "Allow",
            "Action": [
                "iam:CreateOpenIDConnectProvider",
                "iam:TagOpenIDConnectProvider",
                "iam:DeleteOpenIDConnectProvider"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:RequestTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudformation:ListStacks",
                "cloudformation:ListStackResources",
                "cloudformation:ListStackSets",
                "cloudformation:ListChangeSets",
                "cloudformation:DescribeStacks",
                "cloudformation:DescribeStackResources",
                "cloudformation:DescribeStackResource",
                "cloudformation:DescribeStackEvents",
                "cloudformation:DescribeChangeSet",
                "cloudformation:DescribeStackSet",
                "cloudformation:GetTemplate"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudformation:CreateStackSet",
                "cloudformation:CreateStack",
                "cloudformation:CreateChangeSet"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:RequestTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudformation:DeleteStackSet",
                "cloudformation:UpdateStackSet",
                "cloudformation:UpdateStack",
                "cloudformation:DeleteStack",
                "cloudformation:DeleteChangeSet",
                "cloudformation:ExecuteChangeSet"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:ResourceTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "eks:AccessKubernetesApi",
                "eks:CreatePodIdentityAssociation",
                "eks:DescribeClusterVersions",
                "eks:DescribePodIdentityAssociation",
                "eks:DeletePodIdentityAssociation",
                "eks:UpdatePodIdentityAssociation",
                "eks:ListPodIdentityAssociations",
                "eks:DescribeNodegroup",
                "eks:DescribeCluster",
                "eks:DescribeAddon",
                "eks:DescribeAddonVersions",
                "eks:DescribeAddonConfiguration",
                "eks:DescribeFargateProfile",
                "eks:DescribeUpdate",
                "eks:ListTagsForResource",
                "eks:ListUpdates",
                "eks:ListClusters",
                "eks:ListNodegroups",
                "eks:ListAddons",
                "eks:ListFargateProfiles"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "eks:CreateCluster",
                "eks:CreateNodegroup",
                "eks:CreateFargateProfile"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:RequestTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "eks:TagResource"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:RequestTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "eks:UpdateClusterVersion",
                "eks:UpdateClusterConfig",
                "eks:DeleteCluster",
                "eks:UpdateAddon",
                "eks:UpdateNodegroupConfig",
                "eks:UpdateNodegroupVersion",
                "eks:CreateAddon",
                "eks:DeleteAddon",
                "eks:DeleteNodegroup",
                "eks:DeleteFargateProfile",
                "eks:UntagResource"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:ResourceTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "autoscaling:DescribeAutoScalingGroups",
                "autoscaling:DescribeLaunchConfigurations",
                "autoscaling:DescribeScheduledActions",
                "autoscaling:DescribeScalingActivities"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "autoscaling:CreateOrUpdateTags",
                "autoscaling:CreateLaunchConfiguration",
                "autoscaling:CreateAutoScalingGroup"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:RequestTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "autoscaling:TerminateInstanceInAutoScalingGroup",
                "autoscaling:SetDesiredCapacity",
                "autoscaling:UpdateAutoScalingGroup",
                "autoscaling:DeleteAutoScalingGroup",
                "autoscaling:SuspendProcesses",
                "autoscaling:DeleteTags",
                "autoscaling:DeleteLaunchConfiguration"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:ResourceTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:DeleteSecurityGroup",
                "ec2:RevokeSecurityGroupEgress",
                "ec2:AuthorizeSecurityGroupEgress",
                "ec2:RevokeSecurityGroupIngress",
                "ec2:AuthorizeSecurityGroupIngress",
                "ec2:DescribeAvailabilityZones"
            ],
            "Resource": "*",
            "Condition": {
                "ForAllValues:StringEquals": {
                    "aws:TagKeys": ["<KEY>","aws:eks:cluster-name"]
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:ModifySecurityGroupRules",
                "ec2:UpdateSecurityGroupRuleDescriptionsIngress",
                "ec2:UpdateSecurityGroupRuleDescriptionsEgress"
            ],
            "Resource": "*",
            "Condition": {
                "StringEquals": {
                    "aws:ResourceTag/<KEY>": "<VALUE>"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": "ssm:GetParameter",
            "Resource": "arn:aws:ssm:*:*:parameter/aws/service/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "kms:DescribeKey"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "kms:CreateGrant"
            ],
            "Resource": "*"
        }
    ]
}
```

> **Note**
> For customers who will manage their own IAM Roles and Policies, (3) ARNs are required when provisioning managed K8s clusters.

1. Service Role ARN
2. Instance Profile ARN
3. Instance Role ARN

[IAM Roles and Policies](https://docs.rafay.co/clusters/eks/iam_policies_eks/)
