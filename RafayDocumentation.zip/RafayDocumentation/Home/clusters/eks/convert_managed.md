---
title: "KOP Takeover - Convert to Managed"
source: https://docs.rafay.co/clusters/eks/convert_managed/
category: Home
---

# Convert to Managed

Users can optionally allow the controller to takeover lifecycle management of an "Imported" Amazon EKS cluster. This allows the controller to perform all cluster lifecycle management offers capabilities: i.e. scale, add node groups, upgrade and perform any post-provision operations on the imported EKS clusters. The controller retrieves information about the imported EKS clusters to make the cluster’s infrastructure equivalent to the managed EKS clusters provisioned through the controller.

Explore our blog for deeper insights on Takeover Lifecycle Management of Amazon EKS Clusters, available [here](https://docs.rafay.co/blog/2022/12/09/takeover-lifecycle-management-of-amazon-eks-clusters/)!

---

## Requirements

Currently, only EKS clusters with "managed node groups" can be converted to managed clusters and the self managed node groups are ignored for lifecycle management. Customers are recommended to migrate their Kubernetes resources from the self managed node group to a new managed node group before attempting the conversion.

> **Important**
> - Self Managed node groups can be added back to the EKS cluster **after** the conversion to managed is complete.
> - The credentials or IAM role used to convert the cluster must exist as an [Access entry](https://docs.rafay.co/clusters/eks/cluster_access/) in the EKS cluster with the `AmazonEKSClusterAdminPolicy` attached.

---

## Unsupported Resources

The following resources are currently not supported for "takeover" of lifecycle management. Support for these will be added in upcoming releases.

- Node Group Taints
- Managed Add-ons
- Fargate Profiles

---

## Convert To Managed

Users are allowed to convert the "imported EKS cluster" to a Managed Cluster at any point its life.

- On successful import, a clickable label **Convert to Managed** is available next to the imported cluster as shown in the example below. Tthis option provides a workflow for the administrators to initiate the conversion of the cluster from "imported" to "managed".

[![Import Cluster](https://docs.rafay.co/clusters/eks/img/auto_eks/convert_managed-button.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/convert_managed-button.png)

Clicking on the label, the below screen appears

- Select the **Cloud Credentials** and **Region** of the imported cluster
- Select the source cluster name from the provider to link to the imported cluster and click **Convert to Managed Cluster**

[![Import Cluster](https://docs.rafay.co/clusters/eks/img/auto_eks/import_cred.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/import_cred.png)

The system shows the below message and the user must click **Yes** to confirm the conversion process

[![Import Cluster](https://docs.rafay.co/clusters/eks/img/auto_eks/confirm-messsage.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/confirm-messsage.png)

Now the system saves the provided credentials against the cluster and changes the cluster type to "Amazon EKS". The managed and imported property is set to True and a declarative cluster specification gets generated for the cluster. Once complete, the controller declares the cluster as being ready for performing "lifecycle management" operations.

- On successful conversion, you will receive a success message as shown below

[![Import Cluster](https://docs.rafay.co/clusters/eks/img/auto_eks/converted_success.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/converted_success.png)

You can see the cluster type as **Imported + Managed** and the list of operations allowed on the clusters page

[![Import Cluster](https://docs.rafay.co/clusters/eks/img/auto_eks/cluster_type.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/cluster_type.png)

Refer [Import EKS Cluster](https://docs.rafay.co/clusters/import/wizard/#takeover-management) for more information on Convert To Managed clusters

---

## Nodegroup Availability

Once the conversion is complete, the details about the managed node group and actions are available for the users.

[![Import Cluster](https://docs.rafay.co/clusters/eks/img/auto_eks/node_group_avail.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/node_group_avail.png)

---

## Post Conversion Operations

Following are the post conversion (**Day 2**) operations supported on imported Amazon EKS clusters that are converted to managed:

- Kubernetes and AMI Upgrades
  - Control Plane
  - Managed/self-managed node group (including custom amis)
- Node Groups
  - Add managed node groups
  - Add self-managed node groups
  - Scale/Drain managed node groups
  - Scale/Drain self-managed node groups
- Update
  - Blueprints
  - Cloud providers
  - Control Plane Endpoints
  - cloudwatchlogging
  - Control plane labels
  - Control plane tags
  - Update Managed Node-group Labels, Taints, and Tags
  - Rafay labels
  - Toleration, Node-Selectors, and Daemonset override
- Delete
  - Cluster
  - Managed node group
  - Self-managed node group

---

## Delete imported managed cluster(s)

When the user deletes the imported managed cluster, the controller deletes the following resources in the AWS account.

- managed and self managed nodegroups created through controller and the underlying resources
- managed nodegroups that got imported with the cluster and its underlying resources
- EKS cluster itself

The below resources are not deleted:

- The self managed nodegroups and their underlying resources that were **not** created through the controller
- All underlying cluster resources **not** created via the controller (CloudFormation Stack, VPCs, IAM roles etc.)

Refer [IAM policy](https://docs.rafay.co/clusters/eks/full_iam_policy/) to review the required permission for the IAM role to convert the imported EKS cluster to managed

---

## RCTL to Convert EKS Imported Cluster(s)

Users can also use RCTL CLI to convert imported EKS clusters to managed.

```
./rctl convert2managed cluster eks <controller-cluster-name> --source-cluster <imported-cluster> --region <region-name> --credential <credential_name>
```

The name of the imported cluster on controller is referred as the `controller-cluster-name`

The name of the cluster on AWS that you wish to import is referred to as the `imported cluster`

---

## Wait Flag

When a user attempts to convert an imported EKS cluster to managed, they can utilize the `--wait` flag to ascertain the success or failure of the operation. By incorporating the `--wait` flag, the RCTL command will patiently wait for the conversion process to conclude, only returning control once the process is finished or if an error is encountered. This ensures that the command precisely communicates whether the conversion process was successful or not, delivering the essential error messages required for effective detection and resolution.

````
./rctl convert2managed cluster eks <controller-cluster-name> --source-cluster <imported-cluster> --region <region-name> --credential <credential_name> --wait`

---
