---
title: "KOP EKS Clusters - Full"
source: https://docs.rafay.co/clusters/eks/full_iam_policy/
category: Home
---

# Full

### Full IAM Policy

Use this IAM Policy if you do not have pre-existing AWS resources and would like the Controller to dynamically create these in your AWS account for the Amazon EKS Cluster.

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "iam:CreateInstanceProfile",
                "iam:CreateOpenIDConnectProvider",
                "iam:DeleteOpenIDConnectProvider",
                "iam:GetOpenIDConnectProvider",
                "iam:ListOpenIDConnectProviderTags",
                "iam:TagOpenIDConnectProvider",
                "iam:DeleteInstanceProfile",
                "iam:GetRole",
                "iam:GetInstanceProfile",
                "iam:RemoveRoleFromInstanceProfile",
                "iam:CreateRole",
                "iam:DeleteRole",
                "iam:AttachRolePolicy",
                "iam:PutRolePolicy",
                "iam:ListInstanceProfiles",
                "iam:AddRoleToInstanceProfile",
                "iam:ListInstanceProfilesForRole",
                "iam:PassRole",
                "iam:DetachRolePolicy",
                "iam:UpdateAssumeRolePolicy",
                "iam:DeleteRolePolicy",
                "iam:GetRolePolicy",
                "iam:DeleteServiceLinkedRole",
                "iam:CreateServiceLinkedRole",
                "iam:TagRole",
                "iam:ListRoleTags",
                "iam:ListAttachedRolePolicies",
                "iam:ListPolicyVersions",
                "iam:GetPolicy",
                "iam:GetPolicyVersion"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudformation:GetTemplate",
                "cloudformation:ListStacks",
                "cloudformation:ListStackResources",
                "cloudformation:ListStackSets",
                "cloudformation:ListChangeSets",
                "cloudformation:DescribeStacks",
                "cloudformation:DescribeStackResources",
                "cloudformation:DescribeStackResource",
                "cloudformation:DescribeStackEvents",
                "cloudformation:DescribeChangeSet",
                "cloudformation:DescribeStackSet",
                "cloudformation:DeleteStack",
                "cloudformation:DeleteChangeSet",
                "cloudformation:DeleteStackSet",
                "cloudformation:CreateStackSet",
                "cloudformation:UpdateStackSet",
                "cloudformation:CreateChangeSet",
                "cloudformation:ExecuteChangeSet",
                "cloudformation:CreateStack",
                "cloudformation:UpdateStack"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "eks:AssociateEncryptionConfig",
                "eks:CreatePodIdentityAssociation",
                "eks:DescribePodIdentityAssociation",
                "eks:DescribeClusterVersions",
                "eks:DeletePodIdentityAssociation",
                "eks:UpdatePodIdentityAssociation",
                "eks:ListPodIdentityAssociations",
                "eks:CreateAccessEntry",
                "eks:CreateAddon",
                "eks:CreateCluster",
                "eks:CreateFargateProfile",
                "eks:DescribeNodegroup",
                "eks:DescribeCluster",
                "eks:DescribeAddon",
                "eks:DescribeAddonConfiguration",
                "eks:DescribeAddonVersions",
                "eks:DescribeFargateProfile",
                "eks:DescribeUpdate",
                "eks:ListUpdates",
                "eks:UpdateClusterVersion",
                "eks:UpdateClusterConfig",
                "eks:ListAccessPolicies",
                "eks:ListAccessEntries",
                "eks:ListAssociatedAccessPolicies",
                "eks:AssociateAccessPolicy",
                "eks:ListClusters",
                "eks:ListNodegroups",
                "eks:ListAddons",
                "eks:ListFargateProfiles",
                "eks:ListTagsForResource",
                "eks:CreateNodegroup",
                "eks:TagResource",
                "eks:AccessKubernetesApi",
                "eks:DeleteCluster",
                "eks:DeleteAccessEntry",
                "eks:UntagResource",
                "eks:UpdateAddon",
                "eks:UpdateNodegroupConfig",
                "eks:UpdateNodegroupVersion",
                "eks:DeleteAddon",
                "eks:DeleteFargateProfile",
                "eks:DeleteNodegroup",
                "eks:ListInsights",
                "eks:DescribeInsight",
                "eks:DescribeAccessEntry",
                "eks:DisassociateAccessPolicy",
                "eks:UpdateAccessEntry"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "autoscaling:DescribeAutoScalingGroups",
                "autoscaling:DescribeLaunchConfigurations",
                "autoscaling:DescribeScalingActivities",
                "autoscaling:DescribeScheduledActions",
                "autoscaling:CreateLaunchConfiguration",
                "autoscaling:DeleteLaunchConfiguration",
                "autoscaling:TerminateInstanceInAutoScalingGroup",
                "autoscaling:SetDesiredCapacity",
                "autoscaling:UpdateAutoScalingGroup",
                "autoscaling:DeleteAutoScalingGroup",
                "autoscaling:CreateAutoScalingGroup",
                "autoscaling:SuspendProcesses",
                "autoscaling:CreateOrUpdateTags",
                "autoscaling:DeleteTags"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": "ec2:DeleteInternetGateway",
            "Resource": "arn:aws:ec2:*:*:internet-gateway/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:AuthorizeSecurityGroupIngress",
                "ec2:GetConsoleOutput",
                "ec2:DeleteSubnet",
                "ec2:DeleteTags",
                "ec2:CreateNatGateway",
                "ec2:CreateVpc",
                "ec2:AttachInternetGateway",
                "ec2:DescribeVpcAttribute",
                "ec2:DeleteRouteTable",
                "ec2:AssociateRouteTable",
                "ec2:DescribeInternetGateways",
                "ec2:CreateRoute",
                "ec2:CreateInternetGateway",
                "ec2:RevokeSecurityGroupEgress",
                "ec2:CreateSecurityGroup",
                "ec2:ModifyVpcAttribute",
                "ec2:DeleteInternetGateway",
                "ec2:DescribeRouteTables",
                "ec2:ReleaseAddress",
                "ec2:AuthorizeSecurityGroupEgress",
                "ec2:DescribeTags",
                "ec2:CreateTags",
                "ec2:DeleteRoute",
                "ec2:CreateRouteTable",
                "ec2:DetachInternetGateway",
                "ec2:DescribeNatGateways",
                "ec2:DisassociateRouteTable",
                "ec2:AllocateAddress",
                "ec2:DescribeSecurityGroups",
                "ec2:DescribeSecurityGroupRules",
                "ec2:RevokeSecurityGroupIngress",
                "ec2:DeleteSecurityGroup",
                "ec2:DeleteNatGateway",
                "ec2:DeleteVpc",
                "ec2:CreateSubnet",
                "ec2:DescribeSubnets",
                "ec2:DescribeAvailabilityZones",
                "ec2:DescribeImages",
                "ec2:describeAddresses",
                "ec2:DescribeVpcs",
                "ec2:CreateLaunchTemplate",
                "ec2:CreateLaunchTemplateVersion",
                "ec2:DescribeLaunchTemplates",
                "ec2:RunInstances",
                "ec2:DeleteLaunchTemplate",
                "ec2:DescribeLaunchTemplateVersions",
                "ec2:DescribeImageAttribute",
                "ec2:DescribeKeyPairs",
                "ec2:ImportKeyPair",
                "ec2:DescribeInstances",
                "ec2:ModifySubnetAttribute",
                "ec2:ModifySecurityGroupRules",
                "ec2:DescribeInstanceTypeOfferings",
                "ec2:AssociateVpcCidrBlock",
                "ec2:DescribeVolumes",
                "ec2:CreateCarrierGateway",
                "ec2:DeleteCarrierGateway",
                "ec2:DescribeCarrierGateways",
                "ec2:UpdateSecurityGroupRuleDescriptionsIngress",
                "ec2:UpdateSecurityGroupRuleDescriptionsEgress"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": "ssm:GetParameter",
            "Resource": "arn:aws:ssm:*:*:parameter/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "kms:DescribeKey",
                "kms:CreateGrant"
            ],
            "Resource": "*"
        },
         {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "logs:DeleteRetentionPolicy",
                "logs:PutRetentionPolicy"
            ],
            "Resource": "*"
        }
    ]
}
```

### ARC Zonal Shift / Auto Zonal Shift IAM Requirements

If you need to configure ARC Zonal Shift or Auto Zonal Shift (autozonalshift) for your Amazon EKS cluster, you must include the additional IAM permission set documented above in the Full IAM Policy JSON shown above.

For ARC Zonal Shift ensure you have the following AWS IAM policies in place

- [ARC Zonal Shift Permissions](https://docs.rafay.co/clusters/eks/zonal_shift/#iam-permissions)

### EKS Auto Mode IAM Requirements

For EKS Auto Mode cluster ensure you have the following AWS IAM policies in place as per AWS documentation:

- **Cluster IAM Role**: The IAM role used by the EKS Auto Mode cluster must have the necessary permissions for cluster operations
- **Node IAM Role**: The IAM role used by EKS Auto Mode nodes must have the required permissions for node operations

For more details on IAM role requirements, refer to the AWS documentation:

- [EKS Auto Mode cluster IAM role](https://docs.aws.amazon.com/eks/latest/userguide/auto-cluster-iam-role.html)
- [EKS Auto Mode node IAM role](https://docs.aws.amazon.com/eks/latest/userguide/auto-create-node-role.html)
