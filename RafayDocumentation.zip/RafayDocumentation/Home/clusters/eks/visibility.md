---
title: "KOP EKS Clusters - Visibility and Monitoring"
source: https://docs.rafay.co/clusters/eks/visibility/
category: Home
---

# Visibility and Monitoring

The Controller provides an integrated dashboard that provides cluster administrators with detailed visibility and insight into the Amazon EKS Cluster.

Multiple dashboards are provided to help the user manage the resources on the cluster effectively.

- Cluster Dashboard
- Node Dashboard
- Node Group Dashboard
- Kubernetes Resources Dashboard
- Pod Dashboard

---

## Dashboards

### Multi Cluster View

Navigate to the Project where the EKS Cluster is provisioned. A cluster card for all managed clusters is available to the user with "At a Glance" metrics . Note that the information in the cluster card is similar for all cluster types.

[![EKS Cluster Card](https://docs.rafay.co/clusters/eks/img/auto_eks/provisioned_eks_cluster.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/provisioned_eks_cluster.png)

---

### Cluster Dashboard

Click on the cluster name to view the cluster dashboard for the Amazon EKS Cluster.

The information presented in the cluster dashboard for Amazon EKS Clusters is generally similar for all types of clusters. Look at [Cluster Dashboard](https://docs.rafay.co/dashboard/cluster/) for additional details about this feature.

[![EKS Dashboard](https://docs.rafay.co/clusters/eks/img/auto_eks/visibility/cluster_dashboard.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/visibility/cluster_dashboard.png)

---

### Nodegroup Dashboard

Users can view latest status and details of each EKS node group by clicking on the node group name. An example is shown below.

[![Nodegroup Details](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_nodegroup_details.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_nodegroup_details.png)

---

### Node Dashboard

Users can view latest status and details of each worker node by expanding the node's card. An example is shown below.

[![Worker Node Details](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_node_details.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_node_details.png)

Click on "Overview" for a worker node to view the Worker Node Dashboard

[![Worker Node Dashboard](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_node_dashboard.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_node_dashboard.png)

---

### k8s Resources Dashboard

Users can view all the Kubernetes resources and their state on the cluster via an [integrated k8s resources dashboard](https://docs.rafay.co/dashboard/k8sresources/) provided on the Rafay Console.

---

### Pod Dashboard

Users can view a detailed dashboard for every pod operational on the cluster via an [integrated pod dashboard](https://docs.rafay.co/dashboard/pod_dashboard/) provided on the Rafay Console.

---

### Cluster Configuration

Once an Amazon EKS cluster has been provisioned by the Controller, admins can view the cluster's configuration by selecting the "Configuration" tab.

[![Cluster Configuration](https://docs.rafay.co/clusters/eks/img/vpcnetworking/ekscluster_config.png)](https://docs.rafay.co/clusters/eks/img/vpcnetworking/ekscluster_config.png)

To view VPC, Subnet details etc associated with the EKS cluster, click on "View More".

[![View More](https://docs.rafay.co/clusters/eks/img/vpcnetworking/config_details.png)](https://docs.rafay.co/clusters/eks/img/vpcnetworking/config_details.png)

---

## Audit Trail

All actions performed on the Amazon EKS cluster right from initial configuration, provisioning, node group actions and deletion are AUDITED. The audit trail is available in a reverse chronological format.

[![Audit Trail Nodegroup Actions](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_audit_trail.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/eks_audit_trail.png)

---
