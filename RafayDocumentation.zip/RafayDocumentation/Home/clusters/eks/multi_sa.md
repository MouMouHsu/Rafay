---
title: "KOP EKS Clusters - Multiple AWS User Accounts"
source: https://docs.rafay.co/clusters/eks/multi_sa/
category: Home
---

# Cross Account ARN

The AWS accounts are organized into a structure consisting of a "master" account and several "user" accounts. This eliminates the necessity of creating separate cloud credentials for each individual user account.

---

### Add Multiple AWS User Accounts

- Login to AWS Console and add the list of target account in a policy. Below is an illustrative policy encompassing all the necessary assumeRole permissions for facilitating cross-account access.

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "iam:ListPolicyVersions",
                "iam:GetPolicy",
                "iam:GetPolicyVersion",
                "iam:ListAttachedRolePolicies"
            ],
            "Resource": "*"
        },
        {
            "Sid": "VisualEditor3",
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Resource": "arn:aws:iam::200143372387:role/childrolearn"
        }
    ]
}
```

Where `Resource: arn:aws:iam::200143372387:role/childrolearn` is the child account role ARN associated with a master account. You can have many child accounts that the master role can assume.

The resource field contains the ARN of the target account's role, which already possesses the necessary permissions for EKS cluster creation.

---

> **Important**
> In the `master role` account , we require a trust relationship with the **controller aws account**. Additionally, the `child role` accounts assumed by the master role must also establish a trust relationship with the controller aws account.

## AWS IAM Role Configuration for Self-Hosted Controller

> **Important**
> In self hosted controller , ensure that the IRSA role of the controller is trusted by the child or target AWS accounts.

---

## Trust Relationship policy

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<controller aws account id>:root"
            },
            "Action": "sts:AssumeRole",
            "Condition": {
                "StringEquals": {
                    "sts:ExternalId": "xxxexternal_idxxx"
                }
            }
        }
    ]
}
```

> The controller aws account ID and external ID will be available when creating role-based cloud credentials on the controller.

To fetch the AWS child account, the master account must have the following permissions in the policies

- iam:ListPolicyVersions
- iam:GetPolicy
- iam:GetPolicyVersion
- iam:ListAttachedRolePolicies

Refer to IAM policies for different scenarios. You can find more information in [IAM Policy](https://docs.rafay.co/clusters/eks/iam_policy/)

Explore our blog for deeper insights on **AWS Cross Account Support for EKS LCM**, available [here](https://docs.rafay.co/blog/2023/07/17/aws-cross-account-support-for-eks-lcm-in-rafay/)!

---
