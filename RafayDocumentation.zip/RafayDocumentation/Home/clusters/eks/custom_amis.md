---
title: "KOP EKS Nodegroups - Custom AMI"
source: https://docs.rafay.co/clusters/eks/custom_amis/
category: Home
---

# Custom AMI

Users can deploy nodes with pre-built Amazon EKS optimized Amazon Machine Images (AMI) or create their own custom AMIs

A custom AMI allows you to make changes to low-level components that are difficult to implement or take a long time to apply in configuration files

---

### Pre-built AMI(s)

To view and use the pre-built latest AMI IDs, refer to [Pre-built Amazon EKS optimized AMIs](https://docs.aws.amazon.com/eks/latest/userguide/eks-optimized-amis.html).

Users can launch an instance from an existing AMI, customize the instance and save this updated configuration as a custom AMI. Instances launched from this custom AMI include the customizations made when the AMI was created.

All the AMI IDs are mapped to a Kubernetes version.

[![AMI IDS](https://docs.rafay.co/clusters/eks/img/auto_eks/amis_list.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/amis_list.png)

---

### Create AMI ID(s)

Users who do not prefer the existing AMI IDs and require a new Amazon Linux Amazon Machine Image (AMI) to deploy with an Amazon Elastic Kubernetes Service (Amazon EKS) cluster can create a custom AMI ID. Refer [Create Amazon EKS Custom AMI](https://aws.amazon.com/premiumsupport/knowledge-center/eks-custom-linux-ami/) for detailed procedure

---

### Custom AMI in Console

Once the required AMI is retrieved, enter the ID in the Nodegroup setting to deploy with an Amazon Elastic Kubernetes Service (Amazon EKS) cluster during the cluster creation

[![Nodegroup Settings](https://docs.rafay.co/clusters/eks/img/auto_eks/amis_nodegroup.png)](https://docs.rafay.co/clusters/eks/img/auto_eks/amis_nodegroup.png)

- For AmazonLinux2023 based Custom AMI, pass the below parameters via the cluster config file

```
overrideBootstrapCommand: |
  [AmazonLinux2023]
```

An illustrative example of a spec with nodegroup using custom ami of type AmazonLinux2023

```
managedNodeGroups:
- ami: ami-0b1e759617d057b7a
  desiredCapacity: 1
  iam:
    withAddonPolicies:
      autoScaler: true
  instanceType: t3.large
  maxSize: 1
  minSize: 1
  name: mngd-Bottle
  overrideBootstrapCommand: |
    [AmazonLinux2023]
```

- For GPU-based AL2023 nodegroups (e.g. NVIDIA instances), use an EKS-optimized GPU AL2023 AMI with `overrideBootstrapCommand: [AmazonLinux2023]`. The recommended AMI ID can be retrieved from the [AWS Systems Manager Parameter Store](https://docs.aws.amazon.com/eks/latest/userguide/retrieve-ami-id.html) using your Region and Kubernetes version. The accelerated AL2023 AMI is available in two variants: **NVIDIA x86** and **Neuron x86**.

An illustrative example of a spec with a GPU nodegroup using an EKS-optimized GPU AL2023 AMI (`amazon-eks-node-al2023-x86_64-nvidia-1.34-v20260318`)

```
managedNodeGroups:
- ami: ami-00e8faebba1a101ef
  desiredCapacity: 2
  iam:
    withAddonPolicies:
      autoScaler: true
      imageBuilder: true
  instanceTypes:
  - g5.12xlarge
  maxSize: 2
  minSize: 2
  name: demo-gpu-test
  overrideBootstrapCommand: |
    [AmazonLinux2023]
```

- For Bottlerocket based Custom AMI, pass the below parameters via the cluster config file

```
overrideBootstrapCommand: |
  [Bottlerocket]
```

An illustrative example of a spec with nodegroup using custom ami of type bottle rocket

```
managedNodeGroups:
- ami: ami-0aa20e14bc85fd711
  desiredCapacity: 1
  iam:
    withAddonPolicies:
      autoScaler: true
  instanceType: t3.large
  maxSize: 1
  minSize: 1
  name: mngd-Bottle
  overrideBootstrapCommand: |
    [Bottlerocket]
```

- For Windows based Custom AMI, pass the below parameters via the cluster config file

```
overrideBootstrapCommand: |
  [Windows]
```

An illustrative example of a spec with nodegroup using custom ami of type Windows

```
nodeGroups
- ami: ami-0f213d8626f4a0ca8
  desiredCapacity: 1
  iam:
    withAddonPolicies:
      autoScaler: true
      imageBuilder: true
  instanceType: t3.large
  maxSize: 1
  minSize: 1
  name: wind
  overrideBootstrapCommand: |
    [Windows]
  volumeSize: 80
  volumeType: gp3
```

- For Ubuntu based Custom AMI, pass the below parameters via the cluster config file

```
overrideBootstrapCommand: |
  [Ubuntu]
```

An illustrative example of a spec with nodegroup using custom ami of type Ubuntu

```
nodeGroups
- ami: ami-0f213d8626f4a0ca8
  desiredCapacity: 1
  iam:
    withAddonPolicies:
      autoScaler: true
      imageBuilder: true
  instanceType: t3.large
  maxSize: 1
  minSize: 1
  name: wind
  overrideBootstrapCommand: |
    [Ubuntu]
  volumeSize: 80
  volumeType: gp3
```

---
