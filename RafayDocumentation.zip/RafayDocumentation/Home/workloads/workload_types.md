---
title: "Application Lifecycle Management"
source: https://docs.rafay.co/workloads/workload_types/
category: Home
---

# Overview

The controller allows users to create and manage multiple types of workloads.

1. Kubernetes YAML
2. Helm Charts
3. Workload Wizard

The below matrix presents a breakdown of actions like creation, updating, deletion, publish/unpublish Kubernetes Namespaces across multiple deployment methods: Interactive UI, Declarative RCTL commands, API-driven automation, and Terraform.

| Workload Type | Deployment Method | Create | Edit/Update | Delete | Publish | Unpublish |
| --- | --- | --- | --- | --- | --- | --- |
| Helm3 | UI | [Yes](https://docs.rafay.co/workloads/helm_charts/#create-workload) | [Yes](https://docs.rafay.co/workloads/helm_charts/#actions) | [Yes](https://docs.rafay.co/workloads/helm_charts/#actions) | [Yes](https://docs.rafay.co/workloads/helm_charts/#publish-workload) | [Yes](https://docs.rafay.co/workloads/helm_charts/#unpublish) |
|  | CLI | [Yes](https://docs.rafay.co/workloads/wl_cli/#create-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#update-workload-config) | [Yes](https://docs.rafay.co/workloads/wl_cli/#delete-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#create-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#unpublish-workload) |
|  | API Automation | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) |
|  | Terraform | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) |
| K8s YAML | UI | [Yes](https://docs.rafay.co/workloads/k8s_yaml/#create-workload) | [Yes](https://docs.rafay.co/workloads/k8s_yaml/#actions) | [Yes](https://docs.rafay.co/workloads/k8s_yaml/#actions) | [Yes](https://docs.rafay.co/workloads/k8s_yaml/#publish-workload) | [Yes](https://docs.rafay.co/workloads/k8s_yaml/#unpublish) |
|  | CLI | [Yes](https://docs.rafay.co/workloads/wl_cli/#create-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#update-workload-config) | [Yes](https://docs.rafay.co/workloads/wl_cli/#delete-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#create-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#unpublish-workload) |
|  | API Automation | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) |
|  | Terraform | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) |
| Workload Wizard | UI | [Yes](https://docs.rafay.co/workloads/wizard/overview/#step-1-create-workload) | [Yes](https://docs.rafay.co/workloads/wizard/overview/#actions) | [Yes](https://docs.rafay.co/workloads/wizard/overview/#actions) | [Yes](https://docs.rafay.co/workloads/wizard/overview/#step-6-publish-workload) | [Yes](https://docs.rafay.co/workloads/wizard/overview/#unpublish) |
|  | CLI | [Yes](https://docs.rafay.co/workloads/wl_cli/#create-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#update-workload-config) | [Yes](https://docs.rafay.co/workloads/wl_cli/#delete-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#create-workload) | [Yes](https://docs.rafay.co/workloads/wl_cli/#unpublish-workload) |
|  | API Automation | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) | [Yes](https://docs.rafay.co/automation/api/apis/) |
|  | Terraform | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) | [Yes](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/workload) |

---

## Download CLI Config from Workloads

The **Download CLI** option is available in the Workloads page. This provides a convenient shortcut for users who need the CLI while working with workloads.

- Click **Download CLI** and select the appropriate package for your operating system (Mac, Windows, or Linux). This option is helpful because CLI is frequently used for tasks such as:
  - Deploying workloads using declarative specs
  - Automating workload updates and lifecycle operations
  - Integrating workloads into existing CI/CD pipelines
- Download the [CLI configuration](https://docs.rafay.co/cli/config/) file to authenticate and manage your workloads

[![YAML based Workload](https://docs.rafay.co/workloads/img/cliconfig.png)](https://docs.rafay.co/workloads/img/cliconfig.png)

---

## Kubernetes YAML

This option is ideal for situations where the user already has the Kubernetes YAML for their application.

During workload deployment, the controller will validate the provided yaml file and deploy it to multiple managed Kubernetes clusters (as per configured policy).

### Benefits

1. Cloaked K8s Control Plane (no inbound access needed, no roles in every cluster)
2. Multi Cluster Deployments
3. No need for kubectl

[![YAML based Workload](https://docs.rafay.co/workloads/img/create_workload_yaml.png)](https://docs.rafay.co/workloads/img/create_workload_yaml.png)

---

## Helm Charts

This option is well suited for 3rd party applications that are packaged and distributed as Helm charts. It is also a good option for users that have invested in packaging their application as Helm charts.

During workload deployment, the controller will validate the provided Helm chart (a tgz file) and deploy it to multiple managed Kubernetes clusters (as per configured policy)

### Benefits

1. Cloaked K8s Control Plane (no inbound access needed, no roles in every cluster)
2. Multi Cluster Deployments
3. No need for a Helm Client
4. No need to deploy and manage Tiller in every cluster or potentially every namespace.

[![Helm based Workload](https://docs.rafay.co/workloads/img/create_workload_helm.png)](https://docs.rafay.co/workloads/img/create_workload_helm.png)

---

## Workload Wizard

This option is ideal for users that are not familiar with Kubernetes YAML or Helm charts.

The workload wizard based guided workflow allows users to intuitively specify application intent in seconds. The wizard then automatically "translates" the specified intent and generates the necessary Kubernetes YAML during workload deployment.

### Benefits

1. No knowledge of Kubernetes YAML or Helm needed
2. Multi Cluster application deployments
3. Intent based deployments

[![Workload Wizard](https://docs.rafay.co/workloads/img/create_workload_rafay.png)](https://docs.rafay.co/workloads/img/create_workload_rafay.png)

### No Ingress Workloads

Containerized applications of this type do not need to support inbound requests by users or systems.

A common use case for applications of this type are synthetic testing tools that application teams may use for **performance and/or availability testing** their applications from various regions.

For example, a large B2C web application serving a global user base may wish to run their "user simulation" test tool periodically from every location where they have a critical set of users.

The application team can use this to perform **early detection** of regional user access issues (NW congestion etc) so that they can attempt to resolve them before customers start complaining.

Alternatively, application teams can embed this into their CI/CD pipelines making this part of their application upgrade workflows. This way, they can guarantee that the application has not regressed in any non-obvious way from the previous version.

### Workloads with Ingress

This is the more frequent type of application where it accepts inbound requests from users and systems that interact with it.

---

## Workload from Catalog

User are allowed to browse through apps in a catalog and create a workload from an app. User can either edit the values.yaml on controller or upload a values.yaml before publishing the app.

Below is an example of creating an Add-On from catalog

- Click **New Workload** drop-down and select **Create New Workload from Catalog**

[![YAML based Workload](https://docs.rafay.co/workloads/img/create-wl-catalog.png)](https://docs.rafay.co/workloads/img/create-wl-catalog.png)

**Create New Workload from Catalog** screen appears with a list of catalog

[![Provide Artifact](https://docs.rafay.co/workloads/img/wl-catalog.png)](https://docs.rafay.co/workloads/img/wl-catalog.png)

- Select the required catalog and proceed to create a workload

Refer [Catalog](https://docs.rafay.co/catalog/catalog_overview/) for more information

- On successful creation, add-ons are listed with the type **Catalog App** as shown below

[![View All addons](https://docs.rafay.co/workloads/img/wload-list.png)](https://docs.rafay.co/workloads/img/wload-list.png)

Explore our blog for deeper insights on **How to Deploy a Vector Database on Kubernetes**, available [here](https://docs.rafay.co/blog/2023/08/02/vector-databases-for-generative-ai-on-kubernetes/#how-to-deploy-a-vector-database-on-kubernetes)!

---

## **V3 Workloads**

Click the **V3 Workloads** tab to view workloads created using **declarative specifications**. V3 workloads can be created using **System Sync (Git Sync)**, **RCTL with the `--v3` flag**, **V3 Swagger APIs**, or **Terraform**.

The table lists workload details such as **name, package type, namespace, last modified time, deployment status, and associated clusters**, covering both published and unpublished workloads.

For each workload, a **Debug** button is available directly in the list to view debugging information. Additional actions are available by clicking the **Actions** menu, including **Publish**, **Unpublish**, **Delete**, and **Workload Details**. The actions displayed depend on the current deployment state of the workload.

[![View All Workloads](https://docs.rafay.co/workloads/img/gitops_workload.png)](https://docs.rafay.co/workloads/img/gitops_workload.png)

---
