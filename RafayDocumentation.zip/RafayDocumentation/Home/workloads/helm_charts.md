---
title: "KOP Workloads - Helm Charts"
source: https://docs.rafay.co/workloads/helm_charts/
category: Home
---

# Helm Charts

Helm uses a packaging format called charts which is a collection of files that describe a set of Kubernetes resources. A single chart might be used to deploy something simple, like a memcached pod, or something complex, like a full web app stack with HTTP servers, databases, caches, and so on. Charts are created as files laid out in a particular directory tree, then they can be packaged into versioned archives to be deployed.

- Every chart must have a version number
- Kubernetes Helm uses version numbers as release markers
- Packages in repositories are identified by "name + version"

You can manage the lifecycle of Helm based workloads using the Web Console or [RCTL CLI](https://docs.rafay.co/workloads/wl_cli/) or REST APIs. We strongly recommend that customers automate this either

- By [integrating RCTL](https://docs.rafay.co/integrations/ci/overview/) with your existing CI system based automation pipeline, OR
- By leveraging the integrated [GitOps](https://docs.rafay.co/gitops/overview/) capability.

---

## Helm Versions

The Controller supports Helm 2, Helm 3, and Helm 4. Users are strongly advised to use Helm 3 or Helm 4. Support for Helm 2 is **deprecated** and is only meant to be used for legacy charts that are incompatible with Helm 3.

With Helm 3 and Helm 4, the Controller acts like a native Helm client for the selected engine. It does not have to parse and break down the chart into its atomic K8s resources. Read more about Helm 2 [End of Life](https://helm.sh/blog/helm-v2-deprecation-timeline/).

Helm 4 brings typed `--set` values, configurable wait strategies, server-side apply, and dry-run simulation to Helm-based workloads and add-ons, along with a couple of options renamed to match upstream Helm 4's terminology (`Atomic` → `Rollback on Failure`, `Force` → `Force Replace`). To use these capabilities, select **Helm 4** as the **Helm Engine** when creating a workload or add-on, see [Helm 4 Options](#helm-4-options) below for the full reference.

- The Helm 3 flow and its options remain unchanged — no migration required.
- Helm 4 carries forward nearly every Helm 3 option and adds the capabilities above on top.
- Helm 3 and Helm 4 will continue to coexist. Helm 3 is expected to be deprecated in favor of Helm 4 only at some point in the future, but that is not happening yet.
- Rafay exposes a supported subset of upstream Helm 4's changes; see the official [Helm 4 release notes](https://helm.sh/docs/overview) for the complete set.

---

## Create Workload

- Login into the Console (typically as a Project Admin)
- Navigate to Applications -> Workloads
- Click on New Workload
- Provide a name, select **Helm** for package type
- Choose the **Helm Engine**: **Helm 3** (default, unchanged from today) or **Helm 4** (adds the options described in [Helm 4 Options](#helm-4-options)
- Select if you would like to "**upload**" the artifacts or you would like the Controller to "**pull**" it directly from a configured [repository](https://docs.rafay.co/integrations/repositories/overview/).
- Select the namespace where the resources should be deployed

[![Create Helm Workload-Upload](https://docs.rafay.co/workloads/img/helm/create_helm_workloads.png)](https://docs.rafay.co/workloads/img/helm/create_helm_workloads.png)

> **Tip**
> Ensure that a [namespace](https://docs.rafay.co/namespaces/namespaces/) where you would like to deploy has already been created.

---

### Option A: Pull from Repository

This approach requires the user to first select the type of repository (Git or Helm)

[![Create Helm Workload-Pull Artifacts](https://docs.rafay.co/workloads/img/helm/create_helmworkloads_pull.png)](https://docs.rafay.co/workloads/img/helm/create_helmworkloads_pull.png)

> **Note**
> This flow is identical when the Helm Engine is set to **Helm 4**: repository selection, revision, chart path, and values file fields are the same as Helm 3.

#### Option A1: Git Repository Type

In the New Workload dialog, select Git as the Repository Type and click Continue.

Then, in the next step:

- Select the [repository](https://docs.rafay.co/integrations/repositories/overview/) from the dropdown list
- Set the **Revision** (branch, tag, or commit SHA)
- Provide the **Helm chart path**
- Under **Values File(s)**, two options are available and can be used independently or together:
  - **Value Path**: Use this when your values files are in the same repository as the Helm chart. Click **+ ADD PATH** to add multiple value file paths from the chart repository.
  - **Git Path**: use this when your values files are stored in a separate Git repository from the Helm chart. This allows you to maintain environment-specific configurations independently from the chart itself.
    - Select the **Git repository** where your values files are stored
    - Set the **Revision** (branch, tag, or commit SHA)
    - Enter the first **Value file path**
    - Click **+ ADD VALUE FILE PATH** to add more entries

[![Create Helm Workload-Pull Artifacts](https://docs.rafay.co/workloads/img/helm/create_helm_workload_pull_detail.png)](https://docs.rafay.co/workloads/img/helm/create_helm_workload_pull_detail.png)

> **Tip**
> The last entry in the list takes the highest precedence. If multiple files define the same key, the value from the last file wins.

#### Option A2: Helm Repository Type

In the New Workload dialog, select **Helm** as the Repository Type and click **Continue**.

[![Create Helm Workload-Pull Artifacts](https://docs.rafay.co/workloads/img/helm/helm_types.png)](https://docs.rafay.co/workloads/img/helm/helm_types.png)

Then, in the next step:

- Select the [repository](https://docs.rafay.co/integrations/repositories/overview/) from the dropdown list
- Enter the **Chart Name** and **Chart Version** (if not specified, the latest version is pulled)

Under **Values.yaml**, two options are available:

- **Upload**: Use this to upload a values file directly from your local system
- **Override from git repository**: Use this when your values files are managed separately in a Git repository, keeping your chart and environment-specific configurations decoupled
  - Select the **Override git repository**
  - Set the **Revision** (branch, tag, or commit SHA)
  - Enter the first **Value file path**
  - Click **+ ADD VALUE FILE PATH** to add more entries

[![Create Helm Workload-Pull Artifacts](https://docs.rafay.co/workloads/img/helm/override_helm.png)](https://docs.rafay.co/workloads/img/helm/override_helm.png)

> **Tip**
> The last entry in the list takes the highest precedence. If multiple files define the same key, the value from the last file wins.

---

### Option B: Upload Artifacts

This approach is suited for scenarios where the user would like to upload the artifacts to the Controller and not provide any form of access to their Git/Helm repository

- Upload the "Helm chart" (a tgz file) and if necessary a "values.yaml" override file

[![Configure Helm Workload](https://docs.rafay.co/workloads/img/helm/configure_helm_workload.png)](https://docs.rafay.co/workloads/img/helm/configure_helm_workload.png)

---

### Multiple Values Files

It's possible to have multiple values files for the same helm chart.

For **Helm 3** workloads created either by **Upload files manually**, **Pull files from Git Repo**, or **Pull files from Helm Repo**, all these values files can be uploaded or referenced when creating the workload.

> **Note**
> The same Upload / Pull from Repository options are available when the Helm Engine is set to **Helm 4**.

#### Option A

- Click **Upload Files** to upload the Values File(s) from the system that you want to supply to the chart. **Upload** is the default selection
- Fetch values files directly from a **Helm repository** (either a traditional Helm repository or an **OCI-based Helm repository**)

> Note: Users can provide just the Helm chart name or specify it along with the namespace, if required.

[![Multiple values Helm Workload](https://docs.rafay.co/workloads/img/helm/workload_multiple_files.png)](https://docs.rafay.co/workloads/img/helm/workload_multiple_files.png)

**Chart Name Constraints for OCI-Based Helm Repositories**

When configuring a Helm workload using an [OCI-based Helm repository](https://docs.rafay.co/integrations/repositories/manage_repos/), the way the repository endpoint is defined determines how chart names can be referenced:

- **If the endpoint includes a namespace along with a specific chart name** (e.g., `oci://c8n.io/demouser1/nginx`), users must specify either:
  - `nginx` (chart name only)
  - `demouser1/nginx` (namespace/chart-name format)
 In this case, workloads can only use the specified chart (`nginx`), even if multiple charts exist under the namespace.
- **If the endpoint includes only the host** (e.g., `oci://c8n.io`), workloads must be configured with the full namespace path and chart name, such as `demouser1/nginx`
- **If the endpoint includes the host along with the namespace** (e.g., `oci://c8n.io/demouser1`), users can specify any chart available under that namespace when deploying workloads

#### Option B

To use values files stored in a Git repository, perform the following steps:

- Select **Override from git repository** option
- Select the **Override git repository** from the dropdown list
- Set the **Revision** (branch, tag, or commit SHA)
- Enter the first **Value file path**
- Click **+ ADD VALUE FILE PATH** to add more entries

> **Tip**
> The last entry in the list takes the highest precedence. If multiple files define the same key, the value from the last file wins.

[![Override From Git Repository](https://docs.rafay.co/workloads/img/helm/helm_override_gitrepo_file.png)](https://docs.rafay.co/workloads/img/helm/helm_override_gitrepo_file.png)

---

### Advanced Helm Options

Support for advanced Helm options is available under "Helm Options".

| Helm Option | Description |
| --- | --- |
| Atomic | If enabled, upgrade process rolls back changes made in case of failed upgrade. The --wait flag will be set automatically if this option is enabled. It will wait for as long as the configured timeout duration |
| Cleanup on Fail | Allow deletion of new resources as part of the upgrade when upgrade fails |
| Disable Open API Validation | If enabled, the installation/upgrade process will not validate rendered templates against the Kubernetes OpenAPI Schema |
| Force | Force resource updates through a replacement strategy |
| Max History | Limit the maximum number of revisions saved per release, default value is 10 |
| Description | Add a custom description |
| No Hooks | If this option is enabled, pre/post hooks are disabled |
| Render SubChart Notes | If enabled, subchart notes are rendered along with the parent |
| Reset Values | When upgrading, reset the values to the ones built into the chart |
| Reuse Values | When upgrading, reuse the last release's values |
| Set String | set STRING values |
| Skip CRDs | If this option is enabled, no CRDs will be installed. By default, CRDs are installed if not already present |
| Timeout | Time to wait for any individual Kubernetes operation (like Jobs for hooks), default is 5m0s |
| Wait | If enabled, will wait until all Pods, PVCs, Services, and minimum number of Pods of a Deployment, StatefulSet, or ReplicaSet are in a ready state before marking the release as successful. It will wait for as long as the configured timeout duration |
| Wait for Jobs | When configured, it will wait until all Jobs are finished before marking the release as successful. It will wait for as long as the configured timeout duration |

![⚠](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/26a0.svg) **Warning**

- If the Atomic option is set, upgrade process will roll back changes automatically in case of a failed upgrade. Please make sure to specify an appropriate timeout (default is 5 min) if you want to set the Atomic option. More information on Advanced Helm Options is available [here](https://helm.sh/docs/helm/helm_upgrade/)
- When the timeout is set to 0, a default Add-On Timeout of 60 minutes is applied to prevent infinite wait loops. If configured with a higher timeout and the Helm chart encounters issues (e.g., in pre-hooks), the blueprint may remain stuck for that duration. It is recommended to set a reasonable timeout to avoid extended delays.

[![Advanced Helm Options](https://docs.rafay.co/workloads/img/helm/advanced_helm_options.png)](https://docs.rafay.co/workloads/img/helm/advanced_helm_options.png)

---

### Helm 4 Options

When the **Helm Engine** is set to **Helm 4**, the options above are replaced by an expanded **Helm 4 Options** panel, organized into five groups: **Values & metadata**, **Wait & timing**, **Apply & dry-run**, **Validation & hooks**, and **Advanced**.

> **Note**
> The same Helm 4 engine and options described here are also available when creating Helm-based Add-ons.

#### Values & metadata

Override chart values, release labels, and upgrade value handling.

| Helm 4 Option | Description |
| --- | --- |
| Set | Custom Helm values, equivalent to `helm --set`. The type is inferred from the value: `3` is treated as a number, `true`/`false` as a boolean, `null` unsets the key, and `{a,b}` as a list. |
| Set String | Custom Helm values treated strictly as strings, equivalent to `helm --set-string`. `key=123` is always sent as the string `"123"`, regardless of how it looks. Use this for image tags, port numbers, or other numeric-looking values that must stay strings. |
| Labels | Key/value labels attached to the release, for tracking and later filtering deployments. For example, `environment=demo` or `environment=prod`. |
| Description | Custom free-text description for the release. |
| Values Policy | Controls how values from the previous release are handled during an **upgrade**. **Reset Values**: Use this option when you want the release to use only the values provided for the current version. **Reuse Values**: Use this option when you want to retain values from the previous release that may not be specified in the current version. **Reset Then Reuse**: Use this option when upgrading to a chart version that introduces new default values or keys, while preserving values from the previous release. |

[![Values & metadata](https://docs.rafay.co/workloads/img/helm/helm4_options_values.png)](https://docs.rafay.co/workloads/img/helm/helm4_options_values.png)

#### Wait & timing

Control how Helm waits for resources and operation timeouts.

| Helm 4 Option | Description |
| --- | --- |
| Wait Strategy | Defines how Helm waits for resources before marking a release successful. - **Hook Only**: waits only for hook Pods/Jobs to complete, not general chart resources. - **Watcher**: actively confirms every pod/resource comes up healthy. - **Legacy**: the Helm 3 wait behavior, for customers who want to keep the existing behavior. |
| Wait for Jobs | If enabled, waits until all Jobs are finished (as part of the Wait Strategy) before marking the release as successful. |
| Timeout | Time to wait for any individual Kubernetes operation before marking it failed, default is 5m0s. |
| Max History | Limit the maximum number of revisions saved per release, default value is 10. |

[![Wait & timing](https://docs.rafay.co/workloads/img/helm/helm4_options_wait.png)](https://docs.rafay.co/workloads/img/helm/helm4_options_wait.png)

#### Apply & dry-run

Server-side apply and dry-run simulation options.

| Helm 4 Option | Description |
| --- | --- |
| Server-Side Apply | Controls whether the cluster or the Helm client computes and applies updates. - **True**: the cluster handles the apply. - **False**: Helm computes and applies the update itself. - **Auto** (default): on an upgrade, continues whichever mode was used on the prior install/upgrade. |
| Dry Run Strategy | Runs a pre-flight validation check on the chart and values before an actual publish, without persisting any changes and without rendering or displaying the manifest. **None** (default): perform an actual publish. **Server** / **Client**: run the pre-flight validation only; nothing is installed, upgraded, or rendered for viewing. On success, the UI shows "Pre-flight dry run successful". |
| Hide Secret | When using a dry run, hides Kubernetes Secrets from the dry run output so secret values aren't exposed. Only applicable when Dry Run Strategy is Server or Client. |

[![Apply & dry-run](https://docs.rafay.co/workloads/img/helm/helm4_options_apply.png)](https://docs.rafay.co/workloads/img/helm/helm4_options_apply.png)

#### Validation & hooks

Hooks, CRDs, schema validation, and release notes.

| Helm 4 Option | Description |
| --- | --- |
| Disable Hooks | If enabled, pre/post hooks are disabled for this operation. |
| Hide Notes | Hides the chart's notes (`NOTES.txt`) from the output. |
| Sub Chart Notes | If enabled, subchart notes are rendered along with the parent. |
| Skip CRDs | If enabled, no CRDs will be installed. By default, CRDs are installed if not already present. |
| Skip Schema Validation | Skips JSON schema validation of values against the chart's `values.schema.json`. |
| Disable Open API Validation | If enabled, the installation/upgrade process will not validate rendered templates against the Kubernetes OpenAPI Schema. |

[![Validation & hooks](https://docs.rafay.co/workloads/img/helm/helm4_options_validation.png)](https://docs.rafay.co/workloads/img/helm/helm4_options_validation.png)

#### Advanced

Destructive or rarely needed upgrade behaviors.

| Helm 4 Option | Description |
| --- | --- |
| Rollback on Failure | If enabled, the upgrade process rolls back changes made in case of a failed upgrade. This is the Helm 4 name for the Helm 3 Atomic option; make sure to specify an appropriate Timeout when enabling this. |
| Force Replace | Force resource updates through a replacement strategy. This is the Helm 4 name for the Helm 3 Force option. |
| Force Conflicts | Forces a server-side apply through even when there are field-manager conflicts. |
| Take Ownership | Takes ownership of fields currently managed by another field manager. |
| Replace | Replace the release if one with the same name already exists. |
| Cleanup on Fail | Allow deletion of new resources as part of the upgrade when the upgrade fails. |
| Enable DNS | Enable DNS lookups when rendering chart templates/URLs. |

[![Advanced](https://docs.rafay.co/workloads/img/helm/helm4_options_advanced.png)](https://docs.rafay.co/workloads/img/helm/helm4_options_advanced.png)

![⚠](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/26a0.svg) **Warning**

- If **Rollback on Failure** is set, the upgrade process will roll back changes automatically in case of a failed upgrade. Make sure to specify an appropriate Timeout (default is 5 min) if you want to set this option.
- When Timeout is set to 0, a default Add-On Timeout of 60 minutes is applied to prevent infinite wait loops. It is recommended to set a reasonable Timeout to avoid extended delays.

---

## Placement Policy

In this step, specify the [placement policy](https://docs.rafay.co/workloads/placement/) for the workload.

In the example below, the user has selected

- "Not Set" for Drift Detection
- The "Specific Clusters" placement policy

[![Publish Helm Workload](https://docs.rafay.co/workloads/img/helm/place_helm_workload.png)](https://docs.rafay.co/workloads/img/helm/place_helm_workload.png)

---

## Publish Workload

We are now ready to publish the workload. Click on Publish to start the deployment process

[![Publish Helm Workload](https://docs.rafay.co/workloads/img/helm/ready_to_publish.png)](https://docs.rafay.co/workloads/img/helm/ready_to_publish.png)

---

### Progress/Status

Depending on the complexity of the placement policy (e.g. multiple clusters), the Helm chart (e.g. lots of readiness process), the deployment process can take 30 seconds to a few minutes. If the deployment was successful, appropriate status is shown to the user.

[![Successful Helm Deployment](https://docs.rafay.co/workloads/img/helm/publish_helm_success.png)](https://docs.rafay.co/workloads/img/helm/publish_helm_success.png)

Use the **Card View** or **Table View** icons to view the workload details like status, namespace, last modified date & time, etc on the main workload list page. Table view is the default.

To view the cost details of a specific workload, click on the **$** icon. This will navigate you to the Cost Explorer page, where you can access detailed cost information for the required workload.

[![Workload List](https://docs.rafay.co/workloads/img/helm/workload_card_view.png)](https://docs.rafay.co/workloads/img/helm/workload_card_view.png)

To get the list of workloads in the table view, use the **Table View** icon. Clicking on Deployment Status **Ready** workload shows the current state of the workload by cluster

[![Workload List](https://docs.rafay.co/workloads/img/helm/workload_table_view.png)](https://docs.rafay.co/workloads/img/helm/workload_table_view.png)

---

## Pod Metrics

To have the managed prometheus addon scrape pod metrics, add the following annotations to the pods with these parameters

```
metadata:
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/path: /metrics
    prometheus.io/port: "8080"
spec:
```

Adjust the **prometheus.io/path** based on the URL from where the pod serves metrics. Set **prometheus.io/port** to the port from where the pod serves metrics. The values for **prometheus.io/scrape** and **prometheus.io/port** must be enclosed within double quotes

> **Important**
> The collected metrics in Prometheus will be retained for **3 hours**

---

## Debugging/Troubleshooting

If there are application related issues during deployment, both the application developer and/or the operations user will require RBAC secure facilities to remotely debug. Built in "secure, interactive capabilities" are provided to help streamline the debugging and troubleshooting process.

- Navigate to the Workload publish screen
- Click **Debug** to view the deployed Workload, Age (time in minutes since the deployment is complete), Message, Namespace, Reason, Type, Involved Object, Source, and Count
- Use the gear icon to show/hide the required columns

[![Debug Workload](https://docs.rafay.co/workloads/img/helm/debug_wl.png)](https://docs.rafay.co/workloads/img/helm/debug_wl.png)

For more information on Debug, refer [Debug](https://docs.rafay.co/workloads/debug/debug/)

---

### Developers

Developers that are responsible for a microservice or just the workload will not be provided. This persona is typically provisioned with a "Project Admin" role OR a "Project Read Only" role (in production environments).

- Navigate to the workload's publish screen or from the main workload list page, click on options
- Click on Debug

This will take the user to the "main debug page"

- For multi cluster deployments, select the cluster from the drop-down on the left
- A live channel is established to the remote cluster based on the zero trust control channel

[![Debug Helm Workload](https://docs.rafay.co/workloads/img/helm/debug_helm_workload.png)](https://docs.rafay.co/workloads/img/helm/debug_helm_workload.png)

**KubeCTL**

Click on "KubeCTL" to launch a browser based [Zero Trust KubeCTL](https://docs.rafay.co/accessproxy/overview/) shell. Note the KubeCTL operations this user can perform is access controlled and secured using the configured [ROLE](https://docs.rafay.co/security/rbac/roles/). All actions performed by the user are audited for compliance.

---

**Kubernetes Events**

Click on "Show Events" to view the K8s events associated with the workload's resources.

[![Debug - k8s Events](https://docs.rafay.co/workloads/img/helm/debug_workload_k8s_events.png)](https://docs.rafay.co/workloads/img/helm/debug_workload_k8s_events.png)

---

**Logs and Shell**

Click on "Launch" under Logs & Shell to establish a "live, interactive" debug channel to the pod on the remote cluster.

---

### Infrastructure/Operations

This persona is generally an "Infrastructure Administrator" with privileged access to the Kubernetes Cluster.

**All Workloads**

Infrastructure admins are provided a bird's eye view of all workloads and their status on Kubernetes clusters. Click on the "Workloads" link on the cluster card.

In the example below, you can see the deployment status of our "apache-helm3" workload

[![Workloads on Cluster Card](https://docs.rafay.co/workloads/img/helm/debug_infra_workload_list.png)](https://docs.rafay.co/workloads/img/helm/debug_infra_workload_list.png)

**K8s Resources By Workload**

Infrastructure admins can view details about the K8s resources for a given workload on a cluster.

- Click on the Cluster Dashboard
- Click on Resources
- Select "Workloads" for "View By"
- Select the "workload name"

In the example below, you can view the details of all the K8s resources for our workload.

[![k8s Resources by Workload](https://docs.rafay.co/workloads/img/helm/debug_infra_byworkload.png)](https://docs.rafay.co/workloads/img/helm/debug_infra_byworkload.png)

**By Helm Release**

- Click on the Cluster Dashboard
- Click on Resources
- Select "Helm Releases" for "View By"

In the example below, the Operations persona can see the Helm Chart's name, release, app version and other status information. If users have the Helm CLI configured to communicate with their cluster, they can use it to check status directly.

[![Helm Releases](https://docs.rafay.co/workloads/img/helm/debug_infra_helmreleases.png)](https://docs.rafay.co/workloads/img/helm/debug_infra_helmreleases.png)

---

## Unpublish

To unpublish the workload, click on the "unpublish button". The deployed resources on the remote clusters will be automatically removed.

> **Important**
> If the remote cluster was offline when the unpublish operation was initiated, the Controller will send this instruction to the cluster when it reconnects.

---

## Actions

Edit or delete one (or) more workload(s) using the respective icons from the main workloads list page. Follow the prompts to delete a workload.

[![Helm Releases](https://docs.rafay.co/workloads/img/helm/action.png)](https://docs.rafay.co/workloads/img/helm/action.png)

> Note: When modifying a published workload, republish it

---
