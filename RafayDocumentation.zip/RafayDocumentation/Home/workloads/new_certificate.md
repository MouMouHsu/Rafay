---
title: "KOP New Certificate"
source: https://docs.rafay.co/workloads/new_certificate/
category: Home
---

# New Certificate

Users can provide the Certificate and Private Key details through the controller.

---

## New Certificate

- Login into the Console
- Navigate to **Applications** -> **Certificates**
- Click on **New Certificate** and provide a name
- Copy/paste a valid **Certificate** details or upload (:simple-codereview: [Preview Program](https://docs.rafay.co/releasenotes/preview/overview/)) the existing file using the **Upload** button. The supported file formats are **.pem** and **.crt**
- Copy/paste a valid **Private Key** details or upload (:simple-codereview: [Preview Program](https://docs.rafay.co/releasenotes/preview/overview/)) the existing file using the **Upload** button. The supported file format is **.pem**
- If required, enter the password used to secure the files
- Click **Save**

[![Create VM Wizard Workload](https://docs.rafay.co/workloads/img/vmwizard/new_cert.png)](https://docs.rafay.co/workloads/img/vmwizard/new_cert.png)

- Once the details are added, you can view the list of certificates as shown below:

[![Create VM Wizard Workload](https://docs.rafay.co/workloads/img/vmwizard/cert_list.png)](https://docs.rafay.co/workloads/img/vmwizard/cert_list.png)

You can use it in the Ingress Configuration when deploying a workload using the **Wizard** type provided that you do not choose the system domain.

---
