---
title: "KOP Cluster Overrides - Sharing"
source: https://docs.rafay.co/workloads/wl_override_sharing/
category: Home
---

# Share Override

The Cluster Override sharing enhancement has been implemented to support a model similar to other Rafay objects, whereby only **Organization Administrators** will have the ability to share cluster overrides across projects, ensuring better control and governance.

Organization administrators can "share" cluster overrides with "select" or "all projects" within their organization. This sharing capability allows for improved standardization and governance across the enterprise. When cluster overrides are shared, the downstream projects will automatically apply the shared configurations, ensuring consistent governance while maintaining project-specific controls.

> **Did you know ?**
> Workload Override Sharing can be managed through various methods:
>
> - [UI](https://docs.rafay.co/workloads/wl_override_sharing/#share-workload-overrides)
> - [CLI](https://docs.rafay.co/cli/overrides/)
> - [Terraform](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs/resources/cluster_override)
> - [GitOps](https://docs.rafay.co/gitops/stages/system_sync/)

---

## Share Workload Overrides

To share a workload override with one or more projects,

- Navigate to the Project
- Click on **Cluster Overrides** under Applications. Cluster Override page appears
- Click on the "share" icon next to the override.
- Select the Projects you would like to share with

[![New Override](https://docs.rafay.co/workloads/img/overrides/app_wld_overr.png)](https://docs.rafay.co/workloads/img/overrides/app_wld_overr.png)

Once shared, Org Admins can determine "which projects" a workload override is shared with. For example, the demoyamloverride in the "defaultproject" project is shared with three (3) projects.

[![Which Projects](https://docs.rafay.co/workloads/img/overrides/wl_shared.png)](https://docs.rafay.co/workloads/img/overrides/wl_shared.png)

Org Admins can also quickly determine which project a workload override is "inherited" from. For example, the demoyamloverride in is inherited from the "defaultproject" project

[![Workload](https://docs.rafay.co/workloads/img/overrides/overr_inherited.png)](https://docs.rafay.co/workloads/img/overrides/overr_inherited.png)

> **Important**
> - Once an override is shared from a parent project, it cannot be deleted from the parent project
> - Cluster Override Sharing activities can be tracked on the [Audit Log page](https://docs.rafay.co/security/audit/)
> - When a cluster override is created or updated via a Git sync operation, it is created under the Git pipeline owner's role. Override sharing (assigning or unassigning projects) is applied only if the pipeline owner's role has permission to assign and unassign projects.

---
