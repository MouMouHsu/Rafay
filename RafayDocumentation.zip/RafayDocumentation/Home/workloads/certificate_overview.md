---
title: "KOP Certificate - Overview"
source: https://docs.rafay.co/workloads/certificate_overview/
category: Home
---

# Overview

Certificates are designed to provide secure access to workloads deployed on the platform. These certificates are issued by a Certificate Authority, managed by a centralized certificate management system, securely (encrypted) stored in a database and subsequently assigned to the corresponding workload for SSL offloading.

---

## Certificate Creation

A certificate are of two types:

- Server Certificate
- CA Certificate

---

## Process Workflow

The image below describes the typical steps that are performed in a sequence.

```
flowchart TD
    A(Login to Console) --> B(Create New Certificate)
    B --> C(Enter/Upload Certificate)
    C --> D(Enter/Upload Private Key)
    D --> |if required| E(Enter Password)
    E --> F(Database)
    D --> F
```

---
