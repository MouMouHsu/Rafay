---
title: "Zero Trust Kubectl - Secure Kubernetes API Access as a Service"
source: https://docs.rafay.co/accessproxy/overview/
category: Home
---

# Zero Trust Kubectl

Secure, centralized kubectl access with zero trust architecture. Eliminate VPNs and bastion hosts while maintaining complete security, auditability, and performance for Kubernetes API operations across your entire fleet.

#### Zero Trust Architecture

Never Trust, Always Verify

Built-in zero trust security model that eliminates the need for VPNs or publicly accessible API servers.

#### Centralized Access Policy

Fleet-wide Control

Define and manage centralized access policies across globally distributed clusters and multiple environments.

#### Vanilla kubectl Support

No Special Clients

Users continue using standard kubectl CLI without installing special client software or changing existing workflows.

#### Browser-based Terminal

Instant Access

Built-in browser-based kubectl shell in the web console for immediate, secure cluster access.

#### Kubeconfig Download

CLI Integration

Download secure kubeconfig files for seamless integration with existing kubectl workflows and CI/CD systems.

#### Group-based Policies

Role-based Security

Support for group membership-based access policies with fine-grained RBAC enforcement at the network edge.

#### Time-bound Access

Temporary Permissions

Configure time-bound access policies with automatic service account creation and removal based on idle periods.

#### Instant Access Revocation

Fleet-wide Control

Instantly revoke kubectl access across entire fleet of clusters for any group or user when needed.

#### Complete Audit Trail

Security & Compliance

Full auditing of kubectl activities with centralized access to audit logs for all user activity across the fleet.

#### Break Glass Process

Emergency Access

Implement controlled break glass processes for kubectl access to sensitive production environments.

#### Active Session Requirement

Enhanced Security

Require active authenticated session with web console before using downloaded kubeconfig files.

#### High Availability

No Single Point of Failure

Built-in high availability with redundant network paths ensuring reliable access to remote clusters.

#### Optimized Network Path

Low Latency Access

Heavily optimized, low-latency network path between kubectl and target clusters, regardless of location.

#### Firewall-friendly

No Infrastructure Changes

Access clusters behind firewalls without requiring changes to firewall rules or network configurations.

#### Multi-tool Support

Ecosystem Compatibility

Works seamlessly with kubectl, Helm3, and any tools that interact with Kubernetes APIs.

#### Zero Admin Overhead

Instant Availability

No installation or configuration required - instantly available once clusters are visible in the web console.

#### Universal Cluster Support

Imported & Provisioned

Works across both imported existing clusters and newly provisioned clusters from any provider.

#### Certificate-based Auth

Strong Authentication

Client certificate-based authentication with CN validation for secure user identification and access control.

#### Regional Proxy with ZTKA

Optimized, Localized Access

Route kubectl traffic through an optional regional access proxy to minimize latency and improve performance.

[← Back](https://docs.rafay.co/services/overview/)
