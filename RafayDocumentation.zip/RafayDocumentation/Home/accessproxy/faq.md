---
title: "FAQ for Zero Trust Kubectl Service"
source: https://docs.rafay.co/accessproxy/faq/
category: Home
---

# FAQ

## Max Characters

The web based zero trust kubectl shell does not accept more than **1022 characters** being pasted into the kubectl command or when editing files inside of a pod.

---

## VPNs and Proxies

Authorized end users do not require a VPN to securely access their clusters operating behind corporate firewalls using the Zero Trust KubeCTL feature.

However, if a VPN is configured or in use, please ensure that **"*.user.kubeapi-proxy.rafay.dev" FQDN** is whitelisted in the proxy configuration.

The Zero Trust KubeCTL uses mutual authentication to secure the connection from the end user to the KubeCTL access proxy in the controller. Man-in-the-middle proxies that terminate the connection will break the security model and users will be shown an error message by the KubeCTL CLI.

```
Unable to connect to the server: x509: certificate signed by unknown authority
```

---

## Disabling Kubeconfig Download

Org Admins can optionally completely disable the use of downloaded Kubeconfigs in their Org by setting a validity of "0 hours".

---

## User SA Provisioning

User specific Service Accounts (sa) are provisioned "Just in Time (JIT)" on managed clusters by the Controller when the user attempts to access the cluster via KubeCTL the first time. This is automatically de-provisioned from the remote clusters "8" hours after the SA is idle and not used. This is to ensure that there are no dangling credentials on managed clusters.

In the image below, you can see that the SA for the user was created on the cluster "Just In Time (JIT)" when the user tried accessing the cluster using the browser based KubeCTL virtual terminal in the Web Console.

[![SA Created JIT](https://docs.rafay.co/accessproxy/img/jit/jit_sa_creation.png)](https://docs.rafay.co/accessproxy/img/jit/jit_sa_creation.png)

---

## Latency

This section captures common latency required questions for the zero trust kubectl service. Latency, often referred to as “lag,” is a critical factor influencing the quality of the user experience. It represents the delay between when data is sent from a device to a remote server and when a response is received. It measures the time it takes for data to travel from a device to its destination and back.

Latency is typically measured in milliseconds (ms), and a lower latency value indicates a more responsive and smoother online experience. High latency can delay and disrupt various online activities, including gaming, video conferencing, web browsing, and streaming.

### Network Latency

The zero trust kubectl service works effectively when the "network latency" between the Rafay Operator on the customer's Kubernetes cluster and the Rafay Controller (SaaS or self hosted) is **less than 150ms**. Since this is an end user facing service, it is critical for administrators to treat this equivalent to a "general purpose SaaS applications (web apps, collaboration tools)".

> **Info**
> Rafay also operates **regional** proxies in multiple WW locations that helps reduce the latency between the managed clusters and Rafay.

[![Network Latency](https://docs.rafay.co/accessproxy/img/faq/latency.png)](https://docs.rafay.co/accessproxy/img/faq/latency.png)

### First Access Latency

When users access a managed cluster via the Web Console based Zero Trust KubeCTL terminal, they may encounter a **one time** delay of 1-2 seconds because the user's service account needs to be being injected just in time (JIT) on the remote cluster. In the image below, you can see that the first time user access to the cluster took a few seconds longer than subsequent access.

[![First Time Access](https://docs.rafay.co/accessproxy/img/jit/first_access_latency.png)](https://docs.rafay.co/accessproxy/img/jit/first_access_latency.png)

---
