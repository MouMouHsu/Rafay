---
title: "KOP Access Proxy - KubeCTL CLI"
source: https://docs.rafay.co/accessproxy/kubectl_cli/
category: Home
---

# KubeCTL CLI

Authorized users may wish to perform KubeCTL operations on their fleet of clusters in their Project(s) using the KubeCTL CLI. Depending on the user's role, they are provided multiple ways by which they can download the Kubeconfig.

> **Important**
> The downloaded Kubeconfigs will allow the users to securely access the fleet of clusters they are authorized to access using KubeCTL CLI unless user access is revoked OR if the Kubeconfig is revoked OR if the Kubeconfig credentials expire.

---

## Downloading Kubeconfig

In the console, open "My Tools" and click **Download** button to the right of Kubectl Access section.

[![Download Kubeconfig](https://docs.rafay.co/accessproxy/img/kubeconfig/download_my_tool.png)](https://docs.rafay.co/accessproxy/img/kubeconfig/download_my_tool.png)

This will provide the user with a "consolidated" Kubeconfig file for all the clusters that the user is authorized to access as per their configured Role in the Org.

Org/Infrastructure/Cluster Admins can also download the Kubeconfig file by navigating to the Clusters page.

[![Download Kubeconfig for Infra Admins](https://docs.rafay.co/accessproxy/img/kubeconfig/infra_admin_downloadkubeconfig.png)](https://docs.rafay.co/accessproxy/img/kubeconfig/infra_admin_downloadkubeconfig.png)

### Revoke Kubeconfig

If the Kubeconfig file is believed to have been compromised (e.g lost/stolen laptop), it can be revoked. To perform this:

- Log in into the Web Console and click on "My Tools"
- Click on "Revoke" button to the right of Kubectl Access section

[![Revoke Kubeconfig for Project Admins](https://docs.rafay.co/accessproxy/img/kubeconfig/download_my_toolsrevoke.png)](https://docs.rafay.co/accessproxy/img/kubeconfig/download_my_toolsrevoke.png)

---

## RCTL and Kubeconfig

In some environments, automation is critical and foundational. As a result, users and 3rd party systems may need to access the managed cluster's Kube API Server programmatically or via scripts. These systems may also not have the ability to download the Kubeconfig via a web browser. For scenarios like this, the RCTL CLI can be used to download the Kubeconfig files.

Representative examples:

- A Jenkins based CI system that needs to use KubeCTL to securely interact with remote clusters
- A 3rd party SaaS Application such as "Service Now" that needs to securely access the fleet of Kubernetes clusters for inventory and governance purposes

Once RCTL has been downloaded and initialized (i.e. it is now authorized to communicate with the customer's Org in the Controller), use RCTL to download the Kubeconfig file. The downloaded Kubeconfig file will be an unified Kubeconfig that will provide access to all clusters that the RCTL user is authorized to access.

```
./rctl kubeconfig download -h
Download the generated kubeconfig

Usage:
  rctl kubeconfig download [flags]

Flags:
      --cluster string     Set the cluster to get kubeconfig for a specific cluster
  -h, --help               help for download
  -n, --namespace string   Set the default namespace for the kubeconfig
  -f, --to-file string     File location to download the kubeconfig to

Global Flags:
  -c, --config string    Customize cli config file
  -d, --debug            Enable debug logs
  -o, --output string    Using json or yaml output
  -p, --project string   Using json or yaml output
  -v, --verbose          Verbose mode. A lot more information output.
```

---
