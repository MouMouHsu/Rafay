---
title: "KOP Access Proxy - RBAC"
source: https://docs.rafay.co/accessproxy/rbac/
category: Home
---

# RBAC

In some operational environments, administrators may wish to limit what certain users can/cannot do on the clusters. For example, in higher environments, it is common practice for administrators to only allow developer access to "kubectl" with "read only" privileges if necessary. This may be critical for troubleshooting purposes etc.

---

## Org Admins

As top level admins for an organization, users with this role are allowed access to all Kube API verbs in all clusters spanning all Projects in the organization.

---

## Infra and Project Admins

As admins, users with this role are allowed access to all Kube API verbs in clusters in the Project.

---

## Namespace Admins

Users with this role are allowed access to all Kube API verbs in clusters in the "namespace(s)" they are allowed to access.

---

## Read Only Users

Users with "Read Only" roles in the Org are only allowed to perform the following Kube API verbs.

- GET
- WATCH
- LIST

---

## SSO Users

SSO users can also seamlessly use the "Zero Trust KubeCTL" capabilities. SSO users are handled in a manner identical to local users i.e. their access privileges are mapped to roles in the Org based on their group membership in the SSO Provider (IdP).

---
