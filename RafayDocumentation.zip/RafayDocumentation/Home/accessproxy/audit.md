---
title: "KOP Access Proxy - Audit Trail"
source: https://docs.rafay.co/accessproxy/audit/
category: Home
---

# Audit Trail

In environments where users and systems have access to the Kube API server, it is critical from a Security and Governance perspective to be able to answer questions like the following:

- Who can do what?
- Who did what and when?
- Which resources were operated on, by whom and when?
- How did they access?

The ideal solution for this is "RBAC and Auditing". All activity performed on managed clusters via the "Zero Trust KubeCTL Proxy" is audited and persisted.

---

## KubeCTL Audit

- Login into the Web Console
- Click on System > Audit Logs
- Select the KubeCTL tab

Admins are presented with a near real-time view of kubectl audit logs. They are presented with an option to view the audit logs by "commands" or "API calls".

---

### Kubectl Commands Audits

For Kubectl usage performed via the web based shell, the proxy is able to capture and present the audit trail of both full command performed (e.g. kubectl get po -A) as well as the low level API calls.

[![KubeCTL Command Audit](https://docs.rafay.co/accessproxy/img/audit/kubectl_command_audit.png)](https://docs.rafay.co/accessproxy/img/audit/kubectl_command_audit.png)

---

### Kube API Audit Logs

The KubeCTL CLI takes a high level user command (e.g. kubectl get ns), breaks it down into a sequence of low level REST API calls that are sent to the remote cluster's API server via the kubectl proxy. A full audit trail of the sequence of the API calls are persisted and available for administrators.

The following detail is presented to the users. They are also provided useful filters so that they can quickly sort and zero in on the details they require.

- Date: When the activity was performed
- User: The user that performed it
- Cluster: The cluster that was accessed
- Namespace: The target namespace on the cluster
- Resource: The k8s resource that was accessed
- Method: GET, POST, DELETE, PATCH
- Access Method: Browser based or KubeCTL CLI
- Details: Additional data that may be useful for users

[![KubeCTL API Audit](https://docs.rafay.co/accessproxy/img/audit/kubectl_api_audit.png)](https://docs.rafay.co/accessproxy/img/audit/kubectl_api_audit.png)

---

## Export Logs

Users can export the audit logs to a CSV file by clicking on the "Export" button. Note that data for the current set of configured filters is exported.

> **Important**
> Users in production are strongly recommended to [**stream**](https://docs.rafay.co/integrations/siem/overview/) the "Kubectl Audit Logs" to their preferred SIEM for long term retention, forensics and analytics.

---

## Duration

For every operation processed by the "Kube API Server Proxy", the "duration" for the end-to-end operation is captured and displayed in the "Details" column in the audit logs. i.e. this is the response time for the API. Note that a single KubeCTL command may translate to 10s of API calls underneath the covers.

This data can be useful in helping administrators validate the user experience benefits with the zero trust, secure, direct access to clusters vs latency and performance issues experienced due to bastions and VPNs.

---
