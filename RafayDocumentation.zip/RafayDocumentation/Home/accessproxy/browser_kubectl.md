---
title: "KOP Access Proxy - Browser"
source: https://docs.rafay.co/accessproxy/browser_kubectl/
category: Home
---

# Browser

Users that have access to the Web Console are provided with the option to perform KubeCTL operations in a browser based shell after they successfully authenticate.

---

## Infrastructure and Cluster Admins

Users with Infrastructure Admin roles for a Project(s) in the Web Console have access to the "Infrastructure" tab and therefore access to the Kubernetes clusters in the Project. For every managed cluster, in a Project, users are presented with a visible option to initiate KubeCTL. See the image below for an illustrative example.

- Click the **KubeCTL** icon

[![Infra Admins KubeCTL via Browser](https://docs.rafay.co/accessproxy/img/browser/cluster-kubectl.png)](https://docs.rafay.co/accessproxy/img/browser/cluster-kubectl.png)

- This presents the user with a browser based KubeCTL shell. Initially, the connection status is **Connecting** (highlighted in red)

[![Cluster KubeCTL Shell](https://docs.rafay.co/accessproxy/img/browser/browser_kubectl-shell.png)](https://docs.rafay.co/accessproxy/img/browser/browser_kubectl-shell.png)

### Connection Status

- On a successful connection, the status is **Connected** (highlighted in green)

[![Cluster KubeCTL Shell](https://docs.rafay.co/accessproxy/img/browser/connected_kctl.png)](https://docs.rafay.co/accessproxy/img/browser/connected_kctl.png)

- Click **+** icon next to the clusters name to view one or more cluster details through KubeCTL. The connection fetches information for each cluster

[![Cluster KubeCTL Shell](https://docs.rafay.co/accessproxy/img/browser/multiple_clusters.png)](https://docs.rafay.co/accessproxy/img/browser/multiple_clusters.png)

- When the user is away from the controller for a longer period or the session expires, the connection status is **Not Connected**. Click **Reconnect** to get the connection back and use the relevant commands to retrieve the required information

[![Cluster KubeCTL Shell](https://docs.rafay.co/accessproxy/img/browser/disconnected.png)](https://docs.rafay.co/accessproxy/img/browser/disconnected.png)

---

## Project Admins

Users with Project Admin roles for a Project(s) in the Web Console have access to the "Applications" and "Integrations" tabs. Unlike Infrastructure Admins, these users DO NOT have direct, low level access to the Kubernetes clusters in the Projects. However, as application owners/developers, they may require quick KubeCTL access to the namespace where their workloads are deployed so that they can debug/diagnose issues when they occur.

The Web Console provides these users the means to open a browser based KubeCTL shell directly in the namespace of the cluster where their workload is deployed.

- Click on a workload
- Navigate to the Publish tab and click on Debug
- Click on the KubeCTL button

The user will now be presented with a browser based KubeCTL shell and can perform operations in the namespace where the workload was deployed.

[![Browser KubeCTL for Workloads](https://docs.rafay.co/accessproxy/img/browser/workload_kubectl.png)](https://docs.rafay.co/accessproxy/img/browser/workload_kubectl.png)

> **Important**
> Unlike the debug window which automatically provides a filtered view of only the k8s resources for their workload, the KubeCTL shell provides the user visibility into all resources in the namespace.

---

## Namespace Admins

Users with Namespace Admin roles in a Project in the Web Console have access ONLY to specifically identified Kubernetes namespaces. As application owners/developers, they may require quick KubeCTL access to the namespace where their workloads are deployed so that they can debug/diagnose issues when they occur.

The Web Console provides these users the means to open a browser based KubeCTL shell directly in the namespace of the cluster where their workload is deployed.

- Click on a workload
- Navigate to the Publish tab and click on Debug
- Click on the KubeCTL button

The user will now be presented with a browser based KubeCTL shell and can perform operations in the namespace where the workload was deployed.

[![Browser KubeCTL for Workloads](https://docs.rafay.co/accessproxy/img/browser/namespace_kubectl.png)](https://docs.rafay.co/accessproxy/img/browser/namespace_kubectl.png)

> **Important**
> Users with a namespace admin role will be blocked from being able to perform privileged KubeCTL commands outside the allowed namespaces.

---

## Plugins

### grep

The grep plugin is used to search for pod details that match a particular pattern. Below is an example where the user is trying to find pods which contain the strings "httpbin"

```
kubectl grep pod -A httpbin
NAMESPACE   NAME                       READY   STATUS    RESTARTS   AGE
ns-01       httpbin-76b5bcc9bb-pghh5   1/1     Running   0          22h
ns-03       httpbin-c9d44d899-z9gsv    1/1     Running   0          22h
```

Use the below command to view all the available commands of grep plugin

```
kubectl grep -h
```

A few more examples of grep plugin command are given below:

- List all pods in default namespace 

```
kubectl grep pods
```
- List all pods in all namespaces 

```
kubectl grep pods -A
```
- List all pods in namespace "start-lab" which contains keyword "flash" 

```
kubectl grep pods -n star-lab flash
```

### argo rollouts

Argo Rollouts, a Kubernetes workload resource that replaces a Deployment object when more advanced deployment or progressive delivery functionality is required. Argo Rollouts provides features such as blue-green deployments, canary deployments, integration with ingress controllers and service meshes for traffic routing, and integration with metric providers for analysis. Progressive delivery is described as a controlled and gradual release process, reducing release risks through automation and metric analysis. Different deployment strategies are explained, including Rolling Update, Recreate, Blue-Green, and Canary, each offering unique ways to manage application updates and traffic routing for testing and verification purposes. Argo Rollouts allows for customizable stages and percentages to tailor the deployment process based on specific use cases.

Use the below command to view all the available commands of argo rollout plugin

```
kubectl argo rollouts -h
```

The below command consists of multiple subcommands which can be used to manage Argo Rollouts

```
kubectl argo rollouts COMMAND [flags]
```

A few examples of argo rollout plugin sub-commands are given below:

- Get guestbook rollout and watch progress

```
kubectl argo rollouts get rollout guestbook -w
```

- Pause the guestbook rollout

```
kubectl argo rollouts pause guestbook
```

- Promote the guestbook rollout

```
kubectl argo rollouts promote guestbook
```

- Abort the guestbook rollout

```
kubectl argo rollouts abort guestbook
```

- Retry the guestbook rollout

```
kubectl argo rollouts retry guestbook
```

Here is an illustrative example depicting comprehensive details and a graphical representation of an experiment. This operation provides extensive metadata for a resource and presents a tree view, illustrating the child resources created by the parent.

[![Browser KubeCTL for Workloads](https://docs.rafay.co/accessproxy/img/browser/rollout_img1.png)](https://docs.rafay.co/accessproxy/img/browser/rollout_img1.png)

For more info on argo rollout, refer this [page](https://argo-rollouts.readthedocs.io/en/release-1.5/generated/kubectl-argo-rollouts/kubectl-argo-rollouts/).

Explore our blog for deeper insights on **Integrated Grep Plugin for the Kubectl Web Shell**, available [here](https://docs.rafay.co/blog/2023/08/13/integrated-grep-plugin-for-the-kubectl-web-shell/)!

---
