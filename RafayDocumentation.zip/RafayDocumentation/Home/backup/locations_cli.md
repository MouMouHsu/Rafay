---
title: "KOP Backup - Backup Location CLI"
source: https://docs.rafay.co/backup/locations_cli/
category: Home
---

# CLI

## CLI for creating Backup Location

### Amazon S3 Storage/S3 Compatible Storage

Users can also define a location to store the backup snapshots through RCTL with the below commands

**Create Control Plane Backup Location with Amazon Target Type**

```
 ./rctl create dp-location <name> --backup-type <controlplanebackup> --target-type <amazon> --region <region> --bucket-name <bucketname>
```

**Create Control Plane Backup Location with S3 Compatible Endpoint Target Type**

```
./rctl create dp-location <name> --backup-type <controlplanebackup> --target-type <s3compatible> --url <url> --bucket-name <bucketname>
```

**Create Volume Backup Location with Amazon Target Type**

```
./rctl create dp-location <name> --backup-type <volumebackup> --target-type <amazon> --region <region>
```

**Create Volume Backup Location with S3 Compatible Endpoint Target Type**

```
./rctl create dp-location <name> --backup-type <volumebackup> --target-type <s3compatible> --url <url> --bucket-name <bucketname>
```

**Update Location objects with Amazon Target Type**

```
./rctl update dp-location <name> --backup-type <backup-type> --target-type <amazon> --region <region> --bucket-name <bucketname>
```

**Update Location objects with S3 Compatible Endpoint Target Type**

```
./rctl update dp-location <name> --backup-type <backup-type> --target-type <s3compatible> --url <url> --bucket-name <bucketname>
```

### Azure Storage Account

For AKS clusters, users can define a location to store the backup snapshots through RCTL with the below commands

**Create Control Plane Backup Location with Azure Target Type**

```
./rctl create dp-location <name> --backup-type <controlplanebackup> --target-type <azure> --bucket-name <bucketname> --resource-group <resource-group> --storage-account <storage-account>
```

**Create Volume Backup Location with Azure Target Type**

```
./rctl create dp-location <name> --backup-type <volumebackup> --target-type <azure> --resource-group <resource-group>
```

**Update Control Plane Backup Location with Azure Target Type**

```
./rctl update dp-location <name> --backup-type <controlplanebackup> --target-type <azure> --bucket-name <bucketname> --resource-group <resource-group> --storage-account <storage-account>
```

**Update Volume Backup Location with Azure Target Type**

```
./rctl update dp-location <name> --backup-type <volumebackup> --target-type <azure> --resource-group <resource-group>
```

---

## Fetch / Delete Location

**Delete Location**

```
./rctl delete dp-location <name>
```

**Fetch Location objects**

```
./rctl get dp-location
```

An illustrative example is shown below where RCTL retrieves the list of location objects

```
+-------------------+----------------------+------------------------------+
| NAME              | TYPE                 | CREATED AT                   |
+-------------------+----------------------+------------------------------+
| demo-cpb          | Control Plane Backup | Fri Sep 17 09:26:19 UTC 2021 |
+-------------------+----------------------+------------------------------+
| demo-controlplane | Control Plane Backup | Fri Sep 17 09:25:53 UTC 2021 |
+-------------------+----------------------+------------------------------+
| demo-volume       | Volume Backup        | Fri Sep 17 09:26:06 UTC 2021 |
+-------------------+----------------------+------------------------------+
```

Use the below command to retrieve a specific location's details

```
./rctl get dp-location <location-name>
```

---
