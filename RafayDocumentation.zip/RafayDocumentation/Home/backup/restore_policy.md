---
title: "KOP Backup - Restore Policy"
source: https://docs.rafay.co/backup/restore_policy/
category: Home
---

# Restore Policy

Administrators can create a restore policy to specify the rules a restore job has to comply with when it performs a restore operation.

---

## Create Restore Policy

Follow below steps to create a restore policy for your clusters:

- From web console, navigate to Backup/Restore -> Policies menu to add "New Policy"
- Enter a name and an optional description
- Select Type "Restore"

[![Add Restore Policy](https://docs.rafay.co/backup/img/Create-Restore-Policy.png)](https://docs.rafay.co/backup/img/Create-Restore-Policy.png)

- In the Restore Policy Settings page > Config section, check/uncheck "Restore PVs" checkbox to enable/disable restore persistent volume data.

---

### Example: Control Plane and PVs

Here is an example of a policy to restore both cluster control plane and persistent volumes data

[![Configure Restore Policy](https://docs.rafay.co/backup/img/Configure-Restore-Policy-1-With-PV.png)](https://docs.rafay.co/backup/img/Configure-Restore-Policy-1-With-PV.png)

---

### Example: Only Control Plane

Here is an example of a policy to restore only cluster control plane data and no persistent volumes.

[![Configure Restore Policy](https://docs.rafay.co/backup/img/Configure-Restore-Policy-1-No-PV.png)](https://docs.rafay.co/backup/img/Configure-Restore-Policy-1-No-PV.png)

---

### Advanced Options

In a manner similar to a backup policy, administrators can specify fine-grained controls for the restore policy. You can optionally use "target selectors" to refine the scope of the backup policy. You have three options

- Include namespaces (restores performed only from the selected namespaces)
- Exclude namespaces (skip these namespaces for restore operations)
- Specify label selectors (restore resources that match the labels)

Here is an example of a restore policy where the administrator only wishes to restore the cluster data for the "apache" namespace

[![Configure Restore Policy](https://docs.rafay.co/backup/img/Configure-Restore-Policy-2.png)](https://docs.rafay.co/backup/img/Configure-Restore-Policy-2.png)

> **Important**
> For configuring additional parameters, such as `includedResources`, `includeClusterResources`, `namespaceMapping`, and `scheduleName`, use RCTL or API

---
