---
title: "KOP Backup - S3 Compatible Storage"
source: https://docs.rafay.co/backup/credentials_s3/
category: Home
---

# S3 Compatible

Follow the steps described below to create a S3 Compatible Cloud credential:

## S3 Compatible Storage

- Retrieve the **Access Key ID** and **Secret Access Key** to access your MINIO S3 compatible storage (Ensure this has both read and write permission to the bucket)
- Go to controller's web console, and navigate to **Infrastructure -> Cloud Credentials**
- Click **New Credential**, provide a name and select Type **Data Backup**
- Select Provider **MINIO** and Credential Type **ACCESS_KEY**
- Enter **Access Key ID** and **Secret Key**
- Click **SAVE** to create the cloud credential to access the bucket for your cluster data backup

[![Add Credentials](https://docs.rafay.co/backup/img/Cluster-Backup-Minio-Credential.png)](https://docs.rafay.co/backup/img/Cluster-Backup-Minio-Credential.png)

---
