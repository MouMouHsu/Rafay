---
title: "KOP Backup - Data Agent"
source: https://docs.rafay.co/backup/data_agents/
category: Home
---

# Data Agent

A "Data Agent" will be automatically deployed to your cluster where backup or restore needs to be performed. Follow the steps described below to deploy a data agent to your clusters.

---

## Create Agent

- In the web console, navigate to "Backup/Restore" -> Data Agents
- Click **New Agent**, provide a name and an optional description
- Click **Create**

[![Add Data Agent](https://docs.rafay.co/backup/img/Create-back-up-agent.png)](https://docs.rafay.co/backup/img/Create-back-up-agent.png)

- Select the backup agent version: either the latest version ***v1.15.1*** (default) or ***v1.9.3***

**Backup Data Agent Versions**

For users managing older setups, the option to select **v1.9.3** remains available to ensure continuity with legacy systems. While the **Version** dropdown automatically selects **v1.15.1**, users can switch to **v1.9.3** when necessary. This flexibility allows organizations to transition at their own pace while maintaining a consistent and reliable backup and restore workflow.

Users can enable **Volume Backups for On-prem Clusters** and specify the **Pod Volume Path** for both **v1.9.3** and **v1.15.1**. Enable or disable the option **Enable Volume Backups for On-prem Clusters** if this agent is intended for persistent volume backups. These settings ensure compatibility across versions.

The default Velero agent version, **v1.15.1**, provides users with the most recent advancements in performance, security, and compatibility. It is designed to work seamlessly with modern Kubernetes clusters, offering enhanced support for CSI plugins and addressing vulnerabilities found in earlier releases. Setting **v1.15.1** as the default simplifies the creation of agents optimized for current standards without additional configuration.

When selecting **v1.15.1**, users can also **Enable CSI** and **Enable SSE-C Encryption**. Enabling **SSE-C Encryption** requires providing a **Customer Key**, which is sent to Azure, AWS or S3 to encrypt the raw data and has to be mounted inside the pod, ensuring secure encryption of backups and compatibility with advanced features for enhanced data protection.

- Select the "Cloud Credential" from drop-down that will be used for accessing the data backup location
- Click **Save** to add the data agent

[![Add Data Agent](https://docs.rafay.co/backup/img/select_cloud_credential.png)](https://docs.rafay.co/backup/img/select_cloud_credential.png)

---

## Deploy Agent

- From the Data Agent list, click the required agent to be deployed. A message appears saying **Agent Not Deployed**
- Click **Deploy to Clusters**

[![Click Deploy to Cluster](https://docs.rafay.co/backup/img/agents_notdeployed.png)](https://docs.rafay.co/backup/img/agents_notdeployed.png)

**Deploy to Clusters** screen appears at the right pane

- Select the cluster name to deploy the data agent and click **DEPLOY** to deploy this agent to the selected clusters

[![Select Cluster](https://docs.rafay.co/backup/img/select_cluster.png)](https://docs.rafay.co/backup/img/select_cluster.png)

> **Note**
> You can have the same "data agent" deployed to multiple clusters in the same project

- Deployment of the data agent to clusters is fully automated and can take a few minutes
- Once the data agent is deployed successfully to the cluster, a message **Deployment initiated, it might take about 5-10 mins** appears
- Once the data agent is deployed successfully to the cluster, the agent status will display in the Data Agent page

[![Deploy Data Agent](https://docs.rafay.co/backup/img/Agent-Deployment_success.png)](https://docs.rafay.co/backup/img/Agent-Deployment_success.png)

You are now ready to create a backup and restore job for your cluster

> ⚠️ Important:
> The data agent version used for the backup should be the same as the version used for restore jobs. Cross versions are not supported.

Use the refresh button on the Data Agent main page to view the newly added Data Agent

[![Deploy Data Agent](https://docs.rafay.co/backup/img/refresh_button.png)](https://docs.rafay.co/backup/img/refresh_button.png)

---

## Actions

### Edit/Update Agents

To edit/update an existing agent, use the edit icon and perform the changes

> ⚠️ Important:
> To change the data agent version on the cluster, undeploy the existing agent, and then deploy the cluster with the new version of the agent.

### Delete Agent

To delete agents that are not deployed on any cluster, perform the below steps:

- Navigate to the "Backup/Restore" page
- Go to the "Data Agent" page within the Backup/Restore section
- Locate the data agent that you want to delete and click on the "Delete" icon associated with the data agent you wish to remove. A confirmation prompt should appear asking if you want to proceed with the deletion
- Click "Yes" to confirm the deletion

[![Delete Data Agent](https://docs.rafay.co/backup/img/delete_dataagent.png)](https://docs.rafay.co/backup/img/delete_dataagent.png)

These steps helps to easily remove non-deployed agents.

---

## Upgrade Data Agent

- Once a data agent with `v1.9.3` is deployed on a cluster, to upgrade the running data agent to `v1.15.1`, click on **Upgrade Version**

[![Delete Data Agent](https://docs.rafay.co/backup/img/deploy_agent.png)](https://docs.rafay.co/backup/img/deploy_agent.png)

- Select the version `v1.15.1` and the cluster
- If needed, enable `Enable CSI` and `SSE-C Encryption Key`. When enabling `SSE-C Encryption Key`, enter the `Customer Key` and click **Save**

[![Delete Data Agent](https://docs.rafay.co/backup/img/dbversionselect.png)](https://docs.rafay.co/backup/img/dbversionselect.png)

Once the upgrade is initiated, the data agent will be upgraded to v1.15.1, as shown below.

[![Delete Data Agent](https://docs.rafay.co/backup/img/agent_new.png)](https://docs.rafay.co/backup/img/agent_new.png)

---
