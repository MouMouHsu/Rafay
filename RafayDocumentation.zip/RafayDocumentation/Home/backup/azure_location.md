---
title: "KOP Backup - Azure Blob Storage"
source: https://docs.rafay.co/backup/azure_location/
category: Home
---

# Azure Blob Storage

Follow the steps described below to create Azure Blob Storage Location

## Control Plane

- Create an **Azure Container**, **Storage Account** and **Resource Group** in your Azure account. Note down all the storage details

> **Important**
> Credential Type **Service principal** with **Contributor** role is mandatory for Azure Storage Process

Refer [Azure Service Setup](https://docs.rafay.co/clusters/aks/azure_setup/) to know the Azure set up details and retrieve the appropriate data

- From Web Console, navigate to your Project
- Select **Backup/Restore -> Locations** and click **New Location**
- Provide the location name and an optional description
- Select Type **Control Plane Backup** and click **CREATE**

[![Add Location](https://docs.rafay.co/backup/img/create_azure_ctrlplane.png)](https://docs.rafay.co/backup/img/create_azure_ctrlplane.png)

- In the location settings page, under Config section, select Target Type as **Azure**
- Enter the Container Name, Storage Account, and Resource Group of the Azure account
- Click **SAVE** to create the location for control plane backup to Azure blob storage

[![Configure Location](https://docs.rafay.co/backup/img/azure_backup-config.png)](https://docs.rafay.co/backup/img/azure_backup-config.png)

---

## Persistent Volumes

- Navigate to **Backup/Restore > Locations** and click **New Location**
- Provide the location name and an optional description
- Select Type **Volume Backup** and click **CREATE**

[![Configure Volume Backup Location](https://docs.rafay.co/backup/img/azure_volbackup_create.png)](https://docs.rafay.co/backup/img/azure_volbackup_create.png)

- In the location settings page, under Config section, select Target Type as **Azure**
- Enter the **Resource Group** and click **SAVE** to create the location for persistent volume backup to Azure blob storage

[![Configure Azure Location](https://docs.rafay.co/backup/img/azurebackup_config.png)](https://docs.rafay.co/backup/img/azurebackup_config.png)

**For Disk Management**

The below permissions are required on the Resource Group where the disks are to be located:

- Microsoft.Compute/disks/read
- Microsoft.Compute/disks/write
- Microsoft.Compute/disks/endGetAccess/action
- Microsoft.Compute/disks/beginGetAccess/action

**For Snapshot Management**

The below permissions are required on the Resource Group where the snapshots are to be located:

- Microsoft.Compute/snapshots/read
- Microsoft.Compute/snapshots/write
- Microsoft.Compute/snapshots/delete

---

## Actions

To edit/delete a location, use the respective icons

[![Delete Data Agent](https://docs.rafay.co/backup/img/edit_delete.png)](https://docs.rafay.co/backup/img/edit_delete.png)

---
