---
title: "KOP Backup - Backup Job"
source: https://docs.rafay.co/backup/backup_job/
category: Home
---

# Backup Job

Once you have created a [backup policy](https://docs.rafay.co/backup/backup_policy/) and deployed a [data agent](https://docs.rafay.co/backup/data_agents/) to target clusters, you can create or schedule backup jobs for your clusters. A backup job is an instance of a backup operation

---

## On-Demand Backups

Follow the below steps to create a backup job for your cluster:

- In the web console, navigate to your project
- Go to "Backup/Restore -> Jobs" menu
- Click "Backup Job" and create a new backup job
- Select the Backup Policy from the "Policy" drop down list
- Select the cluster from the drop-down that you would like to backup from the cluster drop down list
- Make sure the checkbox "Schedule" is disabled
- Click "EXECUTE" to perform the backup job for your selected cluster from the configured backup policy.

[![Backup Job](https://docs.rafay.co/backup/img/Create-Backup-Jobs.png)](https://docs.rafay.co/backup/img/Create-Backup-Jobs.png)

- Once the backup job is done, the backup job status will be displayed in the "JOBS" list

[![Backup Job](https://docs.rafay.co/backup/img/Backup-Job-Complete.png)](https://docs.rafay.co/backup/img/Backup-Job-Complete.png)

To learn more about a backup job, click the expand/collapse button

[![Backup Job](https://docs.rafay.co/backup/img/job_details.png)](https://docs.rafay.co/backup/img/job_details.png)

- Optionally you can also verify the backup data in your AWS S3 bucket or S3 Compatible Storage. Below is the illustrative example of the successful backup data of the cluster in MinIO bucket

[![Backup Job](https://docs.rafay.co/backup/img/Backup-Data-MinIO.png)](https://docs.rafay.co/backup/img/Backup-Data-MinIO.png)

---

## Scheduled Backups

Follow below steps if you would like to perform the data backup for your cluster from the configured policy based on the defined schedule.

- From the web console, navigate to your Project
- Go to Backup/Restore > Jobs menu to click "Backup Job" to create a new backup job
- Select the Backup Policy from the "Policy" drop down list
- Click "ADD CLUSTER" and select the cluster name that you would like to backup from the cluster drop down list
- Select checkbox "Schedule" to enable a scheduled backup job
- Enter the [Cron Expression](https://crontab.guru/) to schedule your cluster backup job

Below is an example of scheduling a backup job for the cluster to run twice a day at 12am and 12pm

[![Backup Job](https://docs.rafay.co/backup/img/Create-Backup-Schedule.png)](https://docs.rafay.co/backup/img/Create-Backup-Schedule.png)

- Click "EXECUTE" to create the scheduled backup job for your selected cluster from the configured backup policy.

> 🚀  Important Note
> By default, CRON expressions are interpreted in UTC (Coordinated Universal Time). However, the system now supports specifying a time zone within the CRON expression using CRON_TZ=<TimeZone>, allowing backups to run based on the configured time zone. If no time zone is specified, the backup job will execute in UTC.
> This capability is available only in the latest version of the backup agent v1.15.1
> Examples:
> CRON_TZ=Asia/Kolkata 42 1 * * * – Runs the backup at 01:42 AM IST.
> CRON_TZ=America/New_York 0 3 * * * – Runs the backup at 03:00 AM EST.
> CRON_TZ=Europe/London 30 5 * * * – Runs the backup at 05:30 AM GMT.
> CRON_TZ=Australia/Sydney 15 22 * * * – Runs the backup at 10:15 PM AEST.

Once the scheduled backup job is created, the scheduled backup job will be displayed in the "SCHEDULED BACKUPS" list

[![Backup Job](https://docs.rafay.co/backup/img/Schedule-Backup-Job.png)](https://docs.rafay.co/backup/img/Schedule-Backup-Job.png)

A backup job will be performed immediately after the scheduled backup job is created. When the schedule is up next time, a new backup job will be performed automatically.

[![Backup Job](https://docs.rafay.co/backup/img/Backup-Scheduled-Complete.png)](https://docs.rafay.co/backup/img/Backup-Scheduled-Complete.png)

---
