---
title: "Backup and Restore"
source: https://docs.rafay.co/backup/overview/
category: Home
---

# Overview

Included in the Kubernetes Operations Platform offering is a fully integrated and turnkey cluster backup and restore capability -- a unique feature in the industry -- enabling enterprises to centrally configure, automate and operationalize disaster recovery (DR) and/or for cluster migration use cases.

With this capability, administrators can configure backups for their clusters and workload's literally in a few minutes. They do not have to worry about the learning curve associated with yet another standalone tool for this capability.

With this capability, administrators can

1. Quickly recover clusters from disasters like hardware failures
2. Migrate clusters from one environment to another (e.g. on-prem to cloud)
3. Recover data for specific workload namespaces to the last known good configuration in case of data corruption

---

## Automation Options

The below matrix presents a breakdown of actions like creation, updating, and deletion of Backup & Restore across multiple deployment methods: Interactive UI, Declarative RCTL commands, API-driven automation, and Terraform.

| Deployment Types | Data Agents | Locations (AWS) | Locations (Azure) | Locations (S3) | Backup Policies | Backup Jobs | Restore Policies | Restore Jobs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| UI | [Yes](https://docs.rafay.co/backup/data_agents/) | [Yes](https://docs.rafay.co/backup/aws_location/) | [Yes](https://docs.rafay.co/backup/azure_location/) | [Yes](https://docs.rafay.co/backup/s3_location/) | [Yes](https://docs.rafay.co/backup/backup_policy/) | [Yes](https://docs.rafay.co/backup/backup_job/) | [Yes](https://docs.rafay.co/backup/restore_policy/) | [Yes](https://docs.rafay.co/backup/restore_job/) |
| CLI | [Yes](https://docs.rafay.co/cli/backup_cli/#rctl-for-data-agents) | [Yes](https://docs.rafay.co/cli/backup_cli/#rctl-for-backup-location) | [Yes](https://docs.rafay.co/cli/backup_cli/#azure-storage-account) | [Yes](https://docs.rafay.co/cli/backup_cli/#amazon-s3-storages3-compatible-storage) | [Yes](https://docs.rafay.co/cli/backup_cli/#rctl-for-backup-policy) | [Yes](https://docs.rafay.co/cli/backup_cli/#rctl-for-backup-job) | [Yes](https://docs.rafay.co/cli/backup_cli/#rctl-for-restore-policy) | [Yes](https://docs.rafay.co/cli/backup_cli/#rctl-for-restore-job) |
| API | [Yes](https://docs.rafay.co/backup/#api/) | [Yes](https://docs.rafay.co/backup/#api/) | [Yes](https://docs.rafay.co/backup/#api/) | [Yes](https://docs.rafay.co/backup/#api/) | [Yes](https://docs.rafay.co/backup/#api/) | [Yes](https://docs.rafay.co/backup/#api/) | [Yes](https://docs.rafay.co/backup/#api/) | [Yes](https://docs.rafay.co/backup/#api/) |
| Terraform | No | No | No | No | No | No | No | No |

---

### Benefits

Organizations can implement consistent standards internally without requiring deep Kubernetes expertise for all operational personnel.

#### Standardization and Consistency

Administrators can create and manage distinct (a) backup policies and (b) backup locations for every project (mapped to a business unit, team or operating environment). These can then be seamlessly leveraged across the fleet of clusters in the project providing a consistent experience and standardization.

#### Improved Security Posture

Use RBAC to implement clear separation of duties between cluster operations and application owners.

Dramatically improve security posture by eliminating manual handling (provisioning and deprovisioning) of secrets and access credentials. With the integrated backup offering, access credentials and secrets are stored encrypted using a hardware backed KMS. They are securely and seamlessly delivered to the managed clusters where backup/recovery operations need to be performed.

#### Zero Burden Operations

Enabling backup for a cluster is as simple as enabling a toggle button. Provide your operations team a trouble free and intuitive experience like what they are used to with their smartphones. When enabled, the controller will automatically deploy the backup agent on the cluster and automatically configure it with required access credentials.

#### Governance and Compliance

In order to demonstrate governance and compliance, administrators are required to provide evidence that backups are being performed as per configured backup policy. The controller maintains the entire history of backup jobs and this data serves as ongoing evidence that backups are being performed successfully as per documented schedule.

---

### What data to Backup?

Administrators need to specify what data on the cluster they want to backup. Available options are:

- Control Plane i.e. objects stored in the cluster's etcd database
- Backup persistent volumes

---

### Where to Backup?

Any s3 API compatible storage endpoint is supported. This can be a cloud service such as Amazon AWS's [S3 service](https://aws.amazon.com/s3/) or any S3 compatible storage i.e. [MinIO](https://min.io/).

---
