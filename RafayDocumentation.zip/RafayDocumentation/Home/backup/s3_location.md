---
title: "KOP Backup - S3 Compatible Storage"
source: https://docs.rafay.co/backup/s3_location/
category: Home
---

# S3 Compatible Storage

Follow the steps described below to create S3 Compatible Storage Location

## Control Plane

- Install S3 Compatible Storage in your environment like [MinIO](https://min.io/) to use for cluster backup. You can follow the recipe on how to install a centralize MinIO to your infrastructure cluster [here](https://docs.rafay.co/recipes/storage/minio/minio/)
- Create a bucket in your MinIO with Read and Write access to use for backing up your cluster data. Note down Minio's URL and the bucket name to use for configuring in Web Console in later steps.
- From the Web Console, navigate to your Project
- Go to **Backup/Restore > Locations** menu to add **New Location**
- Provide the location name, and an optional description
- Select Type **Control Plane Backup** and click **CREATE**

[![Add Location](https://docs.rafay.co/backup/img/Create-Backup-Location-MinioCluster.png)](https://docs.rafay.co/backup/img/Create-Backup-Location-MinioCluster.png)

- In the location settings page, under Config section, select Target Type as **S3 Compatible Endpoint**
- Enter the **Region** and **MinIO URL**
- Select **True** or **False** to skip TLS verification

[![Configure Location](https://docs.rafay.co/backup/img/s3_location.png)](https://docs.rafay.co/backup/img/s3_location.png)

- Provide the **CA Certificate** and **Bucket Name** for the MinIO bucket created earlier
- Optionally, enable **Select Server Side Encryption** to choose a non-default encryption type and select either **SSE-KMS** or **SSE-C**
  - When **SSE-KMS** is selected, users must provide the **KMS Key ID**
  - When selecting the **SSE-C** encryption type, users should ensure they have provided the SSE-C key while creating the data protection agent
  - Users may optionally enter the **Server-Side Encryption Algorithm**

> Note: If Server Side Encryption is not enabled, default cloud encryption will be applied to the agent

- Click **SAVE** to create the location for control plane backup to MinIO bucket

[![Configure Location](https://docs.rafay.co/backup/img/Config-Backup-Location-MinioCluster.png)](https://docs.rafay.co/backup/img/Config-Backup-Location-MinioCluster.png)

---

## Persistent Volumes

- Go back to Backup/Restore > Locations menu to add **New Location**
- Provide the location name, and an optional description
- Select Type **Volume Backup** and click **CREATE**

[![Add Location](https://docs.rafay.co/backup/img/Create-Backup-Location-MinioPV.png)](https://docs.rafay.co/backup/img/Create-Backup-Location-MinioPV.png)

- In the location settings page, under Config section, select Target Type as **S3 Compatible Endpoint**
- Enter the **MinIO URL** and click **SAVE** to create the location for persistent volume backup to MinIO bucket

[![Configure Location](https://docs.rafay.co/backup/img/Configure-Backup-Location-MinioPV.png)](https://docs.rafay.co/backup/img/Configure-Backup-Location-MinioPV.png)

---

## Actions

To edit/delete a location, use the respective icons

[![Delete Data Agent](https://docs.rafay.co/backup/img/edit_delete.png)](https://docs.rafay.co/backup/img/edit_delete.png)

---
