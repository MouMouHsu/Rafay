---
title: "KOP Backup & Restore - API"
source: https://docs.rafay.co/backup/api/
category: Home
---

# API

Users have the capability to oversee the backup and restore lifecycle by utilizing the REST APIs based on Swagger.

## Backup and Restore APIs

- Login to the console and click **API DOCS** from the Home page
- Select **v2/v1 APIs** from the drop-down

[![API DOCS](https://docs.rafay.co/backup/img/api_v2.png)](https://docs.rafay.co/backup/img/api_v2.png)

Platform API screen appears

- Under Backup and Restore, use the respective **GET**, **POST**, **PUT**, and **DELETE** REST API to create, update, get and delete the required Data agents, Locations, Policies, and Jobs

[![API DOCS](https://docs.rafay.co/backup/img/bpr_apis.png)](https://docs.rafay.co/backup/img/bpr_apis.png)

- Enter the **project_id**, and other mandatory fields
- Click **Execute** to complete the enabling process

Here's an illustration of retrieving specific details about a Data Agent

[![API DOCS](https://docs.rafay.co/backup/img/get_response.png)](https://docs.rafay.co/backup/img/get_response.png)

---
