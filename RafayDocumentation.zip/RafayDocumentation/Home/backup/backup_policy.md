---
title: "KOP Backup - Backup Policy"
source: https://docs.rafay.co/backup/backup_policy/
category: Home
---

# Backup Policy

Administrators can create a backup policy to specify how, when and what needs to be backed up. The policy will define the location to keep the backup data, retention period, whether persistent volumes should be backed up and the scope of cluster objects to backup.

---

## Create Backup Policy

Follow the steps described below to create a backup policy for your clusters:

- From the controller's web console, select "Backup/Restore"-> Policies
- Add "New Policy" and provide a name and optionally a description
- Select Type "Backup"

[![Add Backup Policy](https://docs.rafay.co/backup/img/Create-Backup-Policy.png)](https://docs.rafay.co/backup/img/Create-Backup-Policy.png)

- In the Backup Policy Settings page > Config section, select the Control Plane Backup Location from the dropdown list.
- If you would like to backup the persistent volumes associated with the cluster, select the Volume Backup Location from the dropdown list.
- Enter the Retention Period for your backup data.

> **Note**
> You can "backup" the control plane and the PVs to different locations.

---

### Control Plane and PVs

Here is an example of a configuration which will backup both "cluster control plane data" and "persistent volumes" with a 10-day retention period. Note that the "control plane" and the "PVs (volumes)" are backed up to different locations.

[![Configure Backup Policy](https://docs.rafay.co/backup/img/Configure-Backup-Policy-1-With-PV.png)](https://docs.rafay.co/backup/img/Configure-Backup-Policy-1-With-PV.png)

---

### Control Plane Only

Here is an example of a configuration which will backup ONLY the "cluster control plane data" with a 10-day retention period. Persistent volumes will not be backed up.

[![Configure Backup Policy](https://docs.rafay.co/backup/img/Configure-Backup-Policy-1-No-PV.png)](https://docs.rafay.co/backup/img/Configure-Backup-Policy-1-No-PV.png)

---

### Advanced Options

You can optionally use "target selectors" to refine the scope of the backup policy. You have three options

- Include namespaces (backups performed only from the selected namespaces)
- Exclude namespaces (backups from selected namespaces are skipped)
- Specify label selectors (backup resources that match the labels)

Here is an illustrative example where the administrator wants to backup ALL cluster data except "kube-system", "rafay-infra" and "rafay-system" namespaces.

[![Configure Backup Policy](https://docs.rafay.co/backup/img/Configure-Backup-Policy-2.png)](https://docs.rafay.co/backup/img/Configure-Backup-Policy-2.png)

---
