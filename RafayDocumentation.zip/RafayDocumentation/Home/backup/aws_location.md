---
title: "KOP Backup - AWS S3 Storage"
source: https://docs.rafay.co/backup/aws_location/
category: Home
---

# AWS S3 Bucket

Follow the steps described below to create AWS S3 Bucket Location

## Control Plane

- Create an AWS S3 bucket in your AWS account
- Note down AWS region and the name of the bucket
- From Web Console, navigate to your Project
- Select **Backup/Restore > Locations** and click **New Location**
- Provide the location name and provide an optional description
- Select Type **Control Plane Backup** and click **CREATE**

[![Add Location](https://docs.rafay.co/backup/img/Create-Backup-Loc-Cluster.png)](https://docs.rafay.co/backup/img/Create-Backup-Loc-Cluster.png)

- In the location settings page, under Config section, select Target Type as **Amazon**
- Enter the **Region** and **Bucket Name** for the AWS S3 bucket created above
- Optionally, enable **Select Server Side Encryption** to choose a non-default encryption type and select either **SSE-KMS** or **SSE-C**
  - When **SSE-KMS** is selected, users must provide the **KMS Key ID** retrieved from the AWS portal
  - When selecting the **SSE-C** encryption type, users should ensure they have provided the SSE-C key while creating the data protection agent
  - Users may optionally enter the **Server-Side Encryption Algorithm**

> Note: If Server Side Encryption is not enabled, default cloud encryption will be applied to the agent

- Click **SAVE** to create the location for control plane backup to S3 bucket

[![Configure Location](https://docs.rafay.co/backup/img/Configure-BackupLocation-awsS3-Cluster.png)](https://docs.rafay.co/backup/img/Configure-BackupLocation-awsS3-Cluster.png)

---

## Persistent Volumes

- Go back to Backup/Restore > Locations menu to add **New Location**
- Provide the location name, and an optional description
- Select Type **Volume Backup** and click **CREATE**

[![Add Location](https://docs.rafay.co/backup/img/Create-aws-Backup-Location-PV.png)](https://docs.rafay.co/backup/img/Create-aws-Backup-Location-PV.png)

- In the location settings page, under Config section, select Target Type as **Amazon**
- Enter the **Region name** and click **SAVE** to create the location for persistent volume backup to S3 bucket

[![Configure Location](https://docs.rafay.co/backup/img/Configure-Backup-Location-awsS3-PV.png)](https://docs.rafay.co/backup/img/Configure-Backup-Location-awsS3-PV.png)

---

## Actions

To edit/delete a location, use the respective icons

[![Delete Data Agent](https://docs.rafay.co/backup/img/edit_delete.png)](https://docs.rafay.co/backup/img/edit_delete.png)

---
