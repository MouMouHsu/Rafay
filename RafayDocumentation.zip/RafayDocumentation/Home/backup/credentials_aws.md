---
title: "KOP Backup - AWS S3"
source: https://docs.rafay.co/backup/credentials_aws/
category: Home
---

# Credentials

Follow the steps described below to create a AWS S3 Cloud credential

## Configure IAM Policy

### IAM policy for just the Control Plane backup

This policy will be attached to the IAM user or role and will be used for cluster backup

- In your AWS console, create an **IAM policy** using the JSON provided below
- Ensure that you update the bucket name to your S3 bucket name

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:DeleteObject",
                "s3:PutObject",
                "s3:AbortMultipartUpload",
                "s3:ListMultipartUploadParts"
            ],
            "Resource": [
                "arn:aws:s3:::<bucket_name>/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::<bucket_name>"
            ]
        }
    ]
}
```

### IAM policy for both Control Plane backup and Volume Snapshots

This policy will be attached to the IAM user or role and will be used for cluster backup and volume snapshots.

- In your AWS console, create an **IAM policy** using the JSON provided below
- Ensure that you update the bucket name to your S3 bucket name

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ec2:DescribeVolumes",
                "ec2:DescribeSnapshots",
                "ec2:CreateTags",
                "ec2:CreateVolume",
                "ec2:CreateSnapshot",
                "ec2:DeleteSnapshot"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:DeleteObject",
                "s3:PutObject",
                "s3:AbortMultipartUpload",
                "s3:ListMultipartUploadParts"
            ],
            "Resource": [
                "arn:aws:s3:::<bucket_name>/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::<bucket_name>"
            ]
        }
    ]
}
```

---

## Access Key

- In your AWS console, navigate to **IAM service** and create an IAM user with only programmatic access
- Attach the IAM policy above to the IAM user. This will grant the user permission to access the S3 bucket for cluster data backup
- Download the **CSV** containing the **Access Key ID** and **Secret Access Key**

> **Important**
> For security reasons, this information is not accessible later in AWS. Ensure that you do not skip this step because we will require this information when we create a Cloud Credential in the Console

- On the controller, in the web console, navigate to **Infrastructure -> Cloud Credentials**
- Click **New Credential**, provide a name and select **Data Backup** for Type
- Select Provider **AWS** and Credential Type **ACCESS_KEY**
- Enter **Access Key ID** and **Secret Key** created in AWS above
- Click **SAVE** to create the AWS Access Key credential to access your S3 bucket for cluster data backup

[![Add Credentials](https://docs.rafay.co/backup/img/Cluster-Backup-AWS-AccessKey-Credential.png)](https://docs.rafay.co/backup/img/Cluster-Backup-AWS-AccessKey-Credential.png)

---

## Data Backup/Restore using IRSA

Create a "Cloud Credential" which will be configured to use an IAM role for the Controller in your AWS account. Once created, you can reuse the cloud credential to provision as many clusters as necessary

To configure an AWS IAM role, you will need the Controller's "AWS Account ID" and a "Unique External ID". You will also have to provide the Role ARN (Amazon Resource Name) for the AWS IAM Role before saving the Cloud Credential

**Create Cloud Credential**

- Login to the Console and select "Cloud Credentials" under Infrastructure
- Click **New Credential** and provide a unique name
- Select the Type **Data Backup** and Credential Type **Role**
- Copy/Paste the Role ARN from the AWS Console

Refer [Data Backup and Restore using IRSA](https://docs.rafay.co/backup/IRSA_databackup_restore/) for AWS Credential setting

- Click **Save**

[![View Cloud Credential](https://docs.rafay.co/backup/img/backup_arnrole.png)](https://docs.rafay.co/backup/img/backup_arnrole.png)

---
