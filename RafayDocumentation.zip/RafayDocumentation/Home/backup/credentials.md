---
title: "KOP Backup - Credentials"
source: https://docs.rafay.co/backup/credentials/
category: Home
---

# Overview

Credentials are required to access the backup location and perform backup/restore operations. Refer to the below table for more details on each provider credentials

| S. No | Provider | Reference |
| --- | --- | --- |
| 1 | AWS | [AWS S3 Credentials](https://docs.rafay.co/backup/credentials_aws/) |
| 2 | MINIO | [S3 Compatible Credentials](https://docs.rafay.co/backup/credentials_s3/) |
| 3 | AZURE | [Azure Credentials](https://docs.rafay.co/backup/credentials_azure/) |

---
