---
title: "KOP Backup - Backup Location"
source: https://docs.rafay.co/backup/locations/
category: Home
---

# Overview

In order to perform backup or restore your cluster, you need to first define a location to store the backup snapshots. The backup locations can be an **AWS S3** bucket, (or) any **S3 Compatible Storage** like [MinIO](https://min.io/) (or) **Azure Blob Storage**. Refer to the below table for more details on creating locations on different storages

| S. No | Storage | Reference |
| --- | --- | --- |
| 1 | AWS S3 Bucket | [AWS S3 Bucket](https://docs.rafay.co/backup/aws_location/) |
| 2 | AZURE Blob Storage | [Azure Blob Storage](https://docs.rafay.co/backup/azure_location/) |
| 3 | S3 Compatible Storage | [S3 Compatible Storage](https://docs.rafay.co/backup/s3_location/) |

---
