---
title: "KOP Backup - Azure"
source: https://docs.rafay.co/backup/credentials_azure/
category: Home
---

# Azure

Follow the steps described below to create a Azure Cloud credential

## For Azure Compatible Storage

To add Azure Credential, user must create a **Service Principal** with **Contributor** role in the Azure portal. Refer [Azure Service Setup](https://docs.rafay.co/clusters/aks/azure_setup/) to know how to create the contributor role and retrieve the required data

- Navigate to **Infrastructure -> Cloud Credentials** in the Controller
- Click **New Credential** and provide a name
- Select Type **Data Backup** and Provider **AZURE**
- Enter **Tenant ID**, **Subscription ID**, **Client ID** and **Client Secret**
- Click **SAVE** to create the cloud credential to access the bucket for your cluster data backup

[![Add Credentials](https://docs.rafay.co/backup/img/backup-azure-AccessKey-Credential.png)](https://docs.rafay.co/backup/img/backup-azure-AccessKey-Credential.png)

---
