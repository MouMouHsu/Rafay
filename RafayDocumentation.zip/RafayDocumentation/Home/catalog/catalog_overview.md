---
title: "Helm App Catalog"
source: https://docs.rafay.co/catalog/catalog_overview/
category: Home
---

# Overview

Catalog is a collection of applications that a user can deploy to Kubernetes clusters as a workload template, a workload, or as a blueprint add-on. During the workload template/workload/add-on creation, users can choose from apps in a Catalog and add values.yaml files to the workload template/workload/add-on to override default values.

---

## Catalog Access

In the console, navigate to your project in your Org and click **Catalog**

[![Provide Artifact](https://docs.rafay.co/catalog/img/catalog-options.png)](https://docs.rafay.co/catalog/img/catalog-options.png)

- Users can view the list of apps available in different category of catalog
- Select the required category from the **Filter by Category** drop-down (example: CMS, CRM, E-Learning, Forum, etc.)
- Select the required catalog from the **Filter by Catalog** drop-down. System catalogs (default-bitnami and default-helm) and the custom catalogs (repos created by users) are listed over here
- Select the required app from a catalog. Below is an example of **mongodb-sharded** app from **Database** category   [![Provide Artifact](https://docs.rafay.co/catalog/img/catalog-read-me.png)](https://docs.rafay.co/catalog/img/catalog-read-me.png)   [![Provide Artifact](https://docs.rafay.co/catalog/img/app_versions.png)](https://docs.rafay.co/catalog/img/app_versions.png)   [![Provide Artifact](https://docs.rafay.co/catalog/img/apps_yaml.png)](https://docs.rafay.co/catalog/img/apps_yaml.png)
  - **Readme** tab appears by default with the details on the helm chart, prerequisites, install/uninstall procedure, configuration, and upgrade
  - Click **Versions** tab to view the list of versions available for the selected app helm chart and the release date. Users can select any version
  - Click **Values Yaml** tab to view/copy/download the yaml file. This value file helps to override the default values of the helm chart during the creation of workload/addon

---

## Create Workload Template

On successful selection of app and version, user can create a new workload template

- Click **Create Workload Template**. New Workload Template screen appears
- Enter a **Name** for the new template
- The other details are populated based on the selection

[![Provide Artifact](https://docs.rafay.co/catalog/img/create_workload_template.png)](https://docs.rafay.co/catalog/img/create_workload_template.png)

- Click **Continue** to proceed with the workload template creation. You will be directed to the **Workload Templates -> Repository** page as shown below

[![Provide Artifact](https://docs.rafay.co/catalog/img/workload-template-details.png)](https://docs.rafay.co/catalog/img/workload-template-details.png)

Refer [Workload Template](https://docs.rafay.co/gitops/stages/workload_template/) to complete the template creation process

---

## Create Workload

On successful selection of app and version, user can create a new workload

- Click **Create Workload**. New Workload screen appears
- Enter the **Workload Name** and select the required **Namespace**
- The other details are populated based on the selection

[![Provide Artifact](https://docs.rafay.co/catalog/img/create-workloads.png)](https://docs.rafay.co/catalog/img/create-workloads.png)

- Click **Continue** to proceed with the workload creation. You will be directed to the **Workload -> Respository** page as shown below

[![Provide Artifact](https://docs.rafay.co/catalog/img/workload_details.png)](https://docs.rafay.co/catalog/img/workload_details.png)

Refer [Workload- Mutiple Value Files](https://docs.rafay.co/workloads/helm_charts/) to complete the template creation process

---

## Create Add-On

To create an add-on, perform the below steps:

- Click **Create Add-On**. Create Add-On screen appears
- Enter a **Name** and select the required **Namespace**
- The other details are populated based on the selection

[![Provide Artifact](https://docs.rafay.co/catalog/img/create_addon.png)](https://docs.rafay.co/catalog/img/create_addon.png)

- Click **Create** to proceed with the add-on creation. You will be directed to the **Add-Ons -> New Version** page as shown below
- Enter a version and change the version if required
- Optionally, upload the **Value File(s)** or select **Override from git repository** and provide the repository details
- Click **Save Changes**

[![Provide Artifact](https://docs.rafay.co/catalog/img/addon_page.png)](https://docs.rafay.co/catalog/img/addon_page.png)

Refer [Add-Ons New Version](https://docs.rafay.co/blueprints/addons/) to complete the template creation process

---
