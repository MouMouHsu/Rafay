---
title: "KOP Blueprints - Manage Catalogs"
source: https://docs.rafay.co/catalog/manage_catalog/
category: Home
---

# Manage Catalogs

There are two types of Catalogs that are available to the user:

- **Custom Catalogs:** Allows users to create custom catalogs within a project and selectively add applications as required
- **System Catalogs:** Includes a curated list of applications available by default in the system

## Custom Catalogs

Custom Catalogs can be used to:

- Add applications on top of what is already available with System Catalogs
- Control the available list of applications (and versions) to deploy as an add-on or a workload. It is possible to standardize Custom Catalogs by creating them centrally and sharing them across projects. Custom Catalogs can reference and sync from any public or private helm repositories

Perform the below steps to create **Custom Catalogs**

- Create a **Repository**, instructions to create a new repository can be found [here](https://docs.rafay.co/integrations/repositories/manage_repos/), this can point to any public or private Helm repository

> **Note**
> If no agent is specified for an internet-accessible endpoint, the controller’s hosted agents will be used (not recommended for production). For production environments, it is recommended to configure agents while considering factors such as rate limits enforced by registries like Docker Hub.

- Click **Manage Catalogs** from the Browse Catalog Apps page

[![Provide Artifact](https://docs.rafay.co/catalog/img/manage_catalog_button.png)](https://docs.rafay.co/catalog/img/manage_catalog_button.png)

- Custom Catalogs page appears by default showing the list of catalogs created by the users
- Click **New Catalog** from the Custom Catalog page
- Enter a name for the new catalog and select a **Repository** from the drop-down
- Enabling **Auto Sync Catalog** automatically refreshes the catalog page on any updates to the repository
- Optionally, add one or more Helm charts, and click **Create**

> Note:
> 
> 
> If the OCI Helm Repository endpoint includes only the host (oci://c8n.io), catalogs can add charts with namespace paths if applicable, such as demouser1/airflow or demouser2/nginx.
> 
> 
> If the  OCI Helm Repository endpoint includes the host along with the namespace** (e.g., oci://c8n.io/demouser1), users can specify any charts available under that namespace, such as airflow or nginx.
> 
> 
> Charts are optional if the repository credentials have access to list the repositories for the given domain. For more information, refer to OCI Helm Repository Creation

[![Provide Artifact](https://docs.rafay.co/catalog/img/create_catalog.png)](https://docs.rafay.co/catalog/img/create_catalog.png)

- On creation of the Custom Catalog, a sync can be initiated manually

[![Provide Artifact](https://docs.rafay.co/catalog/img/manual-sync.png)](https://docs.rafay.co/catalog/img/manual-sync.png)

- View the list of custom catalogs in the Manage Catalogs page

[![Provide Artifact](https://docs.rafay.co/catalog/img/view_catalogs.png)](https://docs.rafay.co/catalog/img/view_catalogs.png)

- Use **Manage Sharing** icon to share the catalogs with one or more project(s)
- Click **Sync Catalog** icon to sync from the selected repository
- Use **Delete** icon to delete the custom catalogs

[![Provide Artifact](https://docs.rafay.co/catalog/img/catalog_options.png)](https://docs.rafay.co/catalog/img/catalog_options.png)

---

## System Catalogs

**System Catalogs** page shows the available default catalogs, clicking on a particular system catalog shows the list of available applications

[![Provide Artifact](https://docs.rafay.co/catalog/img/system_catalog_list.png)](https://docs.rafay.co/catalog/img/system_catalog_list.png)

> **Important**
> Users cannot **edit** or **delete** the **System Catalogs**

It is possible to disable one or more of the System Catalogs. The applications included in those System Catalogs will be unavailable across all projects.

- Click on Home -> SYSTEM and select Settings from the drop-down menu
- In the Catalog Setting section, disable System Catalogs as appropriate

[![Provide Artifact](https://docs.rafay.co/catalog/img/org_catalog_setting.png)](https://docs.rafay.co/catalog/img/org_catalog_setting.png)

---
