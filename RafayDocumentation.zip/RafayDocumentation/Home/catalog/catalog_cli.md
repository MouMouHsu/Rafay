---
title: "Catalog - CLI"
source: https://docs.rafay.co/catalog/catalog_cli/
category: Home
---

# Catalog

Users can use RCTL to create custom catalogs and automate the creation of Add-On and Workload from Catalog.

---

## Create/Update Custom Catalog

Users can create/update a custom catalog using a YAML spec that you can store in a Git repository.

The below rctl command is to create/update a custom catalog

```
./rctl apply -f catalog_file.yml
```

An illustrative example of the custom catalog YAML file is shown below. Remove the highlighted (yellow) parameters to not share the catalog with other project(s)

```
apiVersion: apps.k8smgmt.io/v3
kind: Catalog
metadata:
  name: demo-catalog
  project: defaultproject
spec:
  autoSync: true
  repository: demorepo
  type: HelmRepository
  sharing:
    enabled: true
    projects:
    - name: project1
```

---

## Create/Update Workload Template from Catalog

Users can create/update a workload template from catalog using a YAML spec that you can store in a Git repository.

The below rctl command is to create/update a Workload Template from Catalog

```
./rctl apply -f workloadtemplate_filename.yaml --v3
```

An illustrative example of the workload template spec YAML file is shown below

```
apiVersion: apps.k8smgmt.io/v3
kind: WorkloadTemplate
metadata:
  name: wl-temp-cat
  project: defaultproject
spec:
  artifact:
    artifact:
      chartName: nginx
      chartVersion: 10.2.1
      catalog: default-bitnami
      valuesPaths:
        - name: file://nginx-values.yaml
    options:
      maxHistory: 10
      timeout: 5m0s
    type: Helm
```

---

## Create/Update Workload Template from Repository

Users can create or update a workload template sourced directly from a Helm or Git repository

Use the below `rctl` command:

```
./rctl apply -f workloadtemplate_repo.yaml --v3
```

An illustrative example of the YAML spec is shown below:

```
apiVersion: apps.k8smgmt.io/v3
kind: WorkloadTemplate
metadata:
  name: test-template
  project: defaultproject
spec:
  artifact:
    artifact:
      chartName: <chart-name>
      chartVersion: <chart-version>
      repository: <repository-name>
      valuesRef:
        repository: <value-file-git-repository-name>
        revision: <git-revision>
        valuesPaths: <value-file-relative-path>
        - name: <>
    type: Helm
```

---

## Create/Update Add-On from Catalog

Users can create/update an add-on from catalog using a YAML spec that you can store in a Git repository.

The below rctl command is to create/update an Add-On from Catalog

```
./rctl apply -f catalog-addon_filename.yaml --v3
```

An illustrative example of the add-on spec YAML file is shown below

```
apiVersion: infra.k8smgmt.io/v3
kind: Addon
metadata:
  name: addon-number5-rctlv3
  project: demo-project
spec:
  artifact:
    artifact:
      catalog: default-bitnami
      chartName: apache
      chartVersion: 9.1.0
      valuesPaths:
      - name: file://apache-values.yaml
    options:
      maxHistory: 1
      timeout: 1m0s
    type: Helm
  namespace: fleet-ns1
  sharing:
    enabled: false
  version: v1
```

---

## Create/Update Workload from Catalog

Users can create/update a workload from catalog using a YAML spec that you can store in a Git repository.

The below rctl command is to create/update an Workload from Catalog

```
./rctl apply -f catalog-workload_filename.yaml --v3
```

An illustrative example of the workload spec YAML file is shown below

```
apiVersion: apps.k8smgmt.io/v3
kind: Workload
metadata:
  name: workload-rctlv3-1
  project: demo_project
spec:
  artifact:
    artifact:
      catalog: default-bitnami
      chartName: nats
      chartVersion: 7.1.0
      valuesPaths:
      - name: file://nats-values.yaml
    options:
      maxHistory: 2
      timeout: 1m0s
    type: Helm
  drift:
    enabled: false
  namespace: teststage
  placement:
    selector: rafay.dev/clusterName=aks-stage114x-1
  version: workload-rctlv3-1-v1
```

---

## List Catalog

Use the below command to retrieve the list of catalogs. The name of the addons, the type of payload and publish status are returned. An illustrative example is shown below where RCTL retrieves the list of catalogs

```
./rctl get catalog
+-------------------+----------------+------------------------+-----------+
| CATALOG NAME      | CATALOG TYPE   | REPOSITORY             | AUTO SYNC |
+-------------------+----------------+------------------------+-----------+
| nexus             | HelmRepository | nexus-repo             | true      |
+-------------------+----------------+------------------------+-----------+
| nexus-private     | HelmRepository | nexus-private-repo     | true      |
+-------------------+----------------+------------------------+-----------+
| nexus-rctl5       | HelmRepository | nexus-repo             | true      |
+-------------------+----------------+------------------------+-----------+
| nexus-rctl6       | HelmRepository | nexus-repo             | true      |
+-------------------+----------------+------------------------+-----------+
```

---

## Get Specific Catalog Info

To get a specific catalog details, apply the below command with the catalog name

```
./rctl get catalog nexus-private
+-------------------+----------------+------------------------+-----------+
| CATALOG NAME      | CATALOG TYPE   | REPOSITORY             | AUTO SYNC |
+-------------------+----------------+------------------------+-----------+
| nexus-private     | HelmRepository | nexus-private-repo | true      |
+-------------------+----------------+------------------------+-----------+
```

Or you can use below command to get more information of the catalog in json or yaml format

```
./rctl get catalog <catalog-name> -o json
```

```
./rctl get catalog <catalog-name> -o yaml
```

***Example:***

```
./rctl get catalog nexus -o yaml
apiversion: apps.k8smgmt.io/v3
kind: Catalog
metadata:
  name: nexus
  description: ""
  labels: {}
  annotations: {}
  project: defaultproject
  id: ""
  modifiedat: null
  projectid: ""
spec:
  type: HelmRepository
  iconurl: ""
  repository: nexus-repo
  autosync: true
  sharing:
    enabled: true
    projects:
    - name: '*'
      id: ""
status:
  conditiontype: CatalogSync
  conditionstatus: 2
  lastupdated:
    seconds: 1673256010
    nanos: 772816026
  reason: catalog synced
  extra: null
```

---

## Delete Catalog

Use the below command to delete a catalog

```
./rctl delete catalog <catalog-name>
```

---
