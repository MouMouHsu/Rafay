---
title: "Rafay - Official Documentation"
source: https://docs.rafay.co/intro/icons/
category: Home
---

# Icons

Download our official icons for our services and capabilities.

| Service/Capability | Official Image/Icon |
| --- | --- |
| Backup | [![Download Icon](https://docs.rafay.co/intro/img/logos/backup.svg)](https://docs.rafay.co/intro/img/logos/backup.svg) |
| Blueprints | [![Download Icon](https://docs.rafay.co/intro/img/logos/blueprints.svg)](https://docs.rafay.co/intro/img/logos/blueprints.svg) |
| Catalog | [![Download Icon](https://docs.rafay.co/intro/img/logos/catalog.svg)](https://docs.rafay.co/intro/img/logos/catalog.svg) |
| Cost | [![Download Icon](https://docs.rafay.co/intro/img/logos/cost.svg)](https://docs.rafay.co/intro/img/logos/cost.svg) |
| GitOps | [![Download Icon](https://docs.rafay.co/intro/img/logos/gitops.svg)](https://docs.rafay.co/intro/img/logos/gitops.svg) |
| Policy Management | [![Download Icon](https://docs.rafay.co/intro/img/logos/k8s-policy.svg)](https://docs.rafay.co/intro/img/logos/k8s-policy.svg) |
| Multi Cluster Mgmt | [![Download Icon](https://docs.rafay.co/intro/img/logos/mcm.svg)](https://docs.rafay.co/intro/img/logos/mcm.svg) |
| Network Policy | [![Download Icon](https://docs.rafay.co/intro/img/logos/network-policy.svg)](https://docs.rafay.co/intro/img/logos/network-policy.svg) |
| Service Mesh | [![Download Icon](https://docs.rafay.co/intro/img/logos/service-mesh.svg)](https://docs.rafay.co/intro/img/logos/service-mesh.svg) |
| Visibility | [![Download Icon](https://docs.rafay.co/intro/img/logos/visibility.svg)](https://docs.rafay.co/intro/img/logos/visibility.svg) |
| Zero Trust | [![Download Icon](https://docs.rafay.co/intro/img/logos/zero-trust.svg)](https://docs.rafay.co/intro/img/logos/zero-trust.svg) |

---
