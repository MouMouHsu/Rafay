---
title: "KOP Intro - Architecture"
source: https://docs.rafay.co/intro/architecture/
category: Home
---

# Architecture

The platform has been specifically designed such that customers can deploy and manage their Kubernetes clusters in both cloud and on-premise environments. The Platform has two primary components that are described below.

[![System Architecture](https://docs.rafay.co/intro/img/controller/system_architecture.png)](https://docs.rafay.co/intro/img/controller/system_architecture.png)

**Critical Points to Consider:**

1. No inbound ports need to be opened at the customer network's firewall (only port 443 outbound to Rafay's SaaS Controller required)
2. Users can optionally [whitelist](https://docs.rafay.co/security/whitelist/) Rafay's SaaS Controller's IP addresses
3. Users can optionally configure the Rafay operator to use their network proxy to access the SaaS Controller

> **Note**
> Users that cannot use Rafay's SaaS form factor due to regulatory requirements can [**self host**](https://docs.rafay.co/selfhosted/overview/) the controller software on their network.

---

## Key Components

### Rafay Controller

The Rafay Controller is a **management** platform that customers use to manage their environments, Kubernetes clusters and their containerized applications. A separate interface is available for the Platform admins and application developers to ensure that there is clear separation of duties. The controller can be accessed via multiple interfaces

- Web console,
- RCTL CLI utility,
- GitOps w/Write Back to Git,
- REST APIs and
- Rafay's Terraform/OpenTofu provider.

[![Multi Cluster Management](https://docs.rafay.co/intro/img/controller/mcm.png)](https://docs.rafay.co/intro/img/controller/mcm.png)

### Management Operator/Agent

The management operator (aka agent) is deployed by the customer inside their network. The operator is typically deployed into a Kubernetes cluster and is deployed to a dedicated namespace ("rafay-system"). The Rafay operator establishes a mutually authenticated, zero-trust gRPC connection over TLS with the Rafay Controller over TCP port 443. This gRPC connection is used by the operator to pull configuration instructions and configurations from the controller for carrying out Kubernetes lifecycle management operations locally on the cluster. Role-Based Access Control (RBAC) mechanisms regulate what can be performed on clusters on behalf of a user via the Rafay Controller. A detailed audit trail provides visibility into what was performed when.

> **Important**
> No inbound ports need to be opened at the customer's firewall. Only outbound on port 443 to the Controller is required.

---

## Accessing the Controller

The Controller can be accessed via

- Using a web browser (via the Web Console) or
- Programmatically using the RCTL CLI or
- Programmatically via REST APIs or
- A Terraform provider

[![Access Methods](https://docs.rafay.co/intro/img/controller/controller_access_methods.png)](https://docs.rafay.co/intro/img/controller/controller_access_methods.png)

---

## Deployment Options

Three deployment options are supported for the Controller:

1. SaaS (Multi Tenant, Managed)
2. Self Hosted (Managed, Single/Multi Tenant)
3. Self Hosted (Customer Managed, Single/Multi Tenant)

[![Controller Deployment Options](https://docs.rafay.co/intro/img/controller/controller_deployment_models.png)](https://docs.rafay.co/intro/img/controller/controller_deployment_models.png)

---
