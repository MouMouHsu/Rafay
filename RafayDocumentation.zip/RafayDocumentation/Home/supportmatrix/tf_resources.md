---
title: "Terraform Support Matrix"
source: https://docs.rafay.co/supportmatrix/tf_resources/
category: Home
---

# Terraform

| Resource | TF Provider Support | Is Import supported for the resource |
| --- | --- | --- |
| Access API Key | Yes | No |
| Add-on | Yes | Yes |
| AKS Cluster | Yes | Yes |
| Alert Configuration | Yes | No |
| Backup & Restore | No | No |
| Baremetal/VM Cluster (MKS) | No | No |
| Blueprint | Yes | Yes |
| Break Glass Access | Yes | No |
| Catalog | Yes | No |
| Chargeback Group Config | Yes | No |
| Chargeback Group Report | Yes | No |
| Chargeback Share Costs | Yes | No |
| Cloud Credentials | Yes | Yes |
| Cluster Network Policy | Yes | No |
| Cluster Network Policy Rule | Yes | No |
| Cluster Override | Yes | Yes |
| Cluster Sharing | Yes | No |
| Cluster Sharing (Single) | Yes | No |
| Config Context | Yes | Yes |
| Container Registry | Yes | No |
| Cost Profile | Yes | No |
| Custom Role | Yes | Yes |
| Download Kubeconfig | Yes | No |
| Driver | Yes | Yes |
| EKS Cluster | Yes | Yes |
| Environment | Yes | Yes |
| Environment Template | Yes | Yes |
| Fleet Plan | Yes | No |
| GKE Cluster | Yes | Yes |
| Group | Yes | Yes |
| GitOps Agent | Yes | No |
| Group Association | Yes | Yes |
| Import Cluster | Yes | No |
| Namespace | Yes | Yes |
| Namespace Network Policy | Yes | No |
| Namespace Network Policy Rule | Yes | No |
| Network Policy Profile | Yes | No |
| OPA Constraint | Yes | Yes |
| OPA Constraint Template | Yes | Yes |
| OPA Installation Profile | Yes | Yes |
| OPA Policy | Yes | Yes |
| Org Alert Config | Yes | No |
| Pipeline | Yes | Yes |
| Project | Yes | Yes |
| Project Tags Association | Yes | No |
| Repositories | Yes | No |
| Resource Template | Yes | Yes |
| Secret Group | Yes | No |
| Secret Provider | Yes | No |
| Secret Sealer | Yes | No |
| Static Resources | Yes | Yes |
| Tag Group | Yes | No |
| User | Yes | Yes |
| Workflow Handler | Yes | Yes |
| Workload Template | Yes | No |
| Workload | Yes | No |
| Workload CD Operator | Yes | No |
| ZTKA Policy | Yes | Yes |
| ZTKA Rule | Yes | Yes |

---

> **Related Resource: Cluster Sharing**
> For detailed guidance on how to configure and manage cluster sharing using the Rafay Terraform Provider, see: [Cluster Sharing Best Practices](https://docs.rafay.co/automation/tf/cluster_sharing/)

> **Important: Provider Limitations for EKS Cluster Import**
> When you import the existing EKS Cluster resource and use the **terraform show** command to generate the Terraform (TF) file, you may notice extra fields with Boolean values. To prevent errors, compare the generated TF file to your cluster configuration file and remove any unnecessary fields. If you fail to do so, you may see "undiffable" field errors when applying the TF file.

Below is the Terraform Provider Registry link for documentation and provider download:

[Terraform Provider Registry](https://registry.terraform.io/providers/RafaySystems/rafay/latest/docs)
