---
title: "Support Matrix"
source: https://docs.rafay.co/supportmatrix/support_matrix/
category: Home
---

# General

The following tables summarizes requirements and support policy for various features/capabilities offered by the platform.

---

## Supported K8s versions by providers

| Provider | Cluster Lifecycle | Imported |
| --- | --- | --- |
| Amazon EKS | [Supported versions](https://docs.rafay.co/clusters/eks/environments/) | Versions supported by the provider |
| Azure AKS | [Supported versions](https://docs.rafay.co/clusters/aks/environments/) | Versions supported by the provider |
| Google GKE | [Supported versions](https://docs.rafay.co/clusters/gke/environments/) | Versions supported by the provider |
| Upstream Kubernetes (MKS) on Bare Metal and VMs | [Supported versions](https://docs.rafay.co/clusters/upstream/baremetal_vm/environments/) | N/A |

---

## Recommended: Default CNI Support via System Blueprints (MKS)

Rafay now supports adding CNI plugins either via **default system blueprints** or through **custom configurations** (BYO-CNI) in **MKS clusters**. The following CNIs and their versions are currently supported through system default blueprints:

| Blueprint Name | CNI Plugin(s) and Version(s) |
| --- | --- |
| default-upstream-calico | Calico v3.29.0 |
| default-upstream-cilium | Cilium v1.16.4 |
| default-upstream-kubeovn | Kube-OVN v1.13.0 |
| default-upstream-kubeovn-chaining | Kube-OVN v1.13.0, Cilium v1.16.4 |

> Recommended: Use these default system blueprints to leverage the latest CNI versions and simplify lifecycle management of cluster networking.

> **Info**
> For more details on default CNI blueprints, see [Default CNI Blueprints](https://docs.rafay.co/blueprints/default_cni/#default-cni-blueprints-for-deploying-mks-clusters)

---

## Supported Network Plugins by Cluster Type

| Cluster Type | Network Plugin(s) | Customization Allowed |
| --- | --- | --- |
| MKS | Cilium 1.15.7, Cilium 1.14.1, Calico 3.28.1, Calico 3.26.1, Canal-Calico-3.24.5-Flannel-0.15.1, Kube-OVN | Calico, Cilium, Kube-OVN |
| EKS | aws-cni, Calico 3.24.5, Cilium | Calico, Cilium |
| AKS | **Kubenet**: Network Policy — None, Calico **Azure CNI**: Network Policy — None, Calico, Azure **Azure CNI Overlay**: Network Policy — None, Calico, Azure **BYOCNI**: Cilium (as primary CNI) | Cilium (via BYOCNI) |
| GKE | GCP Networking Stack | - |

---

## MKS Version Matrix

### Kubernetes Version Support Matrix

| Kubernetes Version | Status | Platform Version | Notes |
| --- | --- | --- | --- |
| 1.36 | Supported | 1.3.0 | Latest minor version; requires platform 1.3.0 |
| 1.35 | Supported | 1.2.0 | Minimum platform 1.2.0 |
| 1.34.3 | Supported | 1.2.0 | Latest active patch for Kubernetes 1.34 |
| 1.33.7 | Supported | 1.2.0 | Latest active patch for Kubernetes 1.33 |
| 1.32.11 | Supported | 1.2.0 | EOL 28 Feb 2026 |
| 1.34.1 | Deprecated | 1.2.0 | Migration only |
| 1.33.5 | Deprecated | 1.2.0 | Migration only |
| 1.32.9 | Deprecated | 1.2.0 | Migration only |

> **Note**
> Platform version **1.3.0** is the latest and the **default for new cluster creation** (CRI **2.3.0**). Use the latest active Kubernetes patch for each minor version. Kubernetes 1.32.x reaches upstream end of life on 28 Feb 2026.

### MKS Platform Version Status

| Platform Version | Status | Notes |
| --- | --- | --- |
| 1.3.0 | Latest (default) | Default for new cluster creation; required for Kubernetes 1.36; includes CRI 2.3.0 (minimum containerd for Kubernetes 1.36) |
| 1.2.0 | Active | Required for Kubernetes 1.35 and default patches 1.35.4, 1.34.7, 1.33.11 |
| 1.1.0 | Deprecated | Migration only; enable `Show deprecated platform versions` |
| 1.0.0 | Deprecated | Migration only |
| 0.1.0 | Deprecated | Reference for pre-versioning clusters; upgrade to 1.2.0 |

### Platform component versions

| Component | 1.3.0 (latest) | 1.2.0 | 1.1.0 (deprecated) |
| --- | --- | --- | --- |
| CRI | 2.3.0 | 2.0.4 | 2.0.4 |
| etcd | 3.5.24 | 3.5.24 | 3.5.21 |
| Cluster Utils | 2.0.0 | 2.0.0 | 2.0.0 |
| Orchestration Agent | 3006.12 | 3006.12 | 3006.12 |
| Orchestration Proxy | 1.10.1 | 1.10.1 | 1.10.1 |

Platform 1.3.0 is the latest and default for new clusters; it includes CRI 2.3.0 (minimum containerd for Kubernetes 1.36). Platform 1.2.0 includes etcd 3.5.24 (minimum for Kubernetes 1.35+).

---

## Supported EKS managed add-ons corresponding to Kubernetes version

| Managed Addon | K8s version | Addon Version |
| --- | --- | --- |
| Kube-proxy | 1.32 | v1.32.0-eksbuild.2 |
|  | 1.31 | v1.31.2-eksbuild.3 |
|  | 1.30 | v1.30.3-eksbuild.5 |
|  | 1.29 | v1.29.7-eksbuild.5 |
|  | 1.28 | v1.28.4-eksbuild.4 |
|  | 1.27 | v1.27.8-eksbuild.4 |
|  | 1.26 | v1.26.11-eksbuild.4 |
|  | 1.25 | v1.25.16-eksbuild.2 |
|  | 1.24 | v1.24.17-eksbuild.8 |
|  | 1.23 | v1.23.17-eksbuild.9 |
| CoreDNS | 1.32 | v1.11.4-eksbuild.2 |
|  | 1.31 | v1.11.3-eksbuild.1 |
|  | 1.30 | v1.11.3-eksbuild.1 |
|  | 1.29 | v1.11.3-eksbuild.1 |
|  | 1.28 | v1.10.1-eksbuild.7 |
|  | 1.27 | v1.10.1-eksbuild.7 |
|  | 1.26 | v1.9.3-eksbuild.11 |
|  | 1.25 | v1.9.3-eksbuild.11 |
|  | 1.24 | v1.9.3-eksbuild.11 |
|  | 1.23 | v1.8.7-eksbuild.10 |
| VPC CNI | 1.32 | v1.19.2-eksbuild.1 |
|  | 1.31 | v1.19.0-eksbuild.1 |
|  | 1.30 | v1.18.3-eksbuild.3 |
|  | 1.29 | v1.16.2-eksbuild.1 |
|  | 1.28 | v1.16.2-eksbuild.1 |
|  | 1.27 | v1.16.2-eksbuild.1 |
|  | 1.26 | v1.16.2-eksbuild.1 |
|  | 1.25 | v1.16.2-eksbuild.1 |
|  | 1.24 | v1.16.2-eksbuild.1 |
|  | 1.23 | v1.16.2-eksbuild.1 |

---

## Provider support for Environment Manager

### Certified OpenTofu versions

- 1.6.2
- 1.7.2
- 1.8.0

---

## Identity Providers for SSO

### Certified IDPs

- Okta
- PingOne
- Entra ID
- Duo SSO
- ADFS (Active Directory Federation Services)
- Authentik
- AWS SSO
- Google Workspace
- KeyCloak

> **Note**
> Any SAML 2.0 based IDP provider is supported. For more details, refer [here](https://docs.rafay.co/integrations/sso/overview/)

---

## GitOps Pipeline Triggers

### Supported providers for Webhook based triggers

- Github
- Gitlab
- BitBucket
- Azure Repos

> **Note**
> Cron Job based triggers can be leveraged for any Git compatible provider that is not in the list above. For more details, refer [here](https://docs.rafay.co/gitops/triggers/)

---

## Managed System Add-ons & Services

| Managed System Add-ons & Services | OSS Component(s) | Supported Distros |
| --- | --- | --- |
| Managed Storage | Rook-Ceph | Upstream k8s |
| Ingress Controller (Deprecated) | Ingress NGINX | All |
| Monitoring & Alerting | Prometheus | All |
|  | Metrics Server | All |
|  | Alert Manager | All |
| Secrets Store CSI Driver | Secret Store CSI driver + AWS Secrets Manager provider specific plugin | Amazon EKS |
| Policy Management | OPA Gatekeeper | All |
| Backup & Restore | Velero | All |
| Network Policy | Cilium | Refer [here](https://docs.rafay.co/network_policy/overview/) for more details |
| Cost Management | OpenCost | All |
| Local Storage | OpenEBS | Upstream K8s |

---

## Resources Character Limits

The table below provides the maximum allowed character limits for various resources:

| Resource | Resource Type | Maximum Length |
| --- | --- | --- |
| Addon |  | 63 |
| Cluster | EKS | 63 |
|  | AKS | 30 |
|  | GKE | 30 |
|  | Upstream | 30 |
|  | Imported | 30 |
| Cluster Override |  | 253 |
| Namespace |  | 45 |
| Project |  | 256 |
| Workload |  | 63 |

> Note: Alphanumeric characters (a-z, 0-9) and hyphen are allowed, with the exception that hyphen cannot be placed at the beginning or the end

---

## Rafay Agent

The table below provides the maximum allowed character limits for various resources:

| Type | Versions |
| --- | --- |
| Docker | v2.x or higher |
| Kubernetes | Currently supported version |

---

## Kubernetes Resources Deployed by Blueprints

| Blueprint | Chart | Components | Deployed as | Description |
| --- | --- | --- | --- | --- |
| minimal | v2-infra | v2-relay-agent | Deployment | Used for ZTK connectivity with cluster for all the user and controller kubectl access to cluster. |
|  |  | rafay-connector | Deployment | Syncs resources bidirectionally between cluster and controller. Handles namespace synchronization and drift detection via validating webhooks. |
|  |  | controller-manager-v3 | Deployment | Manages custom resource definitions in the cluster like the namespace CRDs. |
|  | v2-edge-client | edge-client | Deployment | Connects to the edge infrastructure broker via gRPC to execute edge commands and report health status. |
| default | v2-infra | v2-relay-agent | Deployment | Used for ZTK connectivity with cluster for all the user and controller kubectl access to cluster. |
|  |  | rafay-connector | Deployment | Syncs resources bidirectionally between cluster and controller. Handles namespace synchronization and drift detection via validating webhooks. |
|  |  | controller-manager-v3 | Deployment | Manages custom resource definitions in the cluster like the namespace CRDs. |
|  | v2-edge-client | edge-client | Deployment | Connects to the edge infrastructure broker via gRPC to execute edge commands and report health status. |
|  |  | rafay-prometheus-adapter | Deployment | Converts Prometheus metrics to Kubernetes custom metrics API for HPA autoscaling. |
|  |  | rafay-prometheus-alertmanager | Deployment | Handles alert routing, grouping, and notifications from Prometheus. |
|  |  | rafay-prometheus-helm-exporter | Deployment | Exports Helm release metrics (chart versions, release status) to Prometheus. |
|  |  | rafay-prometheus-kube-state-metrics | Deployment | Exports Kubernetes object state metrics (pods, deployments, nodes) to Prometheus. |
|  |  | rafay-prometheus-metrics-server | Deployment | Provides Kubernetes resource metrics API (CPU/memory) for kubectl top and HPA. |
|  |  | rafay-prometheus-node-exporter | Daemonset | Exports node-level hardware and OS metrics (CPU, memory, disk, network) to Prometheus. |
|  |  | rafay-prometheus-server | Statefulset | Main Prometheus server that scrapes, stores, and queries metrics from configured targets. |
|  | v2-ingress-infra | ingress-controller-v1-controller | Daemonset | Ingress Controller that watches Kubernetes Ingress resources and configures NGINX to route HTTP/HTTPS traffic to backend services. |
|  | openebs-localpv | localpv-provisioner | Deployment | Dynamic volume provisioner that watches PersistentVolumeClaims and creates local persistent volumes on nodes using hostpath storage. |
|  | aws-node-termination-handler | aws-node-termination-handler | Daemonset | Monitors EC2 instance metadata for termination notifications and drains nodes before termination. |
|  | aws-ebs-csi-driver | ebs-csi-controller | Daemonset | Handles EBS volume lifecycle operations (create, delete, attach, detach, snapshot) by communicating with AWS EC2 API. |
|  |  | ebs-csi-node | Daemonset | Runs on each node to mount/unmount EBS volumes and register the CSI driver with kubelet. |

---
