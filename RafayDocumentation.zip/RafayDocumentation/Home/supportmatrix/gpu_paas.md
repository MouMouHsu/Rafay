---
title: "Support Matrix - GPU PaaS"
source: https://docs.rafay.co/supportmatrix/gpu_paas/
category: Home
---

# GPU PaaS

The following tables summarizes requirements and supported environments for the GPU PaaS capabilities. GPU PaaS offering builds on and extends Rafay Kubernetes Manager and Environment Manager. Please review the [support matrix](https://docs.rafay.co/supportmatrix/support_matrix/) for these offerings to understand dependencies.

---

## Releases and Upgrades

New major Rafay releases are typically available every two months. Rafay supports direct upgrades from the three preceding major releases. For example, if the current release is 41, direct upgrades are supported from releases 38, 39, and 40.

Customers running a version outside this supported upgrade window must perform a stepped upgrade, upgrading through one or more intermediate releases before reaching the current version.

> **Info**
> To remain within the supported direct-upgrade window, customers should plan to upgrade approximately twice per year.

---

## Infrastructure Types

- Private Data Center (Bare Metal or Virtualized-vSphere/OpenStack etc)
- Public Cloud Providers (AWS, Azure, GCP and OCI)

---

## GPU Providers

- [Nvidia](https://www.nvidia.com/) GPUs based on Ampere, Hopper and Blackwell architectures
- [Intel Gaudi 3](https://www.intel.com/content/www/us/en/products/details/processors/ai-accelerators/gaudi.html) AI accelerators
- [AMD Instinct](https://www.amd.com/en/products/accelerators/instinct.html) MI200 and MI300 Series

> **Note**
> Spatial partitioning of GPUs is supported only on Nvidia GPUs capable of supporting [MIG](https://www.nvidia.com/en-us/technologies/multi-instance-gpu/)

---

## Kubernetes Versions

Any version [supported](https://docs.rafay.co/supportmatrix/support_matrix/) by Rafay Kubernetes Manager.

> **Note**
> GPU resources in "imported" Kubernetes clusters cannot be automatically scaled up/down.

---

## Storage

## Private Cloud

For data center environments with Upstream Kubernetes based on Rafay MKS, organizations have the following options:

- Rafay's Integrated Managed Storage (based on Rook/Ceph)
- Bring Your Own Storage (BYOS)
- 3rd Party, AI/HPC Storage Specialist Provider such as [DDN](https://www.ddn.com/)

## Public Cloud

All storage options recommended and supported by the cloud provider. For example, on AWS, users can use EBS or EFS or FSx for Lustre or S3.

---

## Frameworks

- PyTorch (vx.y)
- TensorFlow (vx.y)

---

## User Applications

- Workloads: Kubernetes YAML or Helm Charts
- Jobs: Kubernetes YAML or Helm Charts
- [Jupyter Notebooks](https://github.com/jupyter/notebook/releases): v7.2.1 or later

## Integrations

- Git (GitHub, GitLab)
- Helm Repositories
-
