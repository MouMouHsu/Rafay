---
title: "Support Matrix"
source: https://docs.rafay.co/supportmatrix/rctl_commands/
category: Home
---

# RCTL Commands

### Imperative/Declarative Usage Patterns

> **Important**
> It is recommended that the declarative usage pattern (rctl apply -f config_file) be used to create/update resources wherever supported.

| **Category** | **Description** | **Declarative Support** | **Declarative Schema** | **Imperative Support** |
| --- | --- | --- | --- | --- |
| **Add-Ons** | Create/Update Add-Ons | [Yes](https://docs.rafay.co/cli/addons/) |  | [Yes](https://docs.rafay.co/cli/addons_v2/) |
|  |  |  |  |  |
| **Agents** | Create/Update Agents | [Yes](https://docs.rafay.co/cli/agents/) |  | [Yes](https://docs.rafay.co/cli/agents_v2/) |
|  |  |  |  |  |
| **Backup/Restore** | Create/Update Backup location | No |  | [Yes](https://docs.rafay.co/cli/backup_cli/#nestedblock--backup_location) |
|  | Create/Update Data agent | No |  | [Yes](https://docs.rafay.co/cli/backup_cli/#nestedblock--data_agent) |
|  | Create/Update Backup Policy | No |  | [Yes](https://docs.rafay.co/cli/backup_cli/#nestedblock--backup_policy) |
|  | Create Backup Job | No |  | [Yes](https://docs.rafay.co/cli/backup_cli/#nestedblock--backup_job) |
|  | Create/Update Restore Policy | No |  | [Yes](https://docs.rafay.co/cli/backup_cli/#nestedblock--restore_policy) |
|  | Create Restore Job | No |  | [Yes](https://docs.rafay.co/cli/backup_cli/#nestedblock--restore_job) |
|  |  |  |  |  |
| **Blueprints** | Create/Update Blueprints | [Yes](https://docs.rafay.co/blueprints/bp_cli/) | [Blueprint schema](https://docs.rafay.co/blueprints/bp_schema/) | [Yes](https://docs.rafay.co/blueprints/bp_cli_v2/) |
|  |  |  |  |  |
| **Catalog** | Create/Update Catalog | [Yes](https://docs.rafay.co/catalog/catalog_cli/) |  | No |
|  |  |  |  |  |
| **Cloud Credentials** | Create/Update Cloud Credential | [Yes](https://docs.rafay.co/cli/credentials/) |  | [Yes](https://docs.rafay.co/cli/credentials_v2/) |
|  |  |  |  |  |
| **Cluster** | Add an imported cluster | Yes |  | Yes |
|  | Create/Update an EKS Cluster | Yes | [EKS Cluster schema](https://docs.rafay.co/clusters/eks/eks_schema_v3/) | Yes |
|  | Create/Update an AKS Cluster | Yes | [AKS Cluster schema](https://docs.rafay.co/clusters/aks/aks_schema/) | Yes |
|  | Create/Update a GKE Cluster | [Yes](https://docs.rafay.co/clusters/gke/cli/) | [GKE Cluster schema](https://docs.rafay.co/clusters/gke/gke_schema/) | No |
|  | Create/Update a Bare Metal/VM Cluster | [Yes](https://docs.rafay.co/clusters/upstream/cli/) | [MKS Cluster schema](https://docs.rafay.co/clusters/upstream/mks_schema/) | No |
|  |  |  |  |  |
| **Cluster Overrides** | Create/Update add-on overrides | [Yes](https://docs.rafay.co/cli/overrides/) |  | [Yes](https://docs.rafay.co/cli/overrides_v2/) |
|  |  |  |  |  |
| **Environment Manager** | Create/Update Resource/Environment Templates | [Yes](https://docs.rafay.co/env_manager/cli/) |  | No |
|  |  |  |  |  |
| **Fleet Plan** | Create/Update Fleet Plan | [Yes](https://docs.rafay.co/clusters/fleetplan/automation/) |  | No |
|  |  |  |  |  |
| **IAM Service Account (IRSA)** | Create/Update IAM Service Account | Yes |  | Yes |
|  |  |  |  |  |
| **IDP/SSO** | Create/Update IDP | No |  | [Yes](https://docs.rafay.co/integrations/sso/idp_rctl/) |
|  |  |  |  |  |
| **Namespaces** | Create/Update namespaces | [Yes](https://docs.rafay.co/cli/namespaces/) | [Namespace schema](https://docs.rafay.co/namespaces/ns_schema/) | [Yes](https://docs.rafay.co/cli/namespaces_v2/) |
|  |  |  |  |  |
| **NodeGroup/NodePool** | Create/Update EKS NodeGroup | Yes |  | Yes |
|  | Create/Update AKS NodePools | Yes |  | Yes |
|  |  |  |  |  |
| **Network Policy** | Create/Update Rules/Policies | [Yes](https://docs.rafay.co/network_policy/np_cli/) |  | No |
|  |  |  |  |  |
| **Pipelines** | Create/Update GitOps pipelines | [Yes](https://docs.rafay.co/cli/pipeline/) |  | [Yes](https://docs.rafay.co/cli/pipeline_v2/) |
|  |  |  |  |  |
| **Policy (OPA Gatekeeper)** | Create/Update Installation Profiles, Constraint Templates, Constraints, Policies | [Yes](https://docs.rafay.co/policy/opa_gatekeeper/opa_cli/) |  | No |
|  |  |  |  |  |
| **Projects** | Create/Update Projects | [Yes](https://docs.rafay.co/cli/projects/) |  | [Yes](https://docs.rafay.co/cli/projects_v2/) |
|  |  |  |  |  |
| **Registry** | Create/Update Registries | [Yes](https://docs.rafay.co/cli/registry/) |  | Yes |
|  |  |  |  |  |
| **Repository** | Create/Update Repositories | [Yes](https://docs.rafay.co/cli/repository/) |  | [Yes](https://docs.rafay.co/cli/repository_v2/) |
|  |  |  |  |  |
| **Secret Groups** | Create/Update Secret Groups | Yes |  | Yes |
|  |  |  |  |  |
| **Secret Stores** | Create/Update Secret Stores | [Yes](https://docs.rafay.co/cli/secret_store/) |  | Yes |
|  |  |  |  |  |
| **Triggers** | Create/Update Triggers | [Yes](https://docs.rafay.co/cli/trigger/) |  | [Yes](https://docs.rafay.co/cli/trigger_v2/) |
|  |  |  |  |  |
| **Workloads** | Create/Update Workloads | [Yes](https://docs.rafay.co/workloads/wl_cli/) |  | [Yes](https://docs.rafay.co/workloads/wl_cli_v2/) |
|  |  |  |  |  |
| **Workload Overrides** | Create/Update Workload overrides | [Yes](https://docs.rafay.co/cli/overrides/) |  | [Yes](https://docs.rafay.co/cli/overrides_v2/) |
|  |  |  |  |  |

---
