---
title: "Template Catalog"
source: https://docs.rafay.co/template_catalog/overview/
category: Home
---

# Overview

- **Overview**   [**Introduction**](https://docs.rafay.co/template_catalog/introduction/) and overview of Rafay's Template Catalog addressing common use cases for end user self service access to **AI and Cloud Native** Infrastructure.
- **AI/ML & GenAI**   Self-Service **Generative AI and AI/ML** use cases for data scientists, Generative AI Developers and ML Researchers  [Learn More](https://docs.rafay.co/aiml/overview/)
- **Kubernetes Clusters as a Service**   Self-service Kubernetes clusters for **Public Clouds** (EKS, AKS, GKE etc) and **Private Clouds** (Bare Metal, VMs, vSphere, Nutanix etc)  [Learn More](https://docs.rafay.co/template_catalog/clusters/)
- **Multi-Tenancy**   Accelerate your AppDev workflows by providing users with access to self-service **virtual clusters** or **namespaces** on shared host clusters.  [Learn More](https://docs.rafay.co/template_catalog/multi-tenancy/)
- **Virtual Machines**   End user self-service provisioning and use of Virtual Machines on VMware vSphere, OpenStack and bare metal servers with KVM  [Learn More](https://docs.rafay.co/template_catalog/vm/)
