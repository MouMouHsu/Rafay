---
title: "KOP GCP - Cloud Integration"
source: https://docs.rafay.co/cost_management/gcp_integration/
category: Home
---

# GCP Integration

To integrate Google Cloud Platform (GCP) with Cost Management, follow these steps:

## Assign Required Permissions

Navigate to the GCP Console and create a service account with the following role:

- **Compute Viewer** at the project level

[![Create Cloud Credential](https://docs.rafay.co/cost_management/img/compute_viewer.png)](https://docs.rafay.co/cost_management/img/compute_viewer.png)

- Assign the **Billing Account Viewer** role at the organization level to the created service account

[![Create Cloud Credential](https://docs.rafay.co/cost_management/img/billing_viewer.png)](https://docs.rafay.co/cost_management/img/billing_viewer.png)

- Once these two roles are attached, create a new service account key
- Download the service account key in 'JSON' format for later use in the integration

[![Create Cloud Credential](https://docs.rafay.co/cost_management/img/download_key.png)](https://docs.rafay.co/cost_management/img/download_key.png)

---

## Attach Service Account to Cost Management

Once the roles are assigned, attach the service account and create a [GCP Cloud Credential](https://docs.rafay.co/cost_management/cloud_credentials/#gcp-cloud-credentials) for Cost Management.

[![Create Cloud Credential](https://docs.rafay.co/cost_management/img/gcp_integ.png)](https://docs.rafay.co/cost_management/img/gcp_integ.png)

---
