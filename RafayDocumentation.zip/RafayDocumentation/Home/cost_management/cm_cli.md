---
title: "KOP Cost Management Profiles- CLI"
source: https://docs.rafay.co/cost_management/cm_cli/
category: Home
---

# Profiles

RCTL support helps to automate the lifecycle of operations associated with **Cost Management Profiles**.

| Resource | Create | Get | Delete | Share |
| --- | --- | --- | --- | --- |
| Profiles | YES | YES | YES | Yes |

---

The declarative method allows the users to create **Cost Management Profiles** to ensure that custom pricing can be taken into consideration.

## Profiles

### Create Profile

Run the below command to create a Cost Management Profile using the spec yaml file.

```
./rctl apply -f profile_filename.yaml
```

**AWS Cost Profile**

An illustrative example of the AWS profile shared between 2 projects spec YAML file is shown below.

```
apiVersion: cost.k8smgmt.io/v3
kind: CostProfile
metadata:
  name: <cost_profile_name>
  description: "Cost Profile description"
  project: <project_name>
spec:
  version: <version_name>
  providerType: aws
  sharing:
    enabled: true
    projects:
    - name: <to_project_name_1>
    - name: <to_project_name_2>
  installationParams:
    aws:
      spotIntegration:
        spotLabel: <spot_label>
        spotLabelValue: <spot_label_value>
        awsSpotDataRegion: <aws_spot_data_region>
        awsSpotDataBucket: <aws_spot_data_bucket>
        awsSpotDataPrefix: <aws_spot_data_prefix>
        awsAccountId: <aws_account_id>
      curIntegration:
        athenaRegion: <athena_region>
        athenaBucketName: <athena_bucket_name>
        athenaDatabase: <athena_database>
        athenaTable: <athena_table>
        masterPayerArn: <master_payer_Arn>
      awsCredentials:
        cloudCredentialsName: <cloud_credentials_name>
```

An illustrative example of a spec YAML file for sharing profiles with all projects is show below.

```
apiVersion: cost.k8smgmt.io/v3
kind: CostProfile
metadata:
  name: <cost_profile_name>
  description: "Cost Profile description"
  project: <project_name>
spec:
  version: <version_name>
  providerType: aws
  sharing:
    enabled: true
    projects:
    - name: '*'
  version: v1.0
```

**Azure Cost Profile**

An illustrative example of an Azure Cost Profile specification for sharing profiles across all projects is shown below.

```
apiVersion: cost.k8smgmt.io/v3
kind: CostProfile
metadata:
  modifiedAt: "2024-08-19T02:38:20.697088Z"
  name: <cost_profile_name>
  project: <project_name>
spec:
  installationParams:
    azure:
      customPricing:
        cloudCredentialsName: <cloud_credentials_name>
  providerType: azure
  sharing:
    enabled: true
    projects:
    - name: '*'
  version: <version_name>
```

**GCP Cost Profile**

An illustrative example of an GCP Cost Profile specification for sharing profiles across all projects is shown below.

```
apiVersion: cost.k8smgmt.io/v3
kind: CostProfile
metadata:
  modifiedAt: "2024-11-20T05:23:31.009929Z"
  name: <cost_profile_name>
  project: <project_name>
spec:
  installationParams:
    gcp:
      gcpCredentials:
        cloudCredentialsName: <cloud_credentials_name>
  providerType: gcp
  sharing:
    enabled: true
    projects:
    - name: '*'
  version: <version_name>
```

### Get Profile

Use any of the below commands to get the list of all Cost Management Profiles (or) a specific project

| S. No | Command |
| --- | --- |
| 1 | `./rctl get costprofile -p <project-name>` |
| 2 | `./rctl get cp -p <project-name>` |
| 3 | `./rctl get costprofile` |
| 4 | `./rctl get cp` |

***Example Output***

```
./rctl get cp -p default-project
+----------------------+-------------------+
| PROFILE NAME         | VERSION NAME      |
+----------------------+-------------------+
| demo-profile         | v1                |
+----------------------+-------------------+
| cost-profile1        | v2.0              |
+----------------------+-------------------+
| test-costprofile     | v2.1              |
+----------------------+-------------------+
```

### Delete Profile

To delete a profile, use the below command

```
./rctl delete costprofile <profile name>
```

(or)

```
./rctl delete cp <profile name>
```

---

## Enabling Cost Management and attaching Cost Profile in a Blueprint

Once the Cost Management Profiles are created, users can deploy the Cost Management via blueprint spec yaml. Refer [Blueprint CLI](https://docs.rafay.co/blueprints/bp_cli/) for both the declarative and imperative RCTL commands.

An illustrative example of the blueprint spec YAML with Cost Management parameters is shown below.

```
apiVersion: infra.k8smgmt.io/v3
kind: Blueprint
metadata:
  name: demo-bp
  project: defaultproject
spec:
  base:
    name: default
    version: 1.18.0
  defaultAddons:
    csiSecretStoreConfig:
      providers: {}
    enableIngress: false
    enableLogging: false
    enableMonitoring: true
    enableVM: false
  drift:
    enabled: false
  costProfile:
    enabled: true
    name: "cprole2"
    version: "v1"
  networkPolicy: {}
  opaPolicy: {}
  placement: {}
  prometheusCustomization: {}
  sharing:
    enabled: false
  type: custom
  version: v5
```

---
