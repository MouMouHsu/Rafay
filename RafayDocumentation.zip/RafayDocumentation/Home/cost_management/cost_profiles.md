---
title: "KOP Cost Profiles - Installation Profiles"
source: https://docs.rafay.co/cost_management/cost_profiles/
category: Home
---

# Cost Profiles

## Overview

**Cost Profiles** ensure accuracy of cost metrics by taking the organization's custom pricing and cluster type into consideration. Cost Profile is attached to clusters via Blueprints.

[![Cost Profile](https://docs.rafay.co/cost_management/img/costprofile_mainpage.png)](https://docs.rafay.co/cost_management/img/costprofile_mainpage.png)

---

## Custom Cost Profiles

The **Profiles** page shows the list of Custom (AWS, Azure, and Other) and Default profiles. Default system profiles are available for AWS and Azure. Organizations can customize certain profile parameters to ensure accuracy of cost metrics (e.g. for specific clusters or specific types of environment).

---

## Create a Custom Cost Profile

Perform the below steps to create a custom cost profile:

- Login to the controller and select Profiles under Cost
- Click **New Profile**
- Provide a name for the profile and select a provider type (AWS, AZURE, and Other). Remember that if you intend to share this profile with other projects, the name needs to be unique
- Click Create and provide a version name
- Enter the required parameters based on the provider type

### Parameters Supported for AWS

#### Spot Integrations

Users enabling Spot Integrations option must enter the Spot level information that has been configured in the AWS Console. Follow the steps provided [here](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/spot-data-feeds.html).

| Parameter | Definition |
| --- | --- |
| Spot Feed S3 Region | Region of your spot data bucket |
| Spot Feed S3 Bucket | Configured bucket for the spot data feed |
| Spot Feed S3 Prefix | Configured prefix for your spot data feed bucket |
| AWS Account ID | A unique AWS account ID |

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/spot_integrations.png)](https://docs.rafay.co/cost_management/img/spot_integrations.png)

#### CUR Integrations

Users enabling CUR Integrations must enter the CUR details that have been configured in the AWS console and stored in the Athena DB.

Refer [AWS Cloud Integration](https://docs.rafay.co/cost_management/aws_integration/)

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/cur_integration.png)](https://docs.rafay.co/cost_management/img/cur_integration.png)

> **Important**
> It is mandatory to provide either Spot Integrations or CUR Integrations details to complete the AWS Cost profile configuration.

#### Cloud Credentials

Enable the Cloud Credentials option to select the required cloud credential from the drop-down.

Users are allowed to reuse the credentials that are used for provisioning the cluster by selecting the **Use Cluster Credential** option or use a credential specifically created for Cost Management.

Refer to the [Cloud credentials](https://docs.rafay.co/cost_management/cloud_credentials/) section for more information.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/cloud_credential.png)](https://docs.rafay.co/cost_management/img/cloud_credential.png)

Once the required details are provided, click **Save Changes**. To view the configured parameters of a specific version, click the **i** icon and you can view the configuration spec as shown below.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/aws_config_info.png)](https://docs.rafay.co/cost_management/img/aws_config_info.png)

---

### Parameters Supported for Azure

#### Custom Pricing

Enter a version name and enable the Custom Pricing option. Select the required [Cloud credentials](https://docs.rafay.co/cost_management/cloud_credentials/) in which the required parameters are already set.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/azure_profiles.png)](https://docs.rafay.co/cost_management/img/azure_profiles.png)

Users are allowed to reuse the credentials that are used for provisioning the cluster by selecting the **Use Cluster Credential** option

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/cluster_cred.png)](https://docs.rafay.co/cost_management/img/cluster_cred.png)

Refer to the [Azure Cloud Integration](https://docs.rafay.co/cost_management/azure_integration/) section for more information.

Once the required details are provided, click **Save Changes**. To view the configured parameters of a specific version, click the **i** icon and you can view the configuration spec as shown below.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/azure_configuration.png)](https://docs.rafay.co/cost_management/img/azure_configuration.png)

---

### Parameters Supported for GCP

#### Custom Pricing

Enter a version name and enable the Custom Pricing option. Select the required [Cloud credentials](https://docs.rafay.co/cost_management/cloud_credentials/) in which the required parameters are already set.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/gcp_profile.png)](https://docs.rafay.co/cost_management/img/gcp_profile.png)

Users are allowed to reuse the credentials that are used for provisioning the cluster by selecting the **Use Cluster Credential** option

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/gcp_cluster_cred.png)](https://docs.rafay.co/cost_management/img/gcp_cluster_cred.png)

Refer to the [GCP Integration](https://docs.rafay.co/cost_management/gcp_integration/) section for more information.

Once the required details are provided, click **Save Changes**. To view the configured parameters of a specific version, click the **i** icon and you can view the configuration spec as shown below.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/gcp_new.png)](https://docs.rafay.co/cost_management/img/gcp_new.png)

---

### Parameters Supported for Other Data centers

Users can customize the hourly pricing to provide average estimates of CPU/Memory/GPU.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/other_profile.png)](https://docs.rafay.co/cost_management/img/other_profile.png)

Once the required details are provided, click **Save Changes**. To view the configured parameters of a specific version, click the **i** icon and you can view the configuration spec as shown below.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/other_config.png)](https://docs.rafay.co/cost_management/img/other_config.png)

---

## Blueprint Integration

On successful creation of a cost profile, users can now deploy it to the cluster via blueprint by enabling the **Enable Cost Management** option. Select the required cost profile and version from the drop-down.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/bp_costprofile.png)](https://docs.rafay.co/cost_management/img/bp_costprofile.png)

> **Important**
> **Monitoring & Alerting** add-on is a requirement for Cost Management Service.

---

## Profiles List

On successful creation of any custom profile, you can view the list of profiles as shown below

[![Cost Profile Overview](https://docs.rafay.co/cost_management/img/profiles_custom_list.png)](https://docs.rafay.co/cost_management/img/profiles_custom_list.png)

Click **Default Profiles** to view the AWS and Azure system profiles.

[![Cost Profile Overview](https://docs.rafay.co/cost_management/img/profiles_default_list.png)](https://docs.rafay.co/cost_management/img/profiles_default_list.png)

> **Important**
> The usage metrics are collected every one hour from the clusters.

---

## Profile sharing

Existing cost profiles can be shared to All/Specific/None projects. The profiles created in a project can be edited or deleted within the same project. Profiles inherited from other projects (shared by other projects) cannot be edited or deleted.

[![Installation Profile Overview](https://docs.rafay.co/cost_management/img/share_profile.png)](https://docs.rafay.co/cost_management/img/share_profile.png)

---
