---
title: "KOP Chargeback Group - CLI"
source: https://docs.rafay.co/cost_management/chargeback_cli/
category: Home
---

# Chargeback Groups

RCTL support helps to automate the lifecycle of operations associated with **Chargeback Groups**.

| Resource | Create | Get | Delete |
| --- | --- | --- | --- |
| Chargeback Group | Yes | Yes | Yes |

---

## Chargeback Group

### Create Chargeback Group

Use the below command to create a chargeback group of summary/detailed Report

```
./rctl create chargebackgroup -f <configfile_name>
```

An illustrative example of a detailed report config file is given below

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackGroup
metadata:
  name: rctld2
  description: ""
spec:
  inclusions:
  - project: p1
    cluster: ""
    namespace: ""
    label:
    - scb3
  exclusions:
  - project: p1
    cluster: ""
    namespace: ""
    label: []
  type: detailed
```

An illustrative example of a summary report config file is given below

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackGroup
metadata:
  name: rctld2
  description: ""
spec:
  inclusions:
  - project: p1
  aggregate:
    project: false
    cluster: false
    namespace: false
    label:
    - scb3
  type: summary
```

**Include Additional Namespace Labels in Chargeback Reports (Optional)**

To enhance visibility in cost reports, additional namespace labels can be included in the chargeback group configuration. This is useful in environments where namespaces are tagged with multiple identifiers, such as `team` and `cost_center`.

For summary reports aggregated by namespace, these labels can be specified using the `additionalNSLabels` annotation. While aggregation is always based on namespaces, the specified labels appear as additional columns in the generated CSV report. This provides more context in the report without changing the aggregation logic.

The setup is defined using the `additionalNSLabels` annotation in the chargeback group specification. The system fetches the values of these labels from each namespace and includes them in the output report.

***Example configuration spec***

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackGroup
metadata:
  annotations:
    additionalNSLabels: "team,cost_center"
  name: sas1
spec:
  aggregate:
    namespace: true
  inclusions:
    - project: '*'
  type: summary
```

---

### Generate Report

To generate a chargeback group report, use the below command

```
./rctl create chargebackgroupreport -f <configfile_name>
```

An illustrative example of a report generating config file is given below

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackGroupReport
metadata:
  name: rctld2
  description: ""
spec:
  groupName: rctld2
  startDate:
    seconds: 1669011971
  endDate:
    seconds: 1669616771
```

---

### Download Chargeback Group Report

**Download to the current directory**

To download the Chargeback Group report to the current directory, use the following command:

```
./rctl create chargebackgroupreport -f <filename.yaml>  --download
apiVersion: system.k8smgmt.io/v3
```

**Output**

```
kind: ChargebackGroupReport
metadata:
  name: demo-group
spec:
  groupName: demo-group
  endDate:
    seconds: 1749427199
  startDate:
    seconds: 1747008000
chargeback report: demo-group-20250624-071754.csv
```

demo-group-20250624-071754.csv

**Download to a specific existing directory**

To download the Chargeback Group report to a specific existing directory, use the following command:

```
./rctl create chargebackgroupreport -f <filename.yaml>  --download=<download_path>
```

**Output**

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackGroupReport
metadata:
  name: demo-group
spec:
  groupName: demo-group
  endDate:
    seconds: 1749427199
  startDate:
    seconds: 1747008000
chargeback report: <download_path>/demo-group-20250624-071754.csv
```

The `demo-group-20250624-071754.csv` file will be available in the specified directory.

**Configure Download Timeout for Chargeback Group Reports**

Users can configure how long the system waits for a chargeback report to be generated and downloaded using the `--download-ctx-timeout-min` flag. The default wait time is `2 minutes`. If the report takes longer to generate, users can increase the timeout duration upto `10 minutes` as needed.

Once the report is generated during this specified period, it is downloaded automatically and the process ends. If the report is not generated within the timeout window, the command exits without downloading.

***Example***

The following command sets a `10-minute` timeout and downloads the report to the `test` directory:

```
./rctl create chargebackgroupreport -f <filename.yaml> --download=test --download-ctx-timeout-min 10
```

***Output***

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackGroupReport
metadata:
  name: emo-group
spec:
  groupName: demo-group
  endDate:
    seconds: 1749427199
  startDate:
    seconds: 1747008000
chargeback report: test/demo-group-20250624-071754.csv
```

---

### List Chargeback Groups

To view the list of all chargeback groups, use the below command

```
./rctl get chargebackgroup
+------------+-------------+-------------------+
| GROUP NAME | REPORT TYPE | REPORTS GENERATED |
+------------+-------------+-------------------+
| rctl1      | summary     | 0                 |
+------------+-------------+-------------------+
| rctl2      | summary     | 1                 |
+------------+-------------+-------------------+
| rctl3      | detailed    | 0                 |
+------------+-------------+-------------------+
| cb-group-1 | summary     | 0                 |
+------------+-------------+-------------------+
| cb-group-2 | summary     | 0                 |
+------------+-------------+-------------------+
```

To retrieve a specific chargeback group details, use the below command

```
./rctl get chargebackgroup <group-name>
```

***Example Output***

```
./rctl get chargebackgroup rctl2
+------------+-------------+-------------------+
| GROUP NAME | REPORT TYPE | REPORTS GENERATED |
+------------+-------------+-------------------+
| rctl2      | summary     | 1                 |
+------------+-------------+-------------------+
```

Or you can use below commands to get more information of the chargeback group in json or yaml format

```
./rctl get chargebackgroup <cbg-name> -o json
```

(or)

```
./rctl get chargebackgroup <cbg-name> -o yaml
```

***Example Output***

```
./rctl get chargebackgroup cb-group-1 -o yaml
apiVersion: system.k8smgmt.io/v3
kind: ChargebackGroup
metadata:
  name: cb-group-1
spec:
  aggregate: {}
  inclusions:
  - label:
    - ""
  type: summary
status:
  extra:
    data: {}
```

---

### Chargeback Share Configuration

Users can enable/disable the Chargeback Share Type via the configuration file.

Below is an example of chargeback group share config file. Users can edit the **shareEnabled** parameter to true or false to share/unshare the chargebackgroup and change the required sharetype [tenancy/allocation](https://docs.rafay.co/cost_management/cost_governance/).

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackShare
metadata:
  name: chargebackshare
spec:
  shareUnallocatedCost: true
  shareCommonServicesCost: true
  shareControlPlaneCost: true
  shareType: allocation
```

Now run the below command to apply the required configuration

```
./rctl create chargebackshare -f <configfile_name>
```

> **Note**
> Chargeback share configuration will apply to "unallocated resources", "control plane", and "common services".

---

## Apportioning costs for Common Services

The platform now supports identification of common services (e.g. security tools, monitoring tools) through configuration of namespace list/labels and adds the ability to share the cost of running these common services among tenants (teams/applications) sharing the cluster when generating chargeback/showback reports.

Below are some of the example config specs to configure policies for identifying common services.

### For all clusters in all projects

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackCommonServicesPolicy
metadata:
    name: policy1
spec:
    policyProject: '*'
    selectionType: allClusters
    commonServicesNamespaces:
    - kube-system
    commonServicesNamespaceLabels:
    - key: 'common'
      value: 'service'
```

### For all clusters in a specific project

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackCommonServicesPolicy
metadata:
    name: policy2
spec:
    policyProject: 'project-name'
    selectionType: allClusters
    commonServicesNamespaces:
    - kube-system
    commonServicesNamespaceLabels:
    - key: 'common'
      value: 'service'
```

### For specific cluster(s) in a project

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackCommonServicesPolicy
metadata:
    name: policy3
spec:
    policyProject: 'project-name'
    selectionType: clusterNames
    clusters:
    - 'cluster1'
    - 'cluster2'
    commonServicesNamespaces:
    - kube-system
    commonServicesNamespaceLabels:
    - key: 'common'
      value: 'service'
```

### For specific cluster label(s) in a project

```
apiVersion: system.k8smgmt.io/v3
kind: ChargebackCommonServicesPolicy
metadata:
    name: policy4
spec:
    policyProject: 'project-name'
    selectionType: clusterLabels
    clusterLabels:
    - key: "rafay.dev/clusterName"
      value: "sachin-24-aug"
    commonServicesNamespaces:
    - kube-system
    commonServicesNamespaceLabels:
    - key: 'common'
      value: 'service'
```

---

### Delete Chargeback Group

Users can delete a chargeback group using the below command

```
./rctl delete chargebackgroup <chargebackgroup-name>
```

> **Important**
> You cannot delete a chargeback group report and chargeback share

---
