---
title: "KOP Cost Management - Introduction"
source: https://docs.rafay.co/cost_management/pre-requisites/
category: Home
---

# Considerations

As organizations adopt and scale their K8s environments, they often find themselves running blind struggling to get to a ‘good enough’ appreciation of their cost structure. This slows down their journey significantly and doesn’t allow them to expand their K8s footprint with confidence.

Cost Management service enables organizations to:

- More effectively operationalize and allocate costs across teams in shared cluster scenarios. This is done by collection and aggregation of very granular resource utilization metrics from clusters.
- Open up access and provide real time visibility to cost metrics to Platform and Application teams filtered by their role. This increases transparency and reduces the time to execute on any ‘closing the loop’ cost optimization exercises

---

## Pre-requisites

- Enable **Monitoring & Alerting** when creating a blueprint with Cost Management. This helps to retrieve the cost metrics via Prometheus (metrics containing the usage of CPU, pod, etc.)
- For EKS clusters, necessary [permissions](https://raw.githubusercontent.com/RafaySystems/opencost/rafay/aws/single-account-permissions.yaml) are required to create the [Cost and Usage Report (CUR)](https://docs.rafay.co/cost_management/aws_integration/) and to add IAM credentials for Athena and S3
- The below cluster types have been tested and are supported:

| Name |
| --- |
| EKS |
| AKS |
| GKE |
| On-premise Data centers |

---

## Limitations

- Cost Management support is available for the cluster types EKS, AKS, MKS, and GKE
- In case of having more than one node in a MKS cluster, user must find out the average cost of both the nodes as the CPU & Memory per hour accepts only one custom pricing. Multiple node pricing are not allowed
- On enabling the Cost Management via blueprint (or) performing any updates to the cost management parameters, you must wait upto one (1) hour to view the changes in the Cost Management Dashboard

---

## Role based Access Control (RBAC)

The following table lists the roles that can access specific components of the Cost Management service offering.

| Roles | Cost Management Profiles (Configuration) | Cost Management Dashboard | Chargeback Configuration | Cost Tags |
| --- | --- | --- | --- | --- |
| Infra Admin | Read & Write | View (Org, Project, and Cluster level) | Not Available | Not Available |
| Org Admin | Read & Write | View (Org, Project, and Cluster level) | Read & Write (Org and Project level) | Read & Write |
| Org Read-Only | Read | View (Org, Project, and Cluster level) | Read (Org and Project level) | Read |
| Infra Read-Only | Read | View (Org, Project, and Cluster level) | Not Available | Not Available |
| Cluster Admin | Read | View (Org, Project, and Cluster level) | Not Available | Not Available |
| Project, Namespace, & Workspace Admin | Not Available | Not Available | Not Available | Not Available |
| FinOps Admin | Not Available | View (Org, Project, and Cluster level) | Read & Write (Org and Project level) | Read & Write |

Explore our blog for deeper insights on **Integrated FinOps Role for Cost Management**, available [here](https://docs.rafay.co/blog/2023/07/13/integrated-finops-role-for-cost-management/)!

---

## Process Flow Diagram

The image below describes the typical steps that are performed in a sequence.

```
flowchart TD
    A(Create Cloud Credentials Optional) --> B(Create a Cost Profile)
    B --> C(Attach to Blueprint)
    C --> D(Update Cluster Blueprint)
    D --> |Atleast an hour| E(Create a Chargeback Report)
    D --> |Atleast an hour| F(Check Dashboard)
    G(Update Chargeback Configuration) --> H(Create Chargeback Group)
    H --> E(Create a Chargeback Report)
```

---
