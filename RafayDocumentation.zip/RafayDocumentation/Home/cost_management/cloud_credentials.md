---
title: "KOP Cost Management - Credentials"
source: https://docs.rafay.co/cost_management/cloud_credentials/
category: Home
---

# Credentials for Cost Management

With the Controller, you can fully automate the Cost Management lifecycle in all supported regions.

To create a cost management profile, you need to provide credentials that allow programmatic access to Amazon AWS and Azure.

---

## AWS Cloud Credentials

### Option 1: With Access Key

You will create an AWS "Cloud Credential" which will be configured to use an **Access Key** from your AWS Account for Cost Management through the controller. Once created, you can reuse the cloud credential to create as many cost management profiles as necessary.

- Login to the Console and select "Cloud Credentials" under Infrastructure
- Click **New Credential** and provide a unique name
- Select the Type **Cost Management** and Provider Type **AWS**
- Select the credential type **Access_key**
- Provide the **Access ID** and **Secret Key** available in the AWS Console

Refer [AWS Cloud Integration](https://docs.rafay.co/cost_management/aws_integration/) for Cost Management AWS Credential setting

- Click **Save**

[![Create Cloud Credential](https://docs.rafay.co/cost_management/img/aws_cc.png)](https://docs.rafay.co/cost_management/img/aws_cc.png)

### Option 2: With Role ARN

You will create an AWS "Cloud Credential" which will be configured to use a **Role ARN** from your AWS Account for Cost Management through the controller. Once created, you can reuse the cloud credential to create as many cost management profiles as necessary.

- Login to the Console and select "Cloud Credentials" under Infrastructure
- Click **New Credential** and provide a unique name
- Select the Type **Cost Management** and Provider Type **AWS**
- Select the credential type **Role**
- Provide the **Role ARN** available in the AWS Console

Refer [AWS Cloud Integration](https://docs.rafay.co/cost_management/aws_integration/) for Cost Management AWS Credential setting

- Click **Save**

[![Create Cloud Credential](https://docs.rafay.co/cost_management/img/aws_role_cc.png)](https://docs.rafay.co/cost_management/img/aws_role_cc.png)

---

## AZURE Cloud Credentials

You will create an Azure "Cloud Credential" which will be configured to use multiple information from your Azure Account for Cost Management through the controller. Once created, you can reuse the cloud credential to create as many cost management profiles as necessary.

- Login to the Console and select "Cloud Credentials" under Infrastructure
- Click **New Credential** and provide a unique name
- Select the Type **Cost Management** and Provider Type **AZURE**
- Provide the **Tenant ID**, **Subscription ID**, **Client ID**, and **Client Secret** available in the Azure portal

| Parameter | Definition |
| --- | --- |
| Tenant ID | A Globally Unique Identifier (GUID) that is different than your organization name or domain. |
| Subscription ID | Azure Subscription ID, associated with an Azure Subscription |
| Client ID | An ID used to associate your application with Azure AD at runtime |
| Client Secret | Azure Active Directory Client Secret |

Refer [Azure Cloud Integration](https://docs.rafay.co/cost_management/azure_integration/) for Cost Management Azure Credential setting

- Click **Save**

[![Create Cloud Credential](https://docs.rafay.co/cost_management/img/azure_cc.png)](https://docs.rafay.co/cost_management/img/azure_cc.png)

---

## GCP Cloud Credentials

Create a GCP Cloud Credential configured to use a service account from your GCP account for Cost Management through the controller. Once created, the cloud credential can be reused to create multiple cost management profiles as needed.

1. Log in to the console and select **Cloud Credentials** under **Infrastructure**
2. Click **New Credential** and provide a unique name
3. Select **Cost Management** as the Type and **GCP** as the Provider Type
4. Click **Browse File** and upload the downloaded service account key file
5. Click **Save**

[![Create Cloud Credential](https://docs.rafay.co/cost_management/img/gcp_integ.png)](https://docs.rafay.co/cost_management/img/gcp_integ.png)

Refer to [GCP Cloud Integration](https://docs.rafay.co/cost_management/gcp_integration/) for more details on setting up GCP credentials for Cost Management.

---
