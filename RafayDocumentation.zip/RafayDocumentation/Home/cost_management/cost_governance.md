---
title: "KOP Cost Management - Governance"
source: https://docs.rafay.co/cost_management/cost_governance/
category: Home
---

# Chargeback/Showback

Cost Governance allows creation of chargeback groups to track and bill internal teams based on resource consumption. Chargeback/Showback groups can be any logical grouping of resources and these groups can be created based on project, clusters, namespaces and/or labels. The Chargeback help the users to understand which resources are being consumed and the costs associated with these resources.

An admin can create Chargeback Groups via multiple methods:

- **Controller**
- **API**
- **RCTL CLI**
- **Terraform**

---

## Getting to the Chargeback Settings

- Login to the controller
- Click on System and select **Cost Governance**

[![Service Mesh Dashboard](https://docs.rafay.co/cost_management/img/system_cost_gover.png)](https://docs.rafay.co/cost_management/img/system_cost_gover.png)

Chargeback Settings page appears. By Default, Unallocated Resources, Control Plane and Common Services cost sharing are disabled. It is important to distribute the cost of **unallocated resources**, **Control Plane** and **common services** among the different teams/applications utilizing the cluster

### Unallocated Resources

- Enabling **Unallocated Resources** allows selection of the Sharing Policy
  - **Based on resource allocation:** Allows for distribution in accordance with the ratio determined by each tenant's computed use. For example, if a cluster has 2 namespaces with 30% and 40% allocated, the unallocated cost gets divided in the same ratio (30:40)
  - **Equally:** Allows to equally share the shared cost with all the tenants of a cluster. For example, if a cluster has 2 pods, the remaining 30% of unallocated cost gets divided equally

### Control Plane

- Enabling **Control Plane** allows selection of the Sharing Policy   [![Service Mesh Dashboard](https://docs.rafay.co/cost_management/img/unallocated_resources.png)](https://docs.rafay.co/cost_management/img/unallocated_resources.png)
  - **Based on resource allocation:** Allows for distribution in accordance with the ratio determined by each tenant's computed use
  - **Equally:** Allows to equally share the shared control plane cost with all the tenants of a cluster

### Common Services

Users can configure a common service policy, assigning specific costs to the shared services. The allocation of unallocated costs is then distributed proportionally based on the usage of these common services across namespaces.

Enabling **Common Services** allows to **Add Policy** and select **Share Policy**. Common Services can be configured using the policies. - Click **Add Policy**

[![Service Mesh Dashboard](https://docs.rafay.co/cost_management/img/common_service.png)](https://docs.rafay.co/cost_management/img/common_service.png)

New Policy Details screen appears

- Provide a Policy Name
- Choose either **All Projects** or the specific projects you need
- Opt for **All Clusters** or **Some Clusters** to select the necessary cluster names or labels
- Set up a list of **Namespaces** and **Namespace Labels**. Consequently, all pods within these selected namespace(s) will be considered common services for the chosen projects and clusters

[![Service Mesh Dashboard](https://docs.rafay.co/cost_management/img/policy_1.png)](https://docs.rafay.co/cost_management/img/policy_1.png)

- Click **Save & Exit**

The list of policies is displayed as shown below.

[![Service Mesh Dashboard](https://docs.rafay.co/cost_management/img/list_policy.png)](https://docs.rafay.co/cost_management/img/list_policy.png)

> **Important**
> - Sharing the unallocated resources, control plane, and common services cost is optional

#### Limitations

- In the scenario where customers frequently change their namespace labels, a potential limitation arises in the context of generating chargeback reports or configuring common services policies based on namespace labels. The assumption that a label, once applied, remains unchanged for an extended period is critical for accurate cost metrics. If this assumption does not hold, and a label is added to a namespace while cost metrics are being collected (even for a short duration, such as an hour), the chargeback report assumes the label's presence for the entire 24-hour day.
- When establishing a common services cost-sharing policy filtered by cluster labels, it's important to note that this policy applies only to clusters that have not been deleted from the console. To allocate costs for deleted clusters, users must create cluster-specific policies based on cluster names or select "All Clusters".
- In the context of creating a common services policy or generating a summary report based on namespace labels, it is essential to highlight that the data in the report is limited to clusters with a base blueprint version >=2.1.0.

---

## Chargeback Groups

A chargeback group is a collection of resources forming a logical entity in a customer's organization. These would typically be based on namespaces and/or specific ‘labels’.

Users have the flexibility in the platform to create chargeback groups based on a variety of parameters. **Org Admin** can create chargeback groups.

[![Service Mesh Legend](https://docs.rafay.co/cost_management/img/chargeback_group.png)](https://docs.rafay.co/cost_management/img/chargeback_group.png)

### Create Chargeback Group

Perform the below steps to create a chargeback group:

- Click **Create Chargeback Group** under Groups. A new Chargeback page appears
- Provide a name for the group
- Select the **Report Type**, either **Summary** or **Detailed**
- Selecting **Summary**, allows users to retrieve aggregated cost based on Project, Cluster, Namespace, Label, and Names pace Label. Based on the selection, add details of the resource
  - Example: **Aggregate based on Project** with Resource Selection as **All Projects** generates a cost summary report of all projects

[![Service Mesh Legend](https://docs.rafay.co/cost_management/img/summary_type.png)](https://docs.rafay.co/cost_management/img/summary_type.png)

> 📌 Note
> When selecting Namespace as the aggregation type, you can optionally enable Additional NamespaceLabels.
>   - Enter one or more label keys (e.g., team,cost_center) to include them as additional columns in the generated cost report.
>   - The system fetches the values of these labels from each namespace and displays them in the CSV report, providing extra context without changing the aggregation logic.

- Selecting **Detailed** type allows the users to choose a project and the available clusters/namespaces/labels or a combination/exclusion of all to form a chargeback group
  - Select the required cluster, namespace, and labels available within the selected project, and click **Include**. You can do as many as inclusions based on the requirement
  - Use **Exclude** button to remove a specific cluster, namespace, label or any combination from this group
- Click **Save**

[![Service Mesh Legend](https://docs.rafay.co/cost_management/img/include_exclude.png)](https://docs.rafay.co/cost_management/img/include_exclude.png)

On successful creation, you can view the newly created group in the Groups page as shown below

[![Service Mesh Legend](https://docs.rafay.co/cost_management/img/group_list.png)](https://docs.rafay.co/cost_management/img/group_list.png)

### Generate Cost Reports

Once a chargeback group is created, users can generate cost reports at their convenience.

- Under the Groups, click the ellipsis icon of a specific chargeback group and select **Reports**
- Select a period (Start and End date) and click **Generate**

[![Service Mesh Legend](https://docs.rafay.co/cost_management/img/report_generate_button.png)](https://docs.rafay.co/cost_management/img/report_generate_button.png)

The report generation process is compute intensive and it may take a few minutes to generate the report. Once the report is ready, click the **download** button to download the report in CSV format

[![Service Mesh Legend](https://docs.rafay.co/cost_management/img/download_reports.png)](https://docs.rafay.co/cost_management/img/download_reports.png)

The chargeback report has distinct columns showing the allocated costs for both unallocated resources and common services.

The common service report offers insights into how these common services are utilized, allowing for a more nuanced understanding of cost distribution within the project and across namespaces.

---
