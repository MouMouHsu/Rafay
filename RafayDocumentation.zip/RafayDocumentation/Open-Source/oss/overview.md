---
title: "Open Source Projects by Rafay"
source: https://docs.rafay.co/oss/overview/
category: Open-Source
---

# Open Source Projects

- **B.R.A.V.E**   Create non production bare metal clusters without having access to specialized hardware or networking setup with a single command using Bare Metal Replication And Virtualization Environment (B.R.A.V.E).  [Maintainer](https://github.com/RafaySystems/brave) [Learn More](https://rafay.co/the-kubernetes-current/introducing-brave-a-new-open-source-tool-to-virtualize-bare-metal-deployments/)
- **CAPG**   [CAPG](https://github.com/kubernetes-sigs/cluster-api-provider-gcp) is the Kubernetes Cluster API (CAPI) Provider for GCP bringing declarative Kubernetes-style APIs to cluster lifecycle management.  [Contributor](https://github.com/kubernetes-sigs/cluster-api-provider-gcp)
- **Cluster Insights**   Platform teams can get insights into all the resources on a cluster to help determine how they would like to manage add-ons and applications.  [Maintainer](https://github.com/RafaySystems/getstarted/tree/master/tools/resize) [Learn More](https://docs.rafay.co/blog/2023/02/04/kubernetes-cluster-insights-for-platform-teams/)
- **EKSCTL**   [eksctl](https://eksctl.io/) is the official CLI for Amazon EKS. Users can use the eksctl CLI to create and manage Amazon EKS clusters.  [Contributor](https://github.com/eksctl-io/eksctl) [Learn More](https://eksctl.io/)
- **Multi Cluster Service Mesh**   Set up a multi-cluster service mesh to enable secure and seamless communication between services across Kubernetes clusters. The clusters can span multiple data centers, multiple providers or be a hybrid deployment.  [Maintainer](https://github.com/RafaySystems/rafay-istio-multicluster/tree/main) [Learn More](https://thenewstack.io/setting-up-multicluster-service-mesh-with-rafay-cli/)
- **OpenCost**   [OpenCost](https://www.opencost.io/) is Cloud Native Computing Foundation sandbox open source project focused on cost monitoring for cloud native environments.  [Contributor](https://github.com/opencost/opencost) [Learn More](https://www.opencost.io/)
- **Paralus**   Provide controlled, audited access to Kubernetes infrastructure with just-in-time (JIT) service account creation and user-level credential management that integrates with your RBAC and Single Sign On (SSO).  [Maintainer](https://github.com/paralus/paralus) [Learn More](https://www.paralus.io/)
- **Resize**   Slash cloud/infrastructure costs by identifying and automatically resizing over-provisioned Kubernetes resources on their clusters.  [Maintainer](https://github.com/RafaySystems/getstarted/tree/master/tools/resize)
- **Terraform Provider**   Rafay's Terraform Provider enables platform teams to configure and manage the lifecycle of all resources as Infrastructure as Code (IaC).  [Maintainer](https://github.com/RafaySystems/terraform-provider-rafay)
