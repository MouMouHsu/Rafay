---
title: "Contact Us by Email"
source: https://docs.rafay.co/contact/email/
category: Contact
---

# Email

You can stay in touch with us either via email or Slack.

## Documentation

For corrections and suggestions related to product documentation, please contact us at [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#771318140437051611160e591418).

## Support

For questions about the platform or issues you need help with, please contact us at [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#84f7f1f4f4ebf6f0c4f6e5e2e5fdaae7eb).

## Security

For questions related to the security of the platform, please contact us at [[email protected]](https://docs.rafay.co/cdn-cgi/l/email-protection#186b7d7b6d6a716c61586a797e7961367b77).

> **Important**
> Please review the [security section](https://docs.rafay.co/security/overview/) before contacting us.

---
