---
title: "Contact Rafay"
source: https://docs.rafay.co/contact/overview/
category: Contact
---

# Contact Rafay

- **Email**   [Contact us](https://docs.rafay.co/contact/email/) via email for questions and product support issues
- **Open Source**   Learn about our [open source](https://docs.rafay.co/oss/overview/) projects and initiatives
- **Security**   Interact with us [confidentially using PGP](https://docs.rafay.co/security/contact/) for security related questions and issues
- :simple-slack:{ .middle } **Slack**   Join our community on [Slack](https://docs.rafay.co/contact/slack/) to interact with our developers, architects, product and support personnel
- **Support Matrix**   Please review the official [support matrix](https://docs.rafay.co/supportmatrix/support_matrix/) before contacting us

---
