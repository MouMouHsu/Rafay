---
title: "Contact Us via Slack"
source: https://docs.rafay.co/contact/slack/
category: Contact
---

# Slack

You can stay in touch with us either via email or Slack.

[Join](https://rafaycommunity.slack.com/) our Slack Community.

> **Important**
> Upon request, for customers, partners and prospects, we can create a Private Slack Channel where you can interact privately with our support and product personnel.

---
