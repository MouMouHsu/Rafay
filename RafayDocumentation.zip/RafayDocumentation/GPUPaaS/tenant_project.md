---
title: "Projects and Settings for GPU PaaS"
source: https://docs.rafay.co/aiml/gpupaas/tenant_project/
---

# Projects & Settings

## Projects

The **Projects** section allows tenant administrators to create and manage **GPU PaaS projects** within the tenant organization. Projects provide logical isolation for GPU workloads and serve as the primary scope for organizing resources and controlling access.

Access Projects from: **Tenant Administration → Projects**

From this page, tenant admins can:

- View all existing GPU PaaS projects along with creation details
- Create new projects by specifying a project name and optional description
- Access **Project Settings** to manage project-specific configurations and permissions
- Delete projects that are no longer required

Projects are used to structure GPU PaaS usage, enabling clear separation of workloads and consistent access control across teams and use cases.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/tenantproject.png)](https://docs.rafay.co/aiml/gpupaas/img/tenantproject.png)

---

## Settings

The **Settings** section allows tenant administrators to configure **organization-wide defaults and security-related behaviors** that apply across all GPU PaaS projects.

Access Settings from: **Tenant Administration → Settings**

The following configuration areas are available:

### Default Blueprints

The **Default Blueprints** setting defines the blueprint automatically applied during **GPU PaaS cluster creation**. When enabled, all newly created clusters **inherit the default blueprint by default**, ensuring consistent baseline configurations, policies, and add-ons across projects. This setting does not restrict blueprint usage; it establishes a standard blueprint that is automatically selected unless explicitly changed during cluster creation.

### System Resource Templates

Controls the availability of **system-defined resource templates** across projects. When enabled, predefined templates can be used consistently for GPU PaaS resource provisioning.

### Drift

Controls whether **drift detection webhooks** are deployed through blueprints. When enabled, the system can detect and report configuration drift from the expected state.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/project_sett.png)](https://docs.rafay.co/aiml/gpupaas/img/project_sett.png)

### Catalog Setting

The **Catalog Setting** controls the availability of **default catalogs** for GPU PaaS projects. Tenant administrators can enable or disable individual catalogs (for example, `default-istio`, `default-rafay`, `default-aqua`, `default-helm`) to determine which catalogs are available for use within projects.

This allows organizations to control which curated services and templates are exposed to project users.

### Customize Email Body

The **Customize Email Body** setting allows tenant administrators to define **custom text or HTML content** that is appended to the **default welcome email** sent to GPU PaaS users.

This can be used to include organization-specific information, disclaimers, support contacts, or onboarding instructions. The custom content does not replace the default email message; it is added at the end of the existing email body to maintain standard system messaging while allowing customization.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/custom_email.png)](https://docs.rafay.co/aiml/gpupaas/img/custom_email.png)

### Termination Protection Settings

The **Termination Protection Settings** allow tenant administrators to prevent accidental deletion of **clusters** and **environments** through GitOps System Sync. When enabled, termination protection ensures that protected resources cannot be deleted unintentionally, adding an extra safeguard for critical GPU PaaS infrastructure.

Tenant admins can independently enable or disable protection for:

- **Clusters**
- **Environments**

### API Keys and RCTL Config Settings

The **API Keys and RCTL Config Settings** control the **expiration behavior** of API keys and RCTL configuration files used for programmatic access.

When expiry is **disabled**, API keys and RCTL configurations do not expire. When enabled, a validity period applies **only to keys and RCTL configurations created after the expiry setting is configured**.

Disabling expiry is not a recommended security practice, as it allows credentials to remain valid indefinitely.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/apikeys.png)](https://docs.rafay.co/aiml/gpupaas/img/apikeys.png)

### KubeCTL Settings

The **KubeCTL Settings** section allows tenant administrators to control **kubectl access behavior and security policies** across the tenant organization.

- **General**
  - Configure automatic de-provisioning of service accounts after a defined period of inactivity.
  - Control execution and secret access via kubectl, including:
    - Allowing read-only roles to exec into pods
    - Allowing read-only roles to access secrets
    - Restricting secret access to Organization Admins only
- **CLI Access**
- Define the validity period for kubeconfig files.
- Optionally disable kubectl CLI access.
- Require console login before allowing kubectl access.
- **Browser Access**
- Optionally disable browser-based kubectl access.

These settings help enforce secure and consistent kubectl usage across GPU PaaS environments.

### Address

The **Address** section allows tenant administrators to maintain **organization address details** associated with the tenant.

Admins can provide: * Organization name * Address lines * City, state, country, and zip code

This information is used for organizational reference and administrative purposes within the platform.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/kubectl.png)](https://docs.rafay.co/aiml/gpupaas/img/kubectl.png)

---
