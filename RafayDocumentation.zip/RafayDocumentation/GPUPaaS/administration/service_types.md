---
title: "Default Service SKUs"
source: https://docs.rafay.co/aiml/gpupaas/administration/service_types/
---

# Service SKU Types

## Default Service SKUs

### Notebooks

Notebooks in GPU PaaS enable users to seamlessly launch Jupyter notebooks with GPU-accelerated compute for AI, ML, and data science workloads. These are optimized for high-performance tasks, leveraging predefined skus for efficient resource allocation.

### Inferences

Inference in GPU PaaS enables deploying trained AI/ML models for real-time or batch predictions with GPU acceleration, optimizing performance for tasks like image recognition and anomaly detection. The Rafay console simplifies this by centralizing inference endpoint configuration, ensuring scalability, consistency, and secure access.

### AI/ML Jobs

The AI/ML Jobs feature in GPU PaaS allows users to define, configure, and execute resource-intensive AI/ML tasks, such as model training and data processing, with ease. It streamlines workflows by automating resource provisioning, ensuring consistency, and providing scalability for both experimentation and production deployments.

### Custom Services

Custom services in GPU PaaS enable users to deploy and manage services optimized for GPU-accelerated workloads. These services offer flexibility for integrating specialized AI/ML workflows, ensuring high performance and scalability.

---
