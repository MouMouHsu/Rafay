---
title: "Compute Profile for Virtual Machines"
source: https://docs.rafay.co/aiml/gpupaas/administration/vm_type/
---

# Virtual Machines

## Create a Compute Profile for Virtual Machine

This section outlines the process for creating a Compute Profile using the **Virtual Machine** compute type. Virtual machine profiles enable flexible provisioning of isolated environments within shared physical infrastructure.

Refer to the [Compute Profile Overview](https://docs.rafay.co/aiml/gpupaas/administration/compute_profile/) for general information.

---

## Steps to Create a Virtual Machine Compute Profile

- In the **Developer Console**, navigate to **Compute Profiles** from the left navigation pane.
- Click the **+ New Compute Profile** button.
- In the **Compute Profile** form:
  - **Name**: Provide a unique identifier for the profile (e.g., `vm-dev-large`)
  - **Display Name** *(Optional)*: Enter a user-friendly label (e.g., `Dev Large VM Profile`)
  - **Description** *(Optional)*: Add notes to describe the profile’s purpose or resource configuration
  - Choose the appropriate **Environment Template** from the dropdown (e.g., `env-template-9`)
  - Choose the **Template Version** (e.g., `v9`)
  - **Compute Type**: From the dropdown, select **Virtual Machine**

> ⚠️ This determines that workloads associated with this profile will be provisioned on virtualized infrastructure (VMs).

[![Compute Type - VM](https://docs.rafay.co/aiml/gpupaas/img/vm_types.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_types.png)

- Once all required fields are filled, click **Save & Continue** to proceed to configuration.

---

## Compute Profile Configuration

Once saved, the **Compute Profile Configuration** page appears.

### General

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Name | `vm-dev-large` | string | Internal identifier for the compute profile |
| Display Name | `Dev Large VM Profile` | string | User-friendly label for UI display |
| Description | *Enter Description* | string | Notes describing the profile purpose or usage |
| Allocation Type | `Dedicated` | string | Indicates whether the infrastructure is dedicated or shared |
| Environment Template | `env-template-9` | string | Template associated with the compute profile |
| Environment Template Version | `v9` | string | Version of the selected environment template |
| Compute Type | `Virtual Machines` | string | Type of infrastructure provisioned by the profile |

[![Compute Type - VM](https://docs.rafay.co/aiml/gpupaas/img/general_vms.png)](https://docs.rafay.co/aiml/gpupaas/img/general_vms.png)

### Datacenters

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Datacenter | `default-dc` | string | Select the datacenter where compute instances will be deployed. The list is automatically populated from the infrastructure inventory. |
| Exposed | `false` | boolean | Makes the datacenter visible during deployment. |
| Overridable | `false` | boolean | Allows users to modify the datacenter selection at deployment time. |

### Storage Details

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Storage Details | — | list | Select one or more storage instances to attach to the compute profile. The options are automatically fetched from existing storage service instances. |
| Exposed | `false` | boolean | Makes the storage field visible during deployment. |
| Overridable | `false` | boolean | Allows users to modify the storage selection during deployment. |

[![Compute Profile Inputs](https://docs.rafay.co/aiml/gpupaas/img/dc_storage.png)](https://docs.rafay.co/aiml/gpupaas/img/dc_storage.png)

### Advanced Configuration

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Labels | N/A | key-value | Optional metadata to help categorize and identify the compute profile |
| Annotations | N/A | key-value | Optional key-value pairs for additional context (e.g., `'env': 'dev'`) |
| Extra Configuration | N/A | key-value | Custom key-value metadata for advanced customization or integration |

[![Compute Type - VM](https://docs.rafay.co/aiml/gpupaas/img/label_vm.png)](https://docs.rafay.co/aiml/gpupaas/img/label_vm.png)

### Display Settings

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Icon URL | `https://cdn.example.com/icons/vm-dev-large.svg` | string | URL to a custom icon used to visually identify the compute profile |
| Read Me | `This profile provisions large virtual machines optimized for development use cases.` | string | Short summary describing the purpose or characteristics of the profile |

[![Compute Type - VM](https://docs.rafay.co/aiml/gpupaas/img/vm_readme.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_readme.png)

### Input Settings Table

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| **Allowed Namespaces** | `[]` | hcl | List of namespaces permitted for the configuration |
| **API Key** | `rafay-api-key-789xyz` | envVars | API key used for authenticating with the controller |
| **Controller Endpoint** | `console.qc-gpupaas.dev.rafay-edge.net` | envVars | Endpoint URL of the controller |
| **Distribution** | `k8s` | text | Kubernetes distribution in use |
| **Enable Kata Runtime** | `false` | text | Whether Kata containers runtime is enabled (true/false) |
| **Enable Kube Config** | `true` | text | Enable download or use of kubeconfig for the cluster (true/false) |
| **Enable Network Policy** | `false` | text | Indicates if Kubernetes network policies are enabled (true/false) |
| **GPU Type** | `nvidia` | text | Specifies the GPU type to be provisioned (e.g., nvidia) |
| **Host Cluster Name** | `<host-mks-cluster>` | text | Name of the hosting cluster |
| **Namespace Quota Size** | `small` | text | Specifies the namespace quota size (e.g., small, medium, large) |
| **Node affinity for vcluster** | `zone=us-west-2a` | text | Node affinity rules applied to vcluster nodes |
| **RCTL_SKIP_SERVER_CERT_VALIDATION** | `true` | envVars | Whether to skip TLS certificate validation when using RCTL |

[![Compute Type - VM](https://docs.rafay.co/aiml/gpupaas/img/input_vm.png)](https://docs.rafay.co/aiml/gpupaas/img/input_vm.png)

### Input Configuration Controls

- **Override (Checkbox)**: Allows environment-level overrides for specific input parameters. When enabled, users can modify the input value directly within their environment-specific configurations.
- **Allow Override For All**: A global control that enables the override option for all listed inputs at once. Useful for quickly granting flexibility across the entire configuration.
- **Preview Input Form**: Displays a preview of how the configured inputs will appear to users. It includes field labels, tooltips, input types, validation rules, and grouping settings.
- **Display Config (Edit)**: Opens a configuration panel where display-related settings can be customized. Options include changing the display name, adding user guidance tooltips, setting default values, selecting input types, and organizing fields into logical groups.

***Example: Edited Input for `Allowed Namespaces`***

| **Field** | **Description** |
| --- | --- |
| **Alias** | Display label shown to users (e.g., `demo-ns`) |
| **Tooltip** | Help text shown when hovering over the info icon (e.g., `Give the list of namespaces which needs to communicate with vcluster namespace as ingress`) |
| **Disabled** | Toggle to make the field read-only for end users |
| **Order/Weight** | Determines the order of fields in the UI (e.g., `180`, higher values appear lower in the form) |
| **Type** | Input type for the field (e.g., `Text`, `File Upload`, `Dropdown`) |
| **Validation Type** | Defines the validation mechanism (e.g., `Length`, `Regex`, `Required`) |
| **Validation Pattern** | Used along with validation type; in this case, sets a max length of `20` characters |
| **Section** | Logical grouping under which the field will be displayed (e.g., `Isolation through Network Policies`) |
| **Section Description** | Optional description for the section |

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/vm_example.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_example.png)

### Output Settings

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| **Name** | `generated-cluster-url` | text | Unique identifier for the output configuration. This is a required field |
| **Label** | `Cluster Access URL` | text | Display name shown in the UI for better readability (optional) |
| **Resource** | `vm-dev-large` | text | Optional reference to a resource name that this output is associated with |

- Each output entry includes **Edit** and **Delete** options on the right side, allowing modifications or removal of the configuration as needed
- The **Preview Output Form** button allows visual verification of how the output fields will be rendered in the UI

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/output_vm.png)](https://docs.rafay.co/aiml/gpupaas/img/output_vm.png)

### Schedules

The **Schedule Settings** section allows you to define automated start and stop actions for compute instances created from this compute profile. These schedules help ensure that instances run only during specific time windows, optimizing resource usage.

To create a schedule, click **Add Schedule** and provide the following details:

- **Name**: Enter a unique name for the schedule.
- **Action**: Select the operation to perform. Supported actions include start and stop.
- **Time Zone**: Choose the time zone in which the schedule should be executed.
- **Cron Expression**: Define the time and frequency for the action using a cron expression.
- **Enforce Time Window**: When enabled, the system ensures that the instance remains active only during the scheduled time window. This option applies only to start and stop actions.

Once the schedule is configured, click **Save Changes** to add it to the compute profile. All schedules defined here will automatically apply to compute instances created using this profile.

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/vm_schedule.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_schedule.png)

> Note: If the selected environment template version does not support scheduling actions, the Schedules Settings section will display a message stating “No Actions Available.” In this case, select a different template version or contact your administrator to enable scheduling capabilities.

Once all configurations are complete, click **Save Changes** to apply the updates.

---
