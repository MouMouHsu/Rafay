---
title: "Compute Profile for Kubernetes (K8s)"
source: https://docs.rafay.co/aiml/gpupaas/administration/k8s_type/
---

# K8s

## Create a Compute Profile for K8s

This section outlines the process for creating a Compute Profile using the **K8s** compute type. Kubernetes profiles are designed to provision workloads directly on managed Kubernetes clusters, offering native container orchestration and scalability.

Refer to the [Compute Profile Overview](https://docs.rafay.co/aiml/gpupaas/administration/compute_profile/) for general information.

---

## Steps to Create a K8s Compute Profile

- In the **Developer Console**, navigate to **Compute Profiles** from the left navigation pane
- Click the **+ New Compute Profile** button
- In the **Compute Profile** form:
  - **Name**: Provide a unique identifier for the profile (e.g., `k8s-prod-cluster`)
  - **Display Name** *(Optional)*: Enter a user-friendly label (e.g., `Production K8s Cluster`)
  - **Description** *(Optional)*: Add notes to describe the profile’s purpose or cluster details (e.g., `Managed K8s for prod workloads`)
  - Choose the appropriate **Environment Template** from the dropdown (e.g., `system-env-template`)
  - Choose the **Template Version** (e.g., `v9`)
  - **Compute Type**: From the dropdown, select **K8s**

> ⚠️ This determines that workloads associated with this profile will be deployed on a managed Kubernetes cluster.

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/k8s_type.png)](https://docs.rafay.co/aiml/gpupaas/img/k8s_type.png)

- Once all required fields are filled, click **Save & Continue** to proceed to configuration.

---

## Compute Profile Configuration

Once saved, the **Compute Profile Configuration** page appears.

### General

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Name | `k8s-prod-cluster` | string | Internal identifier for the compute profile |
| Display Name | `Production K8s Cluster` | string | User-friendly label for UI display |
| Description | `Managed K8s for prod workloads` | string | Notes describing the profile purpose or usage |
| Allocation Type | `Dedicated` | string | Indicates whether the infrastructure is dedicated or shared |
| Environment Template | `system-env-template` | string | Template associated with the compute profile |
| Environment Template Version | `v9` | string | Version of the selected environment template |
| Compute Type | `Kubernetes` | string | Type of infrastructure provisioned by the profile |

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/general_k8.png)](https://docs.rafay.co/aiml/gpupaas/img/general_k8.png)

### Datacenters

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Datacenter | `default-dc` | string | Select the datacenter where compute instances will be deployed. The list is automatically populated from the infrastructure inventory. |
| Exposed | `false` | boolean | Makes the datacenter visible during deployment. |
| Overridable | `false` | boolean | Allows users to modify the datacenter selection at deployment time. |

### Storage Details

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Storage Details | — | list | Select one or more storage instances to attach to the compute profile. The options are automatically fetched from existing storage service instances. |
| Exposed | `false` | boolean | Makes the storage field visible during deployment. |
| Overridable | `false` | boolean | Allows users to modify the storage selection during deployment. |

[![Compute Profile Inputs](https://docs.rafay.co/aiml/gpupaas/img/dc_storage.png)](https://docs.rafay.co/aiml/gpupaas/img/dc_storage.png)

### Advanced Configuration

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Labels | N/A | key-value | Optional metadata to help categorize and identify the compute profile |
| Annotations | N/A | key-value | Optional key-value pairs for additional context (e.g., `'env': 'prod'`) |
| Extra Configuration | N/A | key-value | Custom key-value metadata for advanced customization or integration |

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/label_k8s.png)](https://docs.rafay.co/aiml/gpupaas/img/label_k8s.png)

### Display Settings

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| Icon URL | `https://assets.company.com/icons/k8s-prod-cluster.svg` | string | URL pointing to the icon displayed on the compute profile card |
| Read Me | `This profile provisions dedicated Kubernetes clusters for production workloads` | string | Description that appears on the profile card to explain its intended use |

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/iconurl_k8s.png)](https://docs.rafay.co/aiml/gpupaas/img/iconurl_k8s.png)

### Input Settings Table

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| API Key | `rafay-api-key-12345` | envVars | API key used for authenticating with the controller |
| Auto Approve Nodes | `true` | text | Automatically approve new nodes joining the cluster |
| Blueprint Name | `default` | text | Name of the cluster blueprint |
| Blueprint Version | `latest` | text | Version of the selected blueprint |
| Cloud Credentials | `aws-creds-prod` | text | Name or reference to stored cloud credentials |
| Cluster Dedicated Control Planes | `false` | text | Whether to enable dedicated control plane nodes |
| Cluster Kubernetes Version | `v1.32.0` | text | Version of Kubernetes for the cluster |
| Cluster Labels | `{ "env": "dev", "team": "mlops" }` | json | Key-value metadata assigned to the cluster |
| Cluster Location | `sanjose-us` | text | Geographical location or region of the cluster |
| Cluster Name | `$(environment.name)$` | expression | Dynamic reference to the environment name |
| Control Plane Node(s) | `{ "cp-1": { "instanceType": "m5.large" } }` | json | Configuration for control plane nodes |
| Controller Endpoint | `console.qc-gpupaas.dev.rafay-edge.net` | envVars | URL endpoint for accessing the Rafay controller |
| Enable Kata Deployment | `false` | text | Whether to deploy with Kata Containers runtime |
| Enable Opa-gatekeeper Deployment | `true` | text | Whether to enable OPA Gatekeeper |
| High Availability (HA) | `true` | text | Enable or disable high availability mode |
| Installer Certificate TTL | `365` | text | Validity duration (days) for installer certificate |
| Kubelet Args | `{ "max-pods": "200", "cpu-manager-policy": "static" }` | json | Additional configuration passed to kubelet |
| Kubernetes Upgrade | `{ "strategy": "sequential", "drainTimeout": "600s" }` | json | Upgrade strategy for Kubernetes versions |
| Network | `{ "api": "Cilium", "version": "1.14.1" }` | json | Network policy settings or plugin config |
| Opa Constraint Template YAML | `<<YAML constraint-template opa.template>>` | hcl | YAML configuration defining OPA constraint templates |
| Opa Constraints YAML | `<<YAML constraint opa.policy>>` | hcl | YAML file with specific OPA constraints |
| Opa Excluded Namespaces | `[ "kube-system", "monitoring" ]` | hcl | List of namespaces excluded from OPA policies |
| private-key | `id_rsa` | file | File reference to the private key |
| Project | `$(environment.project.name)$` | expression | Dynamic reference to the project name |
| Proxy Config | `{ "httpProxy": "http://proxy.local:8080" }` | json | Proxy server configuration if used |
| RCTL_SKIP_SERVER_CERT_VALIDATION | `true` | envVars | Whether to bypass RCTL server certificate validation |
| System Components Placement | `{ "ingress": { "nodeSelector": { "tier": "edge" } } }` | json | Placement settings for system components |
| Worker Node(s) | `{ "worker-1": { "instanceType": "m5.xlarge", "replicas": 3 } }` | json | Configuration for worker nodes |

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/k8s_variables.png)](https://docs.rafay.co/aiml/gpupaas/img/k8s_variables.png)

### Input Configuration Controls

- **Override (Checkbox)**: Allows environment-level overrides for specific input parameters. When enabled, users can modify the input value directly within their environment-specific configurations.
- **Allow Override For All**: A global control that enables the override option for all listed inputs at once. Useful for quickly granting flexibility across the entire configuration.
- **Preview Input Form**: Displays a preview of how the configured inputs will appear to users. It includes field labels, tooltips, input types, validation rules, and grouping settings.
- **Display Config (Edit)**: Opens a configuration panel where display-related settings can be customized. Options include changing the display name, adding user guidance tooltips, setting default values, selecting input types, and organizing fields into logical groups.

***Example: Edited Input for `Cloud Credentials`***

| **Field** | **Description** |
| --- | --- |
| **Alias** | `cred_1` — Internal alias name used for reference |
| **Tooltip** | *Empty* — No tooltip text has been configured |
| **Disabled** | `true` — Field is disabled (read-only) for end users |
| **Order/Weight** | `40` — Determines field order; lower values appear higher in the form |
| **Type** | `File Upload (Text Only)` — Field accepts only text-based file uploads |
| **Validation Type** | `Regex` — Validation is performed using a regular expression |
| **Validation Pattern** | `20` — Validation pattern set to match value `20` (may be placeholder; regex pattern is unclear) |
| **Section** | `General` — Field is grouped under the "General" section |
| **Section Description** | *Empty* — No description provided for the section |

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/cred_edit.png)](https://docs.rafay.co/aiml/gpupaas/img/cred_edit.png)

### Output Settings

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| **Name** | `k8s-cluster-url` | text | Unique identifier for the output variable capturing a K8s cluster attribute (e.g., access URL) |
| **Label** | `K8s Cluster Access URL` | text | Display name shown in the UI for improved readability (optional) |
| **Resource** | `k8s-prod-cluster` | text | Optional reference to the compute profile or environment resource associated with the output |

- Each output entry includes **Edit** and **Delete** options on the right side, allowing modifications or removal of the configuration as needed
- The **Preview Output Form** button allows visual verification of how the output fields will be rendered in the UI

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/output_k8s.png)](https://docs.rafay.co/aiml/gpupaas/img/output_k8s.png)

### Schedules

The **Schedule Settings** section allows you to define automated start and stop actions for compute instances created from this compute profile. These schedules help ensure that instances run only during specific time windows, optimizing resource usage.

To create a schedule, click **Add Schedule** and provide the following details:

- **Name**: Enter a unique name for the schedule.
- **Action**: Select the operation to perform. Supported actions include start and stop.
- **Time Zone**: Choose the time zone in which the schedule should be executed.
- **Cron Expression**: Define the time and frequency for the action using a cron expression.
- **Enforce Time Window**: When enabled, the system ensures that the instance remains active only during the scheduled time window. This option applies only to start and stop actions.

Once the schedule is configured, click **Save Changes** to add it to the compute profile. All schedules defined here will automatically apply to compute instances created using this profile.

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/k8s_schedule.png)](https://docs.rafay.co/aiml/gpupaas/img/k8s_schedule.png)

> Note: If the selected environment template version does not support scheduling actions, the Schedules Settings section will display a message stating “No Actions Available.” In this case, select a different template version or contact your administrator to enable scheduling capabilities.

Once all configurations are complete, click **Save Changes** to apply the updates.

---
