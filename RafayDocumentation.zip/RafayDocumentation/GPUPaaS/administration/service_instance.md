---
title: "Service Instances"
source: https://docs.rafay.co/aiml/gpupaas/administration/service_instance/
---

# Services Instances

The Services Instance page in the GPU PaaS portal provides a unified interface for creating and managing various GPU-accelerated service instances, including Inference, Notebook, Job, and Custom Services. By leveraging service profiles and compute instances, users can deploy GPU resources to match specific requirements, whether it's running AI/ML models, executing batch jobs, or hosting custom workloads. This flexibility ensures that diverse application needs are met efficiently, maximizing the utility of available GPU resources.

This page streamlines the deployment and management process, offering detailed insights into the status, type, and configuration of services. Users can monitor their services in real-time, make adjustments as needed, and ensure optimal performance for their workloads. The Service Instance page is an essential feature for users working on GPU-intensive tasks like deep learning, data processing, or custom computational workflows, enabling faster development and improved resource utilization.

---

## Managed Service Instances

PaaS Admins can configure and launch service instances by following the steps described below.

- Access PaaS Studio and click on the **Service Instances** menu on the left to access the service instances page
- Click on **New Service Instance**. A prompt will appear to specify the following in a wizard-like experience.

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/service_mainpage.png)](https://docs.rafay.co/aiml/gpupaas/img/service_mainpage.png)

### Available Service Profiles

The list of service profiles available for use with service is displayed here. Choose the desired profile and fill in the necessary details. Service profiles are displayed in ascending order during instance creation flows.

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/list_services.png)](https://docs.rafay.co/aiml/gpupaas/img/list_services.png)

### General Configuration

#### Unique Name

Provide a unique name for the service instance (e.g. `deepcompute`). Note that you cannot change the unique name once the profile has been created.

#### Display Name

This is typically a user friendly name such as "notebook service" that will make sense to the end users. This name is what the end users will see an experience.

#### Description

Provide a multiple sentence description that will help the end users understand more details about the service.

#### Service Profiles

When ready to proceed with the selected service profile, proceed with compute instance selection. Alternatively, click **Change Service Profile** to select a different profile.

Click **Save & Continue**

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/service-input.png)](https://docs.rafay.co/aiml/gpupaas/img/service-input.png)

The Overview page appears with the inputs provided

#### Labels

Labels are optional metadata in the form of key-value pairs that will be automatically attached to the resulting service when they are launched. Labels help in categorizing and organizing services based on specific criteria like environment, project, or team.

#### Annotations

Annotations are also optional metadata in key-value pair format, but unlike labels, they are typically used for descriptive purposes rather than for categorization or filtering. Annotations provide additional context or information about the service.

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/label_ann.png)](https://docs.rafay.co/aiml/gpupaas/img/label_ann.png)

### Input Settings

Environment templates backing a service profile may require user-provided inputs during service instance creation. These inputs can be either mandatory or optional, depending on how the environment template is defined.

The service instance configuration page allows the PaaS admin to choose a service profile for the instance and optionally provide default values for these inputs. Admins can also decide whether to allow end users to override these defaults at runtime.

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/input_sett.png)](https://docs.rafay.co/aiml/gpupaas/img/input_sett.png)

- Users can either click **Save Changes** to save the configuration for later publishing, keeping the deployment status as ***Not Deployed***

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/service_waiting.png)](https://docs.rafay.co/aiml/gpupaas/img/service_waiting.png)

- Click **Deploy** to immediately proceed with publishing the changes
- On clicking **Deploy**, the service instance deployment process begins, and the status updates to **In Progress**
- To add or edit the labels and annotations, click the **Edit Configuration** button. This will direct to the Overview page, where changes to labels and annotations can be made

### Actions

The **Actions** in the instance view allow authorized users to view and execute actions configured within the environment template. Actions displayed here are derived from the associated environment template and reflect the configurations defined in the corresponding Compute Profile.

Each action appears with its variables as defined in the admin configuration. Variables marked as **Allow Override** can be modified during instance creation or execution, while variables with override disabled remain fixed and are not displayed during execution.

[![Actions List](https://docs.rafay.co/aiml/gpupaas/img/service_actions.png)](https://docs.rafay.co/aiml/gpupaas/img/service_actions.png)

For example, if the *override-allow* action variable has the override option enabled, the authorized users can modify its value before executing the action. In contrast, variables such as *not-override* or *run_strategy* with the override option disabled will still appear in the form but remain non-editable during action execution.

In cases where override is allowed, the variable value can be updated (for example, modifying the `run_strategy` value in the **Execute Action: start** form) and then **Apply** can be clicked to execute the action with the updated input.

**Confirm Action Prompt**

When an action is triggered, a confirmation dialog is displayed before execution. This dialog provides a final review of the selected action and the target instance to prevent unintended actions.

[![Confirm Action](https://docs.rafay.co/aiml/gpupaas/img/confirm_actions.jpg)](https://docs.rafay.co/aiml/gpupaas/img/confirm_actions.jpg)

- This step ensures that the action is executed intentionally.
- Click **Confirm** to proceed with the action or **Cancel** to stop the operation.

**Viewing and Executing Actions**

- The list of available actions is automatically displayed based on the selected profile.
- Only actions configured at the template level appear in this section.
- Each action includes its corresponding variables, displayed according to the alias and tooltip defined in the configuration.
- Variables marked as overridable can be edited before executing the action.
- Once configuration is verified, click **Apply** to trigger the action or **Close** to cancel.

[![Action Form](https://docs.rafay.co/aiml/gpupaas/img/services_editiing.png)](https://docs.rafay.co/aiml/gpupaas/img/services_editiing.png)

- Click **Deploy** to start the instance deployment. The page displays the deployment details, with the status initially shown as `Pending`, and then updated to `In Progress`.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/services-deploying.png)](https://docs.rafay.co/aiml/gpupaas/img/services-deploying.png)

> Note: Service Instance with the status In Progress cannot be destroyed. This restriction ensures that the deployment process is not interrupted or corrupted

Once publishing is successful, the deployment status changes to **Success**

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/service_succes.png)](https://docs.rafay.co/aiml/gpupaas/img/service_succes.png)

## View Services

When PaaS Admins click on the **Service Instances** menu on the left, a complete list of available service instances is displayed. They can search for a specific service instance by entering input into the search box. The main listing provides basic information about each service instance.

- Unique Name
- Service Type
- Creation Date
- Publish Status
- Sharing
- Actions Menu (ellipses)

To view additional details about a service instance, simply click on it. This will display all the details the administrator had configured during initial creation.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/service_search.png)](https://docs.rafay.co/aiml/gpupaas/img/service_search.png)

**Resource-Level Deployment Status Messages**

The deployment status message shown on the instance page is derived from annotations configured for each resource in the resource templates associated with the environment template used by the service profile. If no custom annotations are configured for a resource, the system displays the default environment-generated message. When annotations are configured, the corresponding custom message is displayed based on the current deployment state of that resource. During deployment, these annotations are evaluated independently for each resource, allowing resource-specific status messages to be surfaced on the instance page while retaining access to detailed environment logs.

Deployment status messages are supported for the following resource states: `In Progress`, `Success`, `Failed`, and `Waiting` for approval.

***Example***

In this example, the environment includes a single resource with a custom deployment status annotation defined in its resource template. When the service instance deployment fails for that resource, the instance page displays the configured message **“This dummy resource is failed”** under the **Reason** section.

Selecting **View Detailed Errors** opens a detailed view that shows the same custom message at the top, along with the resource name and the underlying environment logs explaining the failure.

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/message_exsp.png)](https://docs.rafay.co/aiml/gpupaas/img/message_exsp.png)

### Update Services

Follow the steps above to "View" service instances. - Click on the actions (ellipses) on the far right of a service instance and select "View Configuration". - Click **Edit** icon and PaaS Admins can now make necessary changes to the instances and save or deploy the changes.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/edit_conf.png)](https://docs.rafay.co/aiml/gpupaas/img/edit_conf.png)

---

### View Instance Schedules

If the **Service Profile** used to create a service instance includes predefined schedules (for example, start and stop actions), these schedules are automatically displayed in the **Service Instance Deployment** view.

In the example shown below, the instance `notebook2` includes two schedules:

- A **start** action scheduled to trigger every day at 7:30 PM.
- A **stop** action scheduled to trigger every day at 9:00 PM.

The next scheduled action is also displayed at the top, indicating the upcoming trigger time based on the cron expressions defined in the profile.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/instance_sched.png)](https://docs.rafay.co/aiml/gpupaas/img/instance_sched.png)

---

### Share Services

To share a service instance with selected or all projects, click on the actions (ellipses) on the far right of a service profile and select "Manage Sharing". Now, select how you wish to share the project. The options are:

- None (This is the default)
- All Projects
- Selected Projects

The ability to share service instances with other projects allows platform teams to centralize the mgmt of service profiles and share them **hierarchically** with downstream projects where they can be used by end users in multiple teams/departments.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/share_services.png)](https://docs.rafay.co/aiml/gpupaas/img/share_services.png)

---

### Delete Services

To delete a service instance, click on the actions (ellipses) on the far right of a instance and select delete.

> **Info**
> This is a destruction action and cannot be reversed. Once an instance is deleted, it is no longer available to end users for use.

If the delete action fails, the service instance moves to Delete Failed status and remains visible in this list once the status filter is changed from the default, Active. No force action is available from here. See [Force Delete](https://docs.rafay.co/aiml/gpupaas/force_delete/) to remove a service instance in Delete Failed status.

---
