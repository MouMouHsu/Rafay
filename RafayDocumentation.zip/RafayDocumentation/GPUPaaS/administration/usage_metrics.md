---
title: "Usage Metrics"
source: https://docs.rafay.co/aiml/gpupaas/administration/usage_metrics/
---

# Usage Metrics

## Introduction

The **Usage Metrics** page provides an overview of system resource utilization and performance over the last 30 days. It summarizes usage across compute instances, services, total system instances, and profile types, while also offering detailed instance-level information for deeper insights.

PaaS Admins can access the Usage Metrics page by navigating to **PaaS Studio → Usage Metrics**.

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/usage_metrics.png)](https://docs.rafay.co/aiml/gpupaas/img/usage_metrics.png)

---

## How Users Can Use This Page

- Monitor total usage trends across compute and service workloads.
- Identify which workloads are consuming the most resources.
- Review instance creation dates and statuses to ensure deployments are healthy.
- Compare compute vs. service consumption for workload planning.
- Track usage distribution across projects and profiles for resource governance.

---

## Why View This Page

- To maintain **visibility into overall system usage**.
- To **analyze resource allocation** and instance activity.
- To **support operational efficiency** by reviewing running workloads and profiles.
- To **assist with cost and capacity planning** through usage tracking.

---

## Key Widgets

### 1. **Total Usage Hours**

- Displays the **aggregate usage time** of all compute and service instances in the system.
- This metric combines both compute usage hours and service usage hours into a single total.
- Helps users understand the **overall workload consumption** across the platform in the selected period.

### 2. **Compute Usage Hours**

- Shows the **total number of hours** consumed by all compute instances.
- A compute instance is typically a workload or container running with allocated CPU/GPU resources.
- This widget allows users to track how much infrastructure capacity has been consumed for computational tasks.

### 3. **Service Usage Hours**

- Shows the **total number of hours** consumed by all service instances.
- A service instance may represent supporting or utility services (e.g., APIs, schedulers, backend services).
- This metric allows users to measure time spent by service-level components running in the system.

### 4. **Total Instances**

- Displays the **total number of active instances** in the system (including both compute and service instances).
- Provides a snapshot of system scale by indicating how many workloads and services are currently running.
- This helps administrators quickly assess deployment size.

### 5. **Profile Types**

- Displays the **total number of unique profile types** used in the system.
- A profile defines configuration and resource policies (such as CPU/GPU size, memory limits, quotas, etc.) applied when creating an instance.
- This metric shows the diversity of workload configurations in use.

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/key_metrics.png)](https://docs.rafay.co/aiml/gpupaas/img/key_metrics.png)

---

## Instance & Service Details Table

Below the summary widgets, the page provides detailed tabular information for both **Compute Instances** and **Service Instances**.

- **Instance Name:** Unique identifier or label of the instance.
- **Profile:** The compute or service profile used to provision the instance.
- **Project:** The catalog or project to which the instance belongs.
- **Usage:** Number of hours the instance has been active during the selected period.
- **Date:** The creation date of the instance.
- **Status:** The current state of the instance (e.g., *Success*).

Users can:

- Switch between **Compute Instances** and **Service Instances** using the tabs.
- Apply filters or use the search bar to narrow results.
- Review instance-level usage and validate operational health.

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/table_metrics.png)](https://docs.rafay.co/aiml/gpupaas/img/table_metrics.png)

### Filters

The **Filters** panel allows PaaS Admins to refine the list of compute or service instances displayed in the table. This helps in quickly locating relevant instances based on project, profile, or state.

#### Filter Options Available

- **Filter by Project**: Displays only the instances associated with a selected project
- **Filter by Profile**: Displays only the instances created using a specific compute or service profile
- **Filter by State**:
  - Displays instances based on their current lifecycle state
  - Available states include:
    - **All States** – Shows all instances regardless of state
    - **Running** – Instances that are currently active and consuming resources
    - **Stopping** – Instances in the process of shutting down
    - **Success** – Instances that have completed successfully
    - **Unknown** – Instances whose state cannot be determined

#### How to Use Filters

1. Click on **Filters**
2. Select one or more filter criteria (Project, Profile, State)
3. Click **Apply Filters** to refresh the list
4. Use the **Close** option to collapse the filter panel when not needed

This feature helps admins **narrow down large sets of instances** and focus only on workloads relevant to their task.

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/metrics_filter.png)](https://docs.rafay.co/aiml/gpupaas/img/metrics_filter.png)

---
