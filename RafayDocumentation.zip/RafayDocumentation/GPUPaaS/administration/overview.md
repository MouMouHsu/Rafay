---
title: "Administration for Enterprise Users"
source: https://docs.rafay.co/aiml/gpupaas/administration/overview/
---

# Overview

Administrators for GPU PaaS are privileged users in a Rafay [Org](https://docs.rafay.co/security/rbac/orgs/). They are typically members of the IT/Operations team or the Platform team in an enterprise.

They are expected to follow a few simple steps before they can start onboarding end users (developers and data scientists).

1. Create [Compute Profiles](https://docs.rafay.co/aiml/gpupaas/compute_profile/)
2. Create [Service Profiles](https://docs.rafay.co/aiml/gpupaas/service_profile/)
3. Create [Compute Instances](https://docs.rafay.co/aiml/gpupaas/compute_instance/)

The screen presents a comprehensive view of the "PaaS Studio" interface, which enables users to design and manage custom profiles and profile catalogs to meet specific requirements. It begins with the "Home" section where users can launch and manage profile catalogs, compute profiles, and service profiles, which define various specifications for services and computing resources. The "Profile Catalogs" tab highlights pre-built profiles that address common use cases, offering the option to launch these profiles into end-user projects.

The "Custom Profiles" section, allows users to create tailored profiles to meet specific requirements by defining developer experiences. Users can design profile cards, manage input fields for customization, and set up environments and templates. This functionality enables users to build and organize profiles to enhance the development process. Along with this, an overview of existing compute and service profiles is available over here, allowing users to launch these profiles and configure them according to their needs. The Developer Hub section facilitates the management of developers, profiles, and instances, streamlining the overall workflow for managing custom and profile catalogs within the platform.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/paas-overview.png)](https://docs.rafay.co/aiml/gpupaas/img/paas-overview.png)

> **Important**
> The process for GPU Clouds is different. Please review the documentation for [CSPs](https://docs.rafay.co/aiml/csp/overview/) for additional information.

---

## Separation of Duties

For larger organizations, separation of duties is generally a critical requirement to ensure that not all admins are given a super admin type role. With GPU PaaS, a special role is available called "PaaS Admin". Admins with this role can create and manage compute and service profiles, but cannot do anything more.

---
