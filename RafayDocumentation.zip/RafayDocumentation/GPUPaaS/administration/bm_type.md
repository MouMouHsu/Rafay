---
title: "Compute Profile for Baremetal"
source: https://docs.rafay.co/aiml/gpupaas/administration/bm_type/
---

# Baremetal

## Create a Compute Profile for Baremetal

This page outlines the steps to create a Compute Profile specifically for the **Baremetal** compute type. Baremetal profiles are used to provision dedicated physical infrastructure for resource-intensive or production-grade workloads.

Refer to the [Compute Profile Overview](https://docs.rafay.co/aiml/gpupaas/administration/compute_profile/) for general information.

---

## Steps to Create a Baremetal Compute Profile

- In the **Developer Console**, select **Compute Profiles** from the left navigation pane
- Click the **+ New Compute Profile** button
- In the **Compute Profile** form:
  - **Name**: Provide a unique identifier (e.g., `prod-large`)
  - **Display Name**: Enter a user-friendly name (e.g., `Large production workloads`)
  - **Description** *(Optional)*: Add relevant information about this profile's purpose or configuration
  - Choose the appropriate **Environment Template** from the dropdown (e.g., `env-template-587788`)
  - Choose the **Template Version** (e.g., `v5`)
  - From the **Compute Type** dropdown, select **Baremetal**

> ⚠️ This determines that the compute instances launched using this profile will run on physical bare metal infrastructure.

[![Compute Type - Baremetal](https://docs.rafay.co/aiml/gpupaas/img/baremetal_type.png)](https://docs.rafay.co/aiml/gpupaas/img/baremetal_type.png)

- Once all fields are configured, click **Save & Continue**.

---

## Compute Profile Configuration

Once saved, the **Compute Profile Configuration** page appears.

### General

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Name | `prod-large` | string | Internal identifier for the compute profile |
| Display Name | `Production Large` | string | User-friendly label for UI display |
| Description | `High-capacity prod` | string | Notes describing the profile purpose or usage |
| Allocation Type | `Dedicated` | string | Indicates whether the infrastructure is dedicated or shared |
| Environment Template | `production-template` | string | Template associated with the compute profile |
| Environment Template Version | `v.587788` | string | Version of the selected environment template |
| Compute Type | `Bare Metals` | string | Type of infrastructure provisioned by the profile |

[![Compute Profile Inputs](https://docs.rafay.co/aiml/gpupaas/img/genera_bm.png)](https://docs.rafay.co/aiml/gpupaas/img/genera_bm.png)

### Datacenters

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Datacenter | `default-dc` | string | Select the datacenter where compute instances will be deployed. The list is automatically populated from the infrastructure inventory. |
| Exposed | `false` | boolean | Makes the datacenter visible during deployment. |
| Overridable | `false` | boolean | Allows users to modify the datacenter selection at deployment time. |

### Storage Details

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Storage Details | — | list | Select one or more storage instances to attach to the compute profile. The options are automatically fetched from existing storage service instances. |
| Exposed | `false` | boolean | Makes the storage field visible during deployment. |
| Overridable | `false` | boolean | Allows users to modify the storage selection during deployment. |

[![Compute Profile Inputs](https://docs.rafay.co/aiml/gpupaas/img/dc_storage.png)](https://docs.rafay.co/aiml/gpupaas/img/dc_storage.png)

### Advanced Configuration

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Labels | N/A | key-value | Optional metadata to help categorize and identify the compute profile |
| Annotations | N/A | key-value | Optional key-value pairs for additional context (e.g., `'env': 'dev'`) |
| Extra Configuration | N/A | key-value | Custom key-value metadata for advanced customization or integration |

[![Compute Type - Baremetal](https://docs.rafay.co/aiml/gpupaas/img/label_config.png)](https://docs.rafay.co/aiml/gpupaas/img/label_config.png)

### Design Profile Card

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Icon URL | N/A | string | URL to a custom icon used to visually identify the compute profile |
| Read Me | N/A | string | Short summary describing the purpose or characteristics of the profile |

[![Compute Type - Baremetal](https://docs.rafay.co/aiml/gpupaas/img/readme.png)](https://docs.rafay.co/aiml/gpupaas/img/readme.png)

### Input Settings Table

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| **API Key** | `12345-abcde-67890-fghij` | envVars | API key for authentication with the controller |
| **cluster_name** | `partner-pravin-b` | text | Name of the target Kubernetes cluster |
| **Controller Endpoint** | `console.rafay.co` | envVars | Endpoint for the Rafay controller |
| **GPU Type** | `nvidia` | text | Type of GPU required (e.g., `nvidia`, `amd`) |
| **host_cluster_name** | `democluster1` | text | Name of the hosting cluster |
| **Ingress Domain** | `Rafay` | text | Domain for ingress routing |
| **Ingress IP** | `35.201.123.45` | text | IP address to expose services via ingress |
| **Ingress Namespace** | `ingress-nginx` | text | Kubernetes namespace for ingress controller deployment |
| **Notebook Profile** | `Minimal environment` | text | Environment type for the notebook workload |
| **Project** | `$(environment.project.name)$` | expression | Name of the associated project, auto-filled dynamically |
| **RCTL_SKIP_SERVER_CERT_VALIDATION** | `true` | envVars | Skip cert validation during controller interaction (boolean) |

[![Compute Type - Baremetal](https://docs.rafay.co/aiml/gpupaas/img/input_settings.png)](https://docs.rafay.co/aiml/gpupaas/img/input_settings.png)

### Input Configuration Controls

- **Override (Checkbox)**: Enables environment-level overrides for a specific input parameter. When selected, users can customize the value of that input in their environment-specific configurations.
- **Allow Override For All**: A global toggle to enable override capability across all listed inputs in one click. Useful when overrides need to be enabled for all fields in the configuration profile.
- **Preview Input Form**: Clicking **Preview Input Form** displays how the configured inputs appear to users. It includes the field labels, tooltips, input types, validation, and grouping as defined in the configuration.
- **Display Config (Edit)**: Opens a configuration panel that allows customization of how the input field appears in the environment form. It can be used to change the display name, add tooltips for user guidance, set default values, define input types, or group fields for better organization.

***Example: Edited Input for `cluster_name`***

| **Field** | **Description** |
| --- | --- |
| **Alias** | Display label shown to users (e.g., `cluster1`) |
| **Tooltip** | Help text shown when hovering over the info icon |
| **Disabled** | Toggle to make the field read-only for end users |
| **Order/Weight** | Determines the order of fields in the UI (lower values appear first) |
| **Type** | Input type for the field (e.g., Text, File Upload, Dropdown) |
| **Validation Type** | Defines the validation mechanism (e.g., Length, Regex, Required) |
| **Validation Pattern** | Used along with validation type; in this case, sets a max length of 20 chars |
| **Section** | Logical grouping under which the field will be displayed (e.g., General) |
| **Section Description** | Optional description for the section |

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/edit_input.png)](https://docs.rafay.co/aiml/gpupaas/img/edit_input.png)

### Output Settings

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| **Name** | `output-cluster` | text | Unique identifier for the output configuration. This is a required field |
| **Label** | `Cluster Output` | text | Display name shown in the UI for better readability (optional) |
| **Resource** | `k8s-cluster-main` | text | Optional reference to a resource name that this output is associated with |

- Each output entry includes **Edit** and **Delete** options on the right side, allowing modifications or removal of the configuration as needed
- The **Preview Output Form** button allows visual verification of how the output fields will be rendered in the UI

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/output_setting.png)](https://docs.rafay.co/aiml/gpupaas/img/output_setting.png)

### Schedules

The **Schedule Settings** section allows you to define automated start and stop actions for compute instances created from this compute profile. These schedules help ensure that instances run only during specific time windows, optimizing resource usage.

To create a schedule, click **Add Schedule** and provide the following details:

- **Name**: Enter a unique name for the schedule.
- **Action**: Select the operation to perform. Supported actions include start and stop.
- **Time Zone**: Choose the time zone in which the schedule should be executed.
- **Cron Expression**: Define the time and frequency for the action using a cron expression.
- **Enforce Time Window**: When enabled, the system ensures that the instance remains active only during the scheduled time window. This option applies only to start and stop actions.

Once the schedule is configured, click **Save Changes** to add it to the compute profile. All schedules defined here will automatically apply to compute instances created using this profile.

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/bm_schedules.png)](https://docs.rafay.co/aiml/gpupaas/img/bm_schedules.png)

> Note: If the selected environment template version does not support scheduling actions, the Schedules Settings section will display a message stating “No Actions Available.” In this case, select a different template version or contact your administrator to enable scheduling capabilities.

Once all configurations are complete, click **Save Changes** to apply the updates.

---
