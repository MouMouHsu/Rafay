---
title: "Centralized Audit Logs"
source: https://docs.rafay.co/aiml/gpupaas/administration/audit/
---

# Audit Logs

A reverse chronological and immutable audit trail is maintained in the Rafay Platform. An audit log is generated for every action performed by both end users and the administrators (i.e. Org Admin, PaaS Admins etc). Organizations can optionally stream the centralized audit logs in a real time basis to their organizations' SIEM.

- **Centralized Audit Logs**   Centrally aggregate, view and monitor audit logs.  [Learn More](https://docs.rafay.co/security/audit/)
- **Stream Audit Logs to SIEM**   Stream the centralized audit logs to your SIEM.  [Learn More](https://docs.rafay.co/integrations/siem/overview/)
