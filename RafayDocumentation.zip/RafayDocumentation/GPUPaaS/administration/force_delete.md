---
title: "Force Delete"
source: https://docs.rafay.co/aiml/gpupaas/administration/force_delete/
---

# Force Delete and Destroy

**Release Information**
 This feature is available from release **v3.1-41** onwards.

Force Delete is a recovery action for compute instances and services that are in Delete Failed status. It does not attempt to reach the infrastructure at all. It only removes the associated records, so any infrastructure that is still running stays running with no remaining handle to reach it.

---

## Availability

Force Delete applies only to compute instances and services that are in Delete Failed status. It is not shown for instances or services in other states, where the available action remains View only. This applies regardless of whether the instance or service was created using the custom method or the native method.

Force Delete is available only in Ops Console, to a partner admin. In SKU Studio console, an instance or service in Delete Failed status can be viewed, but no force action is available on it there.

In the instances list in Ops Console, the Actions menu for an instance or service in Delete Failed status shows View and Force Delete. This applies across resource types, including Bare Metal, Virtual Machines, Kubernetes, Dev Pods, and VCluster. Selecting Force Delete opens a confirmation dialog, which requires the instance name to be entered before the action can be confirmed.

[![Force Delete action in the Ops Console instances list](https://docs.rafay.co/aiml/gpupaas/img/instance_delete.png)](https://docs.rafay.co/aiml/gpupaas/img/instance_delete.png)

In Ops Console, under Cloud Services, Overview, the Instances tab lists instance counts by status, including Delete Failed, for each resource type. Selecting a resource type from this view leads to its instances, where Force Delete can be performed on the ones in Delete Failed status.

---

## Visibility

### SKU Studio

Compute instances and services in Delete Failed status are visible in SKU Studio console. A status filter, set to Active by default, can be changed to also show instances and services in Delete Failed status.

[![SKU Studio console showing an instance in Delete Failed status](https://docs.rafay.co/aiml/gpupaas/img/sku_deletefailed.png)](https://docs.rafay.co/aiml/gpupaas/img/sku_deletefailed.png)

### Developer Hub

Compute instances and services in Delete Failed status are also visible in Developer Hub, in the same list view as active ones, across Bare Metal, Virtual Machines, Clusters, and Notebooks.

[![Developer Hub list view showing an instance in Delete Failed status](https://docs.rafay.co/aiml/gpupaas/img/devhub_failed.png)](https://docs.rafay.co/aiml/gpupaas/img/devhub_failed.png)

An instance or service in Delete Failed status keeps its record until that record is removed. Because duplicate names are not allowed, a new instance or service cannot be created with the same name while the failed one still exists. Contact a partner admin to remove it using Force Delete in Ops Console.

---

## Force Delete

In Ops Console, navigate to Cloud Services, Overview, and select a resource type. In its instances list, open the Actions menu for an instance or service in Delete Failed status, and select Force Delete.

Force Delete removes the PaaS record, EaaS record, and environment record associated with the compute instance or service, and releases the reserved inventory. It makes no attempt to reach the cloud. Any infrastructure still running stays running, with no handle left to reach it. The confirmation dialog states that the operation deletes the instance object from the controller, and may leave behind dangling resources associated with the environment.

> **Warning**
> Force Delete can leave dangling resources behind.

[![Force Delete action in the Ops Console instances list](https://docs.rafay.co/aiml/gpupaas/img/force_delete.png)](https://docs.rafay.co/aiml/gpupaas/img/force_delete.png)

[![Delete Instance confirmation dialog for Force Delete](https://docs.rafay.co/aiml/gpupaas/img/delete_confirm.png)](https://docs.rafay.co/aiml/gpupaas/img/delete_confirm.png)

---

## API endpoints

### Project scoped

Used when the compute instance or service does not belong to a workspace.

```
POST /apis/paas.envmgmt.io/v1/projects/{project}/computeinstances/{name}/remove?force=true
POST /apis/paas.envmgmt.io/v1/projects/{project}/services/{name}/remove?force=true
```

### Workspace scoped

Used when the compute instance or service belongs to a workspace. The project scoped routes do not reach a resource that belongs to a workspace.

```
POST /apis/paas.envmgmt.io/v1/projects/{project}/workspaces/{workspace}/computeinstances/{name}/remove?force=true
POST /apis/paas.envmgmt.io/v1/projects/{project}/workspaces/{workspace}/services/{service}/remove?force=true
```

---
