---
title: "Token Budgets"
source: https://docs.rafay.co/aiml/gpupaas/administration/token_budget/
---

# Token Budgets

**Release Information**
 This feature is available from release **v3.1-41** onwards.

Inferencing against large language models can be expensive, and usage is easy to lose track of once model deployments and endpoints are available to end users. Rate limiting alone controls how *often* a user can call a model, but it says nothing about how much that usage actually costs. Organizations need a way to keep that spend predictable, fairly distributed, and within budget.

Token Budgets addresses this by letting administrators define Monthly and Daily spend limits, in currency terms, and have them enforced automatically against end user inferencing. Budgets can be set at the organization, project, and user level, with alerts that notify the right people before a limit is reached.

In the sections below, we describe how budgets are configured, and how they're enforced

---

## Organization, Project, and User Budgets

**Navigate to:** SKU Management → Token Budgets

Configuring budgets at any level, organization, project, or user, is a **Tenant Admin** or **Organization Admin** action; end users cannot set or change budgets themselves, only view their own status as described later in Visibility for End Users.

Every tenant can set an organization wide Monthly and/or Daily budget as an overall ceiling. This is optional. A tenant can choose to run with no organization level cap and rely on project and user level budgets instead. Entering 0 at the organization level is treated as an unlimited budget for that period, since there's no higher level for it to fall back to. Amounts are entered and displayed in the currency configured for your partner in the ops console; currency isn't chosen per budget.

The overview page shows the active organization's Monthly and Daily budget, current spend, and alert threshold at a glance.

[![Overview](https://docs.rafay.co/aiml/gpupaas/img/overview.png)](https://docs.rafay.co/aiml/gpupaas/img/overview.png)

Admins configure it from the **Set Budget** action on this card.

[![Set Budget](https://docs.rafay.co/aiml/gpupaas/img/org_budget_btn.png)](https://docs.rafay.co/aiml/gpupaas/img/org_budget_btn.png)

**Set Budget** opens the **Set Organization Budget** dialog, where the Monthly and Daily amounts, alert thresholds, and notification recipients are entered.

[![Org Budget](https://docs.rafay.co/aiml/gpupaas/img/org_budget_dialog.png)](https://docs.rafay.co/aiml/gpupaas/img/org_budget_dialog.png)

Below the organization level, administrators can set a Default Project Budget that automatically applies to every project, existing and newly created, so they don't have to configure budgets project by project. Projects following the default are shown with a **DEFAULT** tag. Any individual project can still be overridden with its own Monthly and Daily amounts when it needs more (or less) than the default, for example a project running heavier AI workloads. A project with neither a default nor an override falls back to the organization level budget. Entering 0 for a period at the project level means no cap at that level specifically; the org budget still applies, which is a different meaning from entering 0 at the org level.

Before any default is configured, the Default Project Budget card shows "No default set for new projects" and its overflow menu (**⋯**) offers only **Set Budget**.

[![Default Project Unset](https://docs.rafay.co/aiml/gpupaas/img/default_proj_unset.png)](https://docs.rafay.co/aiml/gpupaas/img/default_proj_unset.png)

**Set Budget** opens the **Set Project Default Budget** dialog, where the Monthly and Daily amounts, Alert Thresholds (added individually via an **Add threshold** button), Notification Recipients, and an option to send email alerts when the daily budget crosses a threshold are entered.

[![Set Project Default](https://docs.rafay.co/aiml/gpupaas/img/set_proj_default.png)](https://docs.rafay.co/aiml/gpupaas/img/set_proj_default.png)

A project can also show **No cap — org budget applies** in the list, drawing directly on the organization budget with no project-level cap of its own. Its **Set Project Budget** dialog shows the Monthly and Daily fields empty, with only placeholder text (for example "e.g. 5000") rather than a configured value. This is a different state from a 0 entered deliberately at the project level.

The project list shows each project's budget, remaining balance, and utilization, with the **DEFAULT** tag marking projects that follow the shared default. Each row's overflow menu (**⋯**) offers **View Details** and **Edit Budget**; **Delete Budget** only appears for a project that has its own override budget, since a project still on the default has no project-level budget record to delete.

[![Project List](https://docs.rafay.co/aiml/gpupaas/img/project_list.png)](https://docs.rafay.co/aiml/gpupaas/img/project_list.png)

The **Set Project Budget** button above the table gives a project its own budget for the first time, one that then takes precedence over the Default Project Budget. It opens the **Set Project Budget** dialog, where the Monthly and Daily amounts, alert thresholds, and notification recipients are entered for that project.

[![Project Budget](https://docs.rafay.co/aiml/gpupaas/img/set_proj.png)](https://docs.rafay.co/aiml/gpupaas/img/set_proj.png)

**Edit Budget** on a project row's overflow menu (**⋯**) is for a project that already has its own budget. It opens the same dialog, labeled **Edit Project Budget** in that case, pre-filled with the project's existing Monthly and Daily amounts, alert thresholds, and notification recipients so they can be changed.

[![Project Budget](https://docs.rafay.co/aiml/gpupaas/img/project_budget_dialog.png)](https://docs.rafay.co/aiml/gpupaas/img/project_budget_dialog.png)

Choosing **View Details** on a project opens its Budget Details view, with a **Monthly**/**Daily** toggle to switch between periods. For the selected period, it shows the project's Total Budget, Spend to Date, Utilization, Remaining balance, and exactly when it resets. The table can also be exported as CSV.

Below that, a Users in this Project table breaks spend down per user, showing each user's Spend, Custom Limit, Utilization, and Remaining.

[![Budget Details](https://docs.rafay.co/aiml/gpupaas/img/budget_details.png)](https://docs.rafay.co/aiml/gpupaas/img/budget_details.png)

A user with their own budget shows their specific Custom Limit. A user without one shows **No cap — org budget applies** across Custom Limit, Utilization, and Remaining, the same fallback text used at the project level, since that user is falling through to whatever budgets apply above them, namely this project's budget and the organization budget beyond that, rather than a configured limit of their own.

[![Budget Details](https://docs.rafay.co/aiml/gpupaas/img/no_users.png)](https://docs.rafay.co/aiml/gpupaas/img/no_users.png)

The same pattern applies to users. A Default User Budget covers all users, and any user can be given an individual override. A user's budget follows them across every project they work in rather than being tied to a single project, so a user who contributes to multiple projects draws from one personal Monthly/Daily allowance no matter which project they're using at the time.

Before any default is configured, the Default User Budget card shows "No default set for new users" and its overflow menu (**⋯**) offers only **Set Budget**.

[![Default User Unset](https://docs.rafay.co/aiml/gpupaas/img/default_user_unset.png)](https://docs.rafay.co/aiml/gpupaas/img/default_user_unset.png)

**Set Budget** opens the **Set User Default Budget** dialog. It shows the Organization the default applies to, and the Monthly and Daily Budget amounts, either of which can be set on its own. Clearing a field removes that period's budget, and entering 0 means no cap at that level; the org budget still applies.

[![Set User Default](https://docs.rafay.co/aiml/gpupaas/img/set_users_default.png)](https://docs.rafay.co/aiml/gpupaas/img/set_users_default.png)

Once a default is set, the card's overflow menu gains **Edit Budget** and **Delete Budget**, so the org wide default can be changed or removed entirely.

[![Default User Menu](https://docs.rafay.co/aiml/gpupaas/img/default_user_menu.png)](https://docs.rafay.co/aiml/gpupaas/img/default_user_menu.png)

**Edit Budget** on the card opens the same dialog, labeled **Edit User Default Budget**, pre-filled with the existing Monthly and Daily amounts.

The Users tab mirrors the Projects tab, with its own Default User Budget card and a per-user table; the **Set User Budget** button adds a new override, and each user row has its own **Edit Budget** action.

[![Users Tab](https://docs.rafay.co/aiml/gpupaas/img/users_tab.png)](https://docs.rafay.co/aiml/gpupaas/img/users_tab.png)

**Edit Budget** on a user row opens the **Edit User Budget** dialog (or **Set User Budget** when adding a new override).

[![User Budget](https://docs.rafay.co/aiml/gpupaas/img/users_budget_dialog.png)](https://docs.rafay.co/aiml/gpupaas/img/users_budget_dialog.png)

---

## Alerts & Notifications

Any budget, at the organization, project, or user level, can carry one or more alert thresholds, such as 80%. Crossing a threshold sends an email to that budget's notification recipients, added as a list of email addresses, so admins can react before usage is actually blocked.

[![Alert Thresholds](https://docs.rafay.co/aiml/gpupaas/img/alert_thresholds.png)](https://docs.rafay.co/aiml/gpupaas/img/alert_thresholds.png)

---

## How Budgets Are Enforced

Each inferencing request is checked against every budget that applies to it: the organization, the project it's made in, and the requesting user's own budget. If any one of those is exhausted for the current period, the request is blocked, regardless of whether the others still have room. A user with budget left can simply continue working in a different project if the one they're in has hit its limit.

Budgets at different levels are independent caps rather than a shared pool. The organization budget is not subdivided across projects, so the total of all project budgets can be larger than the organization budget without conflict. What determines whether a request goes through is each level's own consumption against its own limit.

Enforcement happens before a request is admitted, based on budget state at that moment, not by cutting a response short mid stream. A request that's allowed while just under the limit is left to complete even if its cost pushes spend slightly past the cap. It's the *next* request that gets blocked.

As a concrete example, a user with a $100 monthly budget and a $20 daily budget can spend up to $20 on any day of their choosing during the month. The daily allowance doesn't need to be used every day, and it doesn't carry over if it isn't. As long as running spend for the month stays under $100, inferencing keeps working. Once the monthly cap is hit, it stops for the rest of that month even on days when the daily allowance would otherwise still be available.

There is currently no self service way for a user to request more budget from within the product. A user who hits a limit should contact their Rafay tenant or organization admin directly to have the relevant budget raised.

[![Blocked Request](https://docs.rafay.co/aiml/gpupaas/img/blocked_request.png)](https://docs.rafay.co/aiml/gpupaas/img/blocked_request.png)

> Note: Monthly and Daily budgets reset on a fixed schedule. At reset, spend to date returns to zero and the budget amount stays the same. Any unused amount from the prior period is not carried forward or added on top of the new period's allowance. For example, a user with $34 remaining out of a $100 monthly budget on the last day of the month starts the next month with $0 spent against the same $100 budget; the unused $34 is not added on top.

---

## Visibility for End Users

**Navigate to:** Developer Hub → Token Factory → Token Usage → My Budget

End users can see their own budget status without going through an admin. The My Budget tab shows Monthly and Daily spend to date, the budget amount, remaining balance, and when the period resets. It's a read only view scoped to that individual user, and shows the same Monthly/Daily allowance and spend regardless of which project is currently selected, since a user's budget is org-wide rather than tied to any one project. It's tagged **DEFAULT** when the user is inheriting the Default User Budget rather than an override.

[![My Budget](https://docs.rafay.co/aiml/gpupaas/img/my_budget.png)](https://docs.rafay.co/aiml/gpupaas/img/my_budget.png)

---
