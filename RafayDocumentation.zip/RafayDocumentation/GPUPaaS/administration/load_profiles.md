---
title: "Load Profiles and Templates"
source: https://docs.rafay.co/aiml/gpupaas/administration/load_profiles/
---

# Load SKUs and Templates

## Prerequisites

Ensure the following requirements are met before starting:

- Package URLs:
  - URL to download the installer package for profiles/templates and dependencies
  - URL to download template images (required only for air-gapped controllers)
- Access to Ops Console of the target Rafay Controller with Partner Admin permissions
- A NOC node (Ubuntu, AMD architecture) for setup with:
  - Access to the controller domain
  - Minimum 130 GB free disk space
  - Python 3.x installed

---

## Setup

### 1. Create Partner API Key

1. Login to the controller Ops Console. *Example: `https://ops-console.<example.com>`*.
2. Ensure the user account has Partner Admin access.
3. Navigate to **Users**.
4. Locate the username and click the options menu (⋮).
5. Select **Manage Keys** [![Saving changes to profile](https://docs.rafay.co/aiml/gpupaas/img/user_api.png)](https://docs.rafay.co/aiml/gpupaas/img/user_api.png)
6. Click on **New API Key**
7. Copy and securely store the generated API key for use in the configuration file. [![Saving changes to profile](https://docs.rafay.co/aiml/gpupaas/img/api_key.png)](https://docs.rafay.co/aiml/gpupaas/img/api_key.png)

---

### 2. Download the Package

1. Create a setup directory. *Example: `packagesetup`*
2. Download the package from the URLs provided by Rafay into the setup directory `packagesetup`.
  - Download the images package only for air-gapped controllers.
3. Extract the downloaded packages inside the setup directory `packagesetup`.
  - Extract the images package only if downloaded.

After extraction, the directory contains:

```
catalog-templates.tar.gz
config.yaml
loader-utility.py
Changelog.md
```

---

## Configuring `config.yaml`

The `config.yaml` file must be updated before running the loader utility.

Example configuration:

```
# environment
hostenv: <hostenv>
opsenv: <opsenv>
# API key
apikey: <apikey>
# Project name
projectname: default-catalog
untar: True
load_images: False
images_file_name: rafay-cluster-images-3.1.38.tar.gz
```

### Update the following fields

- `<hostenv>` → Controller console URL (*Example: `console.<example.com>`*)
- `<opsenv>` → Ops Console URL (*Example: `ops-console.<example.com>`*)
- `load_images`
  - `True` → Air-gapped controller (images are loaded into controller registry)
  - `False` → Templates pull images from Rafay Nexus registry

If `load_images` is set to `True`, ensure the images package is downloaded and available in the extracted directory.

> Note: Optionally, update projectname if templates need to be loaded to a project other than default-catalog.

---

## Loading Profiles and Templates

From the setup directory, run:

```
python3 loader-utility.py
```

After successful execution:

- Templates appear under Template Catalog in the Infra Portal.
- Profiles appear under Profile Catalog in SKU Studio.

---
