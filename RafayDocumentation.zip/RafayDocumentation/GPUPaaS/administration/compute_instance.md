---
title: "Managed Compute Instances"
source: https://docs.rafay.co/aiml/gpupaas/administration/compute_instance/
---

# Compute Instances

In addition to being able to create and curate "compute profiles" and "service profiles", admins with a PaaS Admin role can also launch and operate compute instances and services as a "managed service" for their users.

There are situations where administrators will need to deploy and operate compute and service instances on behalf of their end users. For example, an organization may want to provide their Data Scientists and ML Researchers with a "managed service" internally for MLOps. To deliver this, the administrator can deploy Rafay's [**Kubeflow based MLOps Platform**](https://docs.rafay.co/mlops-kubeflow/overview/) (a service profile) and the "compute instance" needed to operate it.

---

## Managed Compute Instance

To create a compute instance, access PaaS Studio and navigate to the home page. The page provides options to manage instances, including compute instances, which can be customized to meet specific requirements. Click on the **Compute Instances** menu on the left to access the compute instances page.

Click on **New Compute Instance**. A prompt will appear to specify the following in a wizard-like experience.

The workflow is identical to the end user workflows for a [compute instance](https://docs.rafay.co/aiml/users/compute_overview/).

> **Info**
> A good example of a compute instance managed by an admin is a large, dedicated cluster with 100 GPUs meant for training of a LLM. Clusters like this need to have a high uptime and operational issues can result in significant delays to the training job.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/compute_instance_page.png)](https://docs.rafay.co/aiml/gpupaas/img/compute_instance_page.png)

### Available Compute Profiles

The list of compute SKUs available for use is displayed here. Choose the desired profile and fill in the necessary details. Compute Profiles are displayed in ascending order during instance creation flows.

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/available_computeprofiles.png)](https://docs.rafay.co/aiml/gpupaas/img/available_computeprofiles.png)

#### Unique Name

Provide a unique name for the service profile (e.g. gpu-instance-prod). Note that you cannot change the unique name once the profile has been created.

#### Display Name

This is typically a user friendly name such as "gpu-instance-prod" that will make sense to the end users. This name is what the end users will see an experience.

#### Description

Provide a multiple sentence description that will help the end users understand more details about the compute instance.

#### Compute Profile

When ready to proceed with the selected compute profile, click **Save & Continue**. Alternatively, click **Change Compute Profile** to select a different profile

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/selecting-cp.png)](https://docs.rafay.co/aiml/gpupaas/img/selecting-cp.png)

The Overview page will display the Deploying Status as Waiting while the process is pending.

#### Labels

Labels are optional metadata in the form of key-value pairs that will be automatically attached to the resulting compute instances when they are launched. Labels help in categorizing and organizing compute instances based on specific criteria like environment, project, or team.

#### Annotations

Annotations are also optional metadata in key-value pair format, but unlike labels, they are typically used for descriptive purposes rather than for categorization or filtering. Annotations provide additional context or information about the compute instance.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/ci_config.png)](https://docs.rafay.co/aiml/gpupaas/img/ci_config.png)

- Users can either click **Save Changes** to save the configuration for later publishing, keeping the deployment status as ***Not Deployed***

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/not-deployed.png)](https://docs.rafay.co/aiml/gpupaas/img/not-deployed.png)

- Click **Deploy** to immediately proceed with publishing the changes
- On clicking **Deploy**, the instance deployment process begins, and the status updates to **In Progress**
- To add or edit the labels and annotations, click the **Edit Configuration** button. This will direct to the Overview page, where changes to labels and annotations can be made

### Actions

The **Actions** in the instance view allow authorized users to view and execute actions configured within the environment template. Actions displayed here are derived from the associated environment template and reflect the configurations defined in the corresponding Compute Profile.

Each action appears with its variables as defined in the admin configuration. Variables marked as **Allow Override** can be modified during instance creation or execution, while variables with override disabled remain fixed and are not displayed during execution.

[![Actions List](https://docs.rafay.co/aiml/gpupaas/img/action_deploymnt.png)](https://docs.rafay.co/aiml/gpupaas/img/action_deploymnt.png)

For example, if the *override-allow* action variable has the override option enabled, the authorized users can modify its value before executing the action. In contrast, variables such as *not-override* or *run_strategy* with the override option disabled will still appear in the form but remain non-editable during action execution.

In cases where override is allowed, the variable value can be updated (for example, modifying the `run_strategy` value in the **Execute Action: start** form) and then **Apply** can be clicked to execute the action with the updated input.

**Confirm Action Prompt**

When an action is triggered, a confirmation dialog is displayed before execution. This dialog provides a final review of the selected action and the target instance to prevent unintended actions.

[![Confirm Action](https://docs.rafay.co/aiml/gpupaas/img/confirm_actions.jpg)](https://docs.rafay.co/aiml/gpupaas/img/confirm_actions.jpg)

- This step ensures that the action is executed intentionally.
- Click **Confirm** to proceed with the action or **Cancel** to stop the operation.

**Viewing and Executing Actions**

- The list of available actions is automatically displayed based on the selected profile.
- Only actions configured at the template level appear in this section.
- Each action includes its corresponding variables, displayed according to the alias and tooltip defined in the configuration.
- Variables marked as overridable can be edited before executing the action.
- Once configuration is verified, click **Apply** to trigger the action or **Close** to cancel.

[![Action Form](https://docs.rafay.co/aiml/gpupaas/img/edit_actions.png)](https://docs.rafay.co/aiml/gpupaas/img/edit_actions.png)

- Click **Deploy** to start the instance deployment. The page displays the deployment details, with the status initially shown as `Pending`, and then updated to `In Progress`.

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/waiting_cis.png)](https://docs.rafay.co/aiml/gpupaas/img/waiting_cis.png)

Once publishing is successful, the deployment status changes to **Success**

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/success_ci.png)](https://docs.rafay.co/aiml/gpupaas/img/success_ci.png)

### View Compute Instances

When PaaS Admins click on the compute instance menu on the left, the entire list of compute instances available are listed. They can search for the compute instances by providing input into the search box. Some basic information about a compute instance is shown to the admin in the main listing.

- Unique Name
- Creation Date
- Publish Status
- Sharing
- Actions Menu (ellipses)

To view additional details about a compute instance, simply click on it. This will display all the details the administrator had configured during initial creation.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/view_ci.png)](https://docs.rafay.co/aiml/gpupaas/img/view_ci.png)

**Resource-Level Deployment Status Messages**

The deployment status message shown on the instance page is derived from annotations configured for each resource in the [resource templates](https://docs.rafay.co/env_manager/templates/resource_templates/) associated with the environment template used by the compute profile. If no custom annotations are configured for a resource, the system displays the default environment-generated message. When annotations are configured, the corresponding custom message is displayed based on the current deployment state of that resource. During deployment, these annotations are evaluated independently for each resource, allowing resource-specific status messages to be surfaced on the instance page while retaining access to detailed environment logs.

Deployment status messages are supported for the following resource states: `In Progress`, `Success`, `Failed`, and `Waiting` for approval.

***Example***

In this example, the environment includes a single resource with a custom deployment status annotation defined in its resource template. When the compute instance deployment fails for that resource, the instance page displays the configured message **“This dummy resource is failed”** under the **Reason** section.

Selecting **View Detailed Errors** opens a detailed view that shows the same custom message at the top, along with the resource name and the underlying environment logs explaining the failure.

[![High Level Steps](https://docs.rafay.co/aiml/gpupaas/img/message_ex.png)](https://docs.rafay.co/aiml/gpupaas/img/message_ex.png)

### Update Compute Instance

Follow the steps above for "View" compute instance. Alternatively, click on the actions (ellipses) on the far right of a compute instance and select "Edit Configuration". PaaS Admins can now make necessary changes to the compute instance and save it.

> **Info**
> Any changes will go into effect only for "new" services that are launched based on the profile. Already running instances will not be impacted.

---

### View Instance Schedules

If the **Compute Profile** used to create a compute instance includes predefined schedules (for example, start and stop actions), these schedules are automatically displayed in the **Compute Instance Deployment** view.

In the example shown below, the instance `computeinstance-scheduled` includes two schedules:

- A **start** action scheduled to trigger every day at 9:00 AM.
- A **stop** action scheduled to trigger every day at 11:00 PM.

The next scheduled action is also displayed at the top, indicating the upcoming trigger time based on the cron expressions defined in the profile.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/compinst_sch.png)](https://docs.rafay.co/aiml/gpupaas/img/compinst_sch.png)

---

### Delete Compute Instance

To delete a compute instance, click on the actions (ellipses) on the far right of a compute instance and select delete.

> **Info**
> This is a destruction action and cannot be reversed. Once a compute instance is deleted, it is no longer available to end users for use.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/ci_mainaction.png)](https://docs.rafay.co/aiml/gpupaas/img/ci_mainaction.png)

If the delete action fails, the compute instance moves to Delete Failed status and remains visible in this list once the status filter is changed from the default, Active. No force action is available from here. See [Force Delete](https://docs.rafay.co/aiml/gpupaas/force_delete/) to remove a compute instance in Delete Failed status.

---
