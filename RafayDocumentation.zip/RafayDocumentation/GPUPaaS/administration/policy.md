---
title: "Policy & Governance for End Users"
source: https://docs.rafay.co/aiml/gpupaas/administration/policy/
---

# Policies

Infrastructure resources (esp. GPUs) can be extremely expensive. As a result, organizations need the means to ensure these scarce resources are being used efficiently, cost effectively, equitably, securely and without wastage. In Rafay GPU PaaS, administrators implement this via centralized policies that are automatically enforced on resources that are created and used by end users.

In the section below, we describe common use cases and how administrators can configure and enforce policies.

---

## Schedule

The typical use case for this is to help avoid wastage due to idling resources. For example, the end user may not need the resources at night and over the weekend. With Rafay GPU PaaS, administrators can configure the instance profiles to use/follow a schedule.

This can particularly cost effective for organizations where they have users in different time zones. With this approach, the same resources can now be used by users in different time zones via a "time sharing" type policy achieved using schedules.

---

## Compliance

The typical use case for this is to make sure that resources spawned by end users are operating the latest/approved versions of the compute and service profiles. These profiles are software defined and point to specific versions of software components. As part of security hygiene, when security vulnerabilities are identified with specific versions of software, administrators may publish new/updated versions of compute and service profiles and retire older versions.

This allows administrators to make sure that any resources created by end users are always based on the latest and compliant versions of the compute and service profiles.

---

## Limits

The typical use case for this is when organizations want to make sure that scarce resources are shared **equitably** across end users. Without this type of control, it is easy for a small pool of users to hog all available resources.

With Rafay GPU PaaS, administrators can specify resource limits for users.

---
