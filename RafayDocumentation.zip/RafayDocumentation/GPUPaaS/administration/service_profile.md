---
title: "Service SKUs"
source: https://docs.rafay.co/aiml/gpupaas/administration/service_profile/
---

# Create Service SKUs

Service SKUs are a way for administrators to manage "app configurations" as code, make them available to end users of GPU PaaS for consumption. The software defined components that are part of the service sku are then deployed by the end user onto a compute instance that they would have already launched.

The lifecycle of Service SKUs and their configuration is managed by administrative users in the Rafay GPU **SKU Studio**. The PaaS studio is an administrative portal purpose built for management of reusable skus.

Service SKUs are "project scoped" by default i.e. they are locked to the [Rafay Project](https://docs.rafay.co/security/tenancy/projects/) they are created in. As with all resources in a project, they can be optionally shared with selected/all projects.

> **Info**
> In addition to the web console, administrators can also perform all the tasks described below programmatically using the platform's REST APIs.

---

## Create service sku

To create a service sku, access PaaS Studio and navigate to the home page. The page provides options to manage skus, including service skus, which can be customized to meet specific requirements. Clicking on the **View All** icon or launching a service sku will navigate to the service skus page, or navigate to **SKUs > Service** on the left menu to access the Service SKUs page.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/sp-home_page.png)](https://docs.rafay.co/aiml/gpupaas/img/sp-home_page.png)

Click on **New Service SKU**. A prompt will appear to specify the following in a wizard-like experience.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/sps_page.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_page.png)

The following information is prompted in a wizard-type experience. Details captured in the service sku are presented to the end user when provisioning the service.

### General Section

#### Unique Name

Provide a unique name for the service sku (e.g. jupyter-notebook). Note that you cannot change the unique name once the sku has been created.

#### Display Name

This is typically a user friendly name such as "Jupyter Notebook" that will make sense to the end users. This name is what the end users will see an experience.

#### Description

Provide a multiple sentence description that will help the end users understand more details about the service sku.

#### Environment Template

Select the name of the environment template from the drop down. When an instance of a service is launched using the sku, the "code" encapsulated in the associated environment template is used to drive the deployment of the necessary software components.

#### Environment Template Version

Select the version of the environment template from the drop down.

#### Service Type

Select a service type from the dropdown list. Note that Service SKUs tagged with a specific service type are made available to end users in the right category to make it easy to find by presenting it in the right context for the end user.

- Notebook
- Inference
- Jobs
- Custom Service

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/sp_notebook.png)](https://docs.rafay.co/aiml/gpupaas/img/sp_notebook.png)

A good example of a custom service is admins at a biotech company packaging "Nvidia's BioNemo" software and make it available for their data scientists as a "1-click" experience.

> **Important**
> Rafay provides a number of **[system service skus](https://docs.rafay.co/aiml/gpupaas/service_types/)** that are available out of box in the platform.

Click **Save & Continue**

Once saved, General Information appears as below.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/sps_generl.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_generl.png)

#### **Datacenters**

The **Datacenters** section in service skus defines the datacenter context used for **storage filtering** during service instance creation. Selecting a datacenter ensures that only the storage resources associated with that datacenter are displayed.

- The list of available datacenters is **fetched from the Inventory (InventoryDatacenter objects)**.
- The selected datacenter is used for filtering storage and also participates in inventory-based matchmaking and agent selection during deployment.
- Storage resources fall under two categories:
  - **Datacenter-specific storage**: storage deployed with a datacenter attached
  - **Open storage**: storage created without a datacenter and visible across all datacenters
- When **no datacenter** is selected, the storage list displays all available storage resources, including **datacenter-specific storages** and **open storages**.
- When a datacenter is selected:
  - Storage mapped to that datacenter is shown
  - Open storage is also shown
- Enabling **Exposed** makes the datacenter visible during service instance creation.
- Enabling **Overridable** allows end users to modify the datacenter value while launching a service instance.
- Only **one datacenter can be selected** per service sku.

[![Service SKU Datacenter & Storage](https://docs.rafay.co/aiml/gpupaas/img/datacenter_storage.png)](https://docs.rafay.co/aiml/gpupaas/img/datacenter_storage.png)

***Example***

If a storage resource such as **`highspeed-dc2`** is deployed with **Data Center 2**:

- It appears only when **Data Center 2** is selected during service instance creation.
- Storage created without a datacenter (open storage) appears for all datacenters, regardless of the selected value.

During sku creation, the system maps the sku to:

- **Datacenter-specific agents**, if the same datacenter is configured in **Global Settings**
- **Global agents**, if no matching datacenter is defined in Global Settings

For details on how datacenters map to agents, see **[Global Settings](https://docs.rafay.co/aiml/csp/global_settings/)**.

#### **Storage**

The **Storage** section in service skus lists the storage instances that can be attached to the service. The storage options shown are filtered based on the selected datacenter and the type of storage defined in the sku.

- Storage instances are fetched from existing **storage service deployments**.
- Storage appears in two categories:
  - **Datacenter-specific storage** – storage originally deployed with a datacenter attached
  - **Open storage** – storage deployed without a datacenter and visible across all datacenters
- When **no datacenter is selected**, the storage list displays all available storage resources, including **datacenter-specific storages** and **open storages**.
- When a datacenter is selected:
  - Storage mapped to that datacenter is displayed
  - Open storage is also displayed
- The storage field supports **Exposed** and **Overridable** controls, allowing visibility and modification during service instance creation.
- Supported storage types include **high-speed-storage** and **object-storage**, depending on how the service sku is configured.

[![service SKU Inputs](https://docs.rafay.co/aiml/gpupaas/img/storages.png)](https://docs.rafay.co/aiml/gpupaas/img/storages.png)

#### Labels

Labels are optional metadata in the form of key-value pairs that will be automatically attached to the resulting compute instances when they are launched. Labels help in categorizing and organizing compute instances based on specific criteria like environment, project, or team.

To allow **Day-2 operations** (redeployment of services even when the status is `Success`), include the following label in the service sku:

```
ALLOW_DAY2_OPERATIONS: true
```

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/labels_day2.png)](https://docs.rafay.co/aiml/gpupaas/img/labels_day2.png)

#### Annotations

Annotations are also optional metadata in key-value pair format, but unlike labels, they are typically used for descriptive purposes rather than for categorization or filtering. Annotations provide additional context or information about the compute instance.

**Custom Error Message for Instance Failures**

These annotations are configured on the **Service SKU** and apply to all service instances created using that sku.

PaaS Admin can define a **custom error message** that is shown to users when a service instance deployment fails. The custom message is displayed as **additional information** to help provide clearer, user-friendly guidance or next steps.

To configure a custom failure message, add the following annotation to the service sku:

- **Key:** `paas.envmgmt.io/instanceFailureMessage`
- **Value:** Custom message to be displayed when the service instance fails *(example: `Service deployment failed due to a configuration issue. Contact your administrator for details.`)*

When an instance deployment fails and this annotation is present in the associated service sku, the specified message is displayed in the **instance details dialog** under the **Message** field. This helps communicate the failure context without exposing low-level system error logs.

If this annotation is not configured, the platform displays the default failure message.

**Display Raw Error Logs for Instances Failures**

By default, detailed system-generated error logs are not shown to end users. PaaS Admin can explicitly enable visibility of the full raw error logs by adding the following annotation to the service sku:

- **Key:** `paas.envmgmt.io/isRawLogsVisible`
- **Value:** `true`

When this annotation is set to `true`, the complete raw error log generated during the service instance deployment failure is displayed to the user.

Both annotations can be configured together based on requirements, allowing providers to control whether users see a user-friendly message, detailed system logs, or both.

**Custom Informational Message for Instance Deletion**

Service providers can present users with a **custom informational message** during the **initial deletion of an instance** to provide additional context or guidance.

This behavior is configured using an **annotation**.

- **Key:** `paas.envmgmt.io/deletionCustomMessage`
- **Value:** Custom message to be displayed during instance deletion *(example: `Instance deletion has been initiated. Please ensure that all dependent resources are backed up.`)*

[![Compute SKU Inputs](https://docs.rafay.co/aiml/gpupaas/img/sp_errors-labels.png)](https://docs.rafay.co/aiml/gpupaas/img/sp_errors-labels.png)

#### Extra Configuration

The Extra Configuration field in the service sku allows adding key-value pairs for additional settings, such as environment variables or custom parameters, to enable further customization of the sku.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/annot.png)](https://docs.rafay.co/aiml/gpupaas/img/annot.png)

### Design SKU Card (Optional)

#### Icon URL

Provide a URL for the Icon that will be displayed to the end user in the catalog of SKUs.

#### Readme

Provide a detailed readme in plain text or markdown. Administrators can use the readme as a means to educate the end user about the service sku and optionally even capture instructions.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/iconurl_label.png)](https://docs.rafay.co/aiml/gpupaas/img/iconurl_label.png)

### Input Settings

Environment templates backing a service sku can require or expect inputs from the user. The inputs can either be mandatory or optional. This section allows the PaaS admin to decide whether to provide default values and whether end users are allowed to override them.

For each input, the PaaS admin can control whether the value can be overridden by end users and whether the value is managed by the system using the **Show to User** and **System Variable** options.

The **Show to User** option controls whether an input is exposed to the end user for configuration. When enabled, the input is displayed in the input form and the end user is allowed to view and override the value. When disabled, the input is not exposed to the end user, and the value is applied during execution based on the partner-defined value in the SKU. In this case, the end user cannot override the value.

The **System Variable** option is used to hide an input from end users while allowing the backend to override its value. This option is available only for skus created in the **system-catalog** project and can be configured only by users who have permission to create or manage skus in the system-catalog project, which is currently limited to the Org Admin role. When enabled, the value is populated from backend logic or global settings, and tenant users cannot view or override it.

These controls allow enforcement of SKU-level, tenant-level, or platform-level constraints while controlling which inputs can be overridden by end users.

For example, in a Jupyter notebook service sku, the input form can display a list of notebook skus for user selection, while other inputs are enforced using partner-defined values or managed as system variables. This ensures that required libraries and frameworks from the selected sku are automatically installed while maintaining system-level control where needed.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/sps_inputsettings.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_inputsettings.png)

> **Note**
> The `sensitive` property for an input is defined at the environment template level and is inherited by the service sku. This property cannot be changed at the sku level. Setting `sensitive: false`, or removing the `sensitive` field, in the service sku specification does not change this behavior. The input continues to be treated as sensitive.

> ⚠️ Important
> Multi-Cluster Support
> Multi-cluster support requires the environment template to include the input variable cluster_details under the Input Variables section. This variable provides the list of eligible target clusters used by the matchmaker to determine the most appropriate deployment destination.
> 
> The value type should be Text and supports comma-separated cluster names.
> This variable is optional, allowing the same template to be used for both single-cluster and multi-cluster configurations.
> When creating a service sku, select an environment template that defines cluster_details, ensuring that the service sku inherits this input and enables matchmaker-based multi-cluster deployment.
> 
> 
> 
> OpenShift-Specific Configuration
> When service skus are deployed on OpenShift clusters, additional input configuration is required in the backing environment template.
> 
> Use pod-as-a-service environment template version v7.0 or later.
> Set the input variable openshift to true to enable automatic creation of OpenShift SecurityContextConstraints (SCC).
> 
> 
> For services that expose ingress (for example, notebooks, vLLM, or openwebui):
> 
> If using the default OpenShift ingress controller with cert-manager:
> Configure the required ingress annotations and ingress class
> Set use_cert_manager to true

#### Manage Translations

**Release Information**
 The Manage Translations feature is available from release **v3.1-40** onwards.

Service SKU inputs and outputs can be presented to end users in multiple languages. The **Manage Translations** option allows the PaaS admin to provide translated display names, tooltips, and descriptions for each variable. End users see these values in their selected language. If a field is not translated, it falls back to the default value defined in the SKU.

> **Important**
> The **Manage Translations** option is visible only if localization is enabled in the Operations Console.

To open the translations window, click **Manage Translations**.

[![Manage Translations](https://docs.rafay.co/aiml/gpupaas/img/sps_managetranslations.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_managetranslations.png)

The Manage Translations window displays all the input variables as rows and the supported languages as columns, including the inputs that are not shown to the end user. This allows the admin to translate only the variables exposed to end users or all the variables, based on the requirement. When multiple languages are configured, a horizontal scroll is available to update the values for each language.

The tabs at the top of the window allow the PaaS admin to switch between the translation types.

The **Display name** tab is used to provide the translated name shown for each variable in the input form.

[![Display Name](https://docs.rafay.co/aiml/gpupaas/img/sp_display_name.png)](https://docs.rafay.co/aiml/gpupaas/img/sp_display_name.png)

The **Tooltip** tab is used to provide the translated tooltip text that appears when the end user hovers over an input.

[![Tooltip Translation](https://docs.rafay.co/aiml/gpupaas/img/sps_tooltip.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_tooltip.png)

The **Description** tab is used to provide the translated description that offers detailed guidance for an input.

[![Description Translation](https://docs.rafay.co/aiml/gpupaas/img/sps_description.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_description.png)

The **Shown to end user** toggle controls whether the translated values are displayed to end users.

Instead of translating each field in the UI, the admin can use the **Download** option to export all the translations, including display names, tooltips, and descriptions, as a single file. The file can be edited offline to add the translated values for each language and then imported using the **Upload** option to apply the changes in bulk.

[![Description Translation](https://docs.rafay.co/aiml/gpupaas/img/show_lang.png)](https://docs.rafay.co/aiml/gpupaas/img/show_lang.png)

Once the translations are configured, click **Save Changes**. Translations are managed on a per SKU basis, and the same capability is available for output settings. For example, an output variable named hostname can be given a display name such as Notebook Access URL, and its translated value is shown automatically when the end user switches to a different language.

> **Note**
> Translations are optional. Any field left blank falls back to the default value defined in the SKU.

---

### Output Settings (Optional)

This section allows the PaaS admin to determine what information they would like to show the end user after the compute instance has been created. These are typically key/value pairs that are dynamically generated by the environment template.

For example, for a Jupyter notebook service sku, once the notebook has been launched, some details (URL and credentials) may need to be presented to the user so that they can access it.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/service_outputs.png)](https://docs.rafay.co/aiml/gpupaas/img/service_outputs.png)

Similar to Input Settings, the **Manage Translations** option is available for output settings to provide translated display names, tooltips, and descriptions for output variables. For more information, refer to Manage Translations.

---

### Schedules Settings

The **Schedules Settings** tab allows configuring schedules to automate actions on the service SKU at defined times.

To create a schedule:

1. Click **Create Schedule**
2. Provide the following details:
  - **Name**: A unique name for the schedule
  - **Action**: The action to perform (for example, start or stop)
  - **Time Zone**: The time zone in which the schedule runs
  - **Cron Expression**: The schedule frequency in cron format. A description of the configured expression is displayed below the fields
  - **Enforce Time Window**: When enabled, the action is enforced within the defined time window. This is applicable only for the Start and Stop actions
3. Click **Create**

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/schedule_service.png)](https://docs.rafay.co/aiml/gpupaas/img/schedule_service.png)

---

### Action Overrides

The **Action Overrides** section enables admins to configure and manage action variables defined in the selected environment template. This section appears while creating or editing a **service sku**, providing an interface to customize how each action and its variables are presented at the instance level.

Actions and variables listed here are automatically derived from the underlying environment template. Each action, such as *start* or *stop*, appears with its respective input variables, for example, `action`. The configuration defined in this section acts as an override to the base template definition, allowing refinement of the display configuration and control of whether variables can be modified further in the instance layer.

Each variable displays the associated **Value** and **Action**, along with the following options:

- **Override:** Controls whether the variable can be modified in the instance layer. When disabled, the variable remains fixed and does not appear during action execution.
- **Display Config (Edit):** Allows customization of how the variable is presented, such as the alias and tooltip.

The **Show All Inputs to User** option controls the visibility of all inputs to end users, and the **Preview Input Form** option provides a view of how the inputs will appear to end users.

If the selected environment template has no actions configured, the **Action Overrides** section still appears, but no actions are displayed.

[![Action Overrides](https://docs.rafay.co/aiml/gpupaas/img/service_action.png)](https://docs.rafay.co/aiml/gpupaas/img/service_action.png)

**Configuring Action Variables**

Each action includes a set of variables that can be configured individually. For every variable, the following options are available:

- **Alias:** Updates the display name of the variable for clarity (for example, changing `input1` to *Sample Input 1*).
- **Tooltip:** Adds helper text visible when hovering over the variable name, providing additional context for administrators and operators.
- **Allow Override:** Controls whether the variable can be modified in the instance layer. When disabled, the variable remains fixed and does not appear during action execution.

These configurations are stored per action, ensuring each action can have distinct customization based on its function and context. For example, inputs such as `run_strategy` can have different default values (e.g., `started` or `halted`) for respective actions like **start** and **stop**. The **Allow Override** option can be enabled or disabled to control whether authorized users can modify these values at runtime, while display properties such as labels or tooltips can be customized to improve clarity.

**Example: Editing Display Configuration**

The following image shows an example of the display configuration edit interface for one action. In this view, the admin can modify the alias, tooltip, and other display parameters for selected variables within that specific action.

This interface represents the configuration screen for a single action. Each action listed in the **Action Settings** section provides a similar configuration experience.

[![Outputs](https://docs.rafay.co/aiml/gpupaas/img/service_edits.png)](https://docs.rafay.co/aiml/gpupaas/img/service_edits.png)

Click **Save Changes**.

---

## View Service SKU

When PaaS Admins click on the service skus menu on the left, the entire list of service skus available are listed. They can search for the service sku by providing input into the search box. Some basic information about the service sku is shown to the admin in the main listing.

- Unique Name
- Service Type
- Creation Date
- Sharing
- Actions Menu (ellipses)

To view additional details about a service sku, simply click on it. This will display all the details the administrator would have configured during initial creation.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/view_sp.png)](https://docs.rafay.co/aiml/gpupaas/img/view_sp.png)

---

## Update Service SKU

Follow the steps above for "View" service sku to view details about a service sku. Alternatively, click on the actions (ellipses) on the far right of a service sku and select "View Configuration". PaaS Admins can now make necessary changes to the service sku and save it.

> **Info**
> Any changes will go into effect only for "new" services that are launched based on the sku. Already running instances of the service sku will not be impacted.

---

## Share Service SKU

To share a service sku with selected or all projects, click on the actions (ellipses) on the far right of a service sku and select **Manage Sharing**. Now, select how you wish to share the project. The options are:

- None (This is the default)
- All Projects
- Selected Projects

The ability to share service skus with other projects allows platform teams to centralize the mgmt of service skus and share them **hierarchically** with downstream projects where they can be used by end users in multiple teams/departments.

> **Note**
> Service skus in the **system-catalog** project cannot be shared with any other project. Service skus created in projects other than `system-catalog` can be shared with selected or all projects.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/sp_sku_share.png)](https://docs.rafay.co/aiml/gpupaas/img/sp_sku_share.png)

---

## Clone Service SKU

Administrators can now **clone existing service skus**, making it easier to replicate and reuse configurations without having to create new skus from scratch. This streamlines sku management and reduces administrative overhead.

- From the Service SKUs page, click the **ellipsis menu (⋯)** next to an existing sku and select **Clone SKU** to start the cloning process

> Note:
> - If a service sku is inherited from another project, no actions (e.g., edit, clone, share, delete) can be performed on it within the current project.
> - Service skus shared by the Org Admin to the tenant from the System Catalog cannot be shared, deleted, or cloned. However, users can edit these skus within the tenant project.
> - Service skus in the system-catalog project cannot be cloned to any other project. They can only be cloned within the system-catalog project. Service skus created in projects other than system-catalog can be cloned to other projects.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/service_prof.png)](https://docs.rafay.co/aiml/gpupaas/img/service_prof.png)

- Provide a **Name** for the sku, and optionally add a **Display Name** and **Description**
- Select the **Target Project** where the sku should be created with the same configuration
- Click **Clone Service SKU**

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/targetproject.png)](https://docs.rafay.co/aiml/gpupaas/img/targetproject.png)

> ❗Important
> The environment template must be shared with the project before cloning a service sku. Otherwise, the operation will fail with an error as shown below.

**When to Use Cloning**

- **Clone within the same project**
 Enables creation of a new service sku with similar configurations based on an existing one.
 ***Example:*** A development team needs a service sku identical to the staging sku, with only a minor change in resource limits.
- **Clone to a different project**
 Supports quick onboarding of new teams or users in separate projects by replicating a previously defined service sku.
 ***Example:*** A new project requires the same node pool configuration and taints used in a production setup from another project.

---

## Delete Service SKU

To delete a service sku, click on the actions (ellipses) on the far right of a service sku and select delete.

> **Info**
> This is a destruction action and cannot be reversed. Once a service sku is deleted, it is no longer available to end users for use.

---
