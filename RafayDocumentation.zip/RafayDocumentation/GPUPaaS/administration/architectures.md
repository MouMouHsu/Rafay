---
title: "Architectural Approaches"
source: https://docs.rafay.co/aiml/gpupaas/administration/architectures/
---

# Architectures

Enterprises can configure and deploy Rafay GPU PaaS to leverage/use infrastructure from a variety of providers. Although many permutations are possible, the most common approaches that organizations use with Rafay GPU PaaS are described below.

> **Note**
> Please review the [support matrix](https://docs.rafay.co/supportmatrix/gpu_paas/) for detailed information on supported infrastructure and provider types.

---

## On-Premises Only

Organizations that typically use this approach are typically heavily regulated OR have a significant data footprint in their data centers that make it impractical to use the public cloud for infrastructure.

Some organizations may also prefer to use this because they have a well understood baseline usage of GPUs and may find it more cost effective to purchase/operate the hardware in their data centers.

---

## Burst to Public Cloud

Organizations that use this approach may wish to provision for "baseline GPU capacity" in their data centers. They will prefer to burst to public cloud providers for peak capacity or for specialized GPU requirements. Some common scenarios are described below.

### Scenario 1

The GPU requirements of the organization may have outstripped the organization's current capacity deployed in their data center and they expect it to take another 6 months before they can increase capacity.

These organizations may leverage technologies such as VPC peering with public cloud providers to effectively extend their data center to the cloud on a temporary or permanent basis.

### Scenario 2

The organization may use the public cloud only for users that require Nvidia H200 GPU systems that they do not have access to in their data center. The IT/OPs team may have a 12 month wait time before they can make the H200 GPU systems deployed in their data center.

### Scenario 3

They may wish to dedicate and prioritize the GPUs in their data center for mission control training and inference requirements.They may prefer to burst to the public cloud for users that are primarily using it for experimentation since these workloads are likely ephemeral in nature.

---

## Public Cloud or Multi Cloud

Some organizations may have made the decision to solely use public clouds (e.g. AWS, Azure etc) for infrastructure and services. They may have negotiated long term commitments with the public clouds. Some organizations may be operating at the other end of the spectrum and use "multiple public cloud providers" and be deployed in "multiple regions".
