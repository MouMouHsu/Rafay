---
title: "Compute Profile for vCluster"
source: https://docs.rafay.co/aiml/gpupaas/administration/vcluster_type/
---

# vCluster

## Create a Compute Profile for K8s

This page outlines the process for creating a Compute Profile using the **vCluster** compute type. vCluster profiles enable workload provisioning inside virtual Kubernetes clusters that run as workloads on shared host clusters. These profiles offer enhanced multi-tenancy and namespace-level isolation while retaining Kubernetes-native capabilities.

Refer to the [Compute Profile Overview](https://docs.rafay.co/aiml/gpupaas/administration/compute_profile/) for general information.

---

## Steps to Create a vCluster Compute Profile

- In the **Developer Console**, navigate to **Compute Profiles** from the left navigation pane
- Click the **+ New Compute Profile** button
- In the **Compute Profile** form:
  - **Name**: Provide a unique identifier for the profile (e.g., `vcluster-dev-profile`)
  - **Display Name** *(Optional)*: Enter a user-friendly label (e.g., `Development vCluster Profile`)
  - **Description** *(Optional)*: Add notes to describe the profile’s purpose or vCluster configuration
  - Choose the appropriate **Environment Template** from the dropdown
  - Choose the **Template Version**
  - **Compute Type**: From the dropdown, select **vCluster**

> ⚠️ This determines that workloads associated with this profile will be provisioned inside virtual Kubernetes clusters hosted on shared infrastructure.

[![Compute Type - vCluster](https://docs.rafay.co/aiml/gpupaas/img/vcluster_type.png)](https://docs.rafay.co/aiml/gpupaas/img/vcluster_type.png)

- Once all required fields are filled, click **Save & Continue** to proceed to configuration.

---

## Compute Profile Configuration

Once saved, the **Compute Profile Configuration** page appears.

The values provided during profile creation, such as Name, Display Name, Description, Allocation Type, Environment Template, Template Version, and Compute Type, are shown under the **General** section.

[![Advanced Configuration vCluster](https://docs.rafay.co/aiml/gpupaas/img/vcluster_general.png)](https://docs.rafay.co/aiml/gpupaas/img/vcluster_general.png)

### Datacenters

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Datacenter | `default-dc` | string | Select the datacenter where compute instances will be deployed. The list is automatically populated from the infrastructure inventory. |
| Exposed | `false` | boolean | Makes the datacenter visible during deployment. |
| Overridable | `false` | boolean | Allows users to modify the datacenter selection at deployment time. |

### Storage Details

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Storage Details | — | list | Select one or more storage instances to attach to the compute profile. The options are automatically fetched from existing storage service instances. |
| Exposed | `false` | boolean | Makes the storage field visible during deployment. |
| Overridable | `false` | boolean | Allows users to modify the storage selection during deployment. |

[![Compute Profile Inputs](https://docs.rafay.co/aiml/gpupaas/img/dc_storage.png)](https://docs.rafay.co/aiml/gpupaas/img/dc_storage.png)

### Advanced Configuration

| Name | Default Value | Value Type | Description |
| --- | --- | --- | --- |
| Labels | N/A | key-value | Optional metadata to help categorize and identify the compute profile |
| Annotations | N/A | key-value | Optional key-value pairs for additional context (e.g., `'env': 'prod'`) |
| Extra Configuration | N/A | key-value | Custom key-value metadata for advanced customization or integration |

[![Advanced Configuration vCluster](https://docs.rafay.co/aiml/gpupaas/img/vcluster_label.png)](https://docs.rafay.co/aiml/gpupaas/img/vcluster_label.png)

### Display Settings

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| Icon URL | `https://cdn.example.com/icons/vcluster-profile.svg` | string | URL to a custom icon used to visually identify the compute profile |
| Read Me | `This profile provisions vCluster environments for isolated tenant workloads.` | string | Short summary describing the purpose or characteristics of the profile |

[![Display Settings - vCluster](https://docs.rafay.co/aiml/gpupaas/img/vcluster_readme.png)](https://docs.rafay.co/aiml/gpupaas/img/vcluster_readme.png)

### Input Settings Table

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| Admin API Key | `********` | text | API key used for authenticating with the controller |
| Controller Admin Endpoint | `ops-console.rafay.dev` | text | Admin access endpoint for the Rafay Controller |
| ethernet_network_fabric | `true` | text | Indicates if Ethernet network fabric is enabled |
| infiniband_network_fabric | `false` | text | Indicates if InfiniBand network fabric is enabled |
| network_operation | `tenant-onboard` | text | Specifies the type of network operation (e.g., onboarding) |
| organization | `rafay-dev` | text | Identifier for the organization or tenant |

[![Compute Type - k8s](https://docs.rafay.co/aiml/gpupaas/img/vcluster_variables.png)](https://docs.rafay.co/aiml/gpupaas/img/vcluster_variables.png)

### Input Configuration Controls

- **Override (Checkbox)**: Allows environment-level overrides for specific input parameters. When enabled, users can modify the input value directly within their environment-specific configurations.
- **Allow Override For All**: A global control that enables the override option for all listed inputs at once. Useful for quickly granting flexibility across the entire configuration.
- **Preview Input Form**: Displays a preview of how the configured inputs will appear to users. It includes field labels, tooltips, input types, validation rules, and grouping settings.
- **Display Config (Edit)**: Opens a configuration panel where display-related settings can be customized. Options include changing the display name, adding user guidance tooltips, setting default values, selecting input types, and organizing fields into logical groups.

***Example: Edited Input for `ethernet_network_fabric`***

| **Field** | **Description** |
| --- | --- |
| **Alias** | Display label shown to users (e.g., `ethernet_fabric_flag`) |
| **Tooltip** | Help text shown when hovering over the info icon (e.g., `Enable Ethernet fabric support`) |
| **Disabled** | Toggle to make the field read-only for end users |
| **Order/Weight** | Determines the order of fields in the UI (e.g., `10`, lower values appear higher in the form) |
| **Type** | Input type for the field (e.g., `Text`, `Dropdown`, `File Upload`) |
| **Validation Type** | Defines the validation mechanism (e.g., `Boolean`, `Length`, `Regex`, `Required`) |
| **Validation Pattern** | Used with validation type; for example, a regex like `true\|false` to limit input to boolean values |
| **Section** | Logical grouping under which the field will be displayed (e.g., `Network Settings`) |
| **Section Description** | Optional description for the section (e.g., `Configure the network fabric settings for compute provisioning`) |

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/vcluster_edit.png)](https://docs.rafay.co/aiml/gpupaas/img/vcluster_edit.png)

### Output Settings

| Name | Sample Value | Value Type | Description |
| --- | --- | --- | --- |
| **Name** | `vcluster-access-url` | text | Unique identifier for the output variable capturing a vCluster endpoint URL |
| **Label** | `vCluster Access URL` | text | Display name shown in the UI for readability (optional) |
| **Resource** | `vcluster-dev-profile` | text | Optional reference to the compute profile or environment linked to the output |

- Each output entry includes **Edit** and **Delete** options on the right side, allowing modifications or removal of the configuration as needed
- The **Preview Output Form** button allows visual verification of how the output fields will be rendered in the UI

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/vclusters_output.png)](https://docs.rafay.co/aiml/gpupaas/img/vclusters_output.png)

### Schedules

The **Schedule Settings** section allows you to define automated start and stop actions for compute instances created from this compute profile. These schedules help ensure that instances run only during specific time windows, optimizing resource usage.

To create a schedule, click **Add Schedule** and provide the following details:

- **Name**: Enter a unique name for the schedule.
- **Action**: Select the operation to perform. Supported actions include start and stop.
- **Time Zone**: Choose the time zone in which the schedule should be executed.
- **Cron Expression**: Define the time and frequency for the action using a cron expression.
- **Enforce Time Window**: When enabled, the system ensures that the instance remains active only during the scheduled time window. This option applies only to start and stop actions.

Once the schedule is configured, click **Save Changes** to add it to the compute profile. All schedules defined here will automatically apply to compute instances created using this profile.

[![Edit cluster_name](https://docs.rafay.co/aiml/gpupaas/img/vclus_schedule.png)](https://docs.rafay.co/aiml/gpupaas/img/vclus_schedule.png)

> Note: If the selected environment template version does not support scheduling actions, the Schedules Settings section will display a message stating “No Actions Available.” In this case, select a different template version or contact your administrator to enable scheduling capabilities.

Once all configurations are complete, click **Save Changes** to apply the updates.

---
