---
title: "Profile Quotas"
source: https://docs.rafay.co/aiml/gpupaas/administration/profile_quota/
---

# Profile Quotas

## Overview

Profile Quotas control how many instances of a Compute or Service Profile can be launched at different scopes: Organization, Project, and User. This hierarchy ensures centralized governance while allowing granular control at the team and user level.

> **Info**
> Learn more in our [**blog**](https://docs.rafay.co/blog/2025/06/27/configure-and-manage-gpu-resource-quotas-in-multi-tenant-clouds/) introducing this feature.

**Profile quotas** are applied at three levels:

- **Organization-Level Quota**: Sets a global cap on the number of profile instances across the entire organization.
- **Project-Level Quota**: Limits the number of instances that can be launched within a specific project.
- **User-Level Quota**: Further restricts the number of instances each user can launch under a project.

An Instance quota limits how many instances of a SKU can run. A GPU quota limits the number of GPU units of a model that can be used in a data center.

This multi-level quota system provides fine-grained control over resource usage and simplifies profile instance governance across teams and users.

### Quota Configuration by Kind and Level

| Kind | Org/global | Project | User |
| --- | --- | --- | --- |
| Instance / SKU count | Ops Console → Quotas (Instance) | Project Quotas → Instance Overall Limit | Limit per User on the same form |
| GPU units | Ops Console → Quotas (GPU) | Project Quotas → GPU Overall Limit | Limit per User on the same GPU form |

> ⚠️ Note: The organization or global quota does not override or replace project or user level quotas. For GPU quotas, the org-level quota is an additional ceiling. All matching limits apply, and the tightest limit wins. Org GPU usage is counted across the entire organization, not separately per project.

---

## Organization-Level Quota

- Defines the global cap for how many instances of a profile can be launched across all projects and users in the organization.
- Ensures resource governance at the highest level—helpful for budgeting, capacity planning, and preventing runaway usage.

**Configure via Global Settings YAML**

```
profiles:
 - name: demo-quota-globalsettings
   quota:
      max-instances: 100 #This profile can have orglevel quota of 100
```

> Note:  If the org-level quota is set to 100, a maximum of 100 instances can be launched across all projects and users.

## Project-Level Quota

- Defines the maximum number of instances of a SKU, or the maximum number of GPU units of a GPU model, that can be launched within a specific project.
- Enables controlled, project-specific resource allocation without breaching organization-level limits.

**Configure via SKU Management**

In the **Tenant Console**, navigate to **SKU Management > Project Quotas**, and select the project to configure from the **Project** dropdown. Click **+ Add Quota**. The Create Project Quotas form walks through the following steps.

**Quota Type**

Choose what this quota limits.

| Field | Required | Description |
| --- | --- | --- |
| **Quota Type** | Yes | **Instance** or **GPU**. This determines which of the steps below are shown next. |

**SKU Type** (Instance quotas only)

Choose the SKU type this quota applies to. This step is shown only when Quota Type is **Instance**.

| Field | Required | Description |
| --- | --- | --- |
| **SKU Type** | Yes | The type of SKU this quota applies to. Options: **Compute SKU**, **Service SKU**, **Pod SKU**. |

**Instance Configuration** (Instance quotas only)

Set the SKU and limits for this instance quota. This step is shown only when Quota Type is **Instance**.

| Field | Required | Description |
| --- | --- | --- |
| **SKU** | Yes | The specific SKU of the selected SKU Type, chosen from the SKUs available in the project. |
| **Overall Limit** | No | Maximum number of instances that can be running in the project for this SKU at any time. |
| **Limit per User** | No | Maximum number of instances that any single user can have running in the project for this SKU at any time. |

[![Create Project Quotas - Instance type](https://docs.rafay.co/aiml/gpupaas/img/users_quota.png)](https://docs.rafay.co/aiml/gpupaas/img/users_quota.png)

**GPU Configuration** (GPU quotas only)

Choose compute-based or pod-based SKUs, then set the model and limits. This single step replaces the SKU Type and Instance Configuration steps above, and is shown only when Quota Type is **GPU**.

| Field | Required | Description |
| --- | --- | --- |
| **SKU Type** | Yes | **Compute-based SKUs** or **Pod-based SKUs**. |
| **Datacenter** | Only for Compute-based SKUs | The data center to which this quota applies. Not shown when SKU Type is Pod-based SKUs. |
| **GPU Model** | Yes | The GPU model to limit (for example, `H100`). For Pod-based SKUs, the model is selected from the pod GPU models available in the project. |
| **Overall Limit** | No | Maximum number of GPU units of this model that can be consumed in the project at any time. |
| **Limit per User** | No | Maximum number of GPU units of this model that any single user can consume in the project at any time. |

[![Create Project Quotas - GPU type](https://docs.rafay.co/aiml/gpupaas/img/gpu_type.png)](https://docs.rafay.co/aiml/gpupaas/img/gpu_type.png)

Click **Create Quota** to apply the quota settings.

> Note:
> 
> If a project's Overall Limit is 100, no more than 100 instances (or GPU units) of that SKU or model can be launched in that project even if other projects have spare capacity.
> The same Add Quota flow is used for Compute SKUs, Service SKUs, Pod SKUs, and GPU quotas, selecting the appropriate Quota Type and SKU Type.
> A GPU quota is keyed by data center and model together. Usage of a model in one data center does not consume the quota for the same model in a different data center, or for a different model in the same data center.
> Overall Limit is the total cap for the project across all users. Limit per User is a separate cap that applies to each user individually. For example, with a Limit per User of 1 and an Overall Limit of 2, a second GPU instance requested by the same user is blocked by the user limit even though the project has not reached its overall limit.
> When both a GPU quota and an instance quota apply to the same deployment, the tighter limit determines the outcome. If the GPU limit is reached, it blocks the deployment even when the instance quota still has capacity.
> Instances configured with gpu_count: 0 do not consume any GPU quota.
> If Overall Limit is lowered below the current usage total, existing running instances are not affected and continue to run. New deployments are blocked until usage falls below the new limit.
> Destroying an instance releases the GPU quota usage it was consuming.
> For a Compute or Service SKU that does not specify a data center at the SKU level, matchmaking assigns a data center for the deployment, and GPU usage is counted against the quota for that assigned data center.

## User-Level Quota

- Limits the number of instances, or GPU units, an individual user can launch within a project.
- Ensures fair usage among users, preventing one user from monopolizing the project quota.
- Configured in the same quota as the project-level limit, not as a separate step.

**Configure via SKU Management**

Follow the same steps as **Project-Level Quota** above. In the **Instance Configuration** or **GPU Configuration** step, in addition to **Overall Limit**, enter a value in **Limit per User** to specify the maximum number of instances, or GPU units, a single user can launch within the project (for example, `50`).

After quotas have been set at the project and user levels, the Project Quotas list page provides a comprehensive view of the assigned quotas. For Instance quotas, the list shows Overall Limit as **Max Total Instances** and Limit per User as **Max Instances per User**. For GPU quotas, the same fields show GPU units instead of instance counts, since GPU usage is counted by `gpu_count` rather than by instance count. For example, a single instance configured with `gpu_count: 2` counts as 2 toward these limits.

[![Project Quotas list](https://docs.rafay.co/aiml/gpupaas/img/user_quota_display.png)](https://docs.rafay.co/aiml/gpupaas/img/user_quota_display.png)

---
