---
title: "Inventory-Based Scheduling"
source: https://docs.rafay.co/aiml/gpupaas/administration/capacity_check/
---

# Inventory-Based Scheduling

## Enabling Inventory Capacity Checks Using Labels

To support advanced compute scheduling based on inventory, labels must be configured on the **Profile** to enable the appropriate matchmaking scheduler and define the corresponding capacity filters.

### Why Use Inventory Capacity Checks?

Inventory capacity checks ensure that compute resources (like CPU, GPU, memory, and storage) are allocated only to devices with sufficient availability. This allows efficient use of resources across:

- Baremetal nodes
- Virtual Machines (VMs)
- vClusters
- MKS clusters

The matchmaking framework uses filters defined in labels to select an appropriate scheduler and to evaluate device readiness based on available inventory.

---

## Step 1: Set the Inventory Type Label

- To enable matchmaking, set the following label on the **Compute Profile**:

```
paas.envmgmt.io/inventory: <inventory-type>
```

Where `<inventory-type>` can be `baremetal`, `vm`, `vcluster`, and `mks`

This tells the system which scheduler to use for evaluating inventory resources.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/label_1.png)](https://docs.rafay.co/aiml/gpupaas/img/label_1.png)

## Step 2: Configure Match and Capacity Filters

Add the label `paas.envmgmt.io/inventory.config` to the Profile to define how environment variables should be matched to inventory fields. The configuration supports two filter types:

- `match`: Matches environment variables with device schema fields or tags.
- `capacity`: Validates if the required compute capacity is available on the device.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/label_2.png)](https://docs.rafay.co/aiml/gpupaas/img/label_2.png)

***Example Label for Match and Capacity Filters***

```
[
  {
    "type": "match",
    "keyInVariable": "gputype",
    "keyInDevice": "gpus.vendorCode"
  },
  {
    "type": "match",
    "keyInVariable": "location",
    "keyInDevice": "tags"
  },
  {
    "type": "match",
    "keyInVariable": "input2",
    "keyInDevice": "gpus.modelNo"
  },
  {
    "type": "match",
    "keyInVariable": "input3",
    "keyInDevice": "model"
  },
  {
    "type": "match",
    "keyInVariable": "zone",
    "keyInDevice": "tags.location"
  },
  {
    "type": "capacity",
    "keyInVariable": "noofNodes",
    "keyInCapacity": "requiredNoofNodes"
  },
  {
    "type": "capacity",
    "keyInVariable": "cpu",
    "keyInCapacity": "requiredCPU"
  },
  {
    "type": "capacity",
    "keyInVariable": "memoryMB",
    "keyInCapacity": "requiredMemoryMB"
  },
  {
    "type": "capacity",
    "keyInVariable": "gpu",
    "keyInCapacity": "requiredGPU"
  },
  {
    "type": "capacity",
    "keyInVariable": "storageGB",
    "keyInCapacity": "requiredStorageGB"
  }
]
```

---

## Filter Types

The matchmaking configuration supports two types of filters:

### Match Filters (type: `match`)

These filters compare environment variables with device attributes or tags. A device is eligible only if all match filters return a successful match.

***Example***

```
{
  "type": "match",
  "keyInVariable": "location",
  "keyInDevice": "tags.location"
}
```

This checks whether the value of the `location` variable matches the `location` tag on the device.

### Capacity Filters (type: `capacity`)

These filters ensure that the selected device has sufficient resources to satisfy the compute request. They do not require exact value matches but instead perform threshold checks.

```
{
  "type": "capacity",
  "keyInVariable": "cpu",
  "keyInCapacity": "requiredCPU"
}
```

This checks whether the device has available CPU resources greater than or equal to the value of the `cpu` variable.

> Note: To skip a particular capacity check (e.g., for storage), remove the corresponding entry from the configuration.

### Custom Capacity Mapping (Optional)

Custom mappings can be defined using capacityMap for advanced capacity selection scenarios such as vCluster quotas.

***Example***

```
{
  "type": "capacity",
  "keyInVariable": "Namespace Quota Size",
  "keyInCapacity": "capacitySize",
  "capacityMap": {
    "small": {
      "requiredCpu": 3,
      "requiredMemoryMB": 3000,
      "requiredStorageGB": 2,
      "requiredGPU": 1
    },
    "medium": {
      "requiredCpu": 3,
      "requiredMemoryMB": 4000,
      "requiredStorageGB": 2,
      "requiredGPU": 2
    },
    "large": {
      "requiredCpu": 3,
      "requiredMemoryMB": 5000,
      "requiredStorageGB": 4,
      "requiredGPU": 3
    }
  }
}
```

---

## Device Metadata Injection

Once a device is selected based on the match and capacity filters, its complete metadata is injected into the environment layer through a dedicated environment variable.

### Required Variable in Template

```
device_details: [type: JSON]
```

This variable receives the selected device’s metadata in JSON format, which may include:

```
{
  "hostname": "server-42",
  "manufacturer": "NVIDIA",
  "model": "DGX H100",
  "totalcpu": 64,
  "totalgpus": 8,
  "tags": {
    "gputype": "H100",
    "location": "india"
  }
}
```

This data can be used during provisioning or runtime configuration of the environment.

---
