---
title: "SKU Catalogs"
source: https://docs.rafay.co/aiml/gpupaas/administration/sku_catalog/
---

# SKU Catalog Management

## Overview

**SKU Catalogs** in the Rafay console provide administrators with predefined service and compute skus, eliminating the need to create new skus in many cases. Rafay develops and maintains a number of default SKUs, which are available out of the box, allowing organizations to quickly become operational with GPU PaaS without needing to develop or curate their own skus. These preconfigured settings save time, ensuring efficiency in service and resource deployment. While the default skus cover most scenarios, administrators can also build on and extend them to meet specific organizational needs. The SKU Catalogs page offers a consolidated view of available skus, categorized by service and compute types for easy access. This feature benefits administrators by streamlining deployment, ensuring consistency across deployments, and providing flexibility to use both default and custom skus.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/profile-cat.png)](https://docs.rafay.co/aiml/gpupaas/img/profile-cat.png)

The SKU Catalog supports two key personas:

- **Partners (CSPs):** Can customize and share skus with their tenant organizations by managing artifacts in the `SKU Catalog` using the Ops Console.
- **Enterprise Organizations:** Can clone templates and skus from the `SKU Catalog` into local projects for customization and reuse across internal projects.

This guide outlines the steps for both CSPs and enterprise admins to effectively use the SKU Catalog while maintaining governance through read-only system-defined baselines.

## Using Default SKUs

Administrators can share sku catalogs across one or more projects through the Operations Console. Once shared, the skus are available within those projects, allowing administrators to use them when creating instances within the specified projects. For more information on sharing skus with tenant organizations, refer to [Share the SKU with Tenant Orgs](#step-3-share-the-sku-with-tenant-orgs).

Once the service sku is shared, navigate to the **SKU Studio -> SKUs -> Service or Compute**.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/serviceprof_default.png)](https://docs.rafay.co/aiml/gpupaas/img/serviceprof_default.png)

Users can now use this service sku when deploying a service instance from SKU Studio.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/service_instance_default.png)](https://docs.rafay.co/aiml/gpupaas/img/service_instance_default.png)

---

## SKU Catalog for CSP/Tenant Organizations

### Step 1: SKU Catalog Population

Rafay loads **system templates and skus** into the `default-catalog` project within the **default Org** of the partner. These are **read-only artifacts**.

For instructions on loading skus and templates into the `default-catalog` project, see [Load SKUs and Templates](https://docs.rafay.co/aiml/gpupaas/load_profiles/).

### Step 2: Project set to `system-catalog`

To expose customized skus to tenant orgs, the partner must ensure that the cloned sku **resides in the `system-catalog` project**.

Follow these steps:

1. Navigate to **SKU Studio → SKU Catalog** from the left-hand menu.
2. Browse and identify the required sku from the catalog (e.g., a service or compute SKU). Use the category tabs, search, or the **Usecase** filter to locate the sku. In the example below, a service sku is selected.
3. Select **Get Started** on the desired sku card. [![compute sku Home](https://docs.rafay.co/aiml/gpupaas/img/skus_cat.png)](https://docs.rafay.co/aiml/gpupaas/img/skus_cat.png)
4. In the **Get Started** dialog:
  - Provide a **Name** for the sku.
  - The **Project** is set to `system-catalog`. This ensures that the sku is placed in the correct project for sharing with tenant organizations. [![Get Started dialog](https://docs.rafay.co/aiml/gpupaas/img/get-started.png)](https://docs.rafay.co/aiml/gpupaas/img/get-started.png)
5. Click **Continue** to proceed. The sku configuration page is displayed with the following tabs: **General**, **Design SKU Card**, **Input Settings**, **Output Settings**, **Schedules Settings**, and **Action Overrides**.
6. Make the required configuration changes to the cloned sku (e.g., basic information, service configuration, environment template settings, variables, or schedule settings) and click **Save Changes** to finalize the sku in the `system-catalog` project.

[![Saving changes to profile](https://docs.rafay.co/aiml/gpupaas/img/catalog_configs.png)](https://docs.rafay.co/aiml/gpupaas/img/catalog_configs.png)

### Step 3: Share the SKU with Tenant Orgs

**Release Information**
 The SKU sharing user interface and process flow are updated from release **v3.1-40** onwards.

Partners can expose customized skus to their tenant organizations via the **Ops Console**.

> Note: These skus must reside in the system-catalog project to be shareable with tenants.

- In the Ops Console, navigate to **Services > SKU Sharing** and select **Compute SKUs** or **Service SKUs**. The list displays all available SKUs that can be shared with other organizations.
- Click the share icon under the **Actions** column for the desired SKU to open the **Manage Sharing** dialog.

[![Compute SKUs list](https://docs.rafay.co/aiml/gpupaas/img/computesku-lists.png)](https://docs.rafay.co/aiml/gpupaas/img/computesku-lists.png)

The **Manage Sharing** dialog displays the SKU name and a sharing status indicator that shows the number of organizations the SKU is currently shared with.

Two sharing modes are available:

- **All Organizations**: Share the sku with every tenant organization, with the option to disable specific ones
- **Specific Organizations**: Choose exactly which organizations can access the sku

> Note: Project-level auto sharing is applied when a sku is shared with a tenant or when a new tenant organization is created. Updates to sharing settings do not retroactively modify existing project-level shares.

#### Share with All Organizations

Select **All Organizations** to share the SKU with every tenant organization.

Under **Project Access**, choose one of the following sharing scopes:

- **Share to all projects**: The SKU is shared with all projects in each organization.
- **SKU catalog only**: The SKU is shared only with the SKU catalog projects (the `default-project` and the `system-catalog` project) of each organization. Org Admins can then share it with other projects separately.

> Note: Project Access changes apply to new organizations or those not yet shared. Organizations already shared are not affected.

Use **Exclude specific organizations** to exclude organizations from sharing. Excluded organizations do not have access, even though the SKU is shared with all organizations.

Search for organizations and click the **+** icon to add them to the **Excluded** list. To remove an organization from the list, click the **X** next to it, or click **Clear all** to remove all excluded organizations.

[![All Organizations sharing](https://docs.rafay.co/aiml/gpupaas/img/allorg_sharing.png)](https://docs.rafay.co/aiml/gpupaas/img/allorg_sharing.png)

#### Share with Specific Organizations

Select **Specific Organizations** to share the SKU only with selected tenant organizations.

Search for organizations and select the required organizations from the list, or use **Select all orgs in this list** to select all listed organizations at once. Selected organizations appear in the **Selected organizations** panel.

For each selected organization, choose one of the following sharing scopes:

- **Share to all projects**: The SKU is shared with all projects in that organization.
- **SKU catalog only**: The SKU is shared only with the SKU catalog projects (`default-project` and the `system-catalog` project) of that organization.

To apply a sharing scope to all selected organizations at once, click the **Actions** menu and select one of the following:

- **Share all to all projects**: Applies the **Share to all projects** scope to all selected organizations.
- **Share all to SKU catalog only**: Applies the **SKU catalog only** scope to all selected organizations.

To remove an organization from sharing, click the **X** next to it in the **Selected organizations** panel.

[![Specific Organizations sharing](https://docs.rafay.co/aiml/gpupaas/img/spec_orgs.png)](https://docs.rafay.co/aiml/gpupaas/img/spec_orgs.png)

- **Save Changes**: Applies the sharing configuration.
- **Cancel**: Discards the changes.
- **Remove Sharing**: Removes sharing entirely; the SKU reverts to an unshared state.

**Constraints on Unsharing SKUs**

- A SKU cannot be unshared from a **project** if active instances of the SKU exist in that project.
- A SKU cannot be unshared from a **tenant organization** if active instances exist in any project within the tenant.

### Step 4: SKUs in Tenant Org's SKU Catalogs

Exposed SKU will be shown in the `SKU Catalogs` of the tenant organizations.

> Note: This sku is read-only for tenant orgs.

PaaS admins in tenant orgs **cannot modify** or **clone** these skus. They can only **share** them with other projects within their organization.

[![Saving changes to profile](https://docs.rafay.co/aiml/gpupaas/img/customizing.png)](https://docs.rafay.co/aiml/gpupaas/img/customizing.png)

---

## SKU Catalog for Enterprise Organizations

Rafay provides system templates and sku to enterprise organizations in a centralized, read-only location called the `SKU Catalog`. These serve as baseline templates that can be used across the organization.

### Step 1: Default Catalog

Rafay loads system environment templates and skus into the `SKU Catalogs`. These are **read-only** and cannot be modified directly.

[![Saving changes to profile](https://docs.rafay.co/aiml/gpupaas/img/defaultprofile.png)](https://docs.rafay.co/aiml/gpupaas/img/defaultprofile.png)

### Step 2: Clone for Customization

Admins in the default organization can customize SKUs by cloning them into a `system-catalog` project.

1. Navigate to **SKU Studio → SKU Catalog**.
2. Locate the required service SKU (for example, **Jupyter Notebook**) and click **Get Started**.
3. In the **Get Started** window:
  - Enter a **Name** for the new catalog (for example, `jupyter-catalog`) and by default, **system-catalog** project is selected.
4. Click **Continue** to clone the SKU.
5. In the cloned SKU, make the required changes (for example, update configurations, variables, or schedules)

[![Saving changes to profile](https://docs.rafay.co/aiml/gpupaas/img/profiles_clone.png)](https://docs.rafay.co/aiml/gpupaas/img/profiles_clone.png)

1. Before saving the customization, configure the **Show to User** and **System Variable** options for the required variables.

The **Show to User** option controls whether an input is exposed in the input form. When enabled, the input is displayed and its value can be viewed and overridden. When disabled, the input is hidden and the value defined in the SKU is applied during execution. The option can be enabled for individual variables or for all variables using **Show All Inputs to User**.

The **System Variable** option hides an input while allowing its value to be overridden by the backend. When enabled, the value is populated from backend logic or global settings and cannot be viewed or overridden. This option is available only for SKUs created in the **system-catalog** project.

[![Saving changes to profile](https://docs.rafay.co/aiml/gpupaas/img/show_user.png)](https://docs.rafay.co/aiml/gpupaas/img/show_user.png)

After configuring the required variables, click **Save** to apply the changes. Once saved, only the variables enabled as **Show to User** can be modified.

> Note: Before cloning, ensure that the environment template is shared with the target SKU.

After the changes are saved, the customized SKUs become available in the Ops Console, where they can be shared with one or more organizations.

> **Important**
> - Refer to **[this page](https://docs.rafay.co/aiml/gpupaas/service_profile/)** to create a custom service sku
> - Refer to **[this page](https://docs.rafay.co/aiml/gpupaas/compute_profile/)** to create a custom compute sku

---
