---
title: "PaaS Instance Email Notifications"
source: https://docs.rafay.co/aiml/gpupaas/administration/instance_alerts/
---

# Instance Email Notifications

PaaS Instance Notifications provide automated email alerts when lifecycle events occur on PaaS compute and service instances. These alerts help stakeholders stay informed about key operational states such as instance creation, deletion, and manual actions.

A single toggle controls notifications for all PaaS instances. When enabled, email alerts are sent for the following events:

- Instance Creation – Success / Failure
- Instance Deletion – Success / Failure
- Instance Action (Start/Stop/Restart) – Success / Failure

Administrators can optionally specify one or more recipient email addresses to receive these notifications.

---

## **Configure Instance Notifications**

1. Navigate to **Administration** → **Events & Reports** → **Alerts** → **Manage Notifications**.
2. Enable the **Instance Notifications** toggle.
3. (Optional) Add **Recipient Emails** to send notifications to specific email addresses.
4. Click **Save**.

[![Notification Email Example](https://docs.rafay.co/aiml/gpupaas/img/email_alerts.png)](https://docs.rafay.co/aiml/gpupaas/img/email_alerts.png)

Notifications are delivered based on the notification recipient policy described below.

**Notification Recipient Logic**

| Configuration State | Notification Recipient |
| --- | --- |
| Notifications enabled and recipient email(s) added | All configured recipients receive alerts |
| Notifications enabled but no recipient email added | The user who triggers the event receives the alert |
| Partner Org has recipient configured, Tenant does not | Partner Org recipient receives instance alerts |
| Tenant Org has recipient configured | Tenant Org recipient receives instance alerts |

**Example Notification Email**

The notification includes the instance status, action performed, and instance details, along with a direct link to view the instance if logged in.

[![Notification Email Example](https://docs.rafay.co/aiml/gpupaas/img/email_example.png)](https://docs.rafay.co/aiml/gpupaas/img/email_example.png)

---
