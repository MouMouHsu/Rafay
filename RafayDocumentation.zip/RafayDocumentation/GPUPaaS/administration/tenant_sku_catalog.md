---
title: "Default Compute and Service Profiles"
source: https://docs.rafay.co/aiml/gpupaas/administration/tenant_sku_catalog/
---

# SKU Catalogs

**SKU Catalog** in the Rafay console provides administrators with predefined **compute and service profiles (SKUs)** that can be used across the organization. Rafay develops and maintains a set of default SKUs that are available out of the box, allowing teams to quickly become operational with GPU PaaS without creating profiles from scratch.

The SKU Catalog presents a consolidated view of available compute and service SKUs, along with their sharing scope (for example, shared with all projects). Administrators can browse, search, and filter SKUs, review profile details, and share SKUs with one or more projects to control availability.

By using the SKU Catalog, organizations can ensure consistency across deployments, reduce setup time, and retain flexibility to extend or customize SKUs to meet specific requirements.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/system_profiles.png)](https://docs.rafay.co/aiml/gpupaas/img/system_profiles.png)

Administrators can share profile catalogs across one or more projects. Once shared, the profiles are available within those projects, allowing administrators to use them when creating instances within the specified projects. For example, the service profile "system-mks-kubeflow-test" is shared with a project "defaultproject." Now click **Save Changes**

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/share_profile.png)](https://docs.rafay.co/aiml/gpupaas/img/share_profile.png)

Once the service profile is shared, end users can navigate to the **defaultproject -> Service Profiles**. Here, the user can view the shared service profile listed on the **Service Profiles** dashboard.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/serviceprof_default.png)](https://docs.rafay.co/aiml/gpupaas/img/serviceprof_default.png)

Users can now use this service profile when deploying a service instance.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/service_instance_default.png)](https://docs.rafay.co/aiml/gpupaas/img/service_instance_default.png)

> **Important**
> - Refer to **[this page](https://docs.rafay.co/aiml/gpupaas/service_profile/)** to create a custom service profile
> - Refer to **[this page](https://docs.rafay.co/aiml/gpupaas/compute_profile/)** to create a custom compute profile

---

## Default Service Profiles

### Notebooks

Notebooks in GPU PaaS enable users to seamlessly launch Jupyter notebooks with GPU-accelerated compute for AI, ML, and data science workloads. These are optimized for high-performance tasks, leveraging predefined profiles for efficient resource allocation.

### Inferences

Inference in GPU PaaS enables deploying trained AI/ML models for real-time or batch predictions with GPU acceleration, optimizing performance for tasks like image recognition and anomaly detection. The Rafay console simplifies this by centralizing inference endpoint configuration, ensuring scalability, consistency, and secure access.

### AI/ML Jobs

The AI/ML Jobs feature in GPU PaaS allows users to define, configure, and execute resource-intensive AI/ML tasks, such as model training and data processing, with ease. It streamlines workflows by automating resource provisioning, ensuring consistency, and providing scalability for both experimentation and production deployments.

### Custom Services

Custom services in GPU PaaS enable users to deploy and manage services optimized for GPU-accelerated workloads. These services offer flexibility for integrating specialized AI/ML workflows, ensuring high performance and scalability.

> Important:
> Similar to Profile Catalogs, default compute profiles can also be shared with the required project and used when deploying a compute instance within that project.

---
