---
title: "Instance Provisioning Control"
source: https://docs.rafay.co/aiml/gpupaas/csp/kyc/
---

# Provisioning Control

The **Instance Provisioning Control** allows administrators to **block** the provisioning of compute and service instances (e.g., Bare Metal, VMs, Notebooks) for an organization. When provisioning control is enabled, API calls attempting to create instances will return an error response with a **customizable message** explaining the reason for the restriction.

This mechanism supports various scenarios, such as:
 - Pending **KYC** approval
 - **Payment due** or billing issues
 - **Compliance or security requirements**
 - **User access suspension**
 - Any **organization-specific business rule**

---

## How It Works

- Provisioning control is enabled by setting **`paas_compute_disabled`** or **`paas_service_disabled`** to `true` in the **Organization Partner API**
- The message included in the API response is **fully customizable** at the organization level via Partner API
- HTML formatting is supported in the message body
- **No UI configuration or controls are provided** — provisioning control can only be enabled or disabled via Partner API

---

## API Response Behavior

When provisioning control is active:

- Any API request to create a compute or service instance will fail
- The API response will include the configured message in the error details

Example of a message displayed when provisioning control is active:

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/kyc/kyc.png)](https://docs.rafay.co/aiml/gpupaas/img/kyc/kyc.png)

---

## Customization

Administrators can:

- Modify the **message content** for any business scenario (KYC, payment, compliance, etc.)
- Include **HTML formatting** for links, images, or styled notices
- Manage settings at **organization** or **partner** level via API only

---

## Configuration via API

Organization Partners can enable/disable provisioning control and set custom messages through the **Organization API**. Below is an example where the partner API is used to enable provisioning control for both compute and service instances with a **custom** KYC message.

```
curl --location --request PUT 'https://<ops-console-host>/auth/v1/organizations/<organization-id>/' \
--header 'X-RAFAY-API-KEYID: <api-key>' \
--header 'Content-Type: application/json' \
--data-raw '{
    "id": "<organization-id>",
    "name": "Billing Demo",
    "settings": {
        "paas_compute_disabled": true,
        "paas_service_disabled": true,
        "paas_compute_disable_message": "<style>.kyc-button{background:#3aaca1;color:#fff;padding:12px 24px;border:none;border-radius:4px;cursor:pointer;font-size:16px}</style><div><h2>KYC Pending!</h2><p>Your KYC is pending. Once it is approved, you will be notified and granted access to the following GPU products.</p><ul><li>PaaS VM (H100, L40s)</li><li>PaaS Baremetal (H100, L40s)</li><li>PaaS Notebook</li></ul><a href=\"https://example.com\" target=\"_blank\" class=\"kyc-button\">Click Here</a></div>",
        "paas_service_disable_message": "<style>.kyc-button{background:#3aaca1;color:#fff;padding:12px 24px;border:none;border-radius:4px;cursor:pointer;font-size:16px}</style><div><h2>KYC Pending!</h2><p>Your KYC is pending. Once it is approved, you will be notified and granted access to the following GPU products.</p><ul><li>PaaS VM (H100, L40s)</li><li>PaaS Baremetal (H100, L40s)</li><li>PaaS Notebook</li></ul><a href=\"https://example.com\" target=\"_blank\" class=\"kyc-button\">Click Here</a></div>"
    }
}'
```

--

## Parameters

- `paas_compute_disabled`: `true` disables compute instance provisioning.
- `paas_service_disabled`: `true` disables service instance provisioning.
- `paas_compute_disable_message`: Custom HTML message displayed for compute provisioning restrictions.
- `paas_service_disable_message`: Custom HTML message displayed for service provisioning restrictions.
- `target_link`: The HTML can include a clickable link (e.g., “Click Here”) that directs users to a customer-defined URL. This link can point to any page, such as a helpdesk form, documentation, or a verification process page to resolve the restriction.

> 💡 Note:
> - Not limited to KYC — supports any reason for restricting instance creation
> - Works across all compute and service provisioning APIs
> - Messages are customizable and dynamic, ensuring users clearly understand the restriction reason

---
