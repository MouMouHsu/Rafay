---
title: "Roles in the Platform"
source: https://docs.rafay.co/aiml/gpupaas/csp/gpu_paas_tenant_roles/
---

# Tenant Roles

## Roles Overview

Tenant Organizations have three primary roles, each designed with clearly defined responsibilities and scoped access:

- **Tenant Admin**
- **PaaS Project Admin**
- **PaaS End Users**

Each role provides a different level of access to resources and platform portals, as detailed below.

---

## Tenant Admin

Tenant Admins are responsible for overall governance, configuration, and operational management of the organization.

### Responsibilities

Tenant Admins can:

- Create and manage projects for teams
- Share CSP profiles with projects
- Customize profiles with overrides (if permitted by the Cloud Provider)
- Set and manage quotas for projects
- Configure policies (for example, scheduling policies)
- Manage users and role assignments
- Configure an Identity Provider (IdP) for Single Sign-On (SSO)
- View audit logs
- Manage additional system-level settings

### Portal Access

Tenant Admins have access to:

- **Administration**
- **SKU Management**
- **Usage Dashboards**
- **Developer Hub**

---

## PaaS Project Admin

PaaS Project Admins manage resources within the specific projects to which they are assigned.

### Responsibilities

Within their assigned projects, Project Admins can:

- View the projects they have access to
- Access all workspaces within those projects
- Create new workspaces
- Launch instances based on shared SKUs available to the project

Their permissions are restricted strictly to their assigned projects.

### Portal Access

PaaS Project Admins have access to:

- **Usage Dashboards** (project scope only)
- **Developer Hub** (project scope only)

---

## PaaS End Users

PaaS End Users are developer-focused roles, which include:

- Developer
- Researcher
- Data Engineer
- Data Scientist
- MLOps Engineer
- GenAI Developer

### Responsibilities

End Users can:

- Create workspaces
- Launch instances based on available SKUs
- Add collaborators to their own workspaces

They **do not**:

- Have visibility into other workspaces within the same project
- Have administrative, quota management, or policy configuration permissions

This model ensures workspace-level isolation within shared projects.

### Portal Access

PaaS End Users have access to:

- **Developer Hub only**

---

## Summary

| Role | Scope | Key Capabilities | Portal Access |
| --- | --- | --- | --- |
| **Tenant Admin** | Organization-wide | Organization governance, project creation, quota management, policy configuration, user management, SSO, audit visibility | Administration, SKU Management, Usage Dashboards, Developer Hub |
| **PaaS Project Admin** | Assigned Projects | Manage project workspaces and launch instances using shared SKUs | Usage Dashboards (project scope), Developer Hub (project scope) |
| **PaaS End Users** | Individual Workspace | Create and manage their own workspaces and launch instances | Developer Hub only |

---
