---
title: "Tenant Lifecycle"
source: https://docs.rafay.co/aiml/gpupaas/csp/ops_tenantonboarding/
---

# Tenant Lifecycle

## Overview

Tenant Lifecycle allows partners to configure the templates that run automatically when a tenant is provisioned onto or removed from the Rafay platform, with no manual setup required. It provides two configurations, **Add Tenant** and **Delete Tenant**, each with its own template name, version, and overrides.

A single Tenant Lifecycle configuration is supported per partner, and this configuration applies to all tenants onboarded under that partner.

---

## Benefits

- Provides a centralized place to configure the templates used for provisioning and deprovisioning tenants
- Ensures the correct template and version are used consistently across all tenant lifecycle operations
- Allows environment, variable, and file overrides to be layered on top of the template
- Runs the configured templates automatically as tenants are added and removed

---

## Prerequisites

Tenant Lifecycle settings should be configured when:

- A specific template must be run when a new tenant is provisioned onto the Rafay platform
- A specific template must be run when a tenant is deprovisioned from the Rafay platform
- Overrides need to be applied on top of the template for provisioning or deprovisioning operations

> **Note**
> Tenant Lifecycle settings only control the lifecycle configuration. The actual tenant provisioning and deprovisioning is performed from **Tenants > Organizations**.

---

## How Tenant Lifecycle Works

1. **Pick Templates**: Choose the environment template and version for each event.
2. **Layer Overrides**: Add environment variables, variables, and files on top.
3. **Runs Automatically**: Each template is applied as tenants are added and removed.

---

## Configure Tenant Lifecycle

Navigation: **Operations Console > Tenant Management > Tenant Lifecycle**

The Tenant Lifecycle page displays two tabs: **Add Tenant** and **Delete Tenant**. Each tab holds the template and override configuration for that event.

[![Tenant Lifecycle](https://docs.rafay.co/aiml/gpupaas/img/tenantsonboarding.png)](https://docs.rafay.co/aiml/gpupaas/img/tenantsonboarding.png)

### Add Tenant

This configuration defines the template that runs automatically when a new tenant is provisioned onto the Rafay platform.

To configure the Add Tenant settings:

1. Select the **Add Tenant** tab and click **Edit Configuration**.
2. Under **Template**, select the **Name** and **Version** for this configuration.   Note Both **Name** and **Version** are required fields.
3. Optionally, configure overrides under the **Overrides** section:  
| Field | Description |
| --- | --- |
| **Environment Overrides** | Key/value pairs applied on top of the template. Click **Add Env** to add a pair. |
| **Variable Overrides** | Name/value pairs applied on top of the template. Click **Add Variable** to add a pair. |
| **File Overrides** | Files uploaded to override template defaults. Click **Add File** to upload a file. |
4. Click **Save**.  [![Tenant Lifecycle](https://docs.rafay.co/aiml/gpupaas/img/tens_config.png)](https://docs.rafay.co/aiml/gpupaas/img/tens_config.png)

To exit without saving, click **Cancel**.

Once saved, the **Add Tenant** tab displays the configuration with the template name, version, and applied overrides. If no overrides are configured, the Overrides field shows **No Overrides Applied**. To update the configuration, click **Edit Configuration**.

[![Tenant Lifecycle](https://docs.rafay.co/aiml/gpupaas/img/ten_add_view.png)](https://docs.rafay.co/aiml/gpupaas/img/ten_add_view.png)

### Delete Tenant

This configuration defines the template that runs automatically when a tenant is deprovisioned from the Rafay platform.

To configure the Delete Tenant settings:

1. Select the **Delete Tenant** tab and click **Edit Configuration**.
2. Under **Template**, select the **Name** and **Version** for this configuration.   Note Both **Name** and **Version** are required fields.
3. Optionally, configure overrides under the **Overrides** section:  
| Field | Description |
| --- | --- |
| **Environment Overrides** | Key/value pairs applied on top of the template. Click **Add Env** to add a pair. |
| **Variable Overrides** | Name/value pairs applied on top of the template. Click **Add Variable** to add a pair. |
| **File Overrides** | Files uploaded to override template defaults. Click **Add File** to upload a file. |
4. Click **Save**.  [![Tenant Lifecycle](https://docs.rafay.co/aiml/gpupaas/img/tens_delete.png)](https://docs.rafay.co/aiml/gpupaas/img/tens_delete.png)

To exit without saving, click **Cancel**.

Once saved, the **Delete Tenant** tab displays the configuration with the template name, version, and applied overrides. If no overrides are configured, the Overrides field shows **No Overrides Applied**. To update the configuration, click **Edit Configuration**.

[![Tenant Lifecycle](https://docs.rafay.co/aiml/gpupaas/img/ten_delete_view.png)](https://docs.rafay.co/aiml/gpupaas/img/ten_delete_view.png)

---

## Provisioning and Deprovisioning Tenants

Once the Tenant Lifecycle configuration is set up, partners can provision or deprovision tenants from the Organizations page.

Navigation: **Operations Console > Tenant Management > Organizations**

1. Click **Add Organization** to add a new organization for the tenant, if one does not already exist.
2. Click the actions menu (**⋯**) on the organization and select **Tenant Lifecycle**.
3. In the **Tenant Management** dialog, select one of the following options:

[![Organizations](https://docs.rafay.co/aiml/gpupaas/img/ten_onboarding.png)](https://docs.rafay.co/aiml/gpupaas/img/ten_onboarding.png)

| Option | Description |
| --- | --- |
| **Provision Tenant** | Provisions a new tenant for the organization. This runs the Add Tenant template configured in the Tenant Lifecycle page. |
| **Tenant Status** | Displays the tenant provisioning status and details. |
| **De-provision Tenant** | Deletes the tenant. This runs the Delete Tenant template configured in the Tenant Lifecycle page. |

Click **Close** to exit the dialog.

---
