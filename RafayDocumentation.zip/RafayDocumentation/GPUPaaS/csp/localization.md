---
title: "Localization"
source: https://docs.rafay.co/aiml/gpupaas/csp/localization/
---

# Localization

The **Localization** page in the Operations Console enables partners to configure multilingual experiences across supported portals. This includes configuring default languages, enabling language selection, managing translation modules, customizing translation files, and adding custom languages.

The Localization page is available under **User Experience** in the Operations Console.

Localization settings are inherited by all organizations under the partner.

## Accessing Localization Settings

To access localization settings:

- Log in to the **Operations Console** and navigate to **User Experience**.
- Click **Localization**.

[![Localization](https://docs.rafay.co/aiml/gpupaas/img/local_home.png)](https://docs.rafay.co/aiml/gpupaas/img/local_home.png)

### Default Language

The **Default Language** determines the language displayed when users access the portal for the first time.

English is selected by default. For example, a partner can change the default language to **French** so that end users see French when they access the portal for the first time.

[![Localization](https://docs.rafay.co/aiml/gpupaas/img/default_langs.png)](https://docs.rafay.co/aiml/gpupaas/img/default_langs.png)

After users log in, they can switch to any enabled language using the language selector.

### Enabled Languages

The platform provides the following languages out of the box:

- English
- Turkish
- Japanese
- French
- Spanish
- Arabic
- German
- Hindi

Partners can enable or disable languages based on their requirements.

[![Localization](https://docs.rafay.co/aiml/gpupaas/img/enabled_lists.png)](https://docs.rafay.co/aiml/gpupaas/img/enabled_lists.png)

> **Note**
> - The default language cannot be disabled.
> - Built-in languages can be enabled or disabled but cannot be deleted. Custom languages can be edited or deleted.
> - **Arabic** localization is currently supported only in the **Developer Hub**.

## Languages

Each configured language appears as a separate tab in the **Languages** section.

Selecting a language displays the available translation modules. Each module contains the translations used by that specific area of the platform.

The following translation modules are available for customization:

- Login
- SKU Studio
- SKU Management
- Developer Hub
- Developer Hub Navigation
- Dashboards
- Administration
- Operations Console

**French** is used as the sample language. The same workflow applies to any supported or custom language.

The platform provides default translations for supported out-of-the-box languages. Partners can further customize translated content to align with organizational terminology and branding requirements.

[![Language Customizations](https://docs.rafay.co/aiml/gpupaas/img/ops_cons.png)](https://docs.rafay.co/aiml/gpupaas/img/ops_cons.png)

## Managing Translation Files

Each translation module contains a JSON-based translation file.

For every module, partners can:

- Download the current translation file.
- Modify translated labels and text.
- Upload an updated translation file.
- Save the changes.

### Uploading Custom Translations

To customize a translation:

1. Select **French** from the language list.
2. Select the required translation module.
3. Download the existing JSON file.
4. Update the translated values.
5. Upload the modified JSON file.
6. Click **Save**.

[![Language Customizations](https://docs.rafay.co/aiml/gpupaas/img/manage_files.png)](https://docs.rafay.co/aiml/gpupaas/img/manage_files.png)

Each module must be saved independently. Changes made to one module do not automatically update other modules.

> **Note**
> If a translation module is not customized, the platform continues to use the default translated content provided by Rafay.

## Compare & Edit

The **Compare & Edit** option opens a side-by-side translation editor.

- The left pane displays the latest English template.
- The right pane displays the selected language translation.
- Missing or newly added keys are highlighted for review.

If a required key exists in the English template but is missing from the selected language, the editor displays a validation error until the missing key is added.

[![Dev Hub Settings](https://docs.rafay.co/aiml/gpupaas/img/portal_example.png)](https://docs.rafay.co/aiml/gpupaas/img/portal_example.png)

> **Note**

Compare & Edit is primarily intended for validating translations and making small updates. For large-scale translation updates, download the translation file, modify it externally, and upload the updated file.

## Adding a New Language

Click **Add Language** to open the **Add New Language** dialog.

Enter the language name and click **Save**.

[![Dev Hub Settings](https://docs.rafay.co/aiml/gpupaas/img/new_lang.png)](https://docs.rafay.co/aiml/gpupaas/img/new_lang.png)

Once the language is created:

- A new language tab is added.

[![Dev Hub Settings](https://docs.rafay.co/aiml/gpupaas/img/lang_added.png)](https://docs.rafay.co/aiml/gpupaas/img/lang_added.png)

- Translation modules become available for customization.
- The language can be enabled or disabled.
- The language can be selected as the default language.
- Translation files can be downloaded, customized, and uploaded.

For example, if **Chinese** is added as a custom language, a new Chinese language tab is created. Translation files can then be customized and uploaded for each available module.

## Managing Translations for SKU Parameters

In the SKU Studio, SKU inputs and outputs can be presented to end users in multiple languages. The **Manage Translations** option allows admins to provide translated display names, tooltips, and descriptions for each variable. End users see these values in their selected language. If a field is not translated, it falls back to the default value defined in the SKU.

To open the translations window, login to the SKU Studio, select a SKU, and navigate to the **Input Settings** tab and click **Manage Translations**

[![Manage Translations](https://docs.rafay.co/aiml/gpupaas/img/sps_managetranslations.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_managetranslations.png)

The Manage Translations window displays all the input variables as rows and the supported languages as columns, including the inputs that are not shown to the end user. This allows the admin to translate only the variables exposed to end users or all the variables, based on the requirement. When multiple languages are configured, a horizontal scroll is available to update the values for each language.

The **tabs** at the top of the window allow the admins to switch between the translation types.

The **Display name** tab is used to provide the translated name shown for each variable in the input form.

[![Display Name](https://docs.rafay.co/aiml/gpupaas/img/sp_display_name.png)](https://docs.rafay.co/aiml/gpupaas/img/sp_display_name.png)

The **Tooltip** tab is used to provide the translated tooltip text that appears when the end user hovers over an input.

[![Tooltip Translation](https://docs.rafay.co/aiml/gpupaas/img/sps_tooltip.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_tooltip.png)

The **Description** tab is used to provide the translated description that offers detailed guidance for an input.

[![Description Translation](https://docs.rafay.co/aiml/gpupaas/img/sps_description.png)](https://docs.rafay.co/aiml/gpupaas/img/sps_description.png)

Instead of translating each field in the UI, the admin can use the **Download** option to export all the translations, including display names, tooltips, and descriptions, as a single file. The file can be edited offline to add the translated values for each language and then imported using the **Upload** option to apply the changes in bulk.

[![Description Translation](https://docs.rafay.co/aiml/gpupaas/img/show_lang.png)](https://docs.rafay.co/aiml/gpupaas/img/show_lang.png)

Once the translations are configured, click **Save Changes**.

Similar to Input Settings, the **Manage Translations** option is available for output settings to provide translated display names, tooltips, and descriptions for output variables.

[![Add Backup Policy](https://docs.rafay.co/aiml/gpupaas/img/service_outputs.png)](https://docs.rafay.co/aiml/gpupaas/img/service_outputs.png)

## End User Experience

After localization is configured:

- Enabled languages appear in the portal language selector.
- Users can switch between supported languages.
- Navigation labels are translated.
- Page titles and descriptions are translated.
- Static UI text is translated.
- Custom translations configured for the selected language are displayed.

[![Japanese Login](https://docs.rafay.co/aiml/gpupaas/img/login_pageset.png)](https://docs.rafay.co/aiml/gpupaas/img/login_pageset.png)

If no language preference exists, the configured default language is used.

Localization changes are automatically applied to all organizations associated with the partner.

---
