---
title: "Rate Cards"
source: https://docs.rafay.co/aiml/gpupaas/csp/rate_cards/
---

# Rate Cards

## Overview

Rate cards define the pricing structure for GPU PaaS resources. Each rate card is associated with a SKU and can be scoped to a specific organization or applied globally across all organizations.

> Note: Only one rate card can be configured per SKU per organization. Another rate card cannot be created for the same SKU under the same organization; attempting to do so results in an error.

---

## How Dimensions Work

Rate card pricing is built on **dimensions**. Dimensions are the input keys associated with the SKU. These inputs are not limited to the environment template. They can be configured in the environment template, in a resource template, or in a config context attached to an environment or resource template. All such inputs are available for use as dimensions in the rate card.

To view the available inputs for a SKU, navigate to **SKU Studio → SKUs → Compute (or) Service → Input Settings**. Each input key listed on this page (for example, `cpu`, `device_details`, `gpu`, `gpu_type`, `instance`, `memory`) can be used as a dimension in the rate card.

[![SKU Input Settings](https://docs.rafay.co/aiml/gpupaas/img/sku_input_settings.png)](https://docs.rafay.co/aiml/gpupaas/img/sku_input_settings.png)

> Dimension Mapping Rules:
> 
> 
> The Dimension field in the rate card must exactly match the input key name defined in the SKU's Input Settings. For example, device_details maps correctly, but device details or device-details will not map.
> 
> 
> It is not mandatory to configure a rate for every input key. Only the inputs you want to bill on need to be added as dimensions. A rate card can contain as few or as many dimensions as required.

---

## Accessing Rate Cards

- Log in to the **Operations Console**
- In the left navigation, select **Rate Cards**

[![Rate Cards](https://docs.rafay.co/aiml/gpupaas/img/ratecard.png)](https://docs.rafay.co/aiml/gpupaas/img/ratecard.png)

The Rate Cards list displays the name, organization scope, associated SKU, and the number of rate entries for each rate card. Use the **Filter by Organization** dropdown to filter the list by a specific organization.

---

## Create a Rate Card

- Log in to the **Operations Console**
- In the left navigation, select **Rate Cards**
- On the Rate Cards page, click **Add Rate Card**
- The Create Rate Card form opens with two sections: **General Information** and **Cost Configuration**

### General Information

| Field | Required | Description |
| --- | --- | --- |
| **Name** | Yes | Unique identifier for the rate card. Example: `ratecard-exp` |
| **Display Name** | No | Human-readable name shown in the console. Example: `GPU Hourly — Demo Purpose` |
| **Description** | No | Free-form, per-currency pricing text displayed as the **Cost** on the SKU card when users create an instance. Select a currency from the dropdown and enter the corresponding description (for example, `123/m`). Only one description is allowed per currency; add more currency-description pairs using **Add Description**. |
| **SKU** | Yes | The SKU this rate card applies to. The rate card is applicable **only** to the selected SKU. Example: `sku-check (Compute)` |
| **Organization** | Yes | The organization this rate card applies to. Select **All Organizations** to apply it globally, or select a specific organization from the list. See the note below on organization scoping. |

[![General Information](https://docs.rafay.co/aiml/gpupaas/img/ratecard_general.png)](https://docs.rafay.co/aiml/gpupaas/img/ratecard_general.png)

> Organization scoping and SKU availability:
> 
> 
> All Organizations can be selected even if the SKU is currently available in only one organization. The rate card takes effect wherever the SKU is available.
> 
> 
> Selecting a specific organization that does not have the SKU results in an error on save (the organization does not contain that SKU). To scope the rate card to that organization, first share the SKU with it using SKU Sharing.
> 
> 
> Rate card precedence: If the same SKU is configured in both a Global rate card and an Organization-scoped rate card, the Organization-scoped rate card takes precedence when the SKU is accessed within that specific organization. For all other organizations where no organization-specific rate card exists, the Global rate card is applied.

**Description Behavior**

- The description is displayed as the **Cost** on the SKU card when a user creates a new instance and selects a SKU from the **Available Compute or Service SKUs** panel. It represents the approximate charge for using that SKU.

[![SKU card showing description as Cost](https://docs.rafay.co/aiml/gpupaas/img/sku_card_cost.png)](https://docs.rafay.co/aiml/gpupaas/img/sku_card_cost.png)

- Only the description matching the **organization's default currency** is displayed. The default currency for an organization is configured in the **Operations Console**, under **Organizations → Select Organization → Settings → Default Currency**, and is the currency used for all billing and pricing calculations for that organization.
- If descriptions are configured for multiple currencies (for example, USD and INR), and the organization's default currency later changes, the description for the new default currency is displayed automatically.

[![SKU card showing description as Cost](https://docs.rafay.co/aiml/gpupaas/img/org_currency.png)](https://docs.rafay.co/aiml/gpupaas/img/org_currency.png)

- If no description is configured (or the description is deleted), the UI falls back to displaying the computed price of the highest-priority dimension (the `instance` dimension) instead — for example, `1.2 per hour USD`.

---

### Cost Configuration

#### Basic Settings

| Field | Required | Description |
| --- | --- | --- |
| **Estimation Unit** | Yes | The unit used to display the **overall** cost estimate to users. Options: **Hourly**, **Monthly**. This applies to the aggregate base price shown for the SKU. Individual dimensions are billed on their own **Billing Unit** (see below), which can differ per dimension. |

#### Rates

Rates define how usage is priced across resources such as GPUs, CPU, RAM, and Public IP. Select **Add Rate** to add a pricing dimension.

| Field | Required | Description |
| --- | --- | --- |
| **Dimension** | Yes | The input key being priced. Must **exactly match** an input key defined in the SKU's Input Settings. Examples: `cpu`, `device_details`, `gpu_type`. |
| **Alias** | No | Display name for the dimension shown to users at the instance level, in place of the raw dimension name. Example: `device_1`. |
| **Resource** | No | The specific input value this rate applies to. When the user enters this value for the dimension at the instance level, the corresponding price is applied. Values can be numeric (`1`, `2`, `5`) or alphabetical (`true`, `false`, `A100`, `H100`). If the user enters a value that does not match any configured Resource, no price is mapped. |
| **Currency** | Yes | The currency for this rate entry. Supported values: USD, EUR, GBP, INR, JPY, CNY, AUD, CAD, CHF, SEK. The rate is applied only when this currency matches the organization's **default currency** (see the multi-currency note below). |
| **Price** | Yes | The numeric price for this dimension per billing unit, applicable to the quantity defined in **Base Unit**. |
| **Billing Unit** | Yes | The time unit for billing **this dimension**. Options: **Hour**, **Day**, **Month**. Each dimension can use a different billing unit — for example, `cpu` billed per hour and `device_details` billed per day. |
| **Base Unit** | No | Defines the billing unit against which the configured price is applied. The pricing engine uses it to normalize cost calculations and determine how pricing should be interpreted. Defaults to `1`.  Use Base Unit when the price is configured for a specific quantity of a resource rather than a single unit. For example, if the price is set for every 2 GB of disk or every 10 units of a resource, then the Base Unit should be set accordingly.  **Example 1 (price per single unit):** Price `200`, Base Unit `1`. This means 200 is charged for every 1 unit consumed. If the user consumes 3 units, the total cost is 600.  **Example 2 (price per multiple units):** Price `10`, Base Unit `2`. This means 10 is charged for every 2 units consumed. If the user consumes 12 units, the total cost is 60.  See the Base Unit rules below for when this field must or must not be set. |
| **Conditional** | No | Determines how the rate input is derived. Options:  **No condition** (default) — the rate is priced on the value the user enters for this dimension.  **Count from** — the quantity is derived from another dimension.  **Value from** — the value is derived from another dimension (or the dimension itself).  See **Conditional Rates: Count from and Value from** below for details and rules. |
| **Dimension Name** | Conditional | Required only when **Conditional** is **Count from** or **Value from**; cannot be configured for **No condition**. Specifies the source dimension from which the count or value is derived. Must match an input key in the SKU's Input Settings. Example: `cpu`. |

[![Rate Entry](https://docs.rafay.co/aiml/gpupaas/img/basic_cost.png)](https://docs.rafay.co/aiml/gpupaas/img/basic_cost.png)

> Base Unit rules:
> 
> Cost calculations are performed by the UI: the entered quantity is multiplied by the (normalized) unit price. For example, with Price 20 and Base Unit 1, entering 2 at the instance level yields 2 × 20 = 40.
> When Resource uses non-numeric values such as true, false, yes, no, or other alphabetical values, the Base Unit should not be specified. If a Base Unit (for example, 1) is provided, the system interprets the resource as a numeric quantity (for example, 1 unit) and attempts to normalize the value, which leads to incorrect behavior.
> When Conditional is set to Count from or Value from, Base Unit is mandatory.
> 
> Currency and multi-currency pricing:
> 
> A rate entry is applied only if its currency matches the organization's default currency (configured in the organization settings).
> If the currencies do not match, the price is not reflected at the instance level.
> Because the default currency of a customer organization may vary, it is recommended to add one rate entry per currency for each dimension (for example, one in USD and one in INR). Only the entry matching the organization's default currency takes effect.

**Value-Based Rate Mapping**

Multiple rate entries can be added for the **same dimension** with different **Resource** values to price the dimension based on the value the user enters. For example, for the dimension `device_details`:

| Resource | Alias | Price | Result at instance level |
| --- | --- | --- | --- |
| `1` | `device_1` | 10 | Entering `1` shows $10.00/hour |
| `2` | `device_2` | 20 | Entering `2` shows $20.00/hour |

**Conditional Rates: Count from and Value from**

By default (**No condition**), a rate is priced based on the value the user enters for the dimension itself. The **Conditional** field allows the rate input to be derived from another dimension instead:

- **Count from** — the quantity for this dimension is taken from the dimension specified in **Dimension Name**. The user does not enter a value for this dimension directly; the count is derived from the source dimension. For example, if `device_details` (Price `10`, Base Unit `1`) is set to **Count from** `cpu`, entering `5` for `cpu` at the instance level automatically prices `device_details` as 5 × 10 = 50.
- **Value from** — the value for this dimension is taken from the dimension specified in **Dimension Name**. The source can be another dimension or the same dimension itself.

The following rules apply when using **Count from** or **Value from**:

- **Dimension Name** is mandatory and must exactly match an input key configured in the SKU's Input Settings (for example, `cpu`).
- **Base Unit** is mandatory.
- The derived price updates automatically at the instance level as the source dimension's value changes.

[![Conditional rate configuration](https://docs.rafay.co/aiml/gpupaas/img/conditional_rates.png)](https://docs.rafay.co/aiml/gpupaas/img/conditional_rates.png)

Select **Clone Rate** to duplicate an existing rate entry. All field values from the original entry are copied into the new entry, which can then be modified as needed. This is useful when configuring multiple Resource values or multiple currencies for the same dimension. Select **Delete Rate** to permanently remove a rate entry.

[![Rate Entry](https://docs.rafay.co/aiml/gpupaas/img/clone_ratecard.png)](https://docs.rafay.co/aiml/gpupaas/img/clone_ratecard.png)

- Once all fields are configured, click **Create Rate Card**
- To exit without saving, click **Discard Changes & Exit**

Upon successful creation, a confirmation message is displayed and the new rate card appears in the Rate Cards list.

[![Rate Entry](https://docs.rafay.co/aiml/gpupaas/img/ratecards_list.png)](https://docs.rafay.co/aiml/gpupaas/img/ratecards_list.png)

---

## Pricing at the Instance Level

When a user creates an instance with a SKU that has a rate card:

- Navigating to **SKU Studio → Instances → Compute (or) Service** and clicking **New Compute (or) Service Instance** opens the **Available Compute or Service SKUs** panel. The rate card **description** (or the fallback price) is shown as the **Cost** on each SKU card.
- On the **Compute (or) Service Instance Configuration** page, as the user enters values for the priced dimensions under **Input Settings**, the mapped price is displayed below the field. For example, entering `1` for `device_details` displays `$10.00 /hour`.
- The estimate panel displays the overall cost based on the **Estimation Unit**. For example, **Monthly estimate: $7,300.00 /month**, along with the approximate hourly equivalent. It also includes an itemized breakdown of the estimate per dimension, with each item listed by its **Alias** (for example, `Device_1`), and a **Total**. The estimate recalculates automatically as input values change.

[![Instance level pricing](https://docs.rafay.co/aiml/gpupaas/img/instance_pricing.png)](https://docs.rafay.co/aiml/gpupaas/img/instance_pricing.png)

When a dimension is configured with **Count from** or **Value from**, the derived quantity drives the price at the instance level:

- The user does not enter a value for the derived dimension directly. Its quantity is taken automatically from the source dimension specified in **Dimension Name**.
- For example, `device_details` is configured to **Count from** `cpu`, priced at $10/hour per unit.
- When the user enters `7` for `cpu`, the price for `device_details` is automatically displayed as `$70.00 /hour` (7 × $10).
- The overall estimate recalculates accordingly — in this example, the monthly estimate updates to **$51,100.00 /month**.

---
