---
title: "Multiple Customers"
source: https://docs.rafay.co/aiml/gpupaas/csp/customers/
---

# Multiple Tenants

With Rafay GPU PaaS, every GPU cloud provider gets access to a dedicated **operations portal** that they can use to manage **multiple orgs** (aka tenant). Each customer of the GPU Cloud Provider will be provisioned with an isolated [Rafay Org](https://docs.rafay.co/security/rbac/orgs/).

[![GPU PaaS Cloud Provider](https://docs.rafay.co/aiml/gpupaas/multitenancy/img/hierarchy.png)](https://docs.rafay.co/aiml/gpupaas/multitenancy/img/hierarchy.png)

---
