---
title: "Notifications"
source: https://docs.rafay.co/aiml/gpupaas/csp/notification/
---

# Notifications

The **Notifications** page enables partners to customize system-generated emails and configure in-console notifications displayed to users in the partner portal. The page contains two tabs: **Email Templates** and **In-Console Notifications**.

The Notifications page is available under **User Experience** in the Operations Console.

## Accessing Notifications

To access notifications:

- Log in to the **Operations Console** and navigate to **User Experience**.
- Click **Notifications**.

[![Notifications](https://docs.rafay.co/aiml/gpupaas/img/notifications_nav.png)](https://docs.rafay.co/aiml/gpupaas/img/notifications_nav.png)

---

## Email Templates

The **Email Templates** tab enables partners to customize system-generated emails sent by the platform. Partners can modify email subjects, customize HTML content, configure localized versions of templates, and preview the final email before saving changes.

### Email Languages

The **Email Languages** section determines the languages available for email content.

The default language configured on the [Localization](https://docs.rafay.co/aiml/gpupaas/localization/) page is automatically available in Email Templates and cannot be removed. A lock icon is displayed next to the default language to indicate it cannot be removed. Additional languages can be added to provide localized email content.

> **Note**
> Email Templates use the languages configured on the **Localization** page. The default language configured in Localization is automatically available and cannot be deleted or removed from Email Templates.

To add a language:

1. Click **Add Language**.
2. Search for and select the required language from the list.
3. Configure the localized email content and click **Save Changes**.

[![Email Languages](https://docs.rafay.co/aiml/gpupaas/img/email_language.png)](https://docs.rafay.co/aiml/gpupaas/img/email_language.png)

### Available Email Templates

The platform provides several predefined email templates for common user lifecycle and account management workflows, such as account creation, invitations, password management, email verification, and sign-up notifications.

Examples include:

- Account Creation
- Account Invitation
- Password Reset
- Email Verification Success

Select a template from the **Available Email Templates** dropdown to customize its subject, content, and localized versions.

[![Available Email Templates](https://docs.rafay.co/aiml/gpupaas/img/email_template_list.png)](https://docs.rafay.co/aiml/gpupaas/img/email_template_list.png)

### Customizing Email Content

Each email template contains:

- Subject
- Body (HTML)
- Template Variables
- Email Preview

#### Subject

The **Subject** field defines the email subject line displayed to recipients.

#### Body (HTML)

The **Body (HTML)** editor contains the HTML content used to generate the email. Administrators can customize the content while retaining the supported template variables.

#### Copy from Language

When creating content for a newly added language, the **Copy from \<Language>** option can be used to copy the subject and body content from an existing language into the currently selected language. The copied content can then be translated and customized as required before saving.

[![Copy From Language](https://docs.rafay.co/aiml/gpupaas/img/copy_langs.png)](https://docs.rafay.co/aiml/gpupaas/img/copy_langs.png)

#### Available Variables

The **Available Variables** section displays the variables supported by the selected template. Click a variable to insert it at the current cursor position.

For example, the **Account Creation** email template supports the following variables:

- `{{.AdminConsoleUrl}}`
- `{{.FirstName}}`
- `{{.OrgName}}`
- `{{.PartnerHelpdeskEmail}}`
- `{{.PartnerProductName}}`
- `{{.PartnerSupportTeam}}`
- `{{.TempPassword}}`

The available variables vary by template and are displayed dynamically based on the selected email template.

#### Previewing Emails

The **Final Email** panel displays a live preview of the email generated from the current subject and HTML content across all configured languages.

An info banner above the Subject field indicates that recipients receive a single email with every selected language stacked in order, and that the preview reflects that combined email.

[![Email Preview](https://docs.rafay.co/aiml/gpupaas/img/emails_preview.png)](https://docs.rafay.co/aiml/gpupaas/img/emails_preview.png)

### Email Localization

Email templates support multiple languages. When multiple languages are configured, recipients receive a single email containing content for each selected language.

Content for the default language is always included first. Additional language content is appended in the order configured.

For example, if French (default) and English are configured, the email contains:

- French content
- English content

> **Note**
> Content for the default language is always included in outgoing emails. Additional language content is appended after the default language content in the order configured.

#### Localized Subjects

The same behavior applies to email subjects. When a localized subject is configured, the localized subject is appended to the default language subject in the final email.

### Saving Changes

After updating the email template:

1. Review the preview.
2. Click **Save Changes**.

Use **Reset** to discard unsaved changes and restore the last saved version of the template.

> **Note**
> - Changes made to the email subject or body are not saved automatically. After creating or updating content for a language, click **Save Changes** to preserve the updates.
> - If you switch to another language or email template without saving, an **Unsaved Changes** dialog is displayed. Select **Keep editing** to continue working on the current content or **Discard & switch** to discard the unsaved changes and switch to the selected language or template. [![Unsaved Changes](https://docs.rafay.co/aiml/gpupaas/img/unsaved_error.png)](https://docs.rafay.co/aiml/gpupaas/img/unsaved_error.png)

---

## In-Console Notifications

The **In-Console Notifications** tab allows you to configure maintenance window notifications that are displayed to users in the partner portal. You can control the notification content, visibility window, and the organizations that can view the notification.

### Notifications List

The notifications list displays the following columns for each notification:

| Column | Description |
| --- | --- |
| **Title** | The notification title. |
| **Organization** | The organization(s) the notification is scoped to. |
| **Location** | Where the notification is displayed (Login, Console, or both). |
| **Start Time - End Time** | The visibility window for the notification. |
| **Status** | The current status of the notification. |
| **Actions** | Actions available for the notification. |

The status of a notification can be one of the following:

- **Active**: The notification is currently visible to users.
- **Expired**: The notification window has ended.

[![Notifications list](https://docs.rafay.co/aiml/gpupaas/img/note_home.png)](https://docs.rafay.co/aiml/gpupaas/img/note_home.png)

### Add a Notification

1. Click **Add Notification**.
2. Under **Notification Content**, enter a **Title**.
3. In the **Rich text or HTML body** field, enter the notification content. You can use plain text or HTML to include formatted text, links, and images. Click **Preview** to see how the notification will appear to users.

[![Add Notification](https://docs.rafay.co/aiml/gpupaas/img/notif_content.png)](https://docs.rafay.co/aiml/gpupaas/img/notif_content.png)

1. Under **Visibility**, configure the following:  
| Field | Description |
| --- | --- |
| **Location** | Select where the notification is displayed. Select **In console** to show the notification to logged-in users, **Login page** to show it on the login page, or **Both** to show it in both locations. The default value is **In console**. |
| **Start time** | Select the date and time when the notification becomes active. The default value is the current time in the browser's local time zone. |
| **End time** | Select the date and time when the notification expires. |
2. Under **Scope**, the available options depend on the **Location** selected in step 4:
  - If **Location** is set to **In console**, select **All Organizations** to display the notification to all organizations, or select **Specific Organizations** and choose one or more organizations.
  - If **Location** is set to **Login page** or **Both**, scope selection is not available. The message **This notification will be shown to all tenants.** is displayed instead.

[![Add Notification](https://docs.rafay.co/aiml/gpupaas/img/scope.png)](https://docs.rafay.co/aiml/gpupaas/img/scope.png)

> **Note**
> Only one notification can be active within a given time period. If the configured time window overlaps with an existing notification, the system displays an error and the notification cannot be saved.

1. Click the dropdown arrow on the save button and select one of the following:
  - **Save as Draft**: Saves the notification without publishing it.
  - **Save & Publish**: Saves and publishes the notification. The notification status is set to **Scheduled** and becomes active at the configured start time.

[![Save options dropdown](https://docs.rafay.co/aiml/gpupaas/img/note_save.png)](https://docs.rafay.co/aiml/gpupaas/img/note_save.png)

Once the notification is saved and published, it appears in the notifications list with its configured start and end time and the current status.

To manage an existing notification, click the ellipsis icon in the Actions column and select one of the following:

- **Edit**: Opens the notification to modify the content or visibility settings.
- **Unpublish**: Removes the notification from the portal without deleting it.
- **Delete**: Permanently deletes the notification.

[![Notification actions](https://docs.rafay.co/aiml/gpupaas/img/action.png)](https://docs.rafay.co/aiml/gpupaas/img/action.png)

### Viewing Notifications

When an active notification is available for the organization, a notification indicator appears next to **Notifications** in the left navigation. Users who are logged in to an organization for which the notification is configured can click **Notifications** to open the **Latest Updates** panel and view the notification content. Click **Mark all as read** to dismiss the indicator.

[![Latest Updates panel](https://docs.rafay.co/aiml/gpupaas/img/note_display.png)](https://docs.rafay.co/aiml/gpupaas/img/note_display.png)

---
