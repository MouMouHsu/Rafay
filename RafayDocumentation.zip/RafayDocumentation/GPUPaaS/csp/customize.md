---
title: "Partner Console - Theme Customization Guide"
source: https://docs.rafay.co/aiml/gpupaas/csp/customize/
---

# White Labeling

The Partner Portal now includes advanced customization options to support partner branding across various areas, including login/signup screens, Developer Hub, and PaaS Studio.

> **Info**
> Please review the related white labeling section

---

## Overview of Customization Features

The following customization options are available in the Partner Portal:

- **Basic Information:** Partner Name, Description, and Console Host configuration.
- **Portal Settings:** GSLB, Self Signup, Default Portal Redirection, and API/Support Links.
- **Authentication/Branding:**
  - Theme Customization (Primary, Secondary, Sidebar Colors).
  - Login/SSO Button Labels and SSO Email Pre-Population.
  - Login Layout, Logo Branding (Light/Dark), and Background Image.
  - Custom Signup URL and Label.
- **Contact & Legal:**
  - Contact and Support Email configuration.
  - Terms of Service, Documentation URL, and Privacy Policy configuration.
- **Portal Content Customization:**
  - Application Catalog Display, Grouping, and Configuration.
  - Customizing Available Compute and Service Types.
  - Renaming the Developer Hub Portal.

---

## Accessing Theme Customization Settings

To access and modify theme customization settings:

- Log in to the **Partner Console** and select a partner from the list
- Click the **Edit** icon for the selected partner
- Navigate to the **Theme** tab

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/console_customs.png)](https://docs.rafay.co/aiml/gpupaas/img/console_customs.png)

---

## Theme Customization

> ℹ️ Minimum Controller Version: v3.1-31

By default, users see the system-defined theme colors until custom colors are configured.

Customize the **Primary**, **Secondary**, and **Sidebar** colors used across the SAAS portal. Customizing these colors will be reflected **on the following pages**:

- Login/Signup page
- Developer Hub
- PaaS Studio
- When colors are selected, a preview is displayed on the right pane, showing how the customized theme will appear
- Click **Save Changes** to apply the updated color settings
- A **Reset to Default** option is available to remove the custom settings and restore the default configuration.

> These changes apply at the partner level and affect all organizations under the partner.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/colors_preview.png)](https://docs.rafay.co/aiml/gpupaas/img/colors_preview.png)

---

## Additional Customization Options

In addition to theme colors, the following options are available for partners who want deeper customization of their console experience. These settings help tailor the branding and user interaction on the login, signup, and related pages.

- On the Partner page, click on **Edit Partner Details**

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/edit_button.png)](https://docs.rafay.co/aiml/gpupaas/img/edit_button.png)

### Basic Info

The **Basic Info** tab in the *Edit Partner Details* screen allows you to configure essential identification, domain, and host information for the partner.

#### Basic Information

| Field | Description | Example (from image) |
| --- | --- | --- |
| **Name** | The official, primary name of the partner. | `Rafay Airgap` |
| **Description** | A brief description of the partner's role or offering. | `Rafay Cloud Partner` |

#### Domain & Host Configuration

This section defines the networking and access configuration for the partner environment.

| Field | Description | Example (from image) |
| --- | --- | --- |
| **Domain** | The root domain name associated with the partner's console and services. | `Team Rafay` |
| **Admin Console Host** | The specific hostname used to access the administrative interface or partner console. | `console.qc-gpupaas.dev.rafay-edge.net` |
| **Ops Console Host** | The specific hostname used to access the Operations Console, if applicable. | `ops-console.qc-gpupaas.dev.rafay-edge.net` |

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/basics_info.png)](https://docs.rafay.co/aiml/gpupaas/img/basics_info.png)

---

### Settings

The **Settings** tab in the *General Settings* screen allows you to configure general system behavior, billing defaults, platform capabilities, and support access for the partner's environment.

#### General Settings

This section contains various checkboxes to control visibility and core system features.

| Setting | Description |
| --- | --- |
| **GSLB** | Enables global server load balancing across datacenters. |
| **Self Signup** | Lets new users create their own account instead of being invited. |
| **API Docs Link** | Shows the API documentation link in the portal. On by default. |
| **Disable System Domain** | Hides the system generated domain so only your custom domain is used. |
| **Hide Portal Title (Default: SKU Studio/Developer Hub)** | Hides the product name beside the logo, for logo only branding. |
| **Hide Controller Version in Footer (Default: Disabled)** | Hides the controller version string in the portal footer. |

[![General Settings tab](https://docs.rafay.co/aiml/gpupaas/img/settings_tab.png)](https://docs.rafay.co/aiml/gpupaas/img/settings_tab.png)

#### Billing Settings

This section applies to every price, rate card, and cost estimate across the platform.

| Setting | Description |
| --- | --- |
| **Default Currency** | The currency used for all billing and pricing calculations. |

#### Capabilities

This section contains capability flags that control which features and service types this partner can offer tenants.

| Setting | Description |
| --- | --- |
| **Enable Token Factory** | Gives tenants model APIs, API keys, and token usage. On by default. |
| **Enable SKU Creation** | Lets tenants author their own SKUs rather than only consuming yours. |
| **Enable Serial Console Access for Bare Metal and VMs** | Enables serial console access for Bare Metal and VM instances. |
| **Enable paasctl** | Enables the paasctl command line tool. |
| **Enable Native Experience for Platform Offerings** | Native SKU types are served by purpose built APIs and interfaces, rather than the generic contract that has to cover every type. |

**Enable Native Experience for Platform Offerings** makes native SKU types available, served by purpose built APIs and interfaces, rather than the generic contract that has to cover every type. There is no separate toggle for this option; selecting a compute type's checkbox below enables native experience for that type directly.

| Compute Type | Description |
| --- | --- |
| **Virtual Machine** | Enables native experience for Virtual Machine SKUs. |
| **Bare Metal** | Enables native experience for Bare Metal SKUs. |
| **Kubernetes** | Enables native experience for Kubernetes SKUs. |
| **Pod** | Enables native experience for Dev Pods SKUs. |

[![Capabilities section](https://docs.rafay.co/aiml/gpupaas/img/capabilities.png)](https://docs.rafay.co/aiml/gpupaas/img/capabilities.png)

**Instance listing layout** determines how the instance listing screen is arranged in the Developer Hub. This applies to every native service, so tenants see one consistent shape.

| Option | Description |
| --- | --- |
| **Tabbed** | Instance types sit behind tabs, one list on screen at a time. Compact, and the default. |
| **Stacked** | Every instance type appears on one scrolling page, each below the last. Better for scanning everything at once. |

When **Stacked** is selected, configure **Listing order** to determine which family appears first:

| Option | Description |
| --- | --- |
| **Native first** | Native services lead, with the custom catalog beneath. The default. |
| **Custom first** | The custom catalog leads, with native services beneath. |

[![Instance listing layout and listing order](https://docs.rafay.co/aiml/gpupaas/img/instance_listing_layout.png)](https://docs.rafay.co/aiml/gpupaas/img/instance_listing_layout.png)

#### Tenant Storage Types (Operations Console)

When Ops users add or edit tenant storages for this partner, the storage type dropdown uses the values configured here. **Value** is stored on the tenant storage; **Label** and **Logo URL** are shown in the UI. Leave customization off to use the default list. `CUSTOM` allows a free text type; if omitted, it is added automatically.

| Field | Description |
| --- | --- |
| **Customize storage type list for this partner** | Enable to define a custom storage type list below. When disabled, the platform's default storage types are used. |
| **Value (Stored Type)** | The value stored on the tenant storage. |
| **Display Label** | The label shown to operators in the UI. |
| **Logo URL** | The logo shown to operators in the UI. |

Click **+ Add type** to add a new storage type, or the trash icon to remove one. Click **Save Changes** to apply, or **Discard** to cancel.

[![Tenant storage types](https://docs.rafay.co/aiml/gpupaas/img/tenant_storage_types.png)](https://docs.rafay.co/aiml/gpupaas/img/tenant_storage_types.png)

---

### Login/Signup Configuration

The **Login/Auth** tab allows partners to customize the authentication experience for their users, including button labels, Single Sign-On (SSO) settings, signup links, and the visual layout of the login page.

| Field / Setting | Description | Example |
| --- | --- | --- |
| **Login Label** (Default: `Login`) | Customizes the text displayed on the primary sign-in button on the login page. | `Login with Email ID` |
| **Login SSO Label** (Default: `Login With SSO`) | Customizes the text displayed on the single sign-on (SSO) button on the login page. | `Login with SSO Email ID` |
| **Query Param for Login Hint (Optional)** | Specifies the query parameter name used to pass a login hint, such as an email address, to the Identity Provider (IDP) so it can pre-fill the field during SSO login. **(See detailed explanation below).** | `saml_login_hint` |
| **Signup Label** | Customizes the text of the sign-up link shown beneath the login form. | `Register Now` |
| **Signup URL** | Specifies the URL the sign-up link redirects to. Use this to point to a custom signup page instead of the default `/signup` path. | `https://www.console.com` |
| **Page Layout Style** | Controls how the sign-in page is arranged. **Default** displays the login form in a single column, centered horizontally. **Split** displays the login form in a two column layout, with a background image in the left column. Click **Show preview** to preview the selected layout before saving. | `Default` |
| **Common IDP for all organisation** | When enabled, all organizations under this partner share a single Identity Provider (IDP) configuration instead of each organization configuring its own. Refer [Global IDP Page](https://docs.rafay.co/aiml/gpupaas/global_idp/) for more details. | `Enabled` |
| **Enable username login** | When enabled, users can sign in with a username in addition to their email address. Some Identity Providers only support usernames that are valid email addresses and may not allow non-email usernames to be configured. | `Enabled` |

#### Pre-Fill Email ID for SSO Logins

> ℹ️ Minimum Controller Version: v3.1-31

This feature is configured using the **Query Param for Login Hint** field. It is designed to improve user experience by pre-filling the user's email address on the SSO Identity Provider (IDP) login page, eliminating the need for manual entry.

Admins configure a query parameter name (e.g., `saml_login_hint`) that the portal appends to the SSO redirect URL. This parameter passes the user’s email ID to the IDP so it can be auto-filled on the login screen.

**Example:** `https://idp.partner.com/[email protected]`

> Important:
> 
> The IDP must support email auto-fill using query parameters.
> This is a customer-specific functionality. Contact Rafay Customer Support for assistance.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/login_options.png)](https://docs.rafay.co/aiml/gpupaas/img/login_options.png)

---

### Logo Branding

> ℹ️ Minimum Controller Version: v3.1-31

Partners can configure branding by specifying URLs for different logo and background image types.

- **Light Background Logo**: Used on login pages or areas with light-colored backgrounds.
  - Enter the image URL in the **Light Background** field.
 Example: `https://rafay.co/wp-content/uploads/2021/10/Rafay_Positive_Ver2x-1.png`
- **Dark Background Logo**: Displayed in the Developer Hub and PaaS Studio (dark theme areas).    If no dark background logo is configured, the system defaults to the light background logo.
  - Enter the image URL in the **Dark Background** field.
 Example: `https://rafay.co/wp-content/uploads/2021/08/[email protected]`

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/bg_color.png)](https://docs.rafay.co/aiml/gpupaas/img/bg_color.png)

- **Favicon**: Enter the URL for a favicon to customize the browser tab icon.
- **Background Media**: Specify a background image, video, or GIF URL for use with the Split layout or Default layout on the login page. Lightweight CSS-based animations for subtle motion effects are also supported.
  - Static images, videos, GIFs, and lightweight CSS-based animations are supported.
  - The media must be accessible through a valid external URL.
  - A real-time preview is displayed when a valid media URL is provided.
  - Invalid URLs do not render a preview.

**Recommended Sizes for background image:**

- Default Layout: `1920x1080px`
- Split Layout: `700x560px`

**Layout behavior for videos and GIFs:**

Background media rendering is based on the layout selected in the **Login/Auth** page.

- **Default Layout**: The video or GIF covers the entire background.
- **Split Layout**: The video or GIF is displayed within the split background section.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/image_gif.png)](https://docs.rafay.co/aiml/gpupaas/img/image_gif.png)

---

#### Contact Information

| Field | Description | Example |
| --- | --- | --- |
| **Notification Email** | Receives platform notifications for this partner. | `[email protected]` |
| **Sender Email** | Address platform email is sent from. Falls back to the system sender if blank. | `[email protected]` |
| **Helpdesk Email** | Where tenant support requests are delivered. | `[email protected]` |

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/contacts_1.png)](https://docs.rafay.co/aiml/gpupaas/img/contacts_1.png)

#### Additional Information

| Field | Description | Example |
| --- | --- | --- |
| **Product Name** | Product name shown to tenants throughout the portal. | `Rafay SelfHosted Product` |
| **Support Team Name** | Signed on support email and shown on help screens. | `Team Rafay` |
| **Copyright Text** | Shown in the portal footer. | `2026 Rafay Systems. All rights reserved.` |
| **Terms of Service URL** | Linked from the sign-in page. Optional. | `https://rafay.co/terms` |
| **Documentation URL** | Linked from the portal help menu. Optional. | `https://docs.rafay.co` |

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/contacts_info.png)](https://docs.rafay.co/aiml/gpupaas/img/contacts_info.png)

#### Privacy Policy Configuration

> ℹ️ Minimum Controller Version: v3.1-31

Partners can configure how the privacy notice is presented on the sign-in page.

| Field | Description | Example |
| --- | --- | --- |
| **Privacy Policy URL** | The policy the sign-in notice links to. | `https://rafay.co/privacy-policy` |
| **Display Privacy Policy CTA Inline** | Shows the privacy notice on the sign-in page. Requires a Privacy Policy URL to be configured. | `Disabled` |
| **Privacy Policy Label Text** | Customizes the text shown with the inline privacy notice. Enabled only after **Display Privacy Policy CTA Inline** is turned on. | `Privacy Policy` |
| **Login Page Preview** | Shows how the privacy notice will appear on the login page. | `By logging in, you agree to accept Privacy Policy` |

Enabling the inline CTA requires a Privacy Policy URL to be configured. The CTA message text is fully customizable to match the partner's tone or policy requirements.

[![Privacy Policy Configuration](https://docs.rafay.co/aiml/gpupaas/img/policy_link.png)](https://docs.rafay.co/aiml/gpupaas/img/policy_link.png)

---

### Applications Configuration

The **Applications** tab in the *Edit Partner Details* screen allows you to configure how the list of available applications is displayed to end-users in the Partner Console, including the view type, grouping, labeling, and defining the applications themselves.

#### General Display Settings

These settings control the overall presentation of the application catalog.

| Setting | Description |
| --- | --- |
| **Preferred Applications View** | Sets the default display format for the applications list.   **Grid View** displays applications as larger tiles with icons.  **List View** displays applications as smaller horizontal cards.   The screenshots below show how the Applications appears **after** selecting each view.   [![List and Grid Views](https://docs.rafay.co/aiml/gpupaas/img/list_views.png)](https://docs.rafay.co/aiml/gpupaas/img/list_views.png) |
| **Separator Label** | Defines a custom label that displays above the main application list (e.g., **Other Applications**). |
| **Enable Application Grouping** | When checked, applications can be organized into definable groups (**Group/Category** field below) for better categorization and display. The Live Preview changes to show **Applications Preview (Grouped by Category)**. |

#### Configuring an Application

To add an application to the catalog, click the **+ Add Application** button. This reveals a form where you define the application's details. You can configure multiple applications by clicking **+ Add Application** again.

| Field | Description |
| --- | --- |
| **Application Name** | The public-facing name of the application displayed in the catalog (e.g., *App Name* in the preview). |
| **Image URL** | The URL to the application's icon or image (e.g., `https://example.com/app-icon.png`). This image will be displayed on the application card/row. |
| **Application URL** | The full URL that users will be directed to when they click the application (e.g., `https://example.com/app`). |
| **Description** | A brief description of the application. |
| **Group/Category** | **(Optional)** If **Enable Application Grouping** is checked, enter the category name here (e.g., *Development*, *Production*, *Tools*). Applications are grouped by this value in the end-user view. |

To remove a configured application, click the **Remove** button associated with that application's configuration block.

After completing all application configurations and display settings, click **Save Changes** at the bottom of the screen to apply the updates.

After completing all customizations, click **Save Changes** to apply the updates.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/apps_cust.png)](https://docs.rafay.co/aiml/gpupaas/img/apps_cust.png)

---

## Customizing Compute Types

> ℹ️ Minimum Controller Version: v3.1-30

Partners can define which compute types are visible in the end user portal, and whether each type uses the native experience. For example, custom entries such as `"Namespace"` can be used to reflect internal conventions.

### Procedure

- Log in to the **Operations Console**.
- Click **Portal Navigation** under **User Experience** in the left menu.
- Click the **Navigation** tab.

[![Portal Navigation](https://docs.rafay.co/aiml/gpupaas/img/paas_pc.png)](https://docs.rafay.co/aiml/gpupaas/img/paas_pc.png)

- Edit or add to the JSON configuration using the following structure:

```
{
  "compute": {
    "navLabel": "Compute",
    "types": [
      {
        "value": "baremetal",
        "useFirstClass": true,
        "label": "Bare Metal",
        "icon": "zmdi zmdi-laptop",
        "description": "Dedicated physical servers with direct hardware access for high-performance, resource-intensive workloads.",
        "objectLabel": "Bare Metal",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-yellow-500/10 bg-yellow-100"
        },
        "homeComputeCard": {
          "description": "Bare Metal provides dedicated servers with full hardware access, strong isolation, and control for demanding workloads needing consistent performance or specific hardware.",
          "iconClass": "border-red-500/10 bg-red-100 text-red-700/70"
        }
      },
      {
        "value": "vm",
        "useFirstClass": false,
        "label": "Virtual Machines",
        "icon": "zmdi zmdi-cloud",
        "description": "Isolated virtual environments with dedicated resources for diverse workload needs.",
        "objectLabel": "Virtual Machine",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-yellow-500/10 bg-yellow-100"
        },
        "homeComputeCard": {
          "description": "Virtual Machines offer flexible, isolated environments with dedicated CPU, memory, and storage, ideal for a wide range of applications with scalable resource demands.",
          "iconClass": "border-yellow-500/10 bg-yellow-100 text-yellow-700/70"
        }
      },
      {
        "value": "k8s",
        "useFirstClass": false,
        "label": "Kubernetes",
        "icon": "zmdi zmdi-brain",
        "description": "Orchestration platform for managing, scaling, and deploying containerized applications.",
        "objectLabel": "Kubernetes",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-blue-500/10 bg-blue-100"
        },
        "homeComputeCard": {
          "description": "Kubernetes provides a powerful container orchestration platform for deploying, scaling, and managing containerized applications. With features like automated deployment, scaling, load balancing, and self healing capabilities, it offers an efficient environment for modern microservices architectures.",
          "iconClass": "border-purple-500/10 bg-purple-100 text-purple-700/70"
        }
      },
      {
        "value": "vcluster",
        "label": "vCluster",
        "icon": "zmdi zmdi-robot",
        "description": "Virtual Kubernetes clusters that provide isolated environments within a shared infrastructure, enabling multi-tenant resource optimization.",
        "objectLabel": "vCluster",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-pink-500/10 bg-pink-100"
        },
        "homeComputeCard": {
          "description": "vClusters are virtual Kubernetes clusters that run inside a namespace of an underlying Kubernetes cluster, providing fully isolated environments with their own control plane. Ideal for multi-tenant scenarios, they enable efficient resource utilization while maintaining strict workload separation.",
          "iconClass": "border-pink-500/10 bg-pink-100 text-pink-700/70"
        }
      },
      {
        "value": "Namespace",
        "label": "Namespace",
        "icon": "zmdi zmdi-robot",
        "description": "Isolated namespaces in a Kubernetes cluster.",
        "objectLabel": "Namespace",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-pink-500/10 bg-pink-100"
        },
        "homeComputeCard": {
          "description": "Isolated namespaces in a Kubernetes cluster for efficient resource utilization.",
          "iconClass": "border-pink-500/10 bg-pink-100 text-pink-700/70"
        }
      }
    ]
  }
}
```

[![Portal Navigation configuration](https://docs.rafay.co/aiml/gpupaas/img/pcn_5.png)](https://docs.rafay.co/aiml/gpupaas/img/pcn_5.png)

`useFirstClass` determines whether the compute type uses the native experience described under Native Experience for Platform Offerings. This field is confirmed for **Bare Metal**, **Virtual Machines**, and **Kubernetes**; the `vCluster` and `Namespace` entries above are carried over from the previous configuration and may need this field added too, once confirmed.

Default compute types include: **Bare Metal**, **Virtual Machines**, **Kubernetes**, and **vCluster**.

When a new compute sku is created, the corresponding compute type options become available for selection.

[![Portal Navigation compute profile](https://docs.rafay.co/aiml/gpupaas/img/pcn_7.png)](https://docs.rafay.co/aiml/gpupaas/img/pcn_7.png)

---

### Migration

If upgrading from a controller version older than **v3.1-30**:

- Annotate existing compute profiles to associate the appropriate compute type, e.g.:

```
"paas.envmgmt.io/compute_type": "vm"
```

- Run the migration script to associate existing compute instances with the correct type

> Important: Contact Rafay support for assistance with the migration process.

---

## Customizing Service Types

Just like compute types, service types can also be customized.

### Procedure

- Log in to the **Operations Console**.
- Click **Portal Navigation** under **User Experience** in the left menu.
- Click the **Navigation** tab.
- Edit or add to the JSON configuration using the following structure:

```
{
  "service": {
    "navLabel": "Services",
    "types": [
      {
        "value": "notebook",
        "useFirstClass": false,
        "label": "Notebooks",
        "icon": "zmdi zmdi-laptop",
        "description": "Notebooks are applications that run on compute instances.",
        "objectLabel": "Notebook",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-yellow-500/10 bg-yellow-100"
        },
        "homeServiceCard": {
          "description": "Notebook SKUs are predefined configurations that deliver an interactive environment for tasks such as data analysis, visualization, and machine learning development. By preconfiguring the required resources, tools, and dependencies, these skus simplify the creation and management of notebook instances.",
          "iconClass": "border-red-500/10 bg-red-100 text-red-700/70"
        }
      },
      {
        "value": "inference",
        "useFirstClass": true,
        "label": "Inference Endpoints",
        "icon": "zmdi zmdi-cloud",
        "description": "Inference services are applications that run on compute instances.",
        "objectLabel": "Inference Endpoint",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-yellow-500/10 bg-yellow-100"
        },
        "homeServiceCard": {
          "description": "Inference Endpoint SKUs are predefined configurations designed to simplify and accelerate the deployment of machine learning models as APIs. These skus provide a structured and standardized approach to serving trained models, enabling rapid prototyping and real time predictions.",
          "iconClass": "border-yellow-500/10 bg-yellow-100 text-yellow-700/70"
        }
      },
      {
        "value": "jobs",
        "label": "AI/ML Jobs",
        "icon": "zmdi zmdi-brain",
        "description": "Jobs services are applications that run on compute instances.",
        "objectLabel": "AI/ML Job",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-blue-500/10 bg-blue-100"
        },
        "homeServiceCard": {
          "description": "AI/ML Job SKUs are predefined configurations designed to streamline and optimize AI/ML tasks, including training, tuning, and deploying machine learning models. These skus deliver a consistent, scalable, and efficient setup across the machine learning lifecycle, reducing operational complexity and simplifying workflows.",
          "iconClass": "border-purple-500/10 bg-purple-100 text-purple-700/70"
        }
      },
      {
        "value": "custom",
        "label": "Custom Services",
        "icon": "zmdi zmdi-robot",
        "description": "Custom services are applications that run on compute instances.",
        "objectLabel": "Custom Service",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-pink-500/10 bg-pink-100"
        },
        "homeServiceCard": {
          "description": "Custom Service SKUs are predefined configurations designed to define, provision, and manage services tailored to unique business requirements. These skus offer a structured, standardized, and repeatable method for deploying and managing services efficiently.",
          "iconClass": "border-pink-500/10 bg-pink-100 text-pink-700/70"
        }
      }
    ]
  }
}
```

[![Portal Navigation](https://docs.rafay.co/aiml/gpupaas/img/pcn-8.png)](https://docs.rafay.co/aiml/gpupaas/img/pcn-8.png)

`useFirstClass` is optional and only appears on service types where native experience applies; it determines whether the service type uses the native experience, the same as for compute types.

Service categories help organize related service types under a shared label for clearer presentation in the end user portal. Service types can be grouped under custom categories using the **`groupBy`** field. This enables the organization of related service types under headings such as *Storage*, *AI Lab*, *Network*, or other provider defined groupings. These categories are displayed in the end user portal under the **Services** section. In the specification shown below, the `groupBy` field is set to *Storage*, and the service types **Object Storage** and **High Speed Storage** are added under this category. As a result, both services appear grouped together under the Storage section in the Developer Hub, as illustrated in the screenshot.

***Example***

```
{
  "service": {
    "navLabel": "Services",
    "types": [
      {
        "value": "object-storage",
        "label": "Object Storage",
        "icon": "zmdi zmdi-storage",
        "groupBy": "Storage",
        "description": "Object Storage supports S3 APIs.",
        "objectLabel": "Object Storage",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-yellow-500/10 bg-yellow-100"
        },
        "homeServiceCard": {
          "description": "Object Storage is a storage system that stores data as objects, distributed across multiple devices.",
          "iconClass": "border-red-500/10 bg-red-100 text-red-700/70"
        }
      },
      {
        "value": "high-speed-storage",
        "label": "High Speed Storage",
        "icon": "zmdi zmdi-file",
        "groupBy": "Storage",
        "description": "High speed file based storage for AI and ML workloads.",
        "objectLabel": "High Speed Storage",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-yellow-500/10 bg-yellow-100"
        },
        "homeServiceCard": {
          "description": "High Speed Storage supports file based storage for high speed data transfer in AI and ML applications.",
          "iconClass": "border-red-500/10 bg-red-100 text-red-700/70"
        }
      }
    ]
  }
}
```

[![Portal Navigation service category](https://docs.rafay.co/aiml/gpupaas/img/service_category.png)](https://docs.rafay.co/aiml/gpupaas/img/service_category.png)

Categories created using `groupBy` are displayed in alphabetical order by default. To control the visible order, list the service types in the JSON in the same sequence as the desired UI ordering.

When a new service sku is created, the corresponding service type options become available for selection.

[![Portal Navigation service profile](https://docs.rafay.co/aiml/gpupaas/img/pcn_9.png)](https://docs.rafay.co/aiml/gpupaas/img/pcn_9.png)

---

## Customizing Portal Navigation Labels

> ℹ️ Minimum Controller Version: v3.1-31

Portal navigation labels can be customized to control how menu items appear in the end user portal. These settings update only the display labels and do not change functionality.

### Procedure

- Go to **Partners** → click **Edit**.
- Open the **Portal Navigation** tab.
- Add or update the required labels in the configuration.

### Example Configuration

```
{
  "developer_hub_label": "Customer Hub",
  "paas_studio_label": "PaaS Studio",
  "sku_management_label": "SKU Management",
  "dashboards_label": "Dashboards",
  "administration_label": "Administration",
  "infrastructure_label": "Infrastructure"
}
```

### Parameter Details

| Parameter | Description | Default Behavior |
| --- | --- | --- |
| `developer_hub_label` | Label displayed for the Developer Hub portal. | Default label is **Developer Hub**. |
| `paas_studio_label` | Label displayed for the SKU Studio menu. | Default value is **SKU Studio** (displayed in the default-org). |
| `sku_management_label` | Label displayed for the SKU Management menu. | Default value is **SKU Management** (displayed in the **tenant org**). |
| `dashboards_label` | Label displayed for the Dashboards menu. | Uses the default label when not configured. |
| `administration_label` | Label displayed for the Administration menu. | Uses the default label when not configured. |
| `infrastructure_label` | Label displayed for the Infrastructure menu. | Uses the default label when not configured. |

[![Portal Customization](https://docs.rafay.co/aiml/gpupaas/img/label_edit.png)](https://docs.rafay.co/aiml/gpupaas/img/label_edit.png)

### Behavior

- Configured values override the default portal navigation labels.
- If a label is not specified, the default value is used.
- Changes affect only UI display text.

---
