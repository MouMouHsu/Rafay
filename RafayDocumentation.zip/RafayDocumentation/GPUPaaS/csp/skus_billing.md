---
title: "Billing Configuration"
source: https://docs.rafay.co/aiml/gpupaas/csp/skus_billing/
---

# Billing Configuration

A billing configuration is automatically created when a SKU is created, whether from SKU Studio or the Operations Console. Admins can select this automatically created billing configuration to define billable dimensions and rate cards for the SKU. Configuring billing is optional; a SKU functions without it. Billing configuration is applicable only to **Virtual Machine**, **Bare Metal**, and **Dev Pods** SKUs.

---

## View Billing Configurations

Access the Operations Console and click on **Billing Configuration**. The page displays a count of Total, Global, and Organization-Specific billing configurations, and separates listings into **Custom** and **First Class** tabs.

The listing provides the following information for each billing configuration:

| Column | Description |
| --- | --- |
| **Billing Configuration** | The name of the billing configuration. |
| **Applies To** | The scope of the billing configuration, for example **All Organizations**. |
| **SKU** | The SKU the billing configuration applies to. |
| **Created** | The date and time the billing configuration was created. |
| **Last Updated** | The date and time the billing configuration was last updated. |
| **Actions** | Click the actions menu to manage the billing configuration. |

Use the search bar to find a billing configuration by name, or click **+ Add Billing Configuration** to create one manually.

[![Billing Configuration list](https://docs.rafay.co/aiml/gpupaas/img/billing-config_list.png)](https://docs.rafay.co/aiml/gpupaas/img/billing-config_list.png)

---

## Edit Billing Configuration

Click a billing configuration name to open it. The editor is organized into the following sections: **General Information**, **Scope**, **SKU Configuration**, and **Billable Dimensions**.

For example, when a Bare Metal SKU named `demo-bmaas-sku` is created, a billing configuration named `global-bm-demo-bmaas-sku-billing-config` is automatically added to the list, scoped to **All Organizations**.

[![Billing Configuration list](https://docs.rafay.co/aiml/gpupaas/img/example_skus.png)](https://docs.rafay.co/aiml/gpupaas/img/example_skus.png)

#### General Information

| Field | Description | Example |
| --- | --- | --- |
| **Display Name** | The display name for this billing configuration. | `demo-bmaas-ratecard` |

#### Scope

| Field | Description | Example |
| --- | --- | --- |
| **Scope** | Select **Global** to apply the billing configuration to all organizations, or **Organization-Specific** to limit it to a single organization. | **Global**, **Organization-Specific** |

#### SKU Configuration

Select the type, SKU, and catalog card price.

| Field | Description | Example |
| --- | --- | --- |
| **Type** | The compute type of the SKU. | `BM`, `VM` |
| **SKU** | The SKU this billing configuration applies to. | `demo-bmaas-sku` |
| **Profile Card Cost** | Optionally, set a flat cost shown on the SKU's catalog card. Select a currency and enter a price. Click **+ Add Currency** to add pricing in additional currencies. | Currency `USD`, Price `2` |

When editing an existing billing configuration, the **SKU** field is populated with the associated SKU by default and is read-only. When adding a new billing configuration, the **SKU** field is editable, and a SKU can be selected from the dropdown.

[![SKU Configuration section](https://docs.rafay.co/aiml/gpupaas/img/general_configs.png)](https://docs.rafay.co/aiml/gpupaas/img/general_configs.png)

#### Billable Dimensions

Configure the estimation unit, billable dimensions, and rates used for usage reporting.

| Field | Description | Example |
| --- | --- | --- |
| **Estimation Unit** | Select the unit used to estimate cost. | **Hourly**, **Monthly** |

Each dimension is listed with its name, value source category, and the number of configured rate cards. Click **+ Add Dimension** to add a new dimension. Click the actions menu (ellipsis) on a dimension for **Edit** or **Delete**.

[![Billable Dimensions section](https://docs.rafay.co/aiml/gpupaas/img/billing-config-dimensions.png)](https://docs.rafay.co/aiml/gpupaas/img/billing-config-dimensions.png)

##### Add or Edit a Dimension

Click **+ Add Dimension**, or the actions menu > **Edit** on an existing dimension, to open the dimension editor.

| Field | Description | Example |
| --- | --- | --- |
| **Dimension Name** | A name for the billable dimension. | `GPU` |
| **Value Source** | Select where the dimension's value comes from. See the options below. | `Instance Specification` |
| **Source** | The path used to read the value, based on the selected Value Source. | `gpu_count` |

A few of the Value Source options are as given below:

| Value Source | Description |
| --- | --- |
| **User Input Variable** | Users choose this value when creating an instance. |
| **SKU Metadata** | Value is read from SKU metadata. |
| **SKU Specification** | Value is read from the SKU specification. |
| **Instance Metadata** | Value is read from instance metadata. |
| **Instance Specification** | Value is read from the instance configuration. |

Click **Save Dimension**.

[![Billable Dimensions section](https://docs.rafay.co/aiml/gpupaas/img/dimension_edit.png)](https://docs.rafay.co/aiml/gpupaas/img/dimension_edit.png)

##### Add a Rate Card

Click on a dimension's rate card count to expand it, then click **+ Add Rate Card** under **Rate Cards** to open the Add Pricing Rate dialog.

[![Edit Billable Dimension dialog](https://docs.rafay.co/aiml/gpupaas/img/add_ratecard.png)](https://docs.rafay.co/aiml/gpupaas/img/add_ratecard.png)

| Field | Description | Example |
| --- | --- | --- |
| **Price Applies To (Dimension)** | The dimension this rate applies to. | `GPU` |
| **Alias** | Optionally, provide a display alias for the dimension. | `Public IP` |
| **Resource** | Optionally, specify the resource value this rate applies to. | `true`, `1`, `3` |
| **Price** | The price and currency for this rate. | Currency `USD`, Price `2` |
| **Billing Period** | Select the billing period. | **Hour**, **Day**, **Month** |
| **Price Per** | Optionally, specify the unit the price is per. | — |
| **Derived From** | Select how the quantity for this rate is determined. | **Count from**, **Value from** |

When **Derived From** is set to **Count from**, select the dimension whose count determines the quantity. When set to **Value from**, select the dimension whose value is used directly for this rate.

Click **Add Rate**.

[![Add Pricing Rate dialog](https://docs.rafay.co/aiml/gpupaas/img/billing-config-rate-card.png)](https://docs.rafay.co/aiml/gpupaas/img/billing-config-rate-card.png)

Once added, the rate card is listed under the dimension along with its price and billing period, for example `GPU — USD 2 / Day`. Click the actions menu (ellipsis) on a rate card to manage it. Repeat this for each dimension that needs a rate card.

[![Rate card added to a dimension](https://docs.rafay.co/aiml/gpupaas/img/billing-config-rate-card-added.png)](https://docs.rafay.co/aiml/gpupaas/img/billing-config-rate-card-added.png)

Once all dimensions and rate cards are configured, click **Save Billing Configuration**, or **Discard Changes & Exit** to cancel.

Once saved, the billing configuration is listed on the Billing Configuration page under the **Display Name** set in General Information, for example `demo-bm-ratecard`, rather than its original auto-generated name.

[![Rate card added to a dimension](https://docs.rafay.co/aiml/gpupaas/img/bm_ratecard_list.png)](https://docs.rafay.co/aiml/gpupaas/img/bm_ratecard_list.png)

---

## Pricing Estimates During Instance Provisioning

Once a billing configuration is set up for a SKU, the configured rate cards are reflected in the Monthly/hourly Estimate panel shown when deploying an instance, whether from SKU Studio, the Operations Console, or the Developer Hub. The panel displays the total estimated cost along with a breakdown by billable dimension.

For example, an instance with **PublicIP** and **ContractTerm** dimensions configured shows a total of `$11/m`, broken down as `PublicIP $6/m` and `ContractTerm $5/m`.

Billing starts when the bare metal instance is running and stops when the instance is deleted.

[![Monthly Estimate](https://docs.rafay.co/aiml/gpupaas/img/billing-estimate.png)](https://docs.rafay.co/aiml/gpupaas/img/billing-estimate.png)

---
