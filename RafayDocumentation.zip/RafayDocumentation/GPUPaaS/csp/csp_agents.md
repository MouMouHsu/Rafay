---
title: "Agents for GPU PaaS"
source: https://docs.rafay.co/aiml/gpupaas/csp/csp_agents/
---

# Rafay Agent Overview

**Agent** is a service that runs in your local network or VPC. This is required for executing tasks related to provisioning compute or service instances, based on defined SKUs, for GPU PaaS.

The agent can be deployed on either **Docker** or **Kubernetes**.

| Type | Versions |
| --- | --- |
| Docker | v2.x or higher |
| Kubernetes | Currently supported version |

👉 To create and configure an agent, follow the instructions here: [GitOps Agent Setup](https://docs.rafay.co/gitops/gitops_agent/)

---

# Agent Architecture

The Rafay Controller (control plane) does not require direct or inbound access to the servers located in the GPU PaaS provider’s data centers.
 Instead, it relies on a lightweight agent that is deployed at each data center site.

The Rafay Agent establishes an outbound, long-running connection to the Rafay Controller over **port 443**. The following architecture diagram illustrates this setup.

[![Agent](https://docs.rafay.co/aiml/gpupaas/img/agent_architecture.png)](https://docs.rafay.co/aiml/gpupaas/img/agent_architecture.png)

---

## Instance Execution Lifecycle

The lifecycle of provisioning and deprovisioning GPU PaaS instances involves three high-level stages:

1. **Activity Generation**
2. The Controller determines the number and types of required activities
3. **Agent Interaction**
4. Agents continuously poll the Controller for activities
5. The Controller assigns activities based on agent association and worker limits
6. **Agent Execution**
7. Activities may run sequentially or in parallel (depending on underlying code)
8. Once completed, pods terminate and resources are released
9. Agents continue polling and queueing additional tasks

> Note: Every instance created at the PaaS layer corresponds to an underlying environment object.

---

## Worker Sizing

**Default Resource Requests and Limits per Worker Type**

| Worker Type | CPU | Memory |
| --- | --- | --- |
| Git Worker | 250m | 512Mi |
| OpenTofu Worker | 500m | 1Gi |
| Function Worker | 100m | 256Mi |

---

## Agent Assignment & Selection

Agents can be configured either within an **environment template** or centrally in **Global Settings**.

👉 For detailed instructions, see [Global Overrides](https://docs.rafay.co/aiml/gpupaas/csp/global_settings/#global-overrides).

---
