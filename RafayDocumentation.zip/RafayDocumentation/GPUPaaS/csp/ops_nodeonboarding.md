---
title: "Node Onboarding"
source: https://docs.rafay.co/aiml/gpupaas/csp/ops_nodeonboarding/
---

# Node Onboarding

## Overview

Node Onboarding allows partners to configure the template used when onboarding new nodes in a data center. It defines the template name, version, and any overrides applied during the onboarding process. These settings are managed directly from the Operations Console. A single Node Onboarding configuration is supported per partner, and this configuration applies to all users under that partner.

---

## Benefits

Without a centralized configuration, managing node onboarding across data centers can lead to inconsistencies and errors. Node Onboarding helps by: - Providing a single place to configure the template used for onboarding nodes - Sharing the configuration across all users under the partner, ensuring a consistent setup - Allowing environment, variable, and file overrides to be applied on top of the template - Ensuring the correct template and version are used consistently across node provisioning

---

## Prerequisites

Node Onboarding settings should be configured when: - A specific template and version must be used for onboarding nodes in a data center - Overrides need to be applied on top of the template

> **Note**
> Node Onboarding settings only control the onboarding configuration. The actual onboarding execution is performed from **Data Centers > [data center] > Servers > Actions > Node Onboarding**.

---

## Configure Node Onboarding

**Navigation:** Operations Console > Inventory > Node Onboarding

The Node Onboarding page displays the current configuration, including the template name, version, and active overrides.

[![Node Onboarding](https://docs.rafay.co/aiml/gpupaas/img/node_onb.png)](https://docs.rafay.co/aiml/gpupaas/img/node_onb.png)

To configure the node onboarding settings:

1. Click **Configure**.
2. Under **Template**, specify the **Name** and **Version** for this configuration.   Note Both **Name** and **Version** are required fields.  [![Node Onboarding](https://docs.rafay.co/aiml/gpupaas/img/node_general.png)](https://docs.rafay.co/aiml/gpupaas/img/node_general.png)
3. Optionally, configure overrides under the **Overrides** section:  
| Field | Description |
| --- | --- |
| **Environment overrides** | Key/value pairs applied on top of the template. Click **Add env** to add a pair. |
| **Variable overrides** | Name/value pairs applied on top of the template. Click **Add variable** to add a pair. |
| **File overrides** | Files to override template defaults. Click **Add file** to upload a file. |

 [![Configure Node Onboarding](https://docs.rafay.co/aiml/gpupaas/img/node_override.png)](https://docs.rafay.co/aiml/gpupaas/img/node_override.png)
4. Click **Save Node Onboarding Settings**.

To exit without saving, click **Discard Changes & Exit**.

---

## Onboard a Node

Once the Node Onboarding configuration is set up, nodes can be onboarded from the Servers page within a data center.

Navigation: **Operations Console > Inventory > Data Centers > [data center] > Servers**

To onboard a node:

1. Click the actions menu (**...**) on the server.
2. Select **Node Onboarding**.

[![Configure Node Onboarding](https://docs.rafay.co/aiml/gpupaas/img/post_onboard.png)](https://docs.rafay.co/aiml/gpupaas/img/post_onboard.png)

---
