---
title: "Tenant Onboarding Automation for NCP Environments"
source: https://docs.rafay.co/aiml/gpupaas/csp/csp_tenant_onboarding/
---

# Tenant Onboarding

## Overview

This guide provides complete instructions for automating tenant onboarding using Rafay's PaaS platform. The system enables Cloud Service Providers (CSPs) and partner organizations to efficiently onboard new tenants with customized infrastructure configurations through UI-based template management and API workflows.

### What is Tenant Onboarding?

Tenant onboarding is the automated process of provisioning new tenants (customers/organizations) into your infrastructure stack. Each tenant receives: - Customized network, compute, and storage configurations - BCM (NVIDIA Based Cluster Management) tool installation - Switch configurations and network rules - Access to specific resources within the data center

### Architecture Overview

The onboarding system uses a hierarchical structure:

- **Partners**: Organizations that manage multiple tenants
- **Tenants**: Individual customers/organizations under each partner
- **Templates**: Reusable configurations that define infrastructure setup
- **Tenant Onboarding Configuration**: Default configurations that can be overridden per tenant

---

## Prerequisites

Before starting tenant onboarding, ensure the following prerequisites are met:

1. **BCM Tool Installation**
  - The BCM (NVIDIA-Based Cluster Management) tool must be installed on a pre-configured head node server with an existing OS.
  - This enables provisioning of physical machines with the correct operating system and network configurations.
  - Installation is typically triggered through a default environment template.
2. **Tenant Onboarding Configuration**
  - The tenant onboarding template must be configured in the Operations Console before using the **Provision Tenant** functionality.
  - This defines the template name, version, and any overrides applied during provisioning.
  - For more information, see [Tenant Onboard Settings](https://docs.rafay.co/aiml/gpupaas/ops_tenantonboarding/).
3. **Environment Template**
  - A default environment template `tenant-onboard` must be configured and available in the platform.
  - This template is used to perform the BCM tool installation and set up the initial server environment for new tenants.
4. **Resource Templates** Ensure the following resource templates are created and accessible in the platform:
  - **system-bcm-head-node-deploy v2.0** : Used for configuring and deploying the head node server with BCM
  - **res-ncp-ethernet v1.0**: Provides standard Ethernet network configuration for tenant provisioning
  - **res-ncp-infiniband v1.0**: Enables high-performance InfiniBand network configuration for tenant environments

**Input Variables Required in these Templates**

- `partner_api_key` (mandatory)
- `inventory_endpoint` (mandatory)
- `organization_name` (mandatory, resolved through resource selectors for InfiniBand and Ethernet resources)

**Contexts**

- `system-bcm-head-node-deploy-env-var`

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/template_var.png)](https://docs.rafay.co/aiml/gpupaas/img/template_var.png)

---

## Provisioning Workflow

### Step 1: Configure Tenant Onboarding Settings

The onboarding template and required variables are configured from the Tenant Onboarding page in the Operations Console.

**Navigation**: **Operations Console > Tenants > Tenant Onboarding**

For more information, Refer [Tenant Onboarding Configuration](https://docs.rafay.co/aiml/gpupaas/ops_tenantonboarding/).

### Step 2: Provision Tenants Using the Ops Console

Navigation: **Operations Console > Tenants > Organizations**

- Click the actions menu (**...**) on the organization and select **Tenant Onboarding**.
- In the **Tenant Management** dialog, click **Provision Tenant**.
- Optionally, provide tenant-specific inputs:
  - **Variables:** Add key-value pairs for variables.
  - **Environment Configuration:** Enter JSON configuration for the environment.
  - **Files:** Upload JSON files to be included in the provision.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/prov_tenant.png)](https://docs.rafay.co/aiml/gpupaas/img/prov_tenant.png)

***Example Configuration***

```
{
  "organization_id": "gkj0zm0",
  "input": {
    "env": {
      "head_node_ip": "192.168.200.9",
      "head_node_mac": "48:b0:2d:00:00:07",
      "bcm_product_key": "205183-894356-010505-709622-527141",
      "ssh_private_key": "-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABlwAAAAdzc2gtcn\nNhAAAAAwEAAQAAAYEAylSYwayjZ+MvuKhuxQKUoiVwvMTv1hJx/xUrdx4XRdayxfnd8lxV\nvwzgOevr/phzpm59/96cWqjotFkNzU2FlbYKvkVadAgua0mhp7HdtKBDu8Vpn7MXuT5epm\nk9mpEBifQn0mt7Ho/HATFalpacodwLjn2CHJbvjfgxuHmDLE1Pqoyi764lfakK20PgXrQX\nkuQboe951QdLEWJMl+X2VIfDuINlNHoGT4WSFvN9wuCC5V+1wzZNB2RnJqg8/nwf4GRIjR\n7NxRiVW4NDWCsKONEpvrwUlJpRFRspKhWcEAc9WnKJskFdS/YRXgi+HS9M0o/N2nKVjzM8\nK2XDVlM/3iKbkWIhePY8Hqm+BHvr/bgwlZZvVDeVYeEtvFiUatn7VIOMaAE3PD0Phv08kN\n4B3JhCPGlsyvltNc9hXrgEmNcZ0l6ua7rc8IUbaPjy3FHJu/xiHcNrAMkhMsLNcyWfL+Mh\nROGqR93XLoHSce1XngEMs3uNuQzQ1amwgaZ39nD9AAAFkBKnWfESp1nxAAAAB3NzaC1yc2\nEAAAGBAMpUmMGso2fjL7iobsUClKIlcLzE79YScf8VK3ceF0XWssX53fJcVb8M4Dnr6/6Y\nc6Zuff/enFqo6LRZDc1NhZW2Cr5FWnQILmtJoaex3bSgQ7vFaZ+zF7k+XqZpPZqRAYn0J9\nJrex6PxwExWpaWnKHcC459ghyW7434Mbh5gyxNT6qMou+uJX2pCttD4F60F5LkG6HvedUH\nSxFiTJfl9lSHw7iDZTR6Bk+FkhbzfcLgguVftcM2TQdkZyaoPP58H+BkSI0ezcUYlVuDQ1\ngrCjjRKb68FJSaURUbKSoVnBAHPVpyibJBXUv2EV4Ivh0vTNKPzdpylY8zPCtlw1ZTP94i\nm5FiIXj2PB6pvgR76/24MJWWb1Q3lWHhLbxYlGrZ+1SDjGgBNzw9D4b9PJDeAdyYQjxpbM\nr5bTXPYV64BJjXGdJermu63PCFG2j48txRybv8Yh3DawDJITLCzXMlny/jIUThqkfd1y6B\n0nHtV54BDLN7jbkM0NWpsIGmd/Zw/QAAAAMBAAEAAAGAAaxMkrtootUHgb14zwMRXhGKWr\nE+h3S3Fxl3zCAbp/2Zaaws2D0duLr0nAirS/tlkhXTT7s+6+ao0pxIPNnxgGuqhT4XEaMO\nA9/uaNp+ahOHg9pjIB7aaR3O1A2bj2HivfSJeMK1QwCEMCprj0Jhu1qRs4+uSf9l2IoZxS\nanaEV1DW9kxdpuNRlhqC7/QGE5BFiuXCWEtSIpONSpK/oK56eIvYeZSGNi684/setjrz8X\n2KmKMU9LY0PYBi3kH+RAWR/f3etxqmzhJgT4kzBN01XyJ2sMKCsKGivVOKIYJSeM8de9Il\nd3vfO4pgfhK+DyWqi44HrnVOdoVGbac0dfO0wYvazyjgZEXHXu12tTR1/vnmQbVQ9nsRwr\n8+AV/jz9BXKikheb1VpaniYP+60gKIFtpwomJT4VSWLP3LZ5nwfLn5IHl3kZPd1LBPThpg\n+rNXWN5iq5yqD7Fg6tqVGPEfgsvB4BIP/HI6H4lAm1T4iXuyWCLHLG+x5CSuZnFethAAAA\nwQDIB9IY1CYSbK7TN8iiY74s9PDe2CM54IZIvfqq1bpbZfVi0MwLOaKrJo1+0nP8RQuR/y\n0lHW0EEt+yeKHCY8tq1GC7nDdfyJrCl/lfpjEAC8dhJ6kKEIPIE+fpu5azr6EuufVifSrP\n5QRgRgw+l4uCvNkejybgEvD/RwU8oyf7OM7AdWvI0hHwDak9msBjIhd42mOzbarL/0twqT\nzBqCxJ5/PyMQEk5V5Zszwa2d4BSsHCwycWx36snjE8xyNvgWkAAADBANf8VmyMmGTqc3kH\nE3WvMZ6mM4LBMN1ZfGMH6CFBVt51iU3dX7pm3jWEbTEg4e9zJjVDC691e6P8LVC68f2D3E\n+2b3A3+amYxzUJkNsWLVK9dlVTsujXZy1gIubEJAzCc+xl5ll0vmxi6T8TNSiiDpu/66Va\nq0KMpJ9QLIkFkjsPpZERaWdvPifZP8pSnD+DdPIbTVYSiLn4QI+ma6IPQ/WvwJC1aLtVD7\nW4MHpBhMK7cesVCGHmQ6JFyMVC53LSIQAAAMEA79CgERJEPT2lsSRQ4IiD8A4mhbx/YxLh\nbfZo7cDjfJZ/n8QPb8FDK6Pxh42nntuSyGjPTKwEPXTpEt/0H7HR3CJhsmCRuBDJFq3uFn\nZNoYxOyJkocNqHy8ZqbuTZFi2b6Ew/83VmIYcZpJ2imFP2k6upUGjvkG0p1mu4iw5yIKSe\n88u3fj3RvdRDbeHZnJ3clOzXBxc3iMiWc+dUtYt8Fb/wBGgiXnrvgqfqAPvZMsovFNDRBe\nvjvPsTPUzvgrtdAAAAFHJvb3RAb29iLW1nbXQtc2VydmVyAQIDBAUG\n-----END OPENSSH PRIVATE KEY-----"
    },
    "variables": {
      "organization": "test-org",
            "inventory_endpoint": "ops-console.ncpqe-testbed.dev.rafay-edge.net"
    }
  }
}
```

**Input Variables**

The tenant onboarding template supports three types of input variables, which can be configured through the UI or passed via API:

| Variable Type | Purpose | Example |
| --- | --- | --- |
| **Environment Variables** (`env`) | Defines environment-specific configuration | `"ENVIRONMENT": "production"` |
| **Variables** (`variables`) | General template configuration and tenant-specific settings | `"tenant_name": "customer-abc"` |
| **Files** (`files`) | Custom scripts, certificates, or configuration files | `"custom_config.yaml": "base64_encoded_content"` |

Environment variables are generally used for Docker settings and sensitive configuration items (e.g., SSH keys), while `variables` define tenant parameters, and `files` carry additional resources or configurations.

- Click **Provision Tenant** to initiate the provisioning process and monitor the progress through the UI dashboard

The provisioning workflow performs the following:

- Configures tenant onboarding settings with the default environment template (`tenant-onboard`) and required input variables at the organization level.
- Installs the BCM tool on the head node server to enable physical machine provisioning.
- Configures the tenant’s network, including Ethernet and InfiniBand connectivity.
- Applies switch configurations and necessary network rules for tenant-specific segmentation.
- Allocates tenant resources within the data center based on tenant-specific inputs.
- Supports additional or optional deployments driven by input variables passed through the template.

#### Variable Override System

The system follows a prioritized override structure for input variables:

1. **Tenant-Specific Inputs**: Values provided at the time of tenant provisioning (highest priority).
2. **Tenant Onboarding**: Defaults defined in the tenant onboard template.
3. **Template Defaults**: Fallback values defined within individual resource templates.

This layered structure ensures a standardized yet flexible configuration approach for onboarding multiple tenants.

### Step 3: Monitoring and Status Tracking

Once the execution is successful, an environment is created with all the input variables applied. Users can view the status by clicking Tenant Status.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/tenants_status.png)](https://docs.rafay.co/aiml/gpupaas/img/tenants_status.png)

The onboarding dashboard provides:

- Real-time provisioning status
- Progress tracking by task
- Error messages with troubleshooting information
- Notifications upon successful onboarding completion

Typical status indicators include:

- **Pending**: Provisioning triggered, waiting to start
- **In Progress**: Resources being provisioned
- **Success**: Provisioning completed successfully
- **Failed**: Errors encountered during provisioning

### Step 4: Access and Review Environment Details

- After the environment is created, log in to the **Rafay Controller** and select the **system-catalog** project from the project scope
- Navigate to **Environments** in the left navigation pane, and locate the newly created environment
- Click on the environment name to view its configuration, deployment status, and results as displayed on the details page

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/env_temp.png)](https://docs.rafay.co/aiml/gpupaas/img/env_temp.png)

---

## API Integration

The platform supports REST APIs for tenant onboarding automation, making it easy to integrate with DevOps pipelines or external systems.

### Add Tenant

**POST**: `/v2/sentry/paas/addtenant`

Use this API to provision a new tenant programmatically. You can pass environment variables, configuration variables, and optional files in the request body.

***Request Example***

```
{
  "organization_id": "gkj0zm0",
  "input": {
    "env": {
      "key": "value"
    },
    "variables": {
      "key": "value"
    },
    "files": {}
  }
}
```

***Response Example***

```
{
  "organization_name": "defaultorg",
  "organization_id": "gkj0zm0",
  "trigger_name": "defaultorg-2531",
  "status": {
    "status": "pending"
  },
  "type": "onboarding"
}
```

**How It Works**

- `organization_id`: The unique ID of the organization where the tenant will be provisioned.
- `input.env`: Environment variables to pass during tenant creation.
- `input.variables`: Additional configuration variables for tenant resources.
- `input.files`: Files to be included, specified as a JSON object.

After submitting this request, the response will show status: pending. Use the status-check API to monitor progress.

### Check Tenant Provisioning Status

**GET**: `/v2/sentry/paas/gettenantactivitiystatus`

Use this endpoint to retrieve the status of tenant onboarding and confirm whether provisioning completed successfully.

***Response Example***

```
{
  "tenantactivity": {
    "organization_name": "defaultorg",
    "organization_id": "gkj0zm0",
    "trigger_name": "defaultorg-2531",
    "status": {
      "status": "success",
      "reason": "service allocation request completed successfully"
    },
    "type": "onboarding"
  }
}
```

**Key Fields**

- `status`: Indicates pending, success, or failed
- `status`reason: Describes the success reason or the error
- `trigger_name`: Correlates with the onboarding trigger for tracking

---
