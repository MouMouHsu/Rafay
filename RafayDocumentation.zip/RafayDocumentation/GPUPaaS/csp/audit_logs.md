---
title: "User LCM Audits"
source: https://docs.rafay.co/aiml/gpupaas/csp/audit_logs/
---

# Audit Logs

## Overview

User LCM Audits capture audit logs for partner-level and organization-level user lifecycle management operations. These audit logs provide visibility into administrative actions performed across partners and organizations.

Audit logs are generated automatically for supported operations and are accessible through the Audit Logs page in the Operations Console, based on the access scope of the logged-in role.

To access the Audit Logs page:

1. Open the Operations Console
2. In the left navigation menu, select Audit Logs

The Audit Logs page displays a list of audit entries based on the selected filters.

---

## Audit Log Details and Scope

Audit logs are generated for supported "partner-level" and "organization-level" operations and are displayed as structured JSON entries, ensuring consistency and traceability.

The following operations generate audit logs:

- User login and logout events
- Partner creation and deletion
- Partner admin user creation, activation, deactivation, deletion, and other administrative actions
- Organization-related operations such as creation, deletion, and organization admin lifecycle management

Each supported operation results in a corresponding audit log entry.

### Audit Log Fields

The Audit Logs page includes the following fields:

| Field | Description |
| --- | --- |
| **Date** | Date and time when the operation occurred |
| **User** | User who performed the operation |
| **Partner** | Partner associated with the operation |
| **Organization** | Organization associated with the operation |
| **Client** | Client used to perform the operation |
| **Type** | Operation identifier |
| **Message** | Human-readable description of the operation |

### Audit Log Filters and Actions

The Audit Logs page provides filter controls to refine the list of audit entries.

The following filters are available:

| Filter | Description |
| --- | --- |
| **All types** | Filters audit entries based on the operation type |
| **All users** | Filters audit entries based on the user who performed the operation |
| **All clients** | Filters audit entries based on the client used to perform the operation |
| **Time range** | Filters audit entries based on the selected time period (for example, Last 1 week) |

The page also includes the following actions:

- **Clear Filters** resets all applied filters
- **Refresh** reloads the audit log entries

[![Audit log filters](https://docs.rafay.co/aiml/gpupaas/img/filters.png)](https://docs.rafay.co/aiml/gpupaas/img/filters.png)

***Example: Audit Log Entry***

This example shows an audit log entry generated for a successful user login event.

**Operation details:**

- **Type**: `user.login.success` Indicates that a user successfully logged in to the system.
- **Message**: `User login success` Confirms that the login operation completed successfully.

When expanded, the JSON payload provides additional context for the operation, including actor information, client details, and system metadata associated with the login event.

[![Audit log entry details](https://docs.rafay.co/aiml/gpupaas/img/audits_log.png)](https://docs.rafay.co/aiml/gpupaas/img/audits_log.png)

### Detailed JSON View

Expanding an audit entry displays the full JSON payload, including:

- Audit category and origin
- Operation type
- Partner and organization identifiers
- Actor details such as user type and username
- Contextual metadata related to the operation

The structured JSON format ensures consistent representation of audit data across all partner-level and organization-level operations.

---

## Audit Log Visibility

Audit logs displayed on the Audit Logs page are scoped based on the role used to access the Operations Console:

- Super admins can view audit logs for all actions associated with the default partner and the organizations under that partner.
- Partner admins can view audit logs for operations associated with their partner and its organizations.

Audit visibility is restricted to the scope of access for the logged-in user role.

---
