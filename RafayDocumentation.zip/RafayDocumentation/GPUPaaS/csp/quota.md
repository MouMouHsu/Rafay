---
title: "Quotas"
source: https://docs.rafay.co/aiml/gpupaas/csp/quota/
---

# Quotas

**Release Information**
 This feature is available from release **v3.1-40** onwards.

Quotas allow Partner Admins to set limits on the compute resources that organizations can consume. A quota defines the maximum number of GPU units or instances that can be spun up under a specific organization or across all organizations. Use quotas to cap resource consumption per data center or GPU type, and to enforce organization-wide boundaries centrally from the Operations Console -- above and beyond any project-level limits set by tenants.

Two quota types are supported:

- **Instance** — Limits the number of instances that can be launched for a specific SKU.
- **GPU** — Limits the total number of GPU units that can be consumed, filtered by SKU type, data center, and GPU model.

---

## Add a Quota

Navigate to **Quotas** in the Operations Console.

[![Quotas list page](https://docs.rafay.co/aiml/gpupaas/img/quotas-list.png)](https://docs.rafay.co/aiml/gpupaas/img/quotas-list.png)

Click **+ Add Quota**. The Create Quota form has three sections: **General Information** and **Scope & Allocation**

### General Information

Define the name and description for this quota.

| Field | Required | Description |
| --- | --- | --- |
| **Name** | Yes | Unique identifier for the quota (e.g. `demo-quota`). |
| **Display Name** | No | Human-readable label shown in the console (e.g. `gpu-quota`). |
| **Description** | No | Brief description of the quota's purpose. |

[![Create Quota - General Information](https://docs.rafay.co/aiml/gpupaas/img/quotas_create_general.png)](https://docs.rafay.co/aiml/gpupaas/img/quotas_create_general.png)

### Scope & Allocation

Configure how and where this quota is applied. The fields shown depend on the **Quota type** selected.

#### Instance Quota

Use this type to limit the number of instances that can be launched for a specific SKU.

| Field | Required | Description |
| --- | --- | --- |
| **Organization** | Yes | Select **All Organizations** to apply the quota across all organizations, or choose a specific organization. |
| **Quota type** | Yes | Select **Instance**. |
| **SKU Name** | Yes | The SKU name to which this limit applies (e.g. `compute-gpu-a100`). This corresponds to the SKU defined in SKU Configuration. |
| **Max Units** | No | Maximum number of instances allowed. Defaults to `100`. |

[![Create Quota - Instance type](https://docs.rafay.co/aiml/gpupaas/img/quota_create_instance.png)](https://docs.rafay.co/aiml/gpupaas/img/quota_create_instance.png)

#### GPU Quota

Use this type to limit GPU consumption based on SKU type, data center, and GPU model.

| Field | Required | Description |
| --- | --- | --- |
| **Organization** | Yes | Select **All Organizations** to apply the quota across all organizations, or choose a specific organization. |
| **Quota type** | Yes | Select **GPU**. |
| **SKU Type** | Yes | **Compute-based SKUs** or **Pod-based SKUs**. |
| **Data Center** | Only for Compute-based SKUs | The data center to which this quota applies. Not shown when SKU Type is Pod-based SKUs. |
| **Model** | Yes | The GPU model to limit. For Compute-based SKUs, this must match the **Model No** value configured on the server's GPU (e.g. `H100`). For Pod-based SKUs, the model is selected from the pod GPU models available. |
| **Max Units** | No | Maximum number of GPU units allowed across the selected scope. Defaults to `100`. |

> **Note**
> Compute-based SKUs cover both virtual machine and bare metal compute instances, and use a Data Center for the quota. Pod-based SKUs do not use a Data Center, and there is no VM or Bare Metal distinction for Pod-based GPU quotas.

[![Create Quota - GPU type](https://docs.rafay.co/aiml/gpupaas/img/quotas_create_gpu.png)](https://docs.rafay.co/aiml/gpupaas/img/quotas_create_gpu.png)

---

## How Quotas Are Enforced

Quotas work across two consoles: the **Operations Console** (where Partner Admins configure quotas) and the **Tenant Console** (where end users consume resources).

### Enforcement Flow

1. A Partner Admin creates a quota in the Operations Console scoped to an organization or all organizations.
2. A user in the scoped organization creates a new compute instance from the Tenant Console (**SKU Management > Compute Instances > New Compute Instance**), selecting a Compute SKU and configuring input settings including `gpu_count` and `gpu_type`.
3. On deploy, the system checks the total GPU units already consumed by published or running instances for the matching GPU model, within the applicable data center, against the configured **Max Units**.
4. If the request would cause total usage to exceed the limit, the deploy fails and the instance remains in a **not_deployed** state. The instance itself is still created; only the deploy is blocked.
5. If usage is within the limit, the instance is deployed successfully.

### How GPU Units Are Counted

For GPU quotas, the system counts units based on the `gpu_count` and `gpu_type` input settings on each published or running compute instance. The `gpu_type` value must match the **Model** defined on the quota (for example, `H100`). Each published or running compute instance contributes its `gpu_count` value toward the quota total for the matching model and data center. Draft or undeployed instances are not counted.

A GPU quota is keyed by data center and model together, not a single shared GPU pool. For example, usage of a `P100` model in one data center does not consume the quota for a `P100` in a different data center, or for a different model in the same data center.

Instances configured with `gpu_count: 0`, or CPU-only instances, do not consume any GPU quota.

If Max Units is lowered below the current usage total, existing running instances are not affected and continue to run. New deployments are blocked until usage falls below the new limit.

Destroying an instance releases the GPU quota usage it was consuming.

***Example***

**Step 1 — Configure the quota (Operations Console)**

A Partner Admin creates a GPU quota with the following settings:

| Field | Value |
| --- | --- |
| Scope | Global |
| Quota type | GPU |
| SKU Type | Compute-based SKUs |
| Data Center | test-dc-50 |
| Model | T100 |
| Max Units | 100 |

[![Create Quota - GPU type](https://docs.rafay.co/aiml/gpupaas/img/examples_step1.png)](https://docs.rafay.co/aiml/gpupaas/img/examples_step1.png)

**Step 2 — View existing compute instances (Tenant Console)**

In the Tenant Console, a user navigates to **SKU Management > Compute Instances**. Two bare metal instances (`bm-ci-1` and `bm-ci-2`) are already running in **Success** status, each configured with `gpu_count: 50` and `gpu_type: T100` in `test-dc-50`, together already consuming the full quota.

**Step 3 — Attempt to spin up a new compute instance (Tenant Console)**

The user clicks **New Compute Instance**, selects a bare metal Compute SKU, and configures `gpu_count: 1` and `gpu_type: T100`. On clicking **Deploy**, the system checks the quota. The deploy fails because the limit for T100 GPUs in `test-dc-50` has already been reached, and the instance remains in a **not_deployed** state.

> **Note**
> Quotas are evaluated against current usage at the time of the request. Resources that were already running before a quota was applied continue to run; the quota applies only to new requests.

### Quotas and Project-Level Quotas

Organizations can also configure project-level instance and GPU quotas from **SKU Management > Project Quotas** in the Tenant Console. Project-level quotas are not a substitute for the quotas configured here in the Operations Console. A deployment request must satisfy every matching limit at the same time, and the tightest matching limit determines the outcome.

For a GPU deployment, this can include the project's Limit per User, the project's Overall Limit, and the organization-specific or global GPU quota configured here in the Operations Console, when one is configured. The Operations Console GPU quota is not skipped when a project-level GPU quota is also set. GPU usage against a project quota is counted within that project only. GPU usage against an organization-specific or global quota configured here is counted across the entire organization, across all of its projects.

A project-level Instance quota is configured against a specific Compute or Service SKU. A project-level GPU quota is configured using a data center and GPU model, without selecting a SKU.

---

## View and Manage Quotas

The **Quotas** list page shows a summary count at the top (for example, **3 Total · 1 Global · 2 Organization-Specific**), breaking down configured quotas by scope.

[![Quotas list page](https://docs.rafay.co/aiml/gpupaas/img/quotalist.png)](https://docs.rafay.co/aiml/gpupaas/img/quotalist.png)

Use the **Search** box to find a quota by name, or use the **Filter by Organization** dropdown to narrow the list to a specific organization.

---
