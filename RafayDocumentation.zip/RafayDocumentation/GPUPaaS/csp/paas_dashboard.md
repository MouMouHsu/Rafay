---
title: "GPU PaaS - Dashboard"
source: https://docs.rafay.co/aiml/gpupaas/csp/paas_dashboard/
---

# Dashboards

## PaaS Dashboard - Introduction

The PaaS Dashboard provides insights into the usage of compute and service instances over time, helping to track trends and resource allocation. It includes key metrics and visualizations to monitor compute and service profiles, along with active users.

> Note: Access to the PaaS Dashboard is restricted to partner organizations. Tenant organizations do not have permission to view it.

Access to the PaaS Dashboard is available through the Grid icon in the top-left corner of the console. Clicking the Grid icon opens the list of available services.

From the services list, select **Dashboards**, and then choose **PaaS** to open the PaaS Dashboard.

[![PaaS Navigation](https://docs.rafay.co/aiml/gpupaas/img/dashboard/paasdash_navi.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/paasdash_navi.png)

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/paas_dashboards.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/paas_dashboards.png)

### Organization Filter in PaaS Dashboard

The **Organization** filter (highlighted in the image) displays only those organizations where a profile has been shared and an instance has been created using it. It does not show all organizations listed in the Ops Console.

Selecting an option (e.g., `tenant_org1`, `partner`) updates all widgets and trend charts on the dashboard. This filter helps narrow down the dashboard view based on the selected organization.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/dashboard_filter.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/dashboard_filter.png)

> ℹ️ Important Note
> - Without Filter by Organization: Displays the total count and summary of all profiles created, regardless of organization.
> - With Filter by Organization: Displays the count and summary only for profiles that have been used to create instances in the selected organization.

---

## Key Metrics

### Compute Instances

Displays the total number of active compute instances across both partner and tenant organizations. This data is updated dynamically, reflecting the latest status when refreshed.

- **Grey**: Inactive instances that are currently not running
- **Amber**: Failed instances that encountered runtime issues
- **Red**: Delete failed instances which encountered errors during termination

Clicking the **three-line (ellipsis) icon** next to the **Compute Instances** card opens a detailed view. This expands into a table that provides comprehensive instance-level information, including:

- **Instance name**
- **Profile**
- **Status** (Active, Inactive, Failed)
- **Last updated**
- **Creation timestamp**
- **Usage hours**
- **Project**
- **Organization** (partner or tenant)

This view enables easy identification and monitoring of instance-level health and status across the organization.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/comp_insta.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/comp_insta.png)

### Service Instances

Displays the number of active service instances across both partner and tenant organizations. The data updates dynamically, reflecting the current state upon refresh.

- **Grey**: Inactive instances that are currently not running
- **Amber**: Failed instances that encountered runtime issues
- **Red**: Delete failed instances which encountered errors during termination

Clicking the **three-line (ellipsis) icon** next to the **Service Instances** card opens a detailed view. This expands into a tabular format displaying the following information for each instance:

- **Instance name**
- **Profile**
- **Status** (Active, Inactive, Failed)
- **Last updated**
- **Creation timestamp**
- **Usage hours**
- **Project**
- **Organization** (partner or tenant)

This view provides a consolidated status summary and helps track service instance activity and health across environments.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/serv_insta.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/serv_insta.png)

This table applies to both **Compute Instances** and **Service Instances**.

| **Status** | **Condition** |
| --- | --- |
| **Active** | Success (Publish Status) |
| **Inactive** | Not Deployed, In Progress |
| **Failed** | Failed, Cancel Failed, Update Failed |
| **Delete Failed** | Failed to terminate or clean up the instance |

In addition to the above table, the following table applies only to **Compute Instances** that support Start and Stop actions.

| **Status** | **Condition** |
| --- | --- |
| **Active** | Action is "Start" and status is "Action Complete" |
| **Inactive** | Action is "Stop", status is "Action Complete" or "Action Pending" |
| **Failed** | Action is "Start" or "Stop" and failed |

### Compute Profiles

Represents the number of unique compute profiles configured across all organizations. Each profile entry includes:

Clicking the **three-line (ellipsis) icon** next to the **Compute Profiles** card opens a detailed view. This expands into a tabular format displaying the following information for each profile:

- **Profile name**
- **Last updated timestamp**
- **Creation timestamp**
- **Associated project**

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/compute_table.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/compute_table.png)

### Service Profiles

Displays the count of service profiles in use across both partner and tenant organizations

Clicking the **three-line (ellipsis) icon** next to the **Service Profiles** card opens a detailed view. This expands into a tabular format displaying the following information for each profile:

- **Profile name**
- **Last updated timestamp**
- **Creation timestamp**
- **Associated project**

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/service_table.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/service_table.png)

- **Active Organizations (30d)**: Shows the number of organizations that have been active in the last 30 days

Clicking the **three-line (ellipsis) icon** next to the **Organizations** card opens a detailed view. This expands into a tabular format displaying the following information for each organization:

- **Organization name**
- **Number of compute instances**
- **Number of service instances**
- **List of compute instances** (displayed when the compute instance count is clicked)
- **List of service instances** (displayed when the service instance count is clicked, if available)

This view helps track organizations that have been active in the last 30 days based on their resource usage.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/org_list.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/org_list.png)

> ℹ️ Note
> - When a compute or service profile is created in the partner organization, it is counted in the total number of profiles.
> - If the profile is created directly in a tenant organization, it is not counted.
> - When a profile is shared from a partner to a tenant, and an instance is launched in the tenant using that shared profile, the number of instances is updated accordingly.
> - Similarly, if an instance is deleted, the count goes down.

### Download Usage Report

The **Download Usage Report** option allows Cloud Providers to generate usage reports for tenant organizations directly from the PaaS Dashboard. This feature supports billing, chargeback, and usage analysis workflows by providing both aggregated and hourly usage data in CSV format.

Clicking **Download Usage Report** opens a dialog where a date range can be selected. Depending on the report type chosen (Summary or Detailed), additional inputs may appear.

[![Download Usage Report](https://docs.rafay.co/aiml/gpupaas/img/dashboard/generate_report.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/generate_report.png)

**Summary Report**

Selecting **Download Summary Reports** opens a dialog that includes the following fields:

- **Date Range (UTC)**: Time window for which usage is aggregated.
- **Parameters**: Accepts comma-separated billable attributes *(for example: `param1,param2,param3`)*.

This report provides an **aggregated overview** of usage for each compute or service instance within the selected period.

***Example:***

| instance_name | kind | start_time | end_time | raw_usage |
| --- | --- | --- | --- | --- |
| test12 | compute | 2025-11-18T00:00:01Z | 2025-12-18T00:00:00Z | 356.88916 |
| si-1 | service | 2025-11-18T00:00:01Z | 2025-12-18T00:00:00Z | 21.601389 |

**Detailed Report**

Selecting **Download Detailed Reports** opens a simplified dialog with only one field:

- **Date Range (UTC)**: This report provides **hourly usage granularity**, generating one row per instance per hour for detailed chargeback and analysis.

***Example:***

| instance_name | kind | start_time | end_time | raw_usage |
| --- | --- | --- | --- | --- |
| rauto-multi-compute-instance-916911 | compute | 2025-11-28T18:00:00Z | 2025-11-28T19:00:00Z | 0.9855555 |
| rauto-multi-compute-instance-916911 | compute | 2025-11-28T19:00:00Z | 2025-11-28T20:00:00Z | 1 |

Both report types are exported in **CSV format**, enabling further processing or integration with external systems.

---

## Graphs & Visualizations

- **Compute Instance Trends (30d)**: A line graph that illustrates the number of compute instances over the last 30 days. A **Profile** filter allows narrowing down the graph to a specific compute profile or viewing trends across all profiles. Hovering over a data point displays the total number of compute instances for that date.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/graphic_trends.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/graphic_trends.png)

- **Service Instance Trends (30d)**: A similar trend graph that visualizes changes in service instances over the past 30 days. A **Profile** filter allows narrowing down the graph to a specific service profile or viewing trends across all profiles. Hovering over a data point on the graph displays the total number of service instance for a specific date.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/service_graph.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/service_graph.png)

---

## Grid View

### Compute Instance by Profile

Displays a list of compute instance profiles along with the count of instances using each profile. The profiles are listed on the left, while the corresponding instance counts are shown on the right. Hovering over the bar reveals the percentage of instance usage for that profile, providing a clearer understanding of resource distribution.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/compute_grids.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/compute_grids.png)

- Clicking the **three-line (ellipsis) icon** next to a profile opens a detailed view of compute instances associated with that profile. This view displays a table with the following columns:
  - **Instance**: Name of the compute instance
  - **Profile**: The associated compute profile
  - **Status**: Current status (e.g., Active, Inactive)
  - **Updated**: Time since the instance was last updated
  - **Created**: Time since the instance was created
  - **Usage**: Total usage time
  - **Project**: Project associated with the instance
  - **Organization**: Organization to which the instance belongs

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/compute_gridlist.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/compute_gridlist.png)

### Service Instance by Profile

Displays a list of service instance profiles along with the count of instances using each profile. The profiles are listed on the left, while the corresponding instance counts are shown on the right. Hovering over the bar reveals the percentage of instance usage for that profile, providing a clearer understanding of resource distribution.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/service_grids.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/service_grids.png)

- Clicking the **three-line (ellipsis) icon** next to a profile opens a detailed view of service instances associated with that profile. This view displays a table with the following columns:
  - **Instance**: Name of the service instance
  - **Profile**: The associated service profile
  - **Status**: Current status (e.g., Active, Inactive)
  - **Updated**: Time since the instance was last updated
  - **Created**: Time since the instance was created
  - **Usage**: Total usage time
  - **Project**: Project associated with the instance
  - **Organization**: Organization to which the instance belongs

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dashboard/service_gridlist.png)](https://docs.rafay.co/aiml/gpupaas/img/dashboard/service_gridlist.png)

---
