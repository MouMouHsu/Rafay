---
title: "Integrations - Global IdP"
source: https://docs.rafay.co/aiml/gpupaas/csp/global_idp/
---

# User Management

## Prerequisites

- **Partner Admin** or **Super Admin** access to the Rafay Ops Console
- **Global IdP** feature enabled for the partner in **Ops Console**
- A default Org configured for the partner
- A valid and verified SAML or OIDC IdP configuration in the default Org

---

The Rafay platform traditionally supports Identity Provider (IdP) configurations at the **customer organization level**, requiring each customer org to configure its own IdP settings.

This feature applies for scenarios where a Cloud Provider wishes to deploy and operate an IdP where they manage user identifies for their customer orgs. In this case, the cloud provider's IdP needs to be made available to all customer orgs managed by the cloud provider.

When the **Global IdP** feature is enabled for a partner, a **single SAML or OpenID Connect (OIDC) Identity Provider** configured in the **partner’s default organization** can be used to authenticate users across all organizations under the partner.

[![Global IdP](https://docs.rafay.co/aiml/gpupaas/img/global_idp.png)](https://docs.rafay.co/aiml/gpupaas/img/global_idp.png)

---

## Supported and Validated Providers

Global IdP is currently **validated** for **Auth0**, **Keycloak**, **Okta** and **PingOne** with both **SAML** and **OIDC**.

> **Note**
> - The IdP must include the organization identifier in its response. This value is matched against the **External ID** configured for each organization to route users to the correct tenant.
> - Organizations can configure IdPs other than the validated providers. Contact Rafay Support if additional configuration details or guidance are required.

---

## Enabling Global IdP

Rafay enables the Global IdP feature for a partner based on requirements.

### UI Support

- Navigate to **Operations Console** → **Partners**
- Select the desired partner and click **Edit**
- Go to the **Login/Auth** tab
- Enable the checkbox **Common IDP for all organisation**

This ensures that a single Identity Provider is shared across all organizations of the selected partner.

[![Create IdP](https://docs.rafay.co/aiml/gpupaas/img/common_idp_ui.png)](https://docs.rafay.co/aiml/gpupaas/img/common_idp_ui.png)

### API Support

Global IdP configuration can also be updated programmatically using the Partner API.

```
PUT /auth/v1/partners/{partner_id}/
```

***Example Request***

```
curl 'https://<ops-console-host>/auth/v1/partners/{partner_id}/' \
  -X 'PUT' \
  -H 'Accept: application/json' \
  -H 'Content-Type: application/json;charset=UTF-8' \
  -H 'x-rafay-partner: <partner_id>' \
  -d '{
    "id": "7kr9pkl",
    "name": "rauto-ncp-partner-qc-gpupaas.partner.dev.rafay-edge.net",
    "description": "rauto-testing",
    "settings": {
      "copyright": "@rauto-Copyright",
      "gslb_enabled": true,
      "sender_email": "[email protected]",
      "signup_enabled": true,
      "ORGANIZATION_APPROVAL": false,
      "disable_system_domain": true,
      "ACCOUNT_CREATION_STRATEGY": "AUTO",
      "applications": [],
      "applications_view": "grid",
      "group_applications": false,
      "support_portal": {
        "enabled": false,
        "label": "Support Portal",
        "url": ""
      },
      "idp_setting": {
        "common_idp_for_all_orgs": true
      }
    },
    "logo_link": "https://i.pinimg.com/originals/4a/b9/3f/4ab93f48c8f1708a615cc62ffc944962.png",
    "fav_icon_link": "https://i.pinimg.com/originals/4a/b9/3f/4ab93f48c8f1708a615cc62ffc944962.png",
    "notification_email": "[email protected]",
    "support_team_name": "rauto-support",
    "partner_helpdesk_email": "[email protected]",
    "partner_product_name": "rauto-ncp-partner-qc-gpupaas.partner.dev.rafay-edge.net",
    "domain": "rauto-test.rafay.co",
    "ops_host": "ops-rauto-ncp-partner-qc-gpupaas.partner.dev.rafay-edge.net",
    "is_totp_enabled": false,
    "is_synthetic_partner_enabled": false
  }'
```

***Response***

A successful request returns **HTTP 200 OK** with the updated partner configuration, including the applied Global IdP settings.

> Important ❗:
> 
> The field idp_setting.common_idp_for_all_orgs enables the Global IdP mode across all organizations.
> Optional parameters such as logo_link, notification_email, and support_team_name can be included to update branding and contact information.
> Include only the fields you intend to update; unspecified fields remain unchanged.
> If ACCOUNT_CREATION_STRATEGY is set to VERIFY, SMTP configuration can be enabled and no password is required during organization creation. If SMTP configuration is enabled, an email is sent to the user with instructions to set the password.
> If ACCOUNT_CREATION_STRATEGY is set to AUTO, a password must be set while creating the organization.

---

## Set Default Organization in Ops Console

When Global IdP is enabled for a partner, one organization must be designated as the **default organization**. This is the organization where the SAML or OIDC IdP is configured and from which all Global IdP authentication flows are initiated.

When a user logs in and their email domain does not match any organization-level IdP, the system automatically falls back to the IdP configured in the default organization to authenticate the user. The default organization acts as the **central authentication hub** for all organizations under the partner.

To set an organization as default:

- In the **Ops Console**, in the left navigation, select **Organizations**
- Click the **Actions menu (⋮)** next to the organization you want to set as default
- Click **Default Organization**

[![Default Organization](https://docs.rafay.co/aiml/gpupaas/img/default_org.png)](https://docs.rafay.co/aiml/gpupaas/img/default_org.png)

> **Note**
> - Any organization under the partner can be set as the default organization
> - Once set, the organization will show a **"Default"** badge next to its name
> - Once a default organization is configured, it cannot be changed. Contact Rafay support if a change is required.
> - The IdP must be configured in this default organization for Global IdP to work
> - If no default organization is set, the Global IdP authentication flow will fail

---

## External ID Requirement for Tenant Mapping

For **Global IdP** authentication to work, the **External ID** field must be configured for each tenant organization in the **Operations Console**.

In the **Operations Console**, navigate to **Organizations**, select the tenant organization, and update the **External ID** field under **Organization Settings**.

[![External ID Configuration](https://docs.rafay.co/aiml/gpupaas/img/external_id.png)](https://docs.rafay.co/aiml/gpupaas/img/external_id.png)

The organization identifier returned by the Identity Provider must match this **External ID** value.

During login, the controller uses this value to identify the target tenant and route the user to the correct organization after successful authentication.

> **Important**
> - The **External ID** field is mandatory for Global IdP login flows.
> - If the returned organization attribute does not match any configured **External ID**, login will fail.
> - The **External ID** value is **case-sensitive** and must exactly match the organization identifier returned by the IdP in the token or assertion. Ensure there are no leading or trailing spaces.

---

## Global IdP Workflow

- A single IdP is configured in the **default organization** of the partner
- Users access the partner’s Rafay Console portal
- The login behavior depends on whether the user exists in the local Rafay user database

### Case 1: User Exists in Local Rafay User Database

If the entered email address matches a local user record:

- The user is shown two options:
  - **Login With SSO**
  - **Login With Password**

[![Create IdP](https://docs.rafay.co/integrations/sso/img/global_sso.png)](https://docs.rafay.co/integrations/sso/img/global_sso.png)

This provides flexibility to authenticate through either method.

---

### Case 2: User Does Not Exist in Local Rafay User Database

If the user is not found in the local database:

- **Only the Login With SSO** option is shown
- The user is redirected to the IdP configured in the partner’s default organization

[![Create IdP](https://docs.rafay.co/integrations/sso/img/only_ssos.png)](https://docs.rafay.co/integrations/sso/img/only_ssos.png)

#### IdP Authentication and Organization Mapping

- After clicking **Login With SSO**, the user is redirected to the Identity Provider configured in the **default organization**.
- The Identity Provider must send the tenant’s **organization identifier** as part of the authentication response.
  - For **SAML**, send it as a **SAML attribute**
  - For **OIDC**, send it as a **token claim**
- This value must exactly match the tenant’s configured **External ID**.
- During login, Rafay compares the received organization identifier with the configured **External ID** values across tenant organizations.
- When a match is found, the user is automatically routed to the correct organization after successful authentication.

> **Note**
> - The **organization identifier attribute / claim** is required only for **Global IdP** flows.
> - For tenant-specific organization-level IdP configurations, this attribute is not required.

#### Support for Mixed Mode

If a subset of organizations require a **custom IdP** and others should use the Global IdP:

- Create individual IDPs in those specific organizations using their domain name(s)
- Create the Global IdP in the default organization

### Identity Provider Precedence

If both a tenant-specific IdP and a Global IdP exist:

- The **tenant-specific IdP always takes precedence**
- The Global IdP is used only when no tenant-specific IdP is configured for the matching domain

This allows a mixed deployment model where selected organizations use dedicated IDPs while others continue using the shared Global IdP.

> **Note**
> During authentication, the system first attempts to use the SAML IdP configuration configured in the default Org. If a valid and verified SAML configuration is not available, the system then attempts to use the OIDC IdP configuration in the default Org. If no valid and verified IdP configuration is found for either SAML or OIDC, the authentication request fails with an error.

---

### Login Flow

- If a user's domain matches a configured organization-level IdP, they are authenticated using that IdP
- Otherwise, the user is authenticated using the Global IdP
- If the user also exists in the local database, both login options (SSO and password) are shown
- If the same user belongs to multiple organizations under the same partner, the login flow prompts for the **organization name** to route the user to the selected tenant.

> Note: For best results, configure only one Global IdP in the default organization. If multiple IDPs exist in the default organization, provider selection may be unpredictable.

---
