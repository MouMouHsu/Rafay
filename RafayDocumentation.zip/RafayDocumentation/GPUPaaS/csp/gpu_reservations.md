---
title: "GPU Reservations"
source: https://docs.rafay.co/aiml/gpupaas/csp/gpu_reservations/
---

# GPU Reservations

**Release Information**
 This feature is available from release **v3.1-39** onwards.

## Overview

GPU Reservations represent a capacity commitment contract between the partner and a tenant (organization) for a fixed duration.

A reservation guarantees a defined number of GPUs for a selected tenant at a reduced contracted rate for the reservation period.

Reserved GPUs:

- Are guaranteed for the selected organization
- Are excluded from the on-demand pool
- Are billed for the full reservation duration
- Continue to be billed even if no instances consume them
- Remain active until the reservation expires or is deleted

This enables predictable GPU availability for long-running workloads such as AI/ML training, inference, and enterprise production deployments.

[![GPU Reservations list page](https://docs.rafay.co/aiml/gpupaas/img/gpu_reserv.svg)](https://docs.rafay.co/aiml/gpupaas/img/gpu_reserv.svg)

GPU Reservations can be configured using two approaches:

1. **Organization-Level Reservation:** Created by Partner Admins for a specific tenant
2. **Partner-Level Reservation Settings:** Used to define the maximum reservable GPU capacity per data center and inventory type

---

## Org Level Reservation

Reservations are managed from the **Operations Console → GPU Reservations** page.

### Create a GPU Reservation

Creating a GPU Reservation is a 3-step wizard: General Details → Configuration → Review & Confirm.

#### Step 1: Navigate to GPU Reservations

1. Log in to the Operations Console.
2. Select **Reservations** from the left navigation under **Usage & Billing**.
3. Click **Add Reservation**.

[![GPU Reservations list page](https://docs.rafay.co/aiml/gpupaas/img/gpu_reserv.png)](https://docs.rafay.co/aiml/gpupaas/img/gpu_reserv.png)

#### Step 2: Enter General Details

- **Name** (Required): A unique identifier for the reservation.
- **Description**: An optional description for reference.
- **Organization** (Required): The tenant/organization for whom the reservation is being created.
- **Data Center** (Required): The target data center where GPUs will be reserved.
- **Inventory Type** (Required): The type of compute inventory. This corresponds to the inventory type used during matchmaking when creating compute or service instances. Select one of:
  - Pod
  - Baremetal
  - VM
- **SKU Type** – Filters the reservation to a specific SKU category. This corresponds to the SKU type (compute type or service type) defined in compute or service instances. Options include:
  - All (default — matches any SKU type)
  - Bare Metal
  - Virtual Machines
  - Kubernetes
  - vCluster
  - Notebooks
  - Inference Endpoints
  - AI/ML Jobs
  - Custom Services

> Note: SKU Type is optional. Selecting All means the reservation will match GPU usage regardless of which SKU type the tenant is using. For example, selecting All would cover Pod, Jupyter Notebooks, or any other workload type equally.

Click **Save & Continue**.

[![Step 1 – General Details form](https://docs.rafay.co/aiml/gpupaas/img/gpu_detail.png)](https://docs.rafay.co/aiml/gpupaas/img/gpu_detail.png)

#### Step 3: Configure the Reservation

The available **GPU Types** are dynamically populated based on the selected **Data Center** and **Inventory Type** from Step 2.

- **GPU Type** (Required): Select the required GPU type (for example, H100, A100).
- **Number of GPUs** (Required): Enter the number of GPUs to reserve.
  - The UI displays the currently available GPU count for the selected type and data center.
  - The reservation cannot exceed available capacity.
- **Expiry Time**: Select the expiration date and time for the reservation. Once expired, the reserved GPU capacity is released back to the on-demand pool.
- **Billing Parameters**: Provide billing metadata in valid JSON format. This field accepts an array of objects that define the billing dimensions and values associated with the reservation. These parameters are used to identify and categorize reservation costs for billing purposes.  Use the **Format JSON** button to validate and format the input.  The JSON schema is the same as the `billableParameters` field in Compute Profiles. Each entry in the array supports the following fields:  
| Field | Description |
| --- | --- |
| `name` | The billing dimension name (for example, `cpu`, `region`). |
| `type` | The extraction method. Use `jsonpath` to reference a value from the instance spec. |
| `value` | A JSONPath expression pointing to the variable in the environment template (for example, `$.spec.variables[?(@.name == 'var-1')].value`). |
| `isLabel` | Optional. Set to `true` if the value should be treated as a label rather than a numeric metric. |

 **Example:**  

```
[
  {
    "name": "cpu",
    "type": "jsonpath",
    "value": "$.spec.variables[?(@.name == 'var-1')].value"
  },
  {
    "name": "region",
    "type": "jsonpath",
    "isLabel": true,
    "value": "$.spec.variables[?(@.name == 'label-1')].value"
  }
]
```

  **Note**: The variable names referenced in the `value` expressions (for example, `var-1`, `label-1`) must match variables defined in the environment template associated with the profile/SKUs.

Click **Save & Continue**.

[![Step 2 – Configuration page](https://docs.rafay.co/aiml/gpupaas/img/gpus_config.png)](https://docs.rafay.co/aiml/gpupaas/img/gpus_config.png)

#### Step 4: Review & Confirm

The Review & Confirm page displays a complete summary of all details entered.

Each section displays an edit icon (pencil) that allows navigating back to that step to make changes if required.

Click **Create Reservation** to finalize.

[![Step 3 – Review & Confirm page](https://docs.rafay.co/aiml/gpupaas/img/prev_configs.png)](https://docs.rafay.co/aiml/gpupaas/img/prev_configs.png)

Once created:

- The reservation appears in the GPU Reservations list.
- The status shows:
  - **Active** – Reservation is valid and GPU capacity is reserved.
  - **Expired** – Reservation has reached its expiry time and capacity has been released back to the pool.

[![GPU Reservations list](https://docs.rafay.co/aiml/gpupaas/img/reserv_lists.png)](https://docs.rafay.co/aiml/gpupaas/img/reserv_lists.png)

> Note: Reservations become active immediately upon successful creation. The tenant is billed for the reserved GPUs for the entire reservation period, regardless of actual usage.

---

### Managing Reservations

From the **Reservations** page, the following actions are available:

- Search by GPU type using the search bar.
- Filter reservations by Datacenter, Organization, or Status.
- Clear applied filters using **Clear All**.
- View reservation details.
- Delete a reservation.

[![GPU Reservations list with Filters panel](https://docs.rafay.co/aiml/gpupaas/img/gpus_filter.png)](https://docs.rafay.co/aiml/gpupaas/img/gpus_filter.png)

#### Understanding the GPUs Column

Each reservation in the list displays a **GPUs** column in the format:

`X Used Y | Available Z`

Where:

- **X** – Total number of GPUs defined in the reservation contract.
- **Used Y** – Number of those GPUs currently consumed by active instances.
- **Available Z** – Number of GPUs still free within the reservation. This value also controls whether new reservations or new on-demand instances can be created. If this reaches zero, no further reservations or on-demand instances can be created for that GPU type and data center combination.

> Note: Editing an existing reservation is not supported. To change reservation parameters, delete the existing reservation and create a new one.

---

### Reservation Expiry Notifications

To receive email alerts when a reservation reaches its expiry time, enable the **PaaS Reservation Expiry** notification from the Administration console.

1. Navigate to **Administration** → **Events & Reports** → **Alerts** → **Manage Notifications**.
2. Enable the **PaaS Reservation Expiry** toggle.
3. (Optional) Add **Recipient Emails** to send notifications to specific email addresses.
4. Click **Save**.

[![Reservation Toggle](https://docs.rafay.co/aiml/gpupaas/img/reserv_alerts.png)](https://docs.rafay.co/aiml/gpupaas/img/reserv_alerts.png)

---

### How Reservations Affect GPU Usage

- If an organization has an active reservation, matching GPU instances consume from the reserved quota.
- If the reserved quota is fully used, additional instances are provisioned as on-demand.
- When a reservation expires or is deleted, GPUs return to the on-demand pool.

***Example***

If an organization reserves **50 A100 GPUs** in **datacenter-1** for **VM** inventory:

- The first 50 matching VM instances consume from the reserved quota.
- The 51st instance is provisioned as on-demand.
- If any of the first 50 instances are deleted, that capacity becomes available again within the reserved quota.

---

### Reserved Instance Classification and Labels

When a compute or service instance is created (in the **Tenant org > SKU Management > Compute Instances > New Compute Instance**), the system automatically checks whether it matches any active reservation based on the following criteria:

- Organization
- Data Center
- Inventory Type
- GPU Type

If a match is found, the instance is classified as a **reserved instance**. This classification is reflected as system-applied labels on the instance.

#### Reservation Labels on Instances

The following labels are automatically added to instances that are fulfilled from a reservation:

| Label | Value | Description |
| --- | --- | --- |
| `paas.envmgmt.io/instance_type_reserved` | `true` | Indicates the instance is classified as reserved |
| `paas.envmgmt.io/gpu_reservation_name` | Reservation name | The name of the reservation this instance is consuming |
| `paas.envmgmt.io/gpu_reservation_id` | Reservation UUID | The unique ID of the reservation, used for billing calculations |

[![Compute Instance labels](https://docs.rafay.co/aiml/gpupaas/img/instance_labels.png)](https://docs.rafay.co/aiml/gpupaas/img/instance_labels.png)

These labels are used by the billing system to track reservation consumption and calculate usage duration for the reservation contract.

#### Dynamic Re-classification

Instance classification between reserved and on-demand is dynamic and adjusts automatically based on the state of the reservation and available quota.

**When reserved quota is full:**

- If all reserved GPU slots are consumed and a new matching instance is created, it is classified as **on-demand**.
- If one of the reserved instances is deleted, the on-demand instance is automatically **re-classified as reserved** — since a slot has become available within the reservation quota.

**When a reservation is deleted:**

- Any instances currently consuming that reservation are automatically **re-classified as on-demand**.
- These instances continue to run but will be billed at the on-demand rate going forward.

**When a reservation expires:**

- At the moment of expiry, all instances that were consuming the reservation are automatically **converted to on-demand**.
- The reservation status changes to **Expired** in the GPU Reservations list and the reserved GPU capacity is released back to the pool.

> Note: At any point in time, the number of instances classified as reserved cannot exceed the GPU count defined in the reservation. The system continuously enforces this quota as instances are created or deleted.

#### Billing Behavior

- The reservation entity itself is billed for the full reservation period from the moment it is created — regardless of instance usage.
- Instances classified as reserved are **not billed separately** — their usage is already covered under the reservation contract.
- Instances converted to on-demand (due to reservation deletion or expiry) are billed at the standard on-demand rate from the point of conversion.

---

### Tracking Reservation Changes

#### Labels and On-Demand Conversion

When an instance is converted from reserved to on-demand — due to reservation deletion, expiry, or quota changes — the reservation labels (`paas.envmgmt.io/instance_type_reserved`, `paas.envmgmt.io/gpu_reservation_name`, `paas.envmgmt.io/gpu_reservation_id`) are automatically removed from the instance.

This means the instance itself no longer carries any indication that it was previously reserved. To track reservation history, use the Audit Logs.

#### Audit Logs

Reservation lifecycle events are recorded in the system **Audit Logs**, accessible from **Tenant Org → Administration → Events & Reports → Audit Logs**.

To view reservation events:

1. Open the **System** tab.
2. Filter by **Type**, such as:
3. `gpureservation.utilised`
4. `gpureservation.released`

Each audit log entry includes:

- **Date** – Timestamp when the reservation was applied or released
- **Type** – Event type
- **Message** – Reservation name and associated compute instance details

***Example: `GPU reservation 'bm-a100-dc4-8gpu' applied to compute instance dc-1-1gpu-bm`***

[![Audit Logs](https://docs.rafay.co/aiml/gpupaas/img/audit_logs.png)](https://docs.rafay.co/aiml/gpupaas/img/audit_logs.png)

This provides a traceable record of when an instance transitioned from reserved to on-demand, without needing to query the database directly.

#### Billing Integration

Reservation classification changes are tracked for billing through an event-driven integration:

- Whenever a reservation label is added or removed from an instance — indicating a transition between reserved and on-demand — a billing event is emitted at that point in time.
- The billing system hooks into this event and uses the reservation name and ID to calculate usage for the reservation contract.
- No additional billing logic or infrastructure changes are required outside of this event mechanism.

---

### Controlling On-Demand Instance Creation

GPU reservations can be used with an organization-level control to restrict workloads to consume GPU capacity only from active reservations, effectively enforcing reservation-based quota usage.

This setting is available in the **Operations Console** under **Organizations → [Select Organization] → Features → On-Demand Instance Creation**.

[![Organization Features page](https://docs.rafay.co/aiml/gpupaas/img/ondemand_toggle.png)](https://docs.rafay.co/aiml/gpupaas/img/ondemand_toggle.png)

The toggle controls the following behavior:

- **Enabled (default):** Users in the organization can create both on-demand and reserved GPU instances freely. They are not restricted to reservation capacity only.
- **Disabled:** Users in the organization cannot create on-demand GPU instances. They can only create instances that belong to an active reservation. If no matching reservation exists, instance creation is blocked.

This is useful when a partner wants to enforce that a tenant only consumes the GPU capacity they have contractually reserved, preventing any unplanned on-demand usage outside of the reservation agreement.

***Example***

A tenant has active reservations for H100 and A100 GPUs. If **On-Demand Instance Creation** is disabled for their organization:

- They can create H100 or A100 instances — these will be fulfilled from the reservation quota.
- They cannot create any instance type that does not have a matching active reservation.
- Once their reservation expires, instance creation is blocked until a new reservation is created or the setting is re-enabled.

> Note: This setting is managed at the organization level by the partner. It applies to all users within that organization.

---

### Notes and Limitations

- Reservations are time-bound and automatically expire at the configured expiry time.
- Reservation capacity is validated during creation.
- Reservations cannot exceed available GPUs in the selected data center.
- Reservations cannot be modified after creation.
- Deleting a reservation immediately releases the reserved capacity back to the available pool.
- Reservations apply only to the selected GPU type, data center, inventory type, and SKU type.
- Expired reservations must be recreated if capacity needs to be reserved again.
- The tenant is billed for the full reservation period regardless of actual GPU usage.

---

## Partner-Level GPU Reservation Settings

Partner Super Admins can configure maximum reservable GPU limits at the partner level. This is a global setting that defines an upper limit on how many GPUs can be allocated for reservations across all organizations for a given data center, inventory type, and GPU type.

For example, if a partner has 1,000 A100 GPUs and wants to reserve only 600 for reservation contracts while keeping 400 available for on-demand use, they can define that limit here. Once set, no reservation can be created that would exceed this cap.

These settings are accessible from **Operations Console**

> Max Reservable vs. Current Reservation:
> 
> Max Reservable GPUs – The upper limit defined by the partner. This is the maximum number of GPUs that can be committed to reservations for the given data center, inventory type, and GPU type.
> Current Reservation – The number of GPUs currently reserved across all active reservation contracts created against this setting.

### Add Partner GPU Setting

#### Step 1: Navigate to Reservation Limits

1. Log in to the Operations Console.
2. From the left navigation, select **Reservation Limits** under **Usage & Billing**.
3. Click **Add**.

[![Settings → GPU tab with Add button](https://docs.rafay.co/aiml/gpupaas/img/gpu_sett.png)](https://docs.rafay.co/aiml/gpupaas/img/gpu_sett.png)

#### Step 2: Enter General Details

Provide the following:

- **Data Center** (Required): Select the target data center.
- **Inventory Type** (Required): Select one: VM, Pod, or Baremetal.
- **SKU Type**: Filters the setting to a specific SKU category. Defaults to All, which matches any SKU type.
- **GPU Type** (Required): Select the required GPU type (for example, H100, A100).
- **Max Reservable GPUs** (Required): Define the maximum number of GPUs that can be reserved for this combination.
  - The UI displays the total available GPUs.
  - The value cannot exceed available capacity.
- **Description**: Optional description for reference.

Click **Save & Continue**.

[![Partner GPU Settings – General Details form](https://docs.rafay.co/aiml/gpupaas/img/sett_general.png)](https://docs.rafay.co/aiml/gpupaas/img/sett_general.png)

#### Step 3: Add Labels

Labels allow attaching key-value metadata to the partner GPU setting.

- Click **Add Label**.
- Enter **Key** and **Value**.
- Multiple labels can be added if required.

Click **Save & Continue**.

[![Partner GPU Settings – Labels step](https://docs.rafay.co/aiml/gpupaas/img/gpu_labels.png)](https://docs.rafay.co/aiml/gpupaas/img/gpu_labels.png)

#### Step 4: Review & Confirm

Review the configuration — both the General Details and Labels.

Click **Create** to finalize the partner GPU setting.

[![Partner GPU Settings – Review & Confirm](https://docs.rafay.co/aiml/gpupaas/img/detail_add.png)](https://docs.rafay.co/aiml/gpupaas/img/detail_add.png)

---

### Managing Partner GPU Settings

From the **General Settings → GPU** page:

- Search by GPU type.
- View configuration details including current reservation usage vs. max reservable limit.
- Use the **Edit** option to modify the entry. Only the **Max Reservable GPUs** field is editable. All other fields are read-only after creation.
- Delete a setting if required.

[![Partner GPU Settings list with edit option](https://docs.rafay.co/aiml/gpupaas/img/editing_gpus.png)](https://docs.rafay.co/aiml/gpupaas/img/editing_gpus.png)

---

### How Partner-Level Settings Affect Reservations

- Organization-level reservations cannot exceed the configured **Max Reservable GPUs** for the matching data center, inventory type, and GPU type.
- The system validates reservation creation against this limit.
- If the limit is reached, additional reservations are rejected.
- Partner-level limits provide centralized control over how much GPU capacity is committed to reservations vs. kept available for on-demand use.

---

## Troubleshooting

### GPU count validation during reservation creation

Some GPU and inventory combinations require the reservation count to align with the supported allocation unit of the selected host type.

***Example 1***

In the following scenario:

- **Inventory Type**: Bare metal
- **GPU Type**: H100
- **Number of GPUs**: 3

The UI displays the following error during **Review & Confirm**:

```
rpc error: code = InvalidArgument desc = count must be a multiple of 8 for H100 baremetal reservations, got 3
```

[![Partner GPU Settings list with edit option](https://docs.rafay.co/aiml/gpupaas/img/gpu_troubleshooting.png)](https://docs.rafay.co/aiml/gpupaas/img/gpu_troubleshooting.png)

This occurs because the selected H100 bare-metal host supports allocation in fixed groups of **8 GPUs per host**.

To resolve this, update **Number of GPUs** to a supported value such as **8**, **16**, or **24**, and then retry the reservation creation.

***Example 2 — A100 Bare Metal***

In the following scenario:

- **Inventory Type**: Bare metal
- **GPU Type**: A100
- **Number of GPUs**: 3

The UI displays a similar error during **Review & Confirm**:

```
rpc error: code = InvalidArgument desc = count must be a multiple of 4 for A100 baremetal reservations, got 3
```

[![Partner GPU Settings list with edit option](https://docs.rafay.co/aiml/gpupaas/img/trouble_2.png)](https://docs.rafay.co/aiml/gpupaas/img/trouble_2.png)

This occurs because the selected A100 bare-metal host supports allocation in fixed groups of **4 GPUs per host**.

To resolve this, update **Number of GPUs** to a supported value such as **4**, **8**, **12**, or **16**, and then retry the reservation creation.

---
