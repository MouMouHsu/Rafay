---
title: "Orchestration Agents"
source: https://docs.rafay.co/aiml/gpupaas/csp/orchestration_agents/
---

# Orchestration Agents

## Overview

Orchestration Agents are created in the system-catalog project. An agent is a data center's outbound link to the controller. Device and tenant onboarding run through it. Deploy two or more agents for high availability.

> **Note**
> Only agents that exist in the `system-catalog` project can be seen and assigned to a datacenter here. If an agent is created through Infra Portal in the default Org rather than through Operations Console, create it directly in the `system-catalog` project. An agent created in another project can be shared into `system-catalog` so it becomes available for datacenter mapping, but its lifecycle from Operations Console is then limited.

---

## Accessing Orchestration Agents

- Log in to the **Operations Console**
- In the left navigation under **Inventory**, select **Orchestration Agents**

[![Orchestration Agents](https://docs.rafay.co/aiml/gpupaas/img/agent.png)](https://docs.rafay.co/aiml/gpupaas/img/agent.png)

The Orchestration Agents list displays the following details for each entry:

| Column | Description |
| --- | --- |
| **Name** | The name of the agent and its type and version. |
| **Status** | The activation status of the agent. |
| **Health** | The health status of the agent. |
| **Datacenters** | The data center the agent is assigned to. Displays **All Datacenters** if the agent is assigned globally, or **Not assigned** if no assignment has been made. |
| **Created** | The date and time the agent was created. |

---

## How Agents Are Selected

### Agent Selection Hierarchy

When an environment is launched, the system determines which agents to use based on the following hierarchy:

- If the environment template specifies agents, those agents are used exclusively and the globally defined agents are ignored.
- If the environment template does not specify agents, the globally defined agents are used as a fallback.

> **Note**
> If agents are shared across multiple projects, ensure the environment template is also shared with those same projects so the environment launch process has access to the shared agents.

### Datacenter-Based Agent Selection

When a compute profile specifies a data center, the system automatically determines which agents to associate based on the data center assignment configured for each agent.

- If the selected data center has agents assigned to it, only those agents are used.
- If the selected data center has no agents assigned, the system falls back to agents assigned to **All Datacenters**.
- If data center specific agents exist but all are unhealthy, an error is returned as no healthy agent is available for scheduling.

### Work Distribution Among Eligible Agents

Agents use a pull based model to receive deployment tasks. When an agent is free and has capacity available, it requests tasks from the controller and executes them.

- When an environment is created, it has a list of eligible agents based on the datacenter assignment configured in the Operations Console.
- If multiple eligible agents are healthy and available, any of them can receive the deployment task. The agent that becomes free first accepts the task. The selection is random and is not based on the order in which agents were created or assigned.
- Agents are independent and do not interact with one another. Each agent requests tasks from the controller on its own.
- Inactive or unhealthy agents never receive tasks.

The system does not verify network connectivity between an agent and the target infrastructure during selection. Ensure every eligible agent for an environment has connectivity to the infrastructure it provisions.

> **Warning**
> If a healthy agent accepts a deployment task for infrastructure it cannot reach, the deployment fails and is not retried by another agent. To restrict an environment to specific agents, specify the agents in the environment template or assign agents to a specific data center. If the environment template comes from the Default Catalog and cannot be modified, clone the template and specify the agents in the clone.

---

## Add an Agent

- On the Orchestration Agents page, click **Add Agent**

[![Add Agent](https://docs.rafay.co/aiml/gpupaas/img/add_agent.png)](https://docs.rafay.co/aiml/gpupaas/img/add_agent.png)

### Agent Name

| Field | Required | Description |
| --- | --- | --- |
| **Agent name** | Yes | A unique name for the agent. Example: `dc-west-agent-1`. A Docker agent is created, set to active, and ready to connect once the install bundle is run. The agent can be deactivated later from the list. |

### Datacenter Assignment

Defines the scope of the agent's availability across data centers.

| Field | Required | Description |
| --- | --- | --- |
| **Applies to** | Yes | Determines the data center scope for the agent. Select **All Datacenters** to make the agent available across every data center available to the partner. Select **Specific Datacenter** to limit the agent to one named data center. |
| **Datacenter name** | Yes, if **Specific Datacenter** is selected | The data center to assign this agent to. Select from the list of available data centers. |

### Resources (Optional)

Defines resource limits for the agent.

| Field | Required | Description |
| --- | --- | --- |
| **Concurrency limit** | No | The maximum number of concurrent API calls the agent can handle. Example: `10`. |
| **Number of workers** | No | The maximum number of parallel workers. Example: `4`. |
| **CPU limit** | No | The CPU limit for the agent. Example: `2` or `500m`. |
| **Memory limit** | No | The memory limit for the agent. Example: `2Gi`. |

[![Add Agent](https://docs.rafay.co/aiml/gpupaas/img/agent_config.png)](https://docs.rafay.co/aiml/gpupaas/img/agent_config.png)

- Once all fields are configured, click **Create agent**
- To exit without saving, click **Cancel**

---

## Assign a Datacenter

A datacenter can be assigned to an existing agent directly from the Orchestration Agents list.

- On the Orchestration Agents list, click the **Datacenters** value for the agent

[![Assign Datacenter](https://docs.rafay.co/aiml/gpupaas/img/select_agent.png)](https://docs.rafay.co/aiml/gpupaas/img/select_agent.png)

- If the agent has no datacenter assigned, the Assign Datacenter dialog opens

| Field | Required | Description |
| --- | --- | --- |
| **Applies to** | Yes | Determines the data center scope for the agent. Select **All Datacenters** to make the agent available across every data center available to the partner. Select **Specific Datacenter** to limit the agent to one named data center. |
| **Datacenter name** | Yes, if **Specific Datacenter** is selected | The data center to assign this agent to. Select from the list of available data centers. |

[![Datacenter Assignment](https://docs.rafay.co/aiml/gpupaas/img/add_dc.png)](https://docs.rafay.co/aiml/gpupaas/img/add_dc.png)

If the agent already has a datacenter assigned, clicking the datacenter value opens the Datacenter Assignment details dialog, which displays the current assignment details.

| Field | Description |
| --- | --- |
| **Scope** | The assignment scope. Displays **Specific Datacenter** or **All Datacenters**. |
| **Datacenter** | The name of the assigned data center. |
| **Agent** | The name of the agent. |
| **Agent health** | The health status of the agent and its version. |
| **Assigned** | The date and time the datacenter was assigned. |

[![Datacenter Assignment](https://docs.rafay.co/aiml/gpupaas/img/shows_dc.png)](https://docs.rafay.co/aiml/gpupaas/img/shows_dc.png)

Select **Remove Datacenter** to remove the current assignment.

---

## Agent Actions

Select the actions menu (**...**) for an agent to perform the following actions:

| Action | Description |
| --- | --- |
| **Setup** | Opens the agent setup instructions for installing the agent on a host with Docker and Docker Compose. |
| **Edit Datacenter** | Opens the Assign Datacenter dialog to update the datacenter assignment for the agent. |
| **Deactivate** | Deactivates the agent. A deactivated agent is no longer available for environment provisioning. |
| **Delete** | Permanently deletes the agent. Only available for agents owned by (created in) the `system-catalog` project. An agent created in another project and later shared into system-catalog cannot be deleted from here; it must be deleted from its owning project. |

[![Datacenter Assignment](https://docs.rafay.co/aiml/gpupaas/img/agent_options.png)](https://docs.rafay.co/aiml/gpupaas/img/agent_options.png)

### Setup

Select **Setup** to open the agent setup instructions. The setup dialog provides the bundle files needed to install the agent.

To install the agent on the host:

1. Copy the bundle files to a host with Docker and Docker Compose.
2. Run `docker compose up -d` on that host.
3. The agent connects to the controller and turns Healthy.
4. Configure passwordless SSH from the agent to the compute nodes.

The setup dialog provides two files for download:

- **relayConfigData JSON** — the agent configuration file. Copy or download this file to the host.
- **docker-compose YAML** — the Docker Compose file to run the agent. Copy or download this file to the host.

[![Agent Setup](https://docs.rafay.co/aiml/gpupaas/img/agent_setup.png)](https://docs.rafay.co/aiml/gpupaas/img/agent_setup.png)

---
