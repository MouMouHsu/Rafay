---
title: "Overrides"
source: https://docs.rafay.co/aiml/gpupaas/csp/overrides/
---

# Overrides

## Overview

Overrides allow administrators to define default values for input variables and environment variables scoped to a specific SKU and organization. Global and SKU-scoped overrides apply across organizations.

---

## Accessing Overrides

- Log in to the **Operations Console**
- In the left navigation, select **Overrides**

[![Overrides](https://docs.rafay.co/aiml/gpupaas/img/override.png)](https://docs.rafay.co/aiml/gpupaas/img/override.png)

The Overrides list displays the following details for each entry:

| Column | Description |
| --- | --- |
| **Organization** | The organization the override is scoped to. Displays **All Organizations** for global overrides. |
| **SKU Name** | The SKU associated with the override. |
| **Overrides** | The number and type of overrides applied. Types include **Environment** and **Input**. |

Use the **Filter By Organization** dropdown to filter the list by a specific organization. Use the **Override Type** dropdown to filter by override type.

---

## Create an Override

- On the Overrides page, click **Add Override**
- The Create Override form opens with two sections: **General Information** and **Key-Value Pairs**

### General Information

| Field | Required | Description |
| --- | --- | --- |
| **Organization** | Yes | The organization this override applies to. Select **All Organizations** to apply it globally, or select **Specific Organization** to limit it to a single organization.  When **Specific Organization** is selected, a **Select Organization** dropdown appears. Choose the target organization from the list. |
| **SKU** | Yes | The SKU this override applies to. Select **All SKUs** to apply it across every SKU, or select **Specific SKU** to limit it to a single SKU.  When **Specific SKU** is selected, a **Select the SKU to override** dropdown appears. Choose the target SKU from the list. |

### Key-Value Pairs

Key-Value Pairs define the override name and its default value.

| Field | Required | Description |
| --- | --- | --- |
| **Environment Overrides** | No | Key/value pairs applied on top of the template as environment variables. Click **Add Env** to add an entry. |
| **Input Overrides** | No | Key/value pairs applied on top of the template as input variables. Click **Add Input** to add an entry. |

[![General Information](https://docs.rafay.co/aiml/gpupaas/img/create_override.png)](https://docs.rafay.co/aiml/gpupaas/img/create_override.png)

- Once all fields are configured, click **Create Override**
- To exit without saving, click **Discard Changes & Exit**

---
