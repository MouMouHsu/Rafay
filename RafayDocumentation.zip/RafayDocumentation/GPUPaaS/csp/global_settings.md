---
title: "Global Settings"
source: https://docs.rafay.co/aiml/gpupaas/csp/global_settings/
---

# Global Settings

> **Note**
> On upgrade to the 3.1-40 release, existing Global Settings configurations are automatically migrated to Operations Console, and the YAML-based configuration approach outlined on this page will be blocked.
>
> For more information, see [Overrides](https://docs.rafay.co/aiml/gpupaas/overrides/), [Rate Cards](https://docs.rafay.co/aiml/gpupaas/rate_cards/), and [Orchestration Agents](https://docs.rafay.co/aiml/gpupaas/orchestration_agents/).

---

## What is Global Settings?

The Global Settings feature provides a centralized configuration management system for profiles (SKUs) across multiple tenants. It allows users to define and manage variable overrides, agent configurations, quota limits, and billing settings at different levels—global, profile-specific, and tenant-specific. This hierarchical structure ensures consistency and efficiency in managing profile deployments.

---

## Why Use Global Settings?

Managing configurations separately for each profile and tenant can lead to inconsistencies, inefficiencies, and increased overhead. The Global Settings feature helps by:

- Ensuring consistency across all profiles and tenants
- Reducing manual effort by applying settings dynamically
- Providing flexibility with a structured hierarchy for overrides
- Automating agent association for environment launches
- Streamlining billing and quota enforcement

---

## When to Use Global Settings?

Global Settings should be used in scenarios where:

- Standardized configurations are required across multiple tenants and profiles
- Automated agent assignments are needed for environment provisioning
- Quota limits must be defined to prevent excessive resource consumption
- A centralized approach is preferred for managing variable overrides
- A structured billing system based on usage is necessary

---

## How to Add Global Settings?

Follow these steps to add or update Global Settings:

- In the **System** menu, navigate to **Global Settings**

[![Audit Logs Console](https://docs.rafay.co/aiml/gpupaas/img/global_setting.png)](https://docs.rafay.co/aiml/gpupaas/img/global_setting.png)

There are two ways to add Global Settings:

**Option 1: Upload a YAML File**

- Click **Upload File**
- Select a valid **YAML** file containing the Global Settings configuration
- Click **Save** to apply the settings

**Option 2: Enter YAML Manually**

- In the editor, type or paste the **YAML specification** for Global Settings
- Click **Save** to apply the settings
- Click **Reset** to discard unsaved changes and revert to the last saved configuration
- Modify the YAML directly in the editor and click **Save** to update the settings

[![Audit Logs Console](https://docs.rafay.co/aiml/gpupaas/img/global_set_spec.png)](https://docs.rafay.co/aiml/gpupaas/img/global_set_spec.png)

---

## Configuration Structure

Global Settings follows a hierarchical structure:

- **Global** (applies to all profiles and tenants)
- **Profile-Specific** (applies to all tenants using a specific profile)
- **Tenant-Specific** (applies to a specific tenant and profile)

If the same setting is defined at multiple levels, the system applies the highest-priority configuration based on this order:

- **Tenant-Specific (Highest Priority)** – Takes precedence over all other levels
- **Profile-Specific** – Applied if no tenant-specific values exist
- **Global (Lowest Priority)** – Used as a fallback when no other values are defined

---

## Global Overrides

### Agent Configuration

Every profile (SKU) requires a healthy agent to launch environments and execute workflows. Instead of manually assigning agents to each profile, you can define them centrally in the Global Settings. These agents will be dynamically associated with all profiles during environment provisioning, unless overridden elsewhere.

**Agent Selection Hierarchy**

The system uses a layered approach to determine which agents are applied during environment launch. This hierarchy gives you fine-grained control when required, while still allowing centralized defaults to simplify setup.

- **Global Agents**

If the environment template does not specify any agents, the globally defined agents from this configuration will be used instead.

***Example***:

```
agents:
  - demoagent-1
  - demoagent-2
  - demoagent-3
```

This configuration ensures that these agents are available to all environments by default.

- **Environment Template Level Agents**

When agents are defined in the environment template, they take full precedence. These agents will be used exclusively during environment provisioning.

***Example***:

```
spec:
  agents:
    - envtemplate-agent-1
    - envtemplate-agent-2
```

If this configuration is present in the environment template, only these agents will be used during environment launch. The global agent list will be ignored.

> 💡 Note:
> - If the agents are shared across multiple projects, make sure the environment template is also shared with those same projects. This ensures that the environment launch process has access to the shared agents as expected.
> 
> Starting with the 3.1-40 release, agent to datacenter mapping is managed from Operations Console, and Operations Console only surfaces agents that exist in the system-catalog project. When creating an agent through Infra Portal in the default Org, create it in the system-catalog project so it can be mapped and used by SKUs or templates shared with tenant orgs. An agent created in another project can still be shared into system-catalog to enable mapping, but its lifecycle from Operations Console is limited (for example, it cannot be deleted there, since only the owning project can delete an agent).

---

### Datacenter-Based Agent Selection

Datacenter selection is also governed by the configuration defined in **Global Settings**. When a compute profile specifies a datacenter, the system automatically determines which agents to associate with the profile based on the datacenter-to-agent mapping configured in this page.

**Datacenter Mapping in Global Settings**

Global Settings supports two levels of agent configuration:

- **Global Agents**: Agents available across all datacenters
- **Datacenter-Specific Agents**: Agents assigned to a particular datacenter

A datacenter entry includes a datacenter name and the list of agents mapped to it.

***Example Configuration***

```
agents:
  - agent-1
  - agent-2
  - agent-3

datacenters:
  - name: us-east
    agents:
      - dc1-agent-1
      - dc1-agent-2
  - name: eu-west
    agents:
      - dc2-agent-1
      - dc2-agent-2
```

**How Datacenter-to-Agent Matching Works**

When a datacenter is selected in the compute profile, the system determines which agents to assign based on the Global Settings configuration.

1. **If the selected datacenter exists in Global Settings:** Only the agents mapped to that datacenter are added to the compute profile’s status.
2. **If the selected datacenter is not present in Global Settings:** The system falls back to the **global agents** defined at the top level.
3. **If datacenter-specific agents exist but all are unhealthy:** An error is returned because no healthy agent is available for scheduling.

***Example Behavior***

Scenario: Datacenter-Specific Agents Exist**

```
Selected datacenter: us-east
Global Settings:
  us-east → dc1-agent-1, dc1-agent-2
```

***Result:*** The compute profile is associated only with the agents mapped to `us-east` (`dc1-agent-1` and `dc1-agent-2`).

---

### Input Variables (Overrides)

Certain variables are commonly used across multiple tenants, profiles, or environments. Instead of defining them separately for each profile, they can be set globally to maintain consistency and reduce duplication.

Example:

```
overrides:
  aws_account_id: "123456789"
  aws_region: "us-east-1"
  iam_role: "arn:aws:iam::123456789012:role/MyCrossAccountRole"
```

- AWS Account ID: Used for multiple tenants
- AWS Region: Shared across environments to standardize deployment locations
- IAM Role: Enables cross-account access without reconfiguration

> 💡 Note: These values remain active unless overridden in profile-specific or tenant-specific sections.

---

## Profile-Specific Overrides

Each profile (SKU) can have its own configuration, including:

- Input Variable Overrides – Replaces specific variables for all tenants using the profile.
- Billing Information – Sets pricing structures based on usage.

**Example without Instance Dimension**

```
profiles:
  - name: demo-gpu-vm
    overrides:
      ingress_firewall_rules: {"source_cidr": "0.0.0.0/0", "dest_port": 22, "protocol": "tcp", "rule_type": "accept"}
    quota:
      max-instances: 5
    billing:
      description:
        USD: "GPU: $0.625/h onwards.\nCPU: $0.125/h.\nRam: $0.25/10GB/h."
        GBP: "GPU: 0.375/h onwards.\nCPU: 0.075/h.\nRam: 0.15/10GB/h."
        EUR: "GPU: EUR 0.5/h onwards.\nCPU: EUR 0.1/h.\nRam: EUR 0.2/10GB/h."
      currency:
      - USD
      - GBP
      - EUR
      dimensions:
      - GPU Model
      - CPU
      - Ram
      - Public IP Address
      ratecard:
        CPU:
        - price: 0.1
          time_unit: h
          base_unit: 1
          currency: EUR
        - price: 0.075
          time_unit: h
          base_unit: 1
          currency: GBP
        - price: 0.125
          time_unit: h
          base_unit: 1
          currency: USD

        Ram:
        - price: 0.2
          time_unit: h
          base_unit: 10
          currency: EUR
        - price: 0.15
          time_unit: h
          base_unit: 10
          currency: GBP
        - price: 0.25
          time_unit: h
          base_unit: 10
          currency: USD

        Public IP Address:
        - price: 2.5
          time_unit: m
          value: "true"
          currency: EUR
        - price: 2
          time_unit: m
          value: "true"
          currency: GBP
        - price: 3
          time_unit: m
          value: "true"
          currency: USD

        GPU Model:
        - price: 1
          time_unit: h
          count_from: GPU
          value: A100
          currency: EUR
        - price: 0.75
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: A100
          currency: GBP
        - price: 1.25
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: A100
          currency: USD

        - price: 1.5
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: H100
          currency: EUR
        - price: 1.125
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: H100
          currency: GBP
        - price: 1.875
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: H100
          currency: USD

        - price: 0.75
          time_unit: h
          count_from: GPU
          value: L40s
          currency: EUR
        - price: 0.56
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: L40s
          currency: GBP
        - price: 0.94
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: L40s
          currency: USD

        - price: 0.5
          time_unit: h
          count_from: GPU
          value: L4
          currency: EUR
        - price: 0.375
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: L4
          currency: GBP
        - price: 0.675
          time_unit: h
          base_unit: 1
          count_from: GPU
          value: L4
          currency: USD
```

**Example with Instance Dimension**

```
- name: test-gpu-vm
  overrides:
    blueprint: "minimal"
  quota:
    max-instances: 2
  billing:
    currency:
    - USD
    - GBP
    - EUR
    dimensions:
    - instance
    - Public IP Address
    ratecard:
      instance:
      - price: 1
        time_unit: h
        currency: EUR
      - price: 0.75
        time_unit: h
        currency: GBP
      - price: 1.25
        time_unit: h
        currency: USD
      Public IP Address:
      - price: 2.5
        time_unit: m
        value: "true"
        currency: EUR
      - price: 2
        time_unit: m
        value: "true"
        currency: GBP
      - price: 3
        time_unit: m
        value: "true"
        currency: USD
```

***Profile-Specific Configuration Explained***

| **Configuration Aspect** | **YAML Field** | **Purpose in Global Settings** |
| --- | --- | --- |
| Profile Name | `name:` | Identifies the Compute/Service Profile name used for billing (`test-gpu-vm`). |
| Billing Configuration | `billing:` | Top-level billing configuration block. Contains all billing-related fields. |
| Billing Currencies | `billing.currency:` | Lists supported currency codes (`USD`, `EUR`, `GBP`) used in ratecard. |
| Billing Dimensions | `billing.dimensions:` | Input variables that are tracked and billed. Includes fixed (`instance`) and conditional (`Public IP Address`) dimensions. |
| Ratecard (Pricing Rules) | `billing.ratecard:` | Defines per-unit pricing for each dimension and currency. Keys must match `dimensions`. |
| Instance Pricing | `billing.ratecard.instance:` | Specifies a **fixed price** per deployment of this profile. No conditions or value matching required. |
| Public IP Pricing | `billing.ratecard.Public IP Address:` | Applies charges only when the input variable `Public IP Address` is `"true"`. |
| Price | `price:` | Unit price per time unit (e.g., `1`, `0.75`, `2.5`). |
| Time Unit | `time_unit:` | Billing interval (`h` for hour, `m` for month). |
| Base Unit | `base_unit:` | Optional. Used for float-based dimensions. Not used in this spec. |
| Currency Code | `currency:` | Currency for the pricing entry (`USD`, `EUR`, `GBP`). |
| Value | `value:` | Used only for `Public IP Address`, specifies condition (`"true"`) for applying price. |
| Count From | `count_from:` | Not used in this spec. Applicable when rate depends on another input variable’s value. |

---

## Tenant-Specific Overrides

A tenant may require different quotas, pricing structures, or variable overrides for a specific profile. Tenant-level configurations take highest priority and override global or profile-specific settings.

Example:

```
tenants:
  - name: test-tenant-1
    profiles:
      - name: demo-gpu-vm
        overrides:
          blueprint: "minimal"
        quota:
          max-instances: 2
        billing:
          currency:
            - USD
            - GBP
            - EUR
          dimensions:
            - GPU Model
            - CPU
            - Ram
            - Public IP Address
          ratecard:
            CPU:
              - price: 0.1
                time_unit: h
                base_unit: 1
                currency: EUR
              - price: 0.075
                time_unit: h
                base_unit: 1
                currency: GBP
              - price: 0.125
                time_unit: h
                base_unit: 1
                currency: USD
            Ram:
              - price: 0.2
                time_unit: h
                base_unit: 10
                currency: EUR
              - price: 0.15
                time_unit: h
                base_unit: 10
                currency: GBP
              - price: 0.25
                time_unit: h
                base_unit: 10
                currency: USD
            Public IP Address:
              - price: 2.5
                time_unit: m
                value: "true"
                currency: EUR
              - price: 2
                time_unit: m
                value: "true"
                currency: GBP
              - price: 3
                time_unit: m
                value: "true"
                currency: USD
            GPU Model:
              - price: 1
                time_unit: h
                count_from: GPU
                value: A100
                currency: EUR
              - price: 0.75
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: A100
                currency: GBP
              - price: 1.25
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: A100
                currency: USD
              - price: 1.5
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: H100
                currency: EUR
              - price: 1.125
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: H100
                currency: GBP
              - price: 1.875
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: H100
                currency: USD
              - price: 0.75
                time_unit: h
                count_from: GPU
                value: L40s
                currency: EUR
              - price: 0.56
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: L40s
                currency: GBP
              - price: 0.94
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: L40s
                currency: USD
              - price: 0.5
                time_unit: h
                count_from: GPU
                value: L4
                currency: EUR
              - price: 0.375
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: L4
                currency: GBP
              - price: 0.675
                time_unit: h
                base_unit: 1
                count_from: GPU
                value: L4
                currency: USD
```

***Tenant-Specific Configuration Explained***

| **Configuration Aspect** | **YAML Field** | **Purpose in Global Settings** |
| --- | --- | --- |
| Tenant Name | `name: test-tenant-1` | Identifies the tenant (organization) receiving custom configuration. |
| Profile Name | `name: demo-gpu-vm` | Specifies which profile this configuration applies to for the tenant. |
| Input Variable Overrides | `overrides:` | Overrides input variables such as `blueprint: minimal` only for this tenant and profile. |
| Quota Enforcement | `quota:` | Defines a **soft limit** of `max-instances: 2`, restricting this tenant to 2 deployments. |
| Billing Currencies | `currency:` | Lists supported currencies for billing (`USD`, `GBP`, `EUR`). |
| Billing Dimensions | `dimensions:` | Specifies the dimensions being billed (e.g., `CPU`, `Ram`, `GPU Model`, `Public IP Address`). |
| Ratecard (Pricing Rules) | `ratecard:` | Defines pricing per dimension, currency, and time unit, including optional fields like `value` and `count_from`. |

---

## Environment Variables in Global Settings

The **Environment Variables** tab in Global Settings enables administrators to centrally define and manage key-value pairs that are used across the platform. These variables are automatically added to the Global Settings configuration as environment variables, eliminating the need to modify YAML files manually. Sensitive values such as API keys or credentials can be securely managed using masking options to ensure confidentiality.

Once defined, these environment variables are automatically injected into triggered environments and can be seamlessly consumed by the respective environments during execution.

### Add Environment Variables

Click **+ Environment Variables** to configure the required fields.

| Field | Description | Example Value |
| --- | --- | --- |
| **Key** | Name of the environment variable. | `PARTNER_API_KEY` |
| **Value** | Value assigned to the variable. | `<REDACTED-KEY>` |
| **Description** | Optional field to specify the purpose or usage of the variable. | `API key used for partner integration.` |
| **Variable Options** | **Sensitive:** Masks the variable value to prevent it from being displayed in plain text. **Required:** Ensures the variable is mandatory for runtime configuration. | Enable/Disable |
| **Override** | Defines whether lower-level configurations can override this variable. Options: • **Allowed** – Enables project or environment-level overrides. • **Not Allowed** – Restricts overrides for this variable. • **Restricted** – Allows overrides with specific conditions. | Allowed/Not Allowed/Restricted |
| **Selectors** | Enables adding selectors to apply variables to specific environments or clusters. | region=us-west cluster=prod-cluster |
| **Immutable** | Prevents modification of the variable after creation. | Disabled (optional) |

[![Audit Logs Console](https://docs.rafay.co/aiml/gpupaas/img/envvars.png)](https://docs.rafay.co/aiml/gpupaas/img/envvars.png)

---

## 📘 Use Case: Simplifying Multi-Tenant Environment Management for a GPU Cloud Provider

A cloud service provider offers GPU-powered compute environments to multiple downstream organizations. To streamline operations, the provider uses **Global Settings** to centrally manage shared configurations such as agents, quotas, input variable overrides, and billing for all tenants and profiles.

This approach eliminates the need to configure agents, limits, or pricing details individually for each tenant or profile, ensuring consistent and efficient environment provisioning at scale.

### 🎯 Objective

- Automatically associate execution agents with all environments
- Enforce instance limits per tenant and profile
- Set shared input values like AWS region/account
- Customize pricing per tenant if needed

### 🧾 YAML Specification

```
# Global-level configuration (applies to all tenants and profiles)
agents:
  - shared-agent-1
  - shared-agent-2

overrides:
  aws_account_id: "987654321000"
  aws_region: "us-west-2"
  iam_role: "arn:aws:iam::987654321000:role/GlobalExecutionRole"

# Profile-specific configuration (applies to all tenants using this profile)
profiles:
  - name: gpu-standard
    overrides:
      accelerator: "nvidia-a100"
    quota:
      max-instances: 5
    billing:
      estimationUnit: hourly
      currency:
        - USD
      dimensions:
        - instance
        - gpu_hours
      ratecard:
        instance:
          - price: 10
            time_unit: h
            currency: USD
        gpu_hours:
          - price: 2.5
            time_unit: h
            currency: USD

# Tenant-specific overrides (applies only to given tenant/profile pair)
tenants:
  - name: org-gamma
    profiles:
      - name: gpu-standard
        quota:
          max-instances: 3
        overrides:
          accelerator: "nvidia-tesla-v100"
        billing:
          estimationUnit: hourly
          currency:
            - USD
          dimensions:
            - instance
            - gpu_hours
          ratecard:
            instance:
              - price: 8
                time_unit: h
                currency: USD
            gpu_hours:
              - price: 2.0
                time_unit: h
                currency: USD

  - name: org-delta
    profiles:
      - name: gpu-standard
        quota:
          max-instances: 1
```

**🌐 Global Configuration**

These settings apply across all tenants and profiles unless explicitly overridden.

| **Field** | **Key** | **Value(s)** |
| --- | --- | --- |
| Agents | `agents` | `shared-agent-1`, `shared-agent-2` — Agents automatically assigned to all environments |
| Input Overrides | `overrides.aws_account_id` | `987654321000` — Shared AWS account ID used across tenants |
|  | `overrides.aws_region` | `us-west-2` — AWS region for deployments |
|  | `overrides.iam_role` | `arn:aws:iam::987654321000:role/GlobalExecutionRole` — Role used for execution |

**📦 Profile-Specific Configuration**

These settings apply to all tenants using the `gpu-standard` profile, unless overridden at the tenant level.

| **Field** | **Key** | **Value(s)** |
| --- | --- | --- |
| Profile Name | `profiles.name` | `gpu-standard` |
| Input Overrides | `profiles.overrides.accelerator` | `nvidia-a100` — Default accelerator for this profile |
| Quota | `profiles.quota.max-instances` | `5` — Max number of instances per tenant using this profile |
| Billing Estimation | `estimationUnit: hourly` | `hourly` or `monthly` — Defines the billing estimation unit |
| Billing Currency | `profiles.billing.currency` | `USD` — Supported billing currency |
| Billing Dimensions | `profiles.billing.dimensions` | `instance`, `gpu_hours` — Metrics used for billing |
| Ratecard - Instance | `profiles.billing.ratecard.instance` | `10 USD/hour` — Cost per instance |
| Ratecard - GPU Hours | `profiles.billing.ratecard.gpu_hours` | `2.5 USD/hour` — Cost per GPU hour |

**🏢 Tenant-Specific Configuration**

These settings apply only to specific tenants and override global and profile-level configurations.

***Tenant: `org-gamma`***

| **Field** | **Key** | **Value(s)** |
| --- | --- | --- |
| Tenant Name | `tenants.name` | `org-gamma` |
| Profile Name | `tenants.profiles.name` | `gpu-standard` |
| Input Overrides | `tenants.profiles.overrides.accelerator` | `nvidia-tesla-v100` — Overrides default accelerator |
| Quota | `tenants.profiles.quota.max-instances` | `3` — Limits this tenant to 3 instances for this profile |
| Billing Estimation | `estimationUnit: hourly` | `hourly` or `monthly` — Defines the billing estimation unit |
| Billing Currency | `tenants.profiles.billing.currency` | `USD` |
| Billing Dimensions | `tenants.profiles.billing.dimensions` | `instance`, `gpu_hours` |
| Ratecard - Instance | `tenants.profiles.billing.ratecard.instance` | `8 USD/hour` — Tenant-specific pricing |
| Ratecard - GPU Hours | `tenants.profiles.billing.ratecard.gpu_hours` | `2.0 USD/hour` — Customized GPU usage pricing |

***Tenant: `org-delta`***

| **Field** | **Key** | **Value(s)** |
| --- | --- | --- |
| Tenant Name | `tenants.name` | `org-delta` |
| Profile Name | `tenants.profiles.name` | `gpu-standard` |
| Quota | `tenants.profiles.quota.max-instances` | `1` — Limits this tenant to only 1 instance |

> 💡 Note: org-delta does not override input variables or billing details — it inherits them from the profile-level configuration.

---
