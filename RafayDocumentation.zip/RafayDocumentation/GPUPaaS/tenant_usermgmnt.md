---
title: "GPU PaaS Tenant Administration – User Access and Security Management"
source: https://docs.rafay.co/aiml/gpupaas/tenant_usermgmnt/
---

# User Management

## User Management

The **User Management** section enables tenant administrators to manage user access for **GPU PaaS services** within the organization. Users managed in this section are specific to GPU PaaS usage and do not apply to other infrastructure or platform-level functionalities.

Tenant Admins can add new users and assign roles such as **Tenant Admin** or **lower PaaS roles** (for example, PaaS Project Admin, Developer, and similar roles) based on access requirements.

Access User Management from: **Tenant Administration → User Management**

### Users

The **Users** page lists all GPU PaaS users configured for the tenant organization and supports searching and filtering by name, role, group, and status. Users are categorized as **Local Users** and **IDP Users**.

From this page, tenant admins can create new users, configure profile details and access types, assign users to groups and roles, update user information, enable or disable access, and remove users as needed.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/user_mgmnt.png)](https://docs.rafay.co/aiml/gpupaas/img/user_mgmnt.png)

#### Local Users

Local Users are created and managed directly within the platform. Tenant admins can create local users, assign **Tenant Admin** or lower PaaS roles, manage group membership, and control console or programmatic access.

#### IDP Users

IDP Users are authenticated through configured external identity providers. These users appear automatically after successful authentication via the identity provider. Tenant admins can assign groups and roles (Tenant Admin or lower PaaS roles) to control GPU PaaS access, while user profile details are managed by the external identity provider.

#### Creating a User

To create a new **local user**, select **New User**. While creating a user, tenant admins configure:

- **Profile**
  - Email address
  - First name and last name
  - Optional contact information
  - Console access and/or programmatic access
- **Group Assignment**
  - Assign the user to one or more groups
  - Group membership determines the assigned Tenant Admin or lower PaaS roles and associated permissions

Save the user to complete the creation process.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/user_new.png)](https://docs.rafay.co/aiml/gpupaas/img/user_new.png)

#### Managing Users

For existing users (local and IDP), tenant admins can: - Edit user profile details (local users only) - Update group and role assignments - Enable or disable user access - Remove users from the organization

User management actions are available through the **Actions** menu for each user entry.

---

### Groups

The **Groups** section allows tenant administrators to manage user groups for **GPU PaaS access control**. Groups are used to assign roles and permissions collectively, simplifying user access management across projects.

Access Groups from: **Tenant Administration → User Management → Groups**

#### Group Listing

The Groups page lists all configured groups along with: - **Group Name** - **Associated Projects** - **Creation Timestamp**

Default groups (such as **Organization Tenant Admin** and **All Local Users**) are available by default, and additional custom groups can be created as needed.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/groups_list.png)](https://docs.rafay.co/aiml/gpupaas/img/groups_list.png)

#### Creating a Group

To create a new group, select **New Group**, provide a **group name** and an optional description, and save the group.

#### Managing Group Members

Tenant admins can add or remove users from a group using the **Add/Remove Members** option.

- Users can be selected from **Local Users** or **IDP Users**
- Multiple users can be added or removed in a single action
- Group membership determines the roles and permissions applied to the users

Save the changes to update group membership.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/groups_new.png)](https://docs.rafay.co/aiml/gpupaas/img/groups_new.png)

Groups provide a centralized way to manage role assignments and permissions for GPU PaaS users.

---

## Identity Providers

The **Identity Providers** section enables tenant administrators to configure federated authentication for GPU PaaS using external identity providers. This allows users to sign in with enterprise identity systems while mapping users and groups to roles defined in Rafay.

- Access Identity Providers from: **Tenant Administration → User Management → Identity Providers**
- Supported identity provider types include **Okta**, **Ping**, and **Custom SAML-based providers**.
- Configuring an identity provider requires setup in **both the controller and the identity provider application**.

In the controller, tenant administrators configure:

- **IdP Configuration**
  - Identity provider name and type
  - Admin email and email domain mapping
  - Organization and group attribute statement names
  - Authentication context and username behavior
- **SP Configuration**
  - Service Provider (SP) configuration details are **retrieved from the identity provider application console** and displayed in Rafay for reference
  - Assertion Consumer Service (ACS) URL
  - Service Provider (SP) Entity ID
  - NameID format and consumer binding
- **Metadata Configuration**
  - Import IdP metadata using a metadata URL or metadata file
- **Webhook Configuration (Optional)**
  - Configure webhook endpoints triggered during user login
  - Define payload attributes and optional custom parameters

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/idp_new.png)](https://docs.rafay.co/aiml/gpupaas/img/idp_new.png)

The corresponding SAML application must be configured in the identity provider’s console. Once configured, IdP users can be assigned to groups, and access to GPU PaaS is governed through group-based role assignments.

---

### Break Glass Access

The **Break Glass Access** section enables tenant administrators to grant temporary, time-bound elevated access to users for **GPU PaaS emergency or exceptional scenarios**. This controlled access allows users to perform critical tasks without permanently altering their standard roles or permissions.

Access Break Glass Access from: **Tenant Administration → User Management → Break Glass Access**

This feature allows tenant admins to: - Select a user (Local or IDP) who requires emergency GPU PaaS access - Assign a predefined group that carries required permissions - Specify an expiration time for the temporary access

Break Glass Access ensures that emergency privileges are granted only for a limited duration and all such actions are auditable.

Only users with **Tenant Admin** role can grant Break Glass Access for GPU PaaS users. Break Glass Access configuration and usage are logged for compliance and audit purposes.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/breakglass.png)](https://docs.rafay.co/aiml/gpupaas/img/breakglass.png)

---

### Login Settings

The **Login Settings** section allows tenant administrators to configure authentication and session-related security controls for **GPU PaaS users**.

Access Login Settings from: **Tenant Administration → User Management → Login Settings**

The following options are available:

- **Multi-Factor Authentication (MFA)**
- **Lockout Settings**
- **Auto Logout Settings**

#### Multi-Factor Authentication (MFA)

The **Multi-Factor Authentication (MFA)** option adds an additional layer of security to GPU PaaS user logins.

When MFA is enabled, all GPU PaaS users are required to authenticate using a supported **TOTP-based authenticator** during login. Users are prompted to enroll in MFA at their next login by setting up an authenticator app and verifying a one-time code.

After enrollment, MFA verification is required for every subsequent login. MFA enforcement applies only to GPU PaaS users managed through Tenant Administration and does not affect other platform or infrastructure authentication settings.

#### Lockout Settings

The **Lockout Settings** option under **Login Settings** allows tenant administrators to automatically lock GPU PaaS user accounts after a defined number of consecutive failed login attempts within a specified time window.

When enabled, users are temporarily locked out once the configured invalid attempt limit is reached. The lockout duration and the maximum number of failed attempts can be customized. By default, users are locked out after **5 consecutive invalid login attempts within 15 minutes**.

Lockout enforcement applies only to GPU PaaS users managed through Tenant Administration and helps protect against brute-force login attempts.

#### Auto Logout Settings

The **Auto Logout Settings** option under **Login Settings** allows tenant administrators to automatically sign out GPU PaaS users after a defined period of inactivity.

When enabled, users are logged out of the GPU PaaS console if no activity is detected for the configured duration. The inactivity timeout can be customized, with a default value of **60 minutes**.

Auto logout enforcement applies only to GPU PaaS users managed through Tenant Administration and helps reduce the risk of unauthorized access from unattended sessions.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/login_set.png)](https://docs.rafay.co/aiml/gpupaas/img/login_set.png)

---
