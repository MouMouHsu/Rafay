---
title: "GPU PaaS - Overview"
source: https://docs.rafay.co/aiml/gpupaas/overview/
---

# Overview

The goal of Rafay's GPU PaaS  (Platform as a Service) is to help take a **rack of servers and GPUs** and **convert** them into an "End user facing, self-service GPU Cloud" in hours.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/concepts/overview.png)](https://docs.rafay.co/aiml/gpupaas/img/concepts/overview.png)

---

## Who is it For?

Rafay GPU PaaS  is designed for both "GPU Cloud Providers" as well as "Enterprises".

---

## What Challenges does it Address?

[![High Level Architecture](https://docs.rafay.co/aiml/gpupaas/img/concepts/marketecture.png)](https://docs.rafay.co/aiml/gpupaas/img/concepts/marketecture.png)

### Cloud Providers

The primary question every GPU Cloud faces is

> How do I go from a rack of GPUs to a revenue generating self service GPU Cloud in days?.

GPU PaaS helps address the following challenges that Cloud Providers encounter.

| **Challenge** | **Description** |
| --- | --- |
| Delayed ROI on Hardware Investments | Time to market issues. Struggling to monetize expensive GPU and hardware infrastructure quickly enough to justify CapEx. |
| Lack of Differentiation in a Crowded Market | Lack of a compelling portfolio of managed AI services and integrated apps. |
| Limited Software-Led Revenue Opportunities | Missing revenue streams from ISV and third-party application ecosystems that could supplement infrastructure income. Lack of a self service experience for users. |
| Margin Pressure Due to High Opex and R&D Spend | High operational complexity (were doing everything manually) and custom engineering efforts (bespoke automation) erode profitability and delay service rollout timelines. |
| Low Platform Stickiness & User Retention | Inability to drive sustained adoption due to limited native AI/ML and GenAI toolsets bundled with compute services. |

---

### Enterprises

Due to extreme scarcity of GPUs, every organization is now being forced to

- Make long term commitments to cloud providers, and/or
- Purchase expensive GPUs (e.g. Nvidia H100) ahead of demand, and/or
- Source GPUs from multiple cloud providers

Once they get access to the GPUs, IT/Operations struggle to answer the question:

> How do we allocate the GPUs to multiple users in a timely and efficient manner?

---
