# Rafay GPU PaaS 文件索引

來源：https://docs.rafay.co/aiml/gpupaas/ ，擷取日期 2026-10-22

- [GPU PaaS - Overview](overview.md)  
  `overview.md`
- [GPU PaaS - Architecture](capabilities.md)  
  `capabilities.md`
- [Deployment Form Factors](formfactor.md)  
  `formfactor.md`
- [Rafay-Netris Integration Overview](integrations/netris/overview.md)  
  `integrations/netris/overview.md`
- [Turnkey Integrations](integrations.md)  
  `integrations.md`
- [Rafay-Netris Integration - Architecture](integrations/netris/architecture.md)  
  `integrations/netris/architecture.md`
- [Rafay-Netris Integration - Prerequisites](integrations/netris/prerequisites.md)  
  `integrations/netris/prerequisites.md`
- [Tenant Onboarding](integrations/netris/tenant_onboarding.md)  
  `integrations/netris/tenant_onboarding.md`
- [Rafay-Netris Integration - Operator Runbook](integrations/netris/operator_runbook.md)  
  `integrations/netris/operator_runbook.md`
- [Overview](integrations/hyper-fabric/overview.md)  
  `integrations/hyper-fabric/overview.md`
- [Rafay-Cisco HyperFabric Integration - Architecture](integrations/hyper-fabric/architecture.md)  
  `integrations/hyper-fabric/architecture.md`
- [Rafay-Cisco HyperFabric Integration - Prerequisites](integrations/hyper-fabric/prerequisites.md)  
  `integrations/hyper-fabric/prerequisites.md`
- [Onboard the HyperFabric Controller](integrations/hyper-fabric/integration.md)  
  `integrations/hyper-fabric/integration.md`
- [Inventory Synchronization](integrations/hyper-fabric/inventory_sync.md)  
  `integrations/hyper-fabric/inventory_sync.md`
- [Node Memberships](integrations/hyper-fabric/node_membership.md)  
  `integrations/hyper-fabric/node_membership.md`
- [Rafay-Fortanix Integration - Overview](integrations/fortanix/overview.md)  
  `integrations/fortanix/overview.md`
- [Tenant Onboarding](integrations/hyper-fabric/onboarding.md)  
  `integrations/hyper-fabric/onboarding.md`
- [Rafay-Fortanix Integration - Architecture](integrations/fortanix/architecture.md)  
  `integrations/fortanix/architecture.md`
- [GPU PaaS for GPU Clouds](csp/overview.md)  
  `csp/overview.md`
- [Rafay-Fortanix Integration - Deploy Confidential AI](integrations/fortanix/deployment.md)  
  `integrations/fortanix/deployment.md`
- [Rafay-Fortanix Integration - Prerequisites](integrations/fortanix/prereq.md)  
  `integrations/fortanix/prereq.md`
- [Partner Console - Theme Customization Guide](csp/customize.md)  
  `csp/customize.md`
- [Localization](csp/localization.md)  
  `csp/localization.md`
- [Notifications](csp/notification.md)  
  `csp/notification.md`
- [SMTP Configuration](csp/smtp_config.md)  
  `csp/smtp_config.md`
- [SMTP Configuration — Administrator Guide](csp/smtp_config_admin.md)  
  `csp/smtp_config_admin.md`
- [Multiple Customers](csp/customers.md)  
  `csp/customers.md`
- [Tenant Onboarding Automation for NCP Environments](csp/csp_tenant_onboarding.md)  
  `csp/csp_tenant_onboarding.md`
- [Tenant Lifecycle](csp/ops_tenantonboarding.md)  
  `csp/ops_tenantonboarding.md`
- [Roles in the Platform](csp/gpu_paas_tenant_roles.md)  
  `csp/gpu_paas_tenant_roles.md`
- [Rate Cards](csp/rate_cards.md)  
  `csp/rate_cards.md`
- [Global Settings](csp/global_settings.md)  
  `csp/global_settings.md`
- [Overrides](csp/overrides.md)  
  `csp/overrides.md`
- [GPU Reservations](csp/gpu_reservations.md)  
  `csp/gpu_reservations.md`
- [Billing Configuration](csp/skus_billing.md)  
  `csp/skus_billing.md`
- [Quotas](csp/quota.md)  
  `csp/quota.md`
- [Blueprint Governance Across Organizations](csp/paas_bp.md)  
  `csp/paas_bp.md`
- [Agents for GPU PaaS](csp/csp_agents.md)  
  `csp/csp_agents.md`
- [GPU PaaS - Inventory Overview](csp/inventory/inventory.md)  
  `csp/inventory/inventory.md`
- [GPU PaaS - Servers](csp/inventory/servers.md)  
  `csp/inventory/servers.md`
- [Rows and Racks](csp/inventory/rows_racks.md)  
  `csp/inventory/rows_racks.md`
- [Node Onboarding](csp/ops_nodeonboarding.md)  
  `csp/ops_nodeonboarding.md`
- [Orchestration Agents](csp/orchestration_agents.md)  
  `csp/orchestration_agents.md`
- [GPU PaaS - Virtual Machines](csp/inventory/vm_inv.md)  
  `csp/inventory/vm_inv.md`
- [GPU PaaS - Storages](csp/inventory/storages.md)  
  `csp/inventory/storages.md`
- [GPU PaaS - Network Switches](csp/inventory/switches.md)  
  `csp/inventory/switches.md`
- [GPU Virtual Machines - View and Manage VM Resources](csp/inventory/infini.md)  
  `csp/inventory/infini.md`
- [Billing with GPU PaaS for GPU Clouds](csp/billing/overview.md)  
  `csp/billing/overview.md`
- [APIs for Billing](csp/billing/apis.md)  
  `csp/billing/apis.md`
- [GPU PaaS - Dashboard](csp/paas_dashboard.md)  
  `csp/paas_dashboard.md`
- [Usage Metrics](administration/usage_metrics.md)  
  `administration/usage_metrics.md`
- [Instance Provisioning Control](csp/kyc.md)  
  `csp/kyc.md`
- [Integrations - Global IdP](csp/global_idp.md)  
  `csp/global_idp.md`
- [GPU Usage Tracking for GPU Clouds](csp/usage/overview.md)  
  `csp/usage/overview.md`
- [User LCM Audits](csp/audit_logs.md)  
  `csp/audit_logs.md`
- [Administration for Enterprise Users](administration/overview.md)  
  `administration/overview.md`
- [Profile Quotas](administration/profile_quota.md)  
  `administration/profile_quota.md`
- [Tenant Dashboard](tenant_dashboard.md)  
  `tenant_dashboard.md`
- [Token Usage Dashboard](token_budget_dashboard.md)  
  `token_budget_dashboard.md`
- [Architectural Approaches](administration/architectures.md)  
  `administration/architectures.md`
- [SKU Catalogs](administration/sku_catalog.md)  
  `administration/sku_catalog.md`
- [Load Profiles and Templates](administration/load_profiles.md)  
  `administration/load_profiles.md`
- [Compute SKUs](administration/compute_profile.md)  
  `administration/compute_profile.md`
- [Compute Profile for Baremetal](administration/bm_type.md)  
  `administration/bm_type.md`
- [Compute Profile for Virtual Machines](administration/vm_type.md)  
  `administration/vm_type.md`
- [Compute Profile for Kubernetes (K8s)](administration/k8s_type.md)  
  `administration/k8s_type.md`
- [Compute Profile for vCluster](administration/vcluster_type.md)  
  `administration/vcluster_type.md`
- [Compute Profile for Slurm](administration/slurm.md)  
  `administration/slurm.md`
- [Inventory-Based Scheduling](administration/capacity_check.md)  
  `administration/capacity_check.md`
- [Service SKUs](administration/service_profile.md)  
  `administration/service_profile.md`
- [Default Service SKUs](administration/service_types.md)  
  `administration/service_types.md`
- [Managed Compute Instances](administration/compute_instance.md)  
  `administration/compute_instance.md`
- [Service Instances](administration/service_instance.md)  
  `administration/service_instance.md`
- [Force Delete](administration/force_delete.md)  
  `administration/force_delete.md`
- [PaaS Instance Email Notifications](administration/instance_alerts.md)  
  `administration/instance_alerts.md`
- [Multi Tenancy for GPU PaaS](administration/mt/overview.md)  
  `administration/mt/overview.md`
- [Virtual Clusters](administration/mt/vcluster.md)  
  `administration/mt/vcluster.md`
- [Isolated Containers](administration/mt/isolated.md)  
  `administration/mt/isolated.md`
- [Enforcement of Network Policy](administration/mt/network_policy.md)  
  `administration/mt/network_policy.md`
- [Enforcement of Cluster Policy](administration/mt/cluster_policy.md)  
  `administration/mt/cluster_policy.md`
- [Enforcement of Role based Access](administration/mt/rbac.md)  
  `administration/mt/rbac.md`
- [Secure Remote Access](administration/mt/remote_access.md)  
  `administration/mt/remote_access.md`
- [Resource Quota Enforcement](administration/mt/quotas.md)  
  `administration/mt/quotas.md`
- [Centralized Audit Logging](administration/mt/audit_logs.md)  
  `administration/mt/audit_logs.md`
- [Cost Visibility](administration/mt/cost_visibility.md)  
  `administration/mt/cost_visibility.md`
- [Network Segmentation](administration/mt/segmentation.md)  
  `administration/mt/segmentation.md`
- [Centralized Audit Logs](administration/audit.md)  
  `administration/audit.md`
- [Policy & Governance for End Users](administration/policy.md)  
  `administration/policy.md`
- [Integration with Identity Provider (IdP) for Single Sign-On](csp/idp/overview.md)  
  `csp/idp/overview.md`
- [Configuring SAML Integration with Auth0](csp/idp/auth_saml.md)  
  `csp/idp/auth_saml.md`
- [Configuring OpenID Connect (OIDC) Integration with Auth0](csp/idp/auth_oidc.md)  
  `csp/idp/auth_oidc.md`
- [Configuring SAML Integration with Okta](csp/idp/okta.md)  
  `csp/idp/okta.md`
- [Configuring OpenID Connect (OIDC) Integration with Okta](csp/idp/oidc_okta.md)  
  `csp/idp/oidc_okta.md`
- [Configuring SAML Integration with Keycloak](csp/idp/keycloak.md)  
  `csp/idp/keycloak.md`
- [Configuring OpenID Connect (OIDC) Integration with Keycloak](csp/idp/oidc_keycloak.md)  
  `csp/idp/oidc_keycloak.md`
- [Configuring SAML Integration with PingOne](csp/idp/ping.md)  
  `csp/idp/ping.md`
- [Tenant Administration and Dashboards](tenant_admin_role.md)  
  `tenant_admin_role.md`
- [Configuring OpenID Connect (OIDC) Integration with PingOne](csp/idp/oidc_ping.md)  
  `csp/idp/oidc_ping.md`
- [PaaS Scheduling Configuration](administration/schedules/overview.md)  
  `administration/schedules/overview.md`
- [Schedule Specification Examples](administration/schedules/specs.md)  
  `administration/schedules/specs.md`
- [GPU PaaS Tenant Administration – User Access and Security Management](tenant_usermgmnt.md)  
  `tenant_usermgmnt.md`
- [Events and Reports for GPU PaaS](events%26reports.md)  
  `events&reports.md`
- [Projects and Settings for GPU PaaS](tenant_project.md)  
  `tenant_project.md`
- [Default Compute and Service Profiles](administration/tenant_sku_catalog.md)  
  `administration/tenant_sku_catalog.md`
- [Token Budgets](administration/token_budget.md)  
  `administration/token_budget.md`
- [End User Self Service Portal](users/overview.md)  
  `users/overview.md`
- [Role based Access Control](users/access_control.md)  
  `users/access_control.md`
- [Landing Page](users/landing.md)  
  `users/landing.md`
- [End User Dashboard](users/user_dashboard.md)  
  `users/user_dashboard.md`
- [Workspaces](users/workspace.md)  
  `users/workspace.md`
- [Compute Instances](users/compute_overview.md)  
  `users/compute_overview.md`
- [Compute Instances - Bare Metal](users/baremetal.md)  
  `users/baremetal.md`
- [Compute Instances - Virtual Machines](users/vm.md)  
  `users/vm.md`
- [Managed Kubernetes Clusters](users/k8s_type.md)  
  `users/k8s_type.md`
- [Compute Instances - vCluster](users/vcluster.md)  
  `users/vcluster.md`
- [Slurm - Virtual Machines](users/slurm_type.md)  
  `users/slurm_type.md`
- [Services](users/services_overview.md)  
  `users/services_overview.md`
- [Inference Endpoints](users/inference.md)  
  `users/inference.md`
- [Custom AI/ML Jobs](users/jobs.md)  
  `users/jobs.md`
- [Custom Services](users/custom_services.md)  
  `users/custom_services.md`
- [Overview](getstarted/overview.md)  
  `getstarted/overview.md`
- [Overview](getstarted/enterprise/intro/overview.md)  
  `getstarted/enterprise/intro/overview.md`
- [Provision Infrastructure](getstarted/enterprise/intro/infra/infra.md)  
  `getstarted/enterprise/intro/infra/infra.md`
- [Prerequisites](getstarted/enterprise/intro/infra/prereqs.md)  
  `getstarted/enterprise/intro/infra/prereqs.md`
- [Rafay MKS on Linux Server](getstarted/enterprise/intro/infra/server.md)  
  `getstarted/enterprise/intro/infra/server.md`
- [Rafay MKS on Windows Laptop](getstarted/enterprise/intro/infra/laptop_win.md)  
  `getstarted/enterprise/intro/infra/laptop_win.md`
- [Cluster Add-Ons via Blueprint](getstarted/enterprise/intro/infra/addons.md)  
  `getstarted/enterprise/intro/infra/addons.md`
- [Configure Templates](getstarted/enterprise/intro/catalog/templates.md)  
  `getstarted/enterprise/intro/catalog/templates.md`
- [Compute Profile Creation and Management](getstarted/enterprise/intro/sku/compute_sku.md)  
  `getstarted/enterprise/intro/sku/compute_sku.md`
- [Jupyter Notebook Service Profile Creation and Management](getstarted/enterprise/intro/sku/notebook_sku.md)  
  `getstarted/enterprise/intro/sku/notebook_sku.md`
- [Invite Users to Developer Hub](getstarted/enterprise/intro/enduser/invite_user.md)  
  `getstarted/enterprise/intro/enduser/invite_user.md`
- [Access Developer Hub as End User](getstarted/enterprise/intro/enduser/devhub.md)  
  `getstarted/enterprise/intro/enduser/devhub.md`
- [Create Workspace](getstarted/enterprise/intro/enduser/workspace.md)  
  `getstarted/enterprise/intro/enduser/workspace.md`
- [Launch Compute Instance](getstarted/enterprise/intro/enduser/compute_instance.md)  
  `getstarted/enterprise/intro/enduser/compute_instance.md`
- [Launch Jupyter Notebook](getstarted/enterprise/intro/enduser/jupyter_notebook.md)  
  `getstarted/enterprise/intro/enduser/jupyter_notebook.md`
- [Collaboration](getstarted/enterprise/intro/enduser/collaboration.md)  
  `getstarted/enterprise/intro/enduser/collaboration.md`
- [Overview](getstarted/cloud_provider/overview.md)  
  `getstarted/cloud_provider/overview.md`
- [Sample Icons](logos.md)  
  `logos.md`
- [KOP EKS Clusters - Troubleshooting](troubleshooting.md)  
  `troubleshooting.md`
- [Manage Jupyter Notebooks](users/notebook.md)  
  `users/notebook.md`
