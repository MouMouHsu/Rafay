---
title: "KOP EKS Clusters - Troubleshooting"
source: https://docs.rafay.co/aiml/gpupaas/troubleshooting/
---

# Troubleshooting

## Scenario 1: Unable to Redeploy Service After Config Changes

Users may notice they cannot update a service to capture new configuration changes if the service status is **Success**. For example, if configuration values are updated in PaaS Studio and a redeployment is attempted, the process fails with a message indicating that services with a Success status cannot be updated.

```
cannot update service with status Success
```

[![Inference in Browser](https://docs.rafay.co/aiml/gpupaas/img/scenario_1.png)](https://docs.rafay.co/aiml/gpupaas/img/scenario_1.png)

**Validation**

To resolve this issue and enable `Day-2 operations`:

- Add the following label to the [service profile](https://docs.rafay.co/aiml/gpupaas/administration/service_profile/#labels):

```
ALLOW_DAY2_OPERATIONS: true
```

[![Inference in Browser](https://docs.rafay.co/aiml/gpupaas/img/resolution_1.png)](https://docs.rafay.co/aiml/gpupaas/img/resolution_1.png)

- Redeploy the service again to capture the updated configuration.

---
