---
title: "Sample Icons"
source: https://docs.rafay.co/aiml/gpupaas/logos/
---

# Icons

## Compute Profiles

Example icons for common sizes/flavors of compute

### Small

Small Compute Profile

[![Small](https://docs.rafay.co/aiml/gpupaas/img/logos/small-green.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/small-green.png)

---

### Medium

Medium Compute Profile

[![Medium](https://docs.rafay.co/aiml/gpupaas/img/logos/medium-green.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/medium-green.png)

---

### Large

Large Compute Profile

[![Large](https://docs.rafay.co/aiml/gpupaas/img/logos/large-green.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/large-green.png)

---

## Services

Example icons for common AI/ML Services

### Jupyter Notebook

Jupyter Notebook with turnkey profiles

[![Jupyter Notebook](https://docs.rafay.co/aiml/gpupaas/img/logos/jupyter.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/jupyter.png)

---

### Ray

Rafay's Ray as a Service

[![Ray](https://docs.rafay.co/aiml/gpupaas/img/logos/ray-small.jpg)](https://docs.rafay.co/aiml/gpupaas/img/logos/ray-small.jpg)

---

### Kubeflow

Rafay's Kubeflow based MLOps

[![Kubeflow](https://docs.rafay.co/aiml/gpupaas/img/logos/kubeflow.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/kubeflow.png)

---

### DeepSeek

[DeepSeek](https://www.deepseek.com/) LLM

[![DeepSeek](https://docs.rafay.co/aiml/gpupaas/img/logos/deepseek.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/deepseek.png)

---

### Amazon SageMaker

[SageMaker](https://aws.amazon.com/sagemaker/)

[![SageMaker](https://docs.rafay.co/aiml/gpupaas/img/logos/sagemaker.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/sagemaker.png)

---

### Slurm

[Slurm](https://slurm.schedmd.com/documentation.html)

[![Slurm](https://docs.rafay.co/aiml/gpupaas/img/logos/slurm.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/slurm.png)

---

### Nvidia Run:ai

[Run:ai](https://www.nvidia.com/en-us/software/run-ai/)

[![Run:ai](https://docs.rafay.co/aiml/gpupaas/img/logos/nvidia_runai.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/nvidia_runai.png)

---

### White Labeling

Logos for ACME Corporation, a hypothetical service provider used in Get Started Guides etc.

#### Dark Mode Logo

This will be used when the user is using Dark Mode

[![Dark Mode ACME Logo](https://docs.rafay.co/aiml/gpupaas/img/logos/acme_dark_bg.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/acme_dark_bg.png)

#### Light Mode Logo

This will be used when the user is using Light Mode

[![Light Mode ACME Logo](https://docs.rafay.co/aiml/gpupaas/img/logos/acme_white_bg.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/acme_white_bg.png)

#### ACME Background

This will be used for the background image

[![ACME Background](https://docs.rafay.co/aiml/gpupaas/img/logos/acme_background.png)](https://docs.rafay.co/aiml/gpupaas/img/logos/acme_background.png)
