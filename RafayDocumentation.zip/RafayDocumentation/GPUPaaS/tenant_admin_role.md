---
title: "Tenant Administration and Dashboards"
source: https://docs.rafay.co/aiml/gpupaas/tenant_admin_role/
---

# Tenant Admin Role

## Tenant Admin Role

The **Tenant Admin** role supports tenant-level administration without exposing underlying infrastructure controls. This role is designed for tenant users who consume shared infrastructure provided by partners and do not require direct access to infrastructure resources.

The Tenant Admin role provides centralized access to user management, governance, security, and tenant-specific configurations through the **Tenant Administration** portal.

---

## Tenant Admin Privileges and Access Scope

Tenant Admins can access and manage the following areas:

- User and access management for tenant users
- Audit, alerting, and reporting at the tenant level
- Zero Trust and access control policies
- Attribute-based access control (ABAC) configurations
- Organization-level tenant settings

Tenant Admins have access to the following platform areas:

- **Developer Hub**: Create, access, and manage tenant-facing resources and services. Access and manage compute and service resources such as bare metal, virtual machines, Kubernetes, notebooks, inference endpoints, AI/ML jobs, and custom services within tenant projects.
- **SKU Management**: View and manage shared system and custom profiles, including compute profiles, service profiles, and the associated compute and service instances made available to the tenant.
- **Dashboards**: Monitor tenant-level SKU usage metrics and insights, including consumption, limits, and high-level usage data across projects.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/tenants_admin.png)](https://docs.rafay.co/aiml/gpupaas/img/tenants_admin.png)

---
