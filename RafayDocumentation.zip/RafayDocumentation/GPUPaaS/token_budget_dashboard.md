---
title: "Token Usage Dashboard"
source: https://docs.rafay.co/aiml/gpupaas/token_budget_dashboard/
---

# Token Usage

## Token Usage Dashboard

The **Token Usage Dashboard** allows tenant administrators and organization administrators to monitor and analyze **token consumption, spend, and cost distribution** across GPU PaaS projects. The dashboard also includes a budget tracking view for monthly and daily spend limits.

Access the Token Usage Dashboard from: **App Launcher → Dashboards → Token Usage**

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/token_usage_overview.png)](https://docs.rafay.co/aiml/gpupaas/img/token_usage_overview.png)

### Project Scope

The Overview, Usage Metrics, and Model Analytics tabs scope their data using a project selector.

- **All Projects** shows an aggregated view of token consumption and spend across every project in the organization.
- Selecting a specific project scopes the summary cards, panels, and charts on that tab to the selected project only.

The **My Budget** tab shows budget details specific to the tenant organization, for Tenant Admin and Org Admin users, independent of any single project or time range.

### Filters

A time range picker (1d, 7d, 30d, or a custom range) is available on the Overview, Usage Metrics, and Model Analytics tabs.

The **Additional Filters** panel, opened from the filter icon, provides further scoping on these same three tabs:

- **Model Deployment** filters by a specific model deployment.
- **Endpoint** filters by a specific endpoint.
- **User** filters by one or more users.

Selected filters apply after choosing **Apply Filters**. **Reset All** clears every additional filter back to its default.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/dash_filters.png)](https://docs.rafay.co/aiml/gpupaas/img/dash_filters.png)

---

## Overview

The **Overview** tab provides a high level summary of token consumption and spend for the selected project and time range.

From this tab, tenant admins and org admins can view:

- **Total Spend** shows total spend for the selected time range, along with the average daily spend.
- **Tokens** shows total tokens consumed across all models, along with the average daily token volume.
- **Models** shows the number of active models in the selected time range, along with the top spending model.
- **Efficiency** shows the token efficiency multiplier and the number of tokens delivered per dollar spent.

The **Usage Distribution** panel shows the breakdown of token consumption by input, output, cache, and image generation. The **Cost Breakdown** panel shows spend across the same categories.

The **Top Projects** panel shows total spend distributed across projects. The **Model Distribution** panel shows total spend distributed across active models.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/overview.png)](https://docs.rafay.co/aiml/gpupaas/img/overview.png)

---

## Usage Metrics

The **Usage Metrics** tab provides volume trends for tokens and image generation.

- **Total Tokens** shows total tokens consumed in the selected time range, along with the average daily token volume.
- **Images Generated** shows the total number of images generated in the selected time range, along with the total megapixels produced.

The **Token Count** chart plots token volume trend over time, broken down by model. The **Images Generated Over Time** chart plots image generation trend over time, broken down by model.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/usage_metrics.png)](https://docs.rafay.co/aiml/gpupaas/img/usage_metrics.png)

---

## Model Analytics

The **Model Analytics** tab provides per model cost insights.

- **Total** shows total cost across all models for the selected time range, along with the number of active models.
- **Concentration** shows the percentage of spend attributed to the top spending model.
- **Top** shows the highest spending model and its total cost.
- **Avg** shows the average cost per model across all active models.

The dashboard also surfaces automated insights based on current spend patterns, such as high cost concentration in a single model or high variance in cost across models.

The **Usage Trend** chart plots cost over time, broken down by model. The **Model List** ranks all models by cost, showing each model's total cost, percentage share of total spend, and a visual distribution of that share relative to other models.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/model_analytic.png)](https://docs.rafay.co/aiml/gpupaas/img/model_analytic.png)

---

## My Budget

The **My Budget** tab shows spend against configured budget limits, tracked separately at a monthly and a daily interval. Each interval is marked **DEFAULT**.

**Monthly**

- **Spend To Date** shows the amount spent in the current month against the monthly budget, with a progress bar and percentage used.
- **Budget** shows the configured monthly budget amount.
- **Remaining** shows budget remaining for the month. This value can go negative once spend exceeds the budget.
- **Resets On** shows the date and time the monthly budget period resets, at the start of the next month.

**Daily**

- **Spend To Date** shows the amount spent in the current day against the daily budget, with a progress bar and percentage used.
- **Budget** shows the configured daily budget amount.
- **Remaining** shows budget remaining for the day.
- **Resets On** shows the date and time the daily budget period resets, at the start of the next day.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/token_budget.png)](https://docs.rafay.co/aiml/gpupaas/img/token_budget.png)

---
