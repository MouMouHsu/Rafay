---
title: "Tenant Dashboard"
source: https://docs.rafay.co/aiml/gpupaas/tenant_dashboard/
---

# SKU Usage

The **Tenant Dashboard** provides a unified view of SKU consumption and resource utilization across the organization. It helps administrators monitor active projects, workspaces, users, and compute resources such as GPUs and CPUs. The dashboard also highlights top-level utilization metrics and quota usage for better capacity planning and workload management.

---

## Access

The **Tenant Dashboard** is accessible only to **Organization Administrators**, **Tenant Admin**, and **PaaS Project Admin**. It provides visibility into organization-level and project-level utilization metrics, quotas, and instance trends.

To access the **Dashboards** service:

1. Click the **App Launcher** icon (nine-dot grid) in the left navigation panel.
2. From the list of available services, select **Dashboards** to open the **SKU Usage** dashboard.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/tenant_admin_dashboard.png)](https://docs.rafay.co/aiml/gpupaas/img/tenant_admin_dashboard.png)

---

## Scope

The dashboard can display information at two levels, based on the selection at the top of the page:

- **All** – Displays **organization-level** metrics, including total counts and overall resource utilization across all projects and workspaces.
- **Project** – Displays **project-level** metrics for the selected project, including instance trends, utilization, and quota usage specific to that project.

---

## Organization Level Dashboard

The dashboard provides an aggregated view of organization-wide resource usage, including active projects, running workspaces, active users (last 30 days), allocated CPUs, allocated GPUs, total SKUs, and total instances. SKU and instance counts are split between compute and service categories. CPU and GPU values represent allocated capacity across the organization, while utilization metrics show allocated, used, and free resources for GPU, CPU, memory, and storage.

> Note: Only projects, workspaces, and users associated with at least one created instance are counted as active. Resource totals and utilization metrics are derived from allocated resources of created instances.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/orgslevel_overview.png)](https://docs.rafay.co/aiml/gpupaas/img/orgslevel_overview.png)

### Overview Widgets

#### Projects

Selecting the **Projects** count in the *Organization Overview* section opens the **Projects** page, which lists all active projects across the organization. This view provides an aggregated summary of resource usage at the project level. The search bar at the top allows filtering the list based on project names.

Each project entry displays the following details:

- **Name** – Displays the name of the project.
- **Workspace** – Indicates the number of active workspaces within the project.
  - Selecting the information icon (**i**) displays the list of associated workspaces.
- **Compute Instances** – Shows the total number of active compute instances running in the project.
- **Service Instances** – Displays the total number of active service instances under the project.
- **Actions** – Select **Go to Project** to open the corresponding project’s **PaaS Admin** page for detailed management and configuration.

> Note: Only projects with active workspaces or instances are included in this list.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/proj_view.png)](https://docs.rafay.co/aiml/gpupaas/img/proj_view.png)

#### Users

Selecting the **Users** count in the ***Organization Overview*** section opens the **Users** page, which lists all active users associated with the organization and their corresponding instance usage details. The search bar at the top allows filtering the list based on user names.

Each user entry includes the following details:

- **Username** – Displays the registered username associated with the organization.
- **Type** – Indicates the authentication method used by the user (for example, *Local* or *SSO*).
- **Compute Instances** – Shows the total number of compute instances created by the user.
  - Selecting the information icon (**i**) displays a list of compute instance names associated with the user.
- **Service Instances** – Displays the total number of active service instances associated with the user.
  - Selecting the information icon (**i**) lists the corresponding service instance names.

> Note: Users who were associated with at least one instance (compute or service) in the past 30 days are displayed in this view..

[![Small](https://docs.rafay.co/aiml/gpupaas/img/user_view.png)](https://docs.rafay.co/aiml/gpupaas/img/user_view.png)

#### Workspaces

Selecting the **Workspaces** count in the *Organization Overview* section opens the **Workspaces** page, which lists all active workspaces and their associated usage details within the organization.

Each workspace entry includes the following details:

- **Name** – Displays the name of the workspace.
- **Project** – Indicates the project under which the workspace is created.
- **Compute Instances** – Shows the total number of compute instances running within the workspace.
- **Service Instances** – Displays the total number of service instances associated with the workspace.

The search bar at the top allows filtering the list by workspace name.

> Note: Only workspaces with active compute or service instances are displayed in this view.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/workspace_view.png)](https://docs.rafay.co/aiml/gpupaas/img/workspace_view.png)

#### CPUs / GPUs

The **CPUs** and **GPUs** metrics display the total allocated compute resources across the organization. These values represent the number of CPU cores and GPU units currently assigned to running workloads across projects and workspaces.

The metrics reflect cumulative allocations from all active projects and update dynamically as workloads are deployed, scaled, or terminated. They help track current compute usage for capacity planning and include only allocations from active workloads; unallocated or idle capacity is not included.

#### Compute and Service SKUs

Displays the total number of SKUs associated with instances across the organization. SKUs are grouped into the following types:

- **Compute SKUs** – Compute profiles used by created compute instances.
- **Service SKUs** – Service profiles used by created service instances.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/profile_widget.png)](https://docs.rafay.co/aiml/gpupaas/img/profile_widget.png)

The **View Compute SKUs** and **View Service SKUs** options provide access to the corresponding lists of SKUs along with their associated instances.

> Note: Only SKUs that are currently in use by created compute or service instances are included in the displayed totals.

##### Compute SKUs

Selecting **View Compute SKUs** opens a detailed list of all compute profiles available in the organization.

Each entry includes the following details:

- **SKU** – Name of the compute SKU.
- **Available Since** – Date and time when the SKU became available for use.
- **Project** – Project associated with the SKU.

The page includes options to:

- Use the **Search** field to locate SKUs by name.
- Filter SKUs by **Project**.
- Select **View** to toggle the visibility of specific columns for all compute SKUs.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/compprofs_list.png)](https://docs.rafay.co/aiml/gpupaas/img/compprofs_list.png)

**Project Details in SKU Usage**

The **Project** column in the SKU list indicates how a SKU is associated with projects. Selecting the project count opens the **Project Details** panel, which provides additional context based on the organization type.

- In a **Partner organization**, the dashboard displays **only the Parent Project** where a profile is created. Profiles can be created in different partner projects (for example, *Project A*, *Project B*, or *System Catalog*). Even though profiles created in the *System Catalog* project can be shared with tenant organizations, the dashboard does not display any tenant organization or tenant project information.

The **Project Details** panel always shows the **Parent Project** based on where the profile was created. For example: * Profiles created in *Project A* display **Parent Project: Project A** * Profiles created in *Project B* display **Parent Project: Project B** * Profiles created in *System Catalog* display **Parent Project: System Catalog**

Only the parent project information is shown, regardless of whether the profile is shared with tenants.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/partner_projects.png)](https://docs.rafay.co/aiml/gpupaas/img/partner_projects.png)

- In a **Tenant organization**, the dashboard reflects where shared profiles are actually used. Profiles shared from the partner organization appear with **Project Details** based on instance creation within tenant projects.

The **Project Details** panel displays **Profile Shared with** only when at least one instance is created using that shared profile in the corresponding tenant project. For example: * If instances are created in *Project A*, it displays **Profile Shared with Project A** * If instances are created in *Project B*, it displays **Profile Shared with Project B** * If no instances are created in a project, that project is not shown

[![Small](https://docs.rafay.co/aiml/gpupaas/img/tenants_projects.png)](https://docs.rafay.co/aiml/gpupaas/img/tenants_projects.png)

Similar to Compute SKUs, details for **Service SKUs** can also be viewed from the corresponding section.

#### Instances

The **Instances** widget displays the total number of **Compute** and **Service** instances that are active in the organization. It provides a consolidated view of all instances created from their respective profiles, helping administrators monitor instance utilization across the organization.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/instances_widget.png)](https://docs.rafay.co/aiml/gpupaas/img/instances_widget.png)

Click **View Compute Instances** or **View Service Instances** to access detailed information.

> Note: Only instances that have been successfully created are included in the total count.

##### Compute Instances

The **Compute Instances** page lists all compute instances available in the organization. Each row provides details such as the instance name, associated SKU, current status, workspace, user, and total usage hours.

Filters are available at the top of the page to narrow the view by **Status**, **SKU**, or **Project**. The **View** option allows toggling specific columns for customized visibility, enabling administrators to view only the information relevant to their monitoring or reporting needs.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/instances_list.png)](https://docs.rafay.co/aiml/gpupaas/img/instances_list.png)

Similar to compute instances, service instances can be viewed under **View Service Instances** for detailed insights.

#### Current Utilization

Displays real-time utilization metrics for GPU, CPU, memory, and storage based on allocated, used, and free capacity. These metrics provide visibility into current resource consumption across the organization.

| **Field** | **Description** |
| --- | --- |
| **GPU** | Displays allocated, used, and free GPU capacity along with overall utilization. |
| **CPU** | Displays allocated, used, and free CPU cores along with current utilization. |
| **Memory** | Displays allocated, used, and free memory capacity with utilization status. |
| **Storage** | Displays allocated, used, and free storage capacity with utilization status. |

Utilization data is displayed only for currently running instances and notebooks with available performance metrics and reflects the real-time state of allocated resource usage.

---

## Project-Level Dashboard

The **Project** tab in the **SKU Usage** dashboard provides utilization and activity details for a specific project.

To view details, select the **Project** tab at the top and choose the required project from the **Project** filter. The dashboard updates automatically to show metrics specific to the selected project.

### Overview

The **Overview** section displays summarized counts and utilization data for the selected project.

It includes the following widgets:

- **Workspaces, Users, GPUs, and CPUs** – Displays counts of running workspaces, active users, and allocated CPU and GPU resources for currently running instances and notebooks in the selected project.
- **Profiles & Instances** – Show total counts for profiles and instances within the project.
  - Each widget provides a breakdown by **Compute** and **Service** types.
  - Options are available to **View Compute SKUs**, **View Service SKUs**, **View Compute Instances**, and **View Service Instances** for detailed insights.
- **Current Utilization** – Displays available metrics for **GPU**, **CPU**, **Memory**, and **Storage**, showing used, free, and total values where data is available.

> Note: Entities without any created instances are not included in the totals.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/project_level_dash.png)](https://docs.rafay.co/aiml/gpupaas/img/project_level_dash.png)

**Key Highlights**

- Displays aggregated metrics at both organization and project levels.
- Provides visibility into resource utilization and instance activity.
- Consolidates active project, workspace, and user counts based on instance creation.
- Only instances with available metrics are displayed.
- All totals are derived from created instances, regardless of deployment status.
- Supports quick navigation to instance and sku-level details.
- Enables administrators to monitor capacity and usage trends from a unified dashboard.

---

### Resource Quotas

The **Resource Quotas** tab provides a graphical view of available and consumed resource quotas across profiles. This helps monitor the distribution of compute and service quotas at both organization and project levels.

#### Organization-Level View

The **All** tab provides a consolidated view of **SKU quota usage across all projects** in the organization. It includes the following sections:

- **Distribution**: Displays a donut chart summarizing overall SKU quota status across the organization.
  - **Within**: SKUs operating within the configured quota limits (healthy usage).
  - **Full**: SKUs that have reached or are at near-capacity.
  - **Unused**: SKUs with quotas configured but no usage recorded.
  - **No Quota**: SKUs where the quota limit is set to `0` (no limit configured).

The center of the chart shows the **total number of SKUs** tracked. Selecting any segment of the donut chart automatically **filters the SKU Quotas** list to display only SKUs matching the selected status (for example, Within, Full, Unused, or No Quota).

- **SKU Quotas**: Lists individual SKUs along with their quota and usage details. Each SKU card includes:
  - **SKU Name** (for example, `partner-scp-cp-1`, `event-label-cp`)
  - **Resource Type** (Compute or Service)
  - **Quota Limit**: Total quota configured for the SKU.
  - **Used**: Indicates the number of instances currently in an active state that are consuming the SKU.
  - **Usage Percentage**: Visual indicator of quota consumption.
  - **Status**: Indicates whether the SKU is *Within*, *Full*, *Unused*, or *No Quota*.
- **Sort Option**: Use the **Type (A–Z)** option to sort SKUs alphabetically by type.
- **View All**: Select **View All** to display the complete list of SKUs and their quota details.

> Note: Only SKUs with a configured quota are displayed in the Org view.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/org_level_rq.png)](https://docs.rafay.co/aiml/gpupaas/img/org_level_rq.png)

#### Project-Level View

The **Project** tab provides a focused view of **SKU quota usage for a selected project**.

It includes the following sections:

- **Project Selector**: Displays the currently selected project context (for example, `system-catalog`). All quota and usage information on this page is scoped to the selected project.
- **Distribution**: Displays a donut chart summarizing the **SKU quota status within the project**.
  - **Within**: SKUs operating within the configured quota limits.
  - **Full**: SKUs that have reached or are at near-capacity.
  - **Unused**: SKUs with quotas configured but no usage recorded.
  - **No Quota**: SKUs where the quota limit is set to `0` (no limit configured).

The center of the chart shows the **total number of SKUs** in the selected project, along with a summary count for each usage category below the chart. Selecting any segment of the donut chart automatically **filters the SKU Quotas** list to display only SKUs matching the selected status (for example, Within, Full, Unused, or No Quota).

- **SKU Quotas**: Lists all SKUs configured for the selected project along with their quota and usage details. Each SKU card includes:
  - **SKU Name** (for example, `Partner Scp Cp 1`, `Partner Scp Sp 1`)
  - **Resource Type** (Compute or Service)
  - **Quota Limit**: Total quota configured for the SKU.
  - **Used**: Indicates the number of instances currently in an active state that are consuming the SKU.
  - **Usage Percentage**: Visual indicator of quota consumption.
  - **Status**: Indicates whether the SKU is *Within*, *Full*, *Unused*, or *No Quota*.
- **Sort Option**: Use the **Type (A–Z)** option to sort SKUs alphabetically by type.
- **View All**: Select **View All** to display the complete list of SKUs and their quota details for the selected project.

> Note: Only SKUs with a configured quota are displayed in the Project view.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/project_rqs.png)](https://docs.rafay.co/aiml/gpupaas/img/project_rqs.png)

---

### Utilization Trends

The **Usage Trends** graph displays resource utilization for selected running instance, with utilization details shown for the last 7 days.The **Top Utilization** section shows real-time utilization data for the highest-consuming entities (currently running instances and notebooks). The functionality remains consistent for both organization-level and project-level views, with the scope of data adjusted based on the selected context.

The page displays resource utilization across **GPU**, **CPU**, **Memory**, and **Storage**. Utilization trends help monitor capacity, identify usage peaks, and assess the efficiency of allocated resources.

- The graph displays GPU, CPU, Memory, and Storage utilization percentages for the selected instance, if available.
- If any of the utilization metrics (GPU, CPU, Memory, or Storage) are unavailable for the instance, the corresponding value is displayed as 0%.

#### Organization-Level View

At the organization level, the utilization graph displays aggregated usage trends across all projects and instances. The **Top Utilization** section lists the top five projects based on GPU utilization, with CPU and memory as fallback metrics.

**Key Highlights**

- Displays resource utilization trends across all projects and instances.
- Top-performing projects are ranked based on GPU usage.
- Hovering over a point in the graph shows detailed utilization percentages for each resource type.
- Clicking on a project name filters the data to show instance-level utilization for that project.
- The **Top Utilization** panel includes two tabs: **Projects** and **Instances** and displays data only for **currently running instances and notebooks**.
  - **Projects**: Displays the **top five projects** associated with currently running instances or notebooks, ranked by **GPU utilization (%)**, along with corresponding **CPU** and **Memory** utilization values. If GPU metrics are not available for any eligible project, the panel displays the **top five projects based on CPU utilization**, and GPU utilization is shown as `0%`.
  - **Instances**: Displays the **top five currently running instances or notebooks**, ranked by **GPU utilization (%)**, along with corresponding **CPU** and **Memory** utilization values. If GPU metrics are unavailable for all eligible instances, the rankings are based on **CPU utilization**, and GPU utilization is shown as `0%`. Each entry includes the instance name, utilization percentages for GPU/CPU/Memory, health status (for example, *High* or *Normal*), and the **peak usage value**.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/org_utili.png)](https://docs.rafay.co/aiml/gpupaas/img/org_utili.png)

#### Project-Level View

At the project level, the utilization graph displays resource trends for instances within the selected project. The **Top Utilization** section highlights instances with the highest GPU usage within that project.

**Key Highlights**

- Displays GPU, CPU, memory, and storage usage for all instances under the selected project.
- The **Top Utilization** panel displays the **top five instances** within the selected project, ranked by **GPU utilization (%)**, along with corresponding **CPU** and **Memory** utilization values.
  - If GPU metrics are unavailable for the selected project, the panel displays the **top five instances based on CPU utilization**, along with corresponding Memory utilization.
  - In this case, **GPU utilization is shown as 0%** for the instances.
- Hovering over the chart reveals resource utilization for the selected instance on specific dates.
- Filters allow switching between projects or specific instances for focused analysis.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/project_utili.png)](https://docs.rafay.co/aiml/gpupaas/img/project_utili.png)

**Note:** Only instances with available utilization metrics are included in the visualization and rankings.

---

### Instance Trends

The **Instance Trends** page provides insights into instance usage patterns and top-performing entities over a selected duration (for example, 30 days). The functionality is available at both organization-level and project-level views, with the scope of data adjusted based on the selected context.

The page displays instance utilization trends for **Compute** and **Service** types. A line graph visualizes the total number of instances over time, helping track instance creation, growth, and overall activity patterns across the platform.

#### Shared Functionality Across Views

- Displays usage trends for Compute and Service instances.
- Includes a **SKU** filter to refine the data view.
- The **Top Instances** panel ranks entities based on usage count.
- Hovering over points in the graph displays the total number of instances for specific dates.
- The **View All** option expands the list of top instances.

#### Organization-Level View

At the organization level, the graph displays the **total number of instances** across all projects. The **Top Instances** section lists the top five projects with the highest instance count, categorized by type (Compute or Service).

**Key Highlights**

- Aggregates instance usage data across all projects.
- Ranks top-performing projects by total instance count.
- Supports filtering by **SKU**.
- Enables switching between **Compute** and **Service** categories for comparative analysis.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/org_inst_trend.png)](https://docs.rafay.co/aiml/gpupaas/img/org_inst_trend.png)

#### Project-Level View

At the project level, the graph focuses on instance usage within the selected project. The **Top Instances** section lists the instances with the highest count within that project.

**Key Highlights**

- Displays instance trends specific to the selected project.
- Shows ranking of top instances by usage within the project.
- Includes filters for **SKU**
- Allows focused analysis of instance activity over time.

[![Small](https://docs.rafay.co/aiml/gpupaas/img/projects_instance.png)](https://docs.rafay.co/aiml/gpupaas/img/projects_instance.png)

---
