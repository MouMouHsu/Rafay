---
title: "Events and Reports for GPU PaaS"
source: https://docs.rafay.co/aiml/gpupaas/events%26reports/
---

# Events & Reports

## Events & Reports

The **Events & Reports** section provides tenant administrators with visibility into **GPU PaaS operational activities, security events, and access-related records** across the organization. This section helps monitor system behavior, track user actions, and respond to operational or security-related events.

Access Events & Reports from: **Tenant Administration → Events & Reports**

The following sections are available:

- **Alerts**
- **Access Reports**
- **Audit Logs**

### Alerts

The **Alerts** section displays system-generated alerts related to **GPU PaaS operations** across tenant projects.

Access Alerts from: **Tenant Administration → Events & Reports → Alerts**

Alerts can be filtered by **project**, **alert status**, **severity**, and **time range**. Each alert represents an operational condition or event detected by the platform. Alerts remain in an **Open** state until the underlying condition is resolved.

Tenant administrators can manage alert notifications using **Manage Notifications**, where instance-level notifications can be enabled or disabled and recipient email addresses can be configured. Alerts provide timely visibility into GPU PaaS issues and help ensure prompt operational response.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/alerts.png)](https://docs.rafay.co/aiml/gpupaas/img/alerts.png)

---

### Access Reports

The **Access Reports** section provides visibility into **GPU PaaS user and group access** for audit and compliance purposes.

Access Access Reports from: **Tenant Administration → Events & Reports → Access Reports**

#### Schedule Report

Tenant administrators can schedule access reports to run automatically by selecting **Schedule Report**. While scheduling, admins define:

- **Report name**
- **Output format**
- **User or group scope**
- **Schedule interval** (weekly, monthly, quarterly, or yearly)

Scheduled reports are generated automatically at the configured intervals, ensuring continuous visibility into GPU PaaS access assignments.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/schedulereport.png)](https://docs.rafay.co/aiml/gpupaas/img/schedulereport.png)

#### Generate Report

Tenant administrators can generate access reports on demand by selecting **Generate Report**. While generating a report, admins specify:

- **Report name**
- **Output format** (CSV or JSON)
- **User or group scope** (All, Local Users, IDP Users, IDP Groups, or Override Groups)

The generated report appears under **Generated Reports**, where it can be downloaded or deleted.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/gen_report.png)](https://docs.rafay.co/aiml/gpupaas/img/gen_report.png)

---

### Audit Logs

The **Audit Logs** section provides a detailed, chronological record of **GPU PaaS–related actions and events** performed within the tenant organization.

Access Audit Logs from: **Tenant Administration → Events & Reports → Audit Logs**

Audit logs capture activities such as:

- User authentication events (login, MFA enablement)
- User, group, and role changes
- Identity provider configuration updates
- Security and access-related actions

Logs can be filtered by **project**, **event type**, **user**, **client**, and **time range** to quickly locate relevant entries. Each log entry includes the timestamp, user, associated groups, client type, action type, and event message.

Audit logs help tenant administrators meet **security, compliance, and troubleshooting** requirements by providing full visibility into GPU PaaS administrative and user activity.

[![GPU PaaS Concept](https://docs.rafay.co/aiml/gpupaas/img/audit_logs.png)](https://docs.rafay.co/aiml/gpupaas/img/audit_logs.png)

---
