---
title: "Deployment Form Factors"
source: https://docs.rafay.co/aiml/gpupaas/formfactor/
---

# Deployment Options

Rafay GPU PaaS  is a control plane product that is available in both **[SaaS](https://console.rafay.dev/)** and a **[self-hosted software](https://docs.rafay.co/selfhosted/overview/)** form factors.

> **Info**
> The self hosted form factor is well suited for **air-gapped** environments such as sovereign clouds.

---

- **SaaS**   Well suited for POCs, Trials and Small Enterprise Deployments. You can sign up for a [Free SaaS Org](https://rafay.co/start) if you wish to try out GPU PaaS.  [Free Org](https://rafay.co/start)
- **Air Gapped Deployments**   Recommended for Cloud Providers, Sovereign Clouds and Regulated Enterprises. [Download and Deploy](https://docs.rafay.co/selfhosted/overview/) Rafay GPU PaaS in your air-gapped data center.  [Contact](https://docs.rafay.co/cdn-cgi/l/email-protection#345d5a525b74465552554d1a575b)
