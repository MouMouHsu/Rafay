---
title: "Overview"
source: https://docs.rafay.co/aiml/gpupaas/getstarted/overview/
---

# Overview

- ![🏛](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/1f3db.svg) **For Enterprises**   Learn about how enterprises can use Rafay GPU PaaS  to provide their users with **on-demand** access to GPUs and AI/ML tooling.  [Get Started](https://docs.rafay.co/aiml/gpupaas/enterprise/intro/overview/)
- **For GPU Cloud Providers**   Learn about how GPU Cloud providers can use Rafay GPU PaaS  to quickly deploy and operate a GPU Cloud service supports 1000s of customers.  [Get Started](https://docs.rafay.co/aiml/gpupaas/cloud_provider/overview/)

---
