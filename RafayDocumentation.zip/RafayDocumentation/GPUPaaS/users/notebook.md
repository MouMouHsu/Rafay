---
title: "Manage Jupyter Notebooks"
source: https://docs.rafay.co/aiml/gpupaas/users/notebook/
---

# Manage Notebooks

It is extremely common for data scientists and researchers to use Jupyter notebooks for exploratory data analysis. Rafay GPU PaaS  provides a turnkey experience for users with a "Notebook as a Service" type experience. Rafay also provides a number of profiles for notebooks that allow users to spin up environments preloaded with the required libraries and frameworks.

---

## Create Notebook

To create a notebook, access the **Developer Hub** and navigate to the home page. The page provides options to create and manage notebooks, which are predefined configurations designed to deliver interactive environments for tasks such as data analysis, visualization, and machine learning development. On the Developer Hub home page, users can either click on **View All** to access the Notebooks page or click on **New Notebook** to create a new notebook. Users can also click on the Notebooks menu on the left to directly access the Notebooks page.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/notebooks_home.png)](https://docs.rafay.co/aiml/gpupaas/img/notebooks_home.png)

---

## New Notebook

To create a new notebook,

- Select **Notebooks** from the menu on the left of the console
- Click on **New notebook**
- Select a suitable notebook service profile that suits your requirements

[![New Notebook](https://docs.rafay.co/aiml/gpupaas/img/new_notebook.png)](https://docs.rafay.co/aiml/gpupaas/img/new_notebook.png)

Once the profile is selected, provide the required details. If pricing for the selected profile is configured in [Global Settings](https://docs.rafay.co/aiml/csp/global_settings/) by the Org Admin, a monthly estimate will be displayed.

- Provide a **Name** for the notebook (adding a **Description** is optional)
- Select the desired **Workspace** from the dropdown list

[![Configure Notebook](https://docs.rafay.co/aiml/gpupaas/img/configure_notebook_name.png)](https://docs.rafay.co/aiml/gpupaas/img/configure_notebook_name.png)

- Now, specify the GPU resources you would like to provide the notebook. Select from the provided options:
  - Number of GPUs
  - GPU Model/Type (i.e. node type)

[![Notebook Resources](https://docs.rafay.co/aiml/gpupaas/img/notebook_resources.png)](https://docs.rafay.co/aiml/gpupaas/img/notebook_resources.png)

- A notebook profile maps to a notebook pre-installed and pre-configured with the required frameworks, libraries and software add-ons that match the profile. Profiles allow the data scientist to start using the notebook right away instead of wasting time trying to install and configure all the software on top of the notebook.

| Profile | Description |
| --- | --- |
| Minimal | Basic libraries and frameworks only |
| Data Science | With common libraries for data science |
| Spark | With libraries required for Spark |
| Tensorflow | With Tensorflow libraries |
| Tensorflow with CUDA | With Tensorflow and CUDA libraries |
| PyTorch | With PyTorch libraries |
| PyTorch with CUDA | With PyTorch and CUDA libraries |

Select the profile you would like to use with your notebook from the provided dropdown list.

[![Notebook Profile](https://docs.rafay.co/aiml/gpupaas/img/select_profile.png)](https://docs.rafay.co/aiml/gpupaas/img/select_profile.png)

- Click on **Deploy** to launch the notebook service

It can take a few minutes for the notebook and associated software components to be deployed and ready for use.

> **Info**
> Users can deploy multiple notebooks on an instance. The only constraint is whether the underlying instance has the resources required for all the notebooks.

- The notebook initially displays a status of ***In Progress***. Upon successful deployment, the status updates to ***Success***

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/success-nb.png)](https://docs.rafay.co/aiml/gpupaas/img/success-nb.png)

---

## Use Notebook

Once a notebook has been successfully deployed onto a compute instance, the user is presented with the URL for the notebook and a token (authentication credentials) to securely access the notebook. To access the notebook, the user can either click on the URL or copy/paste it into a web browser.

[![Notebook in Browser](https://docs.rafay.co/aiml/gpupaas/img/notebook/access_notebook.png)](https://docs.rafay.co/aiml/gpupaas/img/notebook/access_notebook.png)

They need to then provide the access token as a credential before they can access the Jupyter notebook.

---

## View Notebook

Clicking on the notebooks menu will list of all the notebooks the user has access to. Note that notebooks may span different workspaces and different instances. To view details about a specific notebook, users just need to click on the name of the notebook.

[![View Notebook](https://docs.rafay.co/aiml/gpupaas/img/view_notebook.png)](https://docs.rafay.co/aiml/gpupaas/img/view_notebook.png)

---

## Notebook Metrics Dashboard

The Metrics Dashboard provides real-time visibility into resource utilization for Jupyter Notebook instances. This dashboard helps track performance and monitor system behavior while notebooks are running.

- From the Notebooks list, locate the required notebook, click on the **ellipses** (three dots) on the far right and select **View Metrics**. This opens the **Notebook Metrics Dashboard** for the selected instance.

[![View Notebook](https://docs.rafay.co/aiml/gpupaas/img/notebook_metrics.png)](https://docs.rafay.co/aiml/gpupaas/img/notebook_metrics.png)

### Dashboard overview

The Metrics Dashboard provides real-time and historical visibility into resource usage for the selected notebook instance. System-level metrics and GPU-level metrics (when applicable) are displayed as time-series charts, along with summary values for **current**, **peak**, and **average** utilization.

- System charts are displayed at the top of the dashboard.
- GPU panels appear only when the notebook instance is provisioned with GPUs.
- A list of all GPUs is shown at the bottom of the dashboard, with expandable sections for each GPU to view detailed metrics.

These charts provide instance-level visibility into CPU, memory, and storage utilization.

- CPU Utilization: Displays CPU usage over time for the instance.
  - Shows **current**, **peak**, and **average** CPU utilization.
  - May display **Committed** vs **Usage**, indicating reserved CPU limits vs actual consumption.
  - Useful for identifying sustained high CPU load or sudden spikes in demand.
- Memory Utilization: Shows memory usage over time.
  - Indicates **current**, **peak**, and **average** memory consumption.
  - Committed vs Usage highlights reserved memory capacity compared to real usage.
  - Helps assess memory pressure and identify increasing memory trends.
- Storage Utilization: Displays storage usage of the notebook’s associated volume.
  - Shows **current**, **peak**, and **average** storage consumption.
  - Helps determine data growth and future storage sizing requirements.

### GPU metrics (when GPU(s) are present)

When GPUs are attached to the notebook instance, GPU usage and performance metrics are displayed. Each GPU is listed individually and can be expanded to view detailed charts.

- GPU Utilization: Percentage of GPU processing capacity used over time.
- GPU Memory Copy Utilization: Percentage of GPU memory transfer operations (device-to-device or device-to-host) over time.
- GPU Temperature: Shows the operating temperature of the GPU and this can help identify thermal throttling conditions.
- GPU SM Clocks: Displays the Streaming Multiprocessor (SM) clock frequency over time.
- GPU Memory Clocks: Shows the GPU memory clock frequency trends.
- Framebuffer Memory Used: Indicates GPU framebuffer memory actively allocated for workloads.
- Framebuffer Memory Free: Shows remaining available GPU framebuffer memory. This is useful for evaluating workload fit, model sizing, or concurrency limits.
- GPU list view

A list of GPUs is presented below the metric panels. * Each GPU entry shows the GPU identifier and model (for example, NVIDIA H100 80GB). * Expanding a GPU entry displays the full set of GPU metric panels for that specific GPU. * Enables comparison across GPUs in multi-GPU configurations.

[![View Notebook](https://docs.rafay.co/aiml/gpupaas/img/notebook_metrics_1.png)](https://docs.rafay.co/aiml/gpupaas/img/notebook_metrics_1.png)

> Notes:
> * GPU charts appear only if the instance is backed by a GPU SKU.
> * If the instance is stopped or not running, charts may display empty data or no activity.
> * System charts and GPU charts refresh periodically and display time-series trends.

---

## Delete Notebook

To delete a notebook, users should click on the ellipses on the far right of the selected notebook and select delete.

[![Delete Notebook](https://docs.rafay.co/aiml/gpupaas/img/delete_notebooks.png)](https://docs.rafay.co/aiml/gpupaas/img/delete_notebooks.png)

> **Info**
> Once deletion has been initiated, it cannot be stopped or reversed. Users can create a new notebook if required.

---
