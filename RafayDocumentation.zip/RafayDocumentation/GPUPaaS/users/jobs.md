---
title: "Custom AI/ML Jobs"
source: https://docs.rafay.co/aiml/gpupaas/users/jobs/
---

# AI/ML Jobs

The **AI/ML Jobs** Page in the GPU PaaS  platform is a versatile feature that enables users to define and execute AI/ML tasks seamlessly. It provides a centralized interface for managing resource-intensive workloads, ensuring efficiency and scalability. By leveraging this page, users can configure and deploy jobs tailored to specific AI/ML requirements, such as model training, data processing, and algorithm testing.

This page is particularly useful when users need to automate complex workflows or manage tasks requiring high-performance compute resources. It eliminates manual provisioning efforts and ensures consistency in job execution. Users can utilize the Jobs Page to streamline their workflows, save time, and focus on the core aspects of their machine learning projects.

The Jobs Page can be used when a task requires defined resource configurations, integration with other services, or automated deployment of workflows. Whether for experimentation, production deployments, or large-scale AI/ML operations, this feature offers a reliable and structured approach to managing machine learning workloads effectively.

---

## Create Jobs

To create a job, access the **Developer Hub** and navigate to the home page. The page provides options to create and manage AI/ML jobs, which are predefined configurations designed to streamline and optimize machine learning tasks, such as training, tuning, and deploying models. These profiles ensure consistency and efficiency across the machine learning lifecycle, simplifying workflows and reducing operational complexity. On the Developer Hub home page, users can either click on View All to access the **AI/ML Jobs** page or click on **New AI/ML Job** to create a new job. Users can also click on the **AI/ML Jobs** menu on the left to directly access the AI/ML Jobs page.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/job_home.png)](https://docs.rafay.co/aiml/gpupaas/img/job_home.png)

## New Job

To create a new AI/ML Job,

- Select **AI/ML jobs** from the menu on the left of the console
- Click on **New Jobs** and select a suitable service profile that suits your requirements

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/job_sp.png)](https://docs.rafay.co/aiml/gpupaas/img/job_sp.png)

Once the profile is selected, provide the required details. If pricing for the selected profile is configured in [Global Settings](https://docs.rafay.co/aiml/csp/global_settings/) by the Org Admin, a monthly estimate will be displayed.

- Provide a name for the service (optional description)
- Select a workspace from the drop-down
- Enter the required **API Key** and **Controller Endpoint** values
- Based on the configuration fields defined in the selected service profile and its associated template, users must provide the required details
- Click on **Deploy** to launch the job

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/jobs_input.png)](https://docs.rafay.co/aiml/gpupaas/img/jobs_input.png)

Depending on the complexity of the job app, it can take a few minutes for all the components to be deployed, become operational and usable for the user.

- The job initially displays a status of ***In Progress***. Upon successful deployment, the status updates to ***Success***

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/job_success.png)](https://docs.rafay.co/aiml/gpupaas/img/job_success.png)

---

## View Jobs

Clicking on the AI/ML Jobs menu will list of all the jobs the user has access to, their status and additional details about them. Note that jobs may span different workspaces and different instances. To view details about a specific job, users just need to click on the name.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/job_listing.png)](https://docs.rafay.co/aiml/gpupaas/img/job_listing.png)

---

## Delete Jobs

To delete a job, users should click on the ellipses on the far right of the selected service and select delete.

> **Info**
> Once deletion has been initiated, it cannot be stopped or reversed. Users can create a new job if required.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/delete_job.png)](https://docs.rafay.co/aiml/gpupaas/img/delete_job.png)

---
