---
title: "End User Self Service Portal"
source: https://docs.rafay.co/aiml/gpupaas/users/overview/
---

# Overview

Typical end users of GPU PaaS  are data scientists, ML researchers or developers. Once the tenant's "Org Admin" provides the user with the appropriate end user role, they will have the ability to login into the self service portal, create and manage GPU workspaces, request for GPUs, compute, deploy and operate Jupyter notebooks and other services made available by the administrator or service provider.

One of the goals of GPU PaaS  service is to enable IT/Operations or Platform teams to empower these users with an **On Demand** experience to get access to a fully operational and ready to use environment where they can perform their tasks efficiently.

In the example below, the "data scientist" and the "developer are different users in the organization. Both have access to the same "Self Service Portal". Note that the data scientist has done the following:

- Has created one workspace
- Has launched two GPU powered "compute instances" in this workspace
- Has deployed a LLM fine tuning service into one instance
- Has deployed a Jupyter notebook into the other instance for model development

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/users/ssp.png)](https://docs.rafay.co/aiml/gpupaas/img/users/ssp.png)

---

## Access Developer Hub

End Users are taken directly to the self service portal (aka Developer Hub) upon login. This self service provides a unified interface for end users to manage AI/ML workflows efficiently. With this portal, end users can:

- Organize resources using [Workspaces](https://docs.rafay.co/aiml/gpupaas/workspace/)
- Launch and use Compute Resources (i.e. Bare Metal Servers, Virtual Machines, Kubernetes Clusters, vClusters and SLURM Clusters)
- Launch and use Applications and Tools (i.e. Jupyter Notebooks, Inference Servers, MLOps Platforms etc)

Shown below is an example of a "white labeled" end user self service portal.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/dev_hub_home.png)](https://docs.rafay.co/aiml/gpupaas/img/dev_hub_home.png)

---
