---
title: "End User Dashboard"
source: https://docs.rafay.co/aiml/gpupaas/users/user_dashboard/
---

# User Dashboard

## Overview

The End User Dashboard provides a project-level view of resource usage and utilization for compute and service workloads. It enables tracking of allocated resources, running instances, and workspace-level consumption within a project.

The End User Dashboard is accessed from the Developer Hub by navigating to **Developer Hub → Usage**, which opens the dashboard for the currently selected project.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/user_dash.png)](https://docs.rafay.co/aiml/gpupaas/img/user_dash.png)

## Dashboard Scope

- The End User Dashboard operates at the project level
- Project selection determines the data shown in the dashboard
- Workspace-level views are available through filtering
- Data visibility is governed by RBAC permissions

**RBAC-Based Data Visibility**

The End User Dashboard enforces Role-Based Access Control (RBAC) to determine which projects, workspaces, instances, and resource metrics are visible.

Data displayed in the dashboard is scoped strictly to the projects and workspaces permitted by assigned roles.

**Project Visibility**

- Only permitted projects are available for selection
- Projects without assigned access are not listed and their data is excluded
- All dashboard metrics are calculated only for the selected project

**Workspace Visibility**

Workspace visibility is determined by workspace-level roles.

- Only permitted workspaces are listed
- Workspaces without access are excluded from all views
- Resource metrics aggregate data only from accessible workspaces

When access is limited to a subset of workspaces, the dashboard displays a combined view of data only from those workspaces.

**Instance Visibility**

- Only instances created within accessible workspaces are displayed
- Instances from inaccessible workspaces are excluded

**Project-Scoped Instances**

The **Project-scoped** view includes: - Instances created directly at the project level - Instances not associated with any workspace

Project-scoped instances are displayed only when access to the project is permitted.

**Metric Aggregation Behavior**

- Resource Overview and utilization metrics aggregate data only from accessible instances
- Instances from inaccessible workspaces are excluded from counts and utilization
- SKU and profile listings include only those associated with visible instances

This ensures that usage data, instance counts, and resource metrics reflect only the scope permitted by RBAC policies.

**Role-Based Access**

The End User Dashboard is accessible to: - Org Admins - Tenant Admins in non-default organizations - PaaS Project Admins - Users with workspace-level RBAC roles

Any role with access to the Developer Hub can access the End User Dashboard.

---

## Project-Level Aggregated View

This view presents an aggregated, project-level summary of resource usage across **all accessible workspaces and project-scoped instances**.

All metrics, instance counts, and utilization values reflect combined data from compute and service workloads permitted by RBAC policies.

### Resource Overview

The Resource Overview section provides a summary of resources associated with the selected project.

#### Workspaces Widget

The **Workspaces** widget displays the number of **running workspaces** within the selected project. It reflects workspace activity based on currently running compute and service instances.

Selecting the Workspaces widget opens a detailed workspace view that lists all accessible workspaces and provides visibility into instance distribution across them.

- **Workspace name**: Name of the workspace
- **Project**: Project to which the workspace belongs
- **Compute Instances**: Number of running compute instances in the workspace
- **Service Instances**: Number of running service instances in the workspace

The data shown represents only **active workloads** within the project. Workspace visibility and counts follow RBAC permissions, ensuring that only workspaces accessible to the user are included.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/usage_worksp.png)](https://docs.rafay.co/aiml/gpupaas/img/usage_worksp.png)

#### SKUs

The **SKUs** widget displays the list of **available SKUs** associated with the selected project. It presents a **combined view of compute and service profiles**, reflecting SKUs that are currently in use or available through active profiles.

Selecting the SKUs widget opens a detailed view of all SKUs available in the project.

Each SKU entry includes: - **SKU**: Name of the SKU - **SKU Type**: Category associated with the SKU, such as Bare Metal, Virtual Machines, Notebooks, or Inference Endpoints - **Available Since**: Timestamp indicating when the SKU became available

The profiles are differentiated using the **SKU Type** value.

**SKU Type Filter**

The SKUs view includes an **SKU Type** filter that allows narrowing down the list based on available types.

- Only SKU types associated with **currently available profiles** are listed in the filter
- SKU types without any associated profiles or instances are not displayed
- Custom SKU types appear only after profiles or instances are created using those types

This ensures that the SKUs list and filter reflect only relevant and active profile types within the project.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/skus_filter.png)](https://docs.rafay.co/aiml/gpupaas/img/skus_filter.png)

#### Instances Widget

The Instances widget provides visibility into all instances within the selected project. It displays a combined list of compute and service instances associated with available SKUs.

Selecting the Instances widget opens a detailed instances view.

Each instance entry includes: - **Instance**: Name of the instance - **SKU**: SKU used by the instance - **SKU Type**: Category associated with the SKU - **Status**: Current state of the instance, such as Active, Inactive, Failed, or Delete Failed - **Workspace**: Workspace associated with the instance, if applicable - **Owner**: User who created the instance - **Usage**: Duration for which the instance has been running

Compute and service instances are listed together and are not separated by instance type.

**Filters**

The Instances view includes the following filters to refine the displayed data:

- **Status**: Filters instances based on their current state.
- **SKU Type**: Filters instances by SKU type. Only SKU types associated with available instances are displayed.
- **SKU**: Filters instances by specific SKUs. Only SKUs currently associated with instances are listed.
- **Workspace**: Filters instances by workspace or project scope. The Workspace filter includes a **Project-scoped** option, which represents instances that are not associated with any workspace.

Filter values are dynamically populated based on available data and RBAC permissions, ensuring that only relevant and accessible options are shown.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/instance_view.png)](https://docs.rafay.co/aiml/gpupaas/img/instance_view.png)

**RBAC Visibility**

The Instances view adheres to RBAC rules: - Only instances associated with accessible workspaces are displayed - Instances outside permitted workspaces are excluded from the view - Project-scoped instances are displayed based on permitted access

#### GPUs Widget

The **GPUs** widget displays the total number of **allocated GPUs** within the selected project. The value represents GPUs allocated to **actively running instances** across compute and service workloads.

- GPU allocation is aggregated across all accessible workspaces
- Only active instances contribute to the allocation count
- Data visibility follows RBAC permissions

#### CPUs Widget

The **CPUs** widget displays the total number of **allocated CPU cores** within the selected project. The value reflects CPU resources assigned to **actively running instances**.

- CPU allocation is aggregated across compute and service workloads
- Only active instances are included
- Allocation values represent assigned resources, not usage or limits

#### Current Resource Utilization

The Current Resource Utilization section displays real-time usage of allocated resources.

**Resource types**

- GPU
- CPU
- Memory
- Storage

> Note: GPU utilization supports filtering using the Type selector.

Each resource card includes: - Allocated: Resources assigned to running instances - Used: Resources currently consumed - Free: Unused portion of allocated resources - Utilization status: High or Low utilization indicators

---

## Workspace-Level Usage View

The **Workspace** tab provides both **project-scoped** and **workspace-scoped** views of resource usage within the selected project. It enables switching between individual workspaces and a project-level scope to analyze resource consumption and instance activity.

The Workspace tab lists: - All available workspaces accessible to the user - A default **Project-scoped** option

### Project-Scoped View

The **Project-scoped** view represents instances that are **not associated with any workspace**. These typically include instances created directly at the project level.

- Displays instances that are not linked to any workspace
- Excludes instances associated with specific workspaces
- Resource Overview and Current Resource Utilization metrics reflect only project-scoped instances
- Metrics update dynamically when the Project-scoped option is selected

**Resource Overview**

The Resource Overview section includes: - **SKUs** – Available SKUs associated with project-scoped instances - **Instances** – Total project-scoped instances - **GPUs** – Allocated GPUs for active project-scoped instances - **CPUs** – Allocated CPU cores for active project-scoped instances

**Resource Utilization**

The Current Resource Utilization section displays real-time usage for: - GPU - CPU - Memory - Storage

All values represent **allocated resources for actively running project-scoped instances**.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/projectscoped.png)](https://docs.rafay.co/aiml/gpupaas/img/projectscoped.png)

### Workspace-Scoped View

When a specific workspace is selected, the dashboard displays resource usage and instance data **only for that workspace**.

- Displays only instances **associated with the selected workspace**
- Excludes instances created without a workspace
- Resource Overview metrics reflect data for the selected workspace only
- Current Resource Utilization metrics are calculated based on active instances in the workspace

**SKU and Instance Listing**

- Only SKUs associated with **instances running in the selected workspace** are displayed
- Only profiles linked to **active instances** in the workspace are included
- Compute and service instances are displayed in a combined view

This ensures that the workspace-scoped view accurately reflects resource consumption and active workloads within the selected workspace.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/workspace_scope.png)](https://docs.rafay.co/aiml/gpupaas/img/workspace_scope.png)

**RBAC Visibility**

Workspace visibility follows RBAC rules: - Only workspaces accessible to the user are listed - Resource data is aggregated only from permitted workspaces - Project-scoped instances are displayed based on access permissions

---
