---
title: "Workspaces"
source: https://docs.rafay.co/aiml/gpupaas/users/workspace/
---

# Workspaces

End users can use workspaces to **group and organize** resources they create. For example, a data scientist may wish to create two workspaces called "devops-workspace" and "support-dept".

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/ws_list.png)](https://docs.rafay.co/aiml/gpupaas/img/ws_list.png)

Workspaces are also a way to achieve **multi tenancy** and **isolation**. Users can invite collaborators to specific workspaces. In the example above, you can see that the data scientist has invited three (3) to collaborate with him only in the "devops-workspace" workspace. Although Sally can access all resources inside the Dev workspace, she cannot view/access any resources inside the "QA" workspace.

In summary, workspaces help end users achieve the following:

- Group and Organize Resources
- Collaboration with Isolation and Multi Tenancy for End User Resources

---

## Create Workspace

Users can create and manage multiple workspaces. Although here is no limit to the number of workspaces they create, a practical number may be 3-5 workspaces. To create a workspace, access the **Developer Hub** and navigate to the home page. The page provides options to create and manage workspaces, which serve as logical isolation boundaries offering a dedicated space for creating and managing instances based on available profiles.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/users/ssp.png)](https://docs.rafay.co/aiml/gpupaas/img/users/ssp.png)

To create a workspace, access the **Developer Hub** and navigate to the home page. The page provides options to create and manage workspaces, which serve as logical isolation boundaries offering a dedicated space for creating and managing instances based on available profiles. On the Developer Hub home page, users can either click on **View All** to access the Workspaces page or click on **New Workspace** to create a new workspace. Users can also click on the Workspaces menu on the left to directly access the Workspaces page.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/workspace_home.png)](https://docs.rafay.co/aiml/gpupaas/img/workspace_home.png)

On clicking New Workspace, provide the required details:

- Name: Unique name for the workspace (e.g., qa-dept)
- Display Name:User-friendly name for the workspace (e.g., "Project QA")
- Description: Brief summary of the workspace’s purpose
- Labels: Key-value pairs for categorizing the workspace (e.g., env: dev)
- Annotations: Additional key-value metadata for the workspace (e.g., owner: JohnDoe)

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/ws_create.png)](https://docs.rafay.co/aiml/gpupaas/img/ws_create.png)

---

## View Workspace

When the user selects the workspaces menu on the left, the list of all workspaces will be displayed. Users can view additional details (e.g. when was it created? when was it last modified) about a workspace by clicking on the name.

If the user has a large number of workspaces, they can "search" for the workspace by entering either a partial or full name in the search box. This will display a filtered list of all workspaces that matched the search criteria.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/view_ws.png)](https://docs.rafay.co/aiml/gpupaas/img/view_ws.png)

---

## Edit Workspace

To modify the workspace, click on the ellipses on the far right of the workspace to bring up the **actions** menu. Select "edit configuration", make the necessary changes and save the workspace.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/edit_ws.png)](https://docs.rafay.co/aiml/gpupaas/img/edit_ws.png)

---

## Add/Remove Collaborators

To add collaborators to a workspace, click on the workspace or click on **View Configuration**. This will display additional details about the workspace. In the collaborators section, you will see a list of users that have access to the workspace with their roles (i.e. privileges describing what they can/cannot do in the workspace).

### New Users

To invite new collaborators to the workspace,

- Click on **Add Collaborator** and select the user ids from the list as shown below:

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/add_collab.png)](https://docs.rafay.co/aiml/gpupaas/img/add_collab.png)

- Click **Save**

Collaborators can be added to a workspace with different roles depending on the level of access they require. A subset of [roles](https://docs.rafay.co/security/rbac/roles/) available in Rafay is listed below for the convenience of users.

| Role | Controller Access | ZTKA Access (Cluster Resources) |
| --- | --- | --- |
| PaaS End Users (Collaborators) | Includes roles such as Developer, Researcher, Data Engineer, Data Scientist, MLOps Engineer, and GenAI Developer. These roles can launch instances (from system or custom profiles), create workspaces, and add collaborators to workspaces | RoleBinding    **Resources:** Instances, workspaces    **Verbs:** Create, view, manage |
| PaaS Workspace Collaborator Read Only | A workspace-scoped, view-only role that allows users to view workspaces, services, compute instances, collaborators, and usage/dashboard information within assigned workspaces. Portal access is limited to Developer Hub (workspace scope, read-only). | RoleBinding    **Resources:** Instances, workspaces    **Verbs:** View |
| PaaS Project Admin | A role that allows viewing Profile Catalogs, creating custom profiles (compute/service profiles within the project), and launching instances (from Profile Catalogs or custom profiles) | RoleBinding    **Resources:** Compute/Service profiles, Instances    **Verbs:** Create, view, manage |

For type of user, you can either select "Console" or "API Only". Select the latter if you want to limit the user to "programmatic access" to the workspace.

> **Note**
> - New users will be sent an activation email with a temporary password. They will be required to reset and create a new password before they can access the workspace.

### Existing Users

Users already in the Organization can be added to the workspace quickly as well.

- Click on "existing users"
- Select a role from the drop down
- Select one or more users from the drop down list and Save.

### Delete Users

To remove a user from a workspace, click on the "ellipses" on the far right of the user row and click on "actions" and select "delete".

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/delete_users.png)](https://docs.rafay.co/aiml/gpupaas/img/delete_users.png)

---

## Delete Workspace

Users with the "PaaS Workspace Admin" role are authorized to delete a workspace. They are considered owners/co-owners of the workspace.

- Click on the workspace menu on the left to view the list of all workspaces
- Click on the ellipses menu on the right of the workspace
- From the list of available actions, select "delete" to delete the workspace

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/delete_ws.png)](https://docs.rafay.co/aiml/gpupaas/img/delete_ws.png)

> **Note**
> Once a workspace is deleted, it cannot be recovered/restored.

---
