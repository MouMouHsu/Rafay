---
title: "Managed Kubernetes Clusters"
source: https://docs.rafay.co/aiml/gpupaas/users/k8s_type/
---

# Kubernetes

**Kubernetes** compute instances are well-suited for running distributed applications that need to scale dynamically and recover automatically from failures. They offer a structured environment for deploying workloads using containers, with support for managing deployments, updates, and resource usage across clusters. This compute option helps teams accelerate development cycles and maintain consistent application behavior across environments.

---

## Create K8s Compute Instance

To create a K8s compute instance, navigate to the **Developer Hub** and select the **Kubernetes** type.

- Click `New Kubernetes` to create a new instance.
- Click `View All` to view and manage existing K8s instances.

Users can also access using the left navigation pane under the Compute section.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/k8s_instance.png)](https://docs.rafay.co/aiml/gpupaas/img/k8s_instance.png)

Clicking on the Kubernetes option from the left pane or selecting "New Kubernetes" from the home page opens a wizard that allows users to select from the available K8s type Compute Profiles.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/k8s_available.png)](https://docs.rafay.co/aiml/gpupaas/img/k8s_available.png)

Once the profile is selected, provide the required details. If pricing for the selected profile is configured in [Global Settings](https://docs.rafay.co/aiml/csp/global_settings/) by the Org Admin, a monthly estimate will be displayed.

- Name: Enter a unique name for the compute instance
- Description: Provide a brief summary of the instance
- Compute Profile: Proceed with the selected profile
- Workspace: Select the workspace from the drop-down menu
- Based on the configuration fields defined in the selected compute profile and its associated template, users must provide the required details
- Click **Deploy**

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/k8s_inputs.png)](https://docs.rafay.co/aiml/gpupaas/img/k8s_inputs.png)

Once an instance deployment is initiated, the **Status Tracker** section displays real-time progress and estimated completion time.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/k8s_in_prog.png)](https://docs.rafay.co/aiml/gpupaas/img/k8s_in_prog.png)

> Note: The deployment typically takes 50–60 minutes to complete.

Upon successful deployment, the status updates to ***Success***.

---

### Kube Config

Once the deployment is complete, the following screen appears, displaying the Kube Config and available Utilities. Users can view or download the `Kube Config` file for the cluster using the **View** and **Download** options.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/kube_config.png)](https://docs.rafay.co/aiml/gpupaas/img/kube_config.png)

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/view_kubeconfig.png)](https://docs.rafay.co/aiml/gpupaas/img/view_kubeconfig.png)

---

### Utilities

Once the Kubernetes instance is deployed, the **Utilities** section provides quick access to different monitoring and management tools. Clicking each button opens the respective page for the deployed instance:

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/utilities.png)](https://docs.rafay.co/aiml/gpupaas/img/utilities.png)

- **K8s Resources**: Displays the Kubernetes resources (such as Namespaces, Pods, Deployments, ReplicaSets, StatefulSets, DaemonSets, and Jobs) running within the instance.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/resources.png)](https://docs.rafay.co/aiml/gpupaas/img/resources.png)

- **Utilization Dashboard**: Shows detailed metrics on cluster health, CPU usage, memory usage, storage utilization, node count, and pod count.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/utlitzation.png)](https://docs.rafay.co/aiml/gpupaas/img/utlitzation.png)

- **Kubectl**: Opens a built-in terminal interface where users can execute `kubectl` commands directly against the cluster (e.g., viewing namespaces, pods, and configurations).
- **GPU Dashboard**: Provides real-time monitoring of GPU metrics including utilization, memory usage, SM/Memory clocks, temperature, and power consumption.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/gpu_dashboard.png)](https://docs.rafay.co/aiml/gpupaas/img/gpu_dashboard.png)

> **Important**
> The list of compute profiles presented to the end user is dynamic i.e. if the administrator updates or publishes a new profile, it will be immediately available to the end user as an option to consume.

---

## View Compute Instances

When the user clicks on Kubernetes, they are presented with the list of K8s compute instances in their workspace.

- Name
- Workspace
- Created At
- Services
- Publish Status
- Actions

[![Compute Instances](https://docs.rafay.co/aiml/gpupaas/img/k8s_success.png)](https://docs.rafay.co/aiml/gpupaas/img/k8s_success.png)

---

### Actions

Once an instance has been launched and is operational, users can perform a number of actions on it. This section describes the list of actions that can be performed.

#### Remote Access

The end user will need access to the remote instance that is operating **behind a firewall** in a private data center or public cloud. These instances can be either a Kubernetes namespace or a Virtual Cluster or a Dedicated Kubernetes cluster. The secure remote access capability is powered by Rafay's [Zero Trust Kubectl (ZTKA)](https://docs.rafay.co/accessproxy/overview/) feature.

The user can download the ZTKA "kubeconfig" file, configure their KubeCTL CLI utility to use it and access the instance remotely. The user can also click on the "kubectl" button which will open a web shell that will allow them to securely interact with the instance.

#### Collaborators

It is common for end users to work with both internal (i.e. employees) and external (i.e. outside the company) collaborators. Users can easily add/remove other users to a specific instance. Once the user enters the collaborator's "email address", an email invitation is sent to the user with details on how they can access this instance. Once they login, they will have the same level (i.e. role/privilege) of access to the instance.

---

## Delete Compute Instance

If the user does not require a compute instance, they can delete it by clicking on the delete icon on the right of the compute instance

> **Note**
> This action is irreversible and cannot be undone.

---
