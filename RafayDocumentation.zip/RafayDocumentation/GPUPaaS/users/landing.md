---
title: "Landing Page"
source: https://docs.rafay.co/aiml/gpupaas/users/landing/
---

# Landing Page

When the end user successfully authenticates into Rafay GPU PaaS , they are presented with a landing/home page that provides them with a quick summary of all the resources that are active and in use. The landing page is meant to provide the user with a bird's eye view of everything in their tenant and act as the launch point for their tasks.

---

## Summary

The user is provided with a quick view into the number of resources of what type they have spanning workspaces, compute instances, notebooks, jobs, inferences, custom services.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/landing_page.png)](https://docs.rafay.co/aiml/gpupaas/img/landing_page.png)

---

## Available Profiles

The user is also presented with a list of available compute and service profiles available to them. By clicking on them, they can quickly configure and launch instances and services in literally two clicks. The user can also filter profiles by type to quickly zero in on the profiles that they would like to use.

---
