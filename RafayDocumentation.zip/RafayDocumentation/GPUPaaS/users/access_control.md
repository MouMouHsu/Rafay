---
title: "Role based Access Control"
source: https://docs.rafay.co/aiml/gpupaas/users/access_control/
---

# Access

Typical end users of GPU PaaS  are data scientists, ML researchers or developers. Once the Org Admin provides the user with the appropriate role, they will have the ability to login into the self service portal, create and manage GPU workspaces, request for GPUs, compute, deploy and operate Jupyter notebooks and other services made available by the administrator or service provider. One of the goals of GPU PaaS  service is to enable IT/Operations or Platform teams to empower these users with an **On Demand** experience to get access to a fully operational and ready to use environment where they can perform their tasks efficiently.

---

## Access Control

All end users have to authenticate before they can access the self service portal in GPU PaaS .

### Authentication (Local vs SSO)

The Rafay platform provides the means for an Org Admin to manage users locally in their Org. Local users are authenticated by the Rafay platform before they are provided access. Admins can require users to use Multi Factor Authentication (MFA) as well. Please review detailed documentation for [Local Users](https://docs.rafay.co/security/rbac/users/), [Groups](https://docs.rafay.co/security/rbac/groups/) and [MFA](https://docs.rafay.co/security/rbac/mfa/) for additional information.

It is a security best practice and a recommendation for enterprises to integrate their Rafay Org with their corporate Identity Provider (IdP). This integration will help provide end users with a superior user experience (i.e. single sign on) and also centralize authentication of users. Please review our [IdP Integration](https://docs.rafay.co/integrations/sso/overview/) documentation for instructions on how to implement this.

> **Info**
> Administrators can also optionally centralize authorization at their IdP as well.

### Authorization

Authorization of user access to GPU PaaS is performed using [Roles](https://docs.rafay.co/security/rbac/roles/). If end users can successfully authenticate and demonstrate they have been assigned the necessary roles, they will be able to access their Self Service Portal. The roles that are relevant for GPU PaaS are:

- Data Scientist, ML Researcher, Developer
- PaaS Workspace Administrator
- Paas Workspace Collaborator
- PaaS Workspace Collaborator Read Only

#### Groups

At scale, it will be impractical to manage roles for every user on a 1x1 basis. It is a common and recommended practice to use **groups** as a way to streamline the management burden. For example, administrators can create a **group** called "data scientists" and assign the role "Data Scientist" to the group. With this approach, they just need to add a user to this group to onboard a new data scientist.

> **Note**
> Organizations that are unable to centralize group management in their Identity Provider can **[override](https://docs.rafay.co/security/rbac/groups/)** authorization in the Rafay Platform. The overrides can either augment or replace the authorization details for the user.
