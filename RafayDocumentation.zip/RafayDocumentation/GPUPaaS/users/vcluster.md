---
title: "Compute Instances - vCluster"
source: https://docs.rafay.co/aiml/gpupaas/users/vcluster/
---

# vCluster

The **vCluster** compute instance type allows users to provision virtual Kubernetes clusters that operate within a shared underlying Kubernetes environment. These instances provide logically isolated control planes, giving the experience of working with a dedicated cluster without the overhead of managing full infrastructure. vCluster instances are ideal for teams that need lightweight, cost-effective, and quickly deployable Kubernetes environments for use cases such as tenant separation, development testing, or CI/CD workflows. They combine operational efficiency with strong workload isolation.

---

## Create vCluster Compute Instance

To create a vCluster compute instance, navigate to the **Developer Hub** and select the **vCluster** type.

- Click `New vCluster` to create a new instance.
- Click `View All` to view and manage existing vCluster instances.

Users can also access using the left navigation pane under the Compute section.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/vcluster_homepage.png)](https://docs.rafay.co/aiml/gpupaas/img/vcluster_homepage.png)

Clicking on the vCluster option from the left pane or selecting "New vCluster" from the home page opens a wizard that allows users to select from the available vCluster Compute Profiles.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/availavle_vlcus.png)](https://docs.rafay.co/aiml/gpupaas/img/availavle_vlcus.png)

Once the profile is selected, provide the required details. If pricing for the selected profile is configured in [Global Settings](https://docs.rafay.co/aiml/csp/global_settings/) by the Org Admin, a monthly estimate will be displayed.

- Name: Enter a unique name for the compute instance
- Description: Provide a brief summary of the instance
- Compute Profile: Proceed with the selected profile
- Workspace: Select the workspace from the drop-down menu
- Based on the configuration fields defined in the selected compute profile and its associated template, users must provide the required details
- Click **Deploy**

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/vclus_input.png)](https://docs.rafay.co/aiml/gpupaas/img/vclus_input.png)

The instance initially displays a status of ***In Progress***.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/vclus_inprog.png)](https://docs.rafay.co/aiml/gpupaas/img/vclus_inprog.png)

Upon successful deployment, the status updates to ***Success***.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/vclus_success.png)](https://docs.rafay.co/aiml/gpupaas/img/vclus_success.png)

> **Important**
> The list of compute profiles presented to the end user is dynamic i.e. if the administrator updates or publishes a new profile, it will be immediately available to the end user as an option to consume.

---

## View Compute Instances

When the user clicks on vCluster, they are presented with the list of vCluster compute instances in their workspace.

- Name
- Workspace
- Created At
- Services
- Publish Status
- Actions

[![Compute Instances](https://docs.rafay.co/aiml/gpupaas/img/view_vcluster.png)](https://docs.rafay.co/aiml/gpupaas/img/view_vcluster.png)

---

## Integrated Developer Tools for Kubernetes Compute

Developers and data scientists using virtual clusters (vClusters) or dedicated Kubernetes clusters now have access to a suite of integrated tools for remote access, observability, and troubleshooting.

[![Compute Instances](https://docs.rafay.co/aiml/gpupaas/img/vclusters_kubeconfig.png)](https://docs.rafay.co/aiml/gpupaas/img/vclusters_kubeconfig.png)

- In the **vCluster list**, click on the desired vCluster instance to open its details page.
- Click **View** to see the configuration or **Download** to securely download the Kubeconfig file for the compute instance.

[![Compute Instances](https://docs.rafay.co/aiml/gpupaas/img/view_config.png)](https://docs.rafay.co/aiml/gpupaas/img/view_config.png)

- Click **K8s Resources** to access the vCluster resources page. This visual dashboard allows users to view and interact with Kubernetes objects such as pods, deployments, and namespaces.

[![Compute Instances](https://docs.rafay.co/aiml/gpupaas/img/instance_resources.png)](https://docs.rafay.co/aiml/gpupaas/img/instance_resources.png)

- Click **Utilization Dashboard** to monitor real-time metrics for CPU, memory, and storage. Metrics can be viewed for the `last 1 hour` or `last 24 hours`. The refresh interval can also be customized.

> **Info**
> The **Utilization Dashboard** is not available for vClusters, as they use a minimal blueprint without integrated monitoring. This dashboard is supported for host clusters (e.g., MKS, GKE) where monitoring is enabled.

- Click **Kubectl** to launch a browser-based shell and execute `kubectl` commands directly against the cluster.

[![Compute Instances](https://docs.rafay.co/aiml/gpupaas/img/vcluster_kubectl.png)](https://docs.rafay.co/aiml/gpupaas/img/vcluster_kubectl.png)

---

## Actions

Once an instance has been launched and is operational, users can perform a number of actions on it. This section describes the list of actions that can be performed.

### Remote Access

The end user will need access to the remote instance that is operating **behind a firewall** in a private data center or public cloud. These instances can be either a Kubernetes namespace or a Virtual Cluster or a Dedicated Kubernetes cluster. The secure remote access capability is powered by Rafay's [Zero Trust Kubectl (ZTKA)](https://docs.rafay.co/accessproxy/overview/) feature.

The user can download the ZTKA "kubeconfig" file, configure their KubeCTL CLI utility to use it and access the instance remotely. The user can also click on the "kubectl" button which will open a web shell that will allow them to securely interact with the instance.

### Collaborators

It is common for end users to work with both internal (i.e. employees) and external (i.e. outside the company) collaborators. Users can easily add/remove other users to a specific instance. Once the user enters the collaborator's "email address", an email invitation is sent to the user with details on how they can access this instance. Once they login, they will have the same level (i.e. role/privilege) of access to the instance.

---

## Delete Compute Instance

If the user does not require a compute instance, they can delete it by clicking on the delete icon on the right of the compute instance

> **Note**
> This action is irreversible and cannot be undone.

---
