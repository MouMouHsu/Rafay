---
title: "Compute Instances - Virtual Machines"
source: https://docs.rafay.co/aiml/gpupaas/users/vm/
---

# Virtual Machines

**Virtual Machine** compute instances provide isolated environments with dedicated CPU, memory, and storage resources, making them suitable for workloads that require full operating system access and consistent performance. This compute type is commonly used for hosting traditional applications, running software that depends on OS-level features, or replicating production-like environments for testing and validation. Its flexibility and ability to scale based on workload demands make it a reliable choice for a wide range of enterprise use cases.

---

## Create VM Compute Instance

To create a VM compute instance, navigate to the **Developer Hub** and select the **Virtual Machine** type.

- Click `New Virtual Machines` to create a new instance.
- Click `View All` to view and manage existing VM instances.

Users can also access using the left navigation pane under the Compute section.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/vm_home.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_home.png)

Clicking on the Virtual Machine option from the left pane or selecting "New Virtual Machine" from the home page opens a wizard that allows users to select from the available VM type Compute Profiles.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/available_vms.png)](https://docs.rafay.co/aiml/gpupaas/img/available_vms.png)

Once the profile is selected, provide the required details. If pricing for the selected profile is configured in [Global Settings](https://docs.rafay.co/aiml/csp/global_settings/) by the Org Admin, a monthly estimate will be displayed.

- Name: Enter a unique name for the compute instance
- Description: Provide a brief summary of the instance
- Compute Profile: Proceed with the selected profile
- Workspace: Select the workspace from the drop-down menu
- Based on the configuration fields defined in the selected compute profile and its associated template, users must provide the required details
- Click **Deploy**

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/vm_inputs.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_inputs.png)

The instance initially displays a status of ***In Progress***.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/vm_inprog.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_inprog.png)

Upon successful deployment, the status updates to ***Success***.

[![Create Compute Instance](https://docs.rafay.co/aiml/gpupaas/img/vm_success.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_success.png)

> **Important**
> The list of compute profiles presented to the end user is dynamic i.e. if the administrator updates or publishes a new profile, it will be immediately available to the end user as an option to consume.

---

## View Compute Instances

When the user clicks on Virtual Machines, they are presented with the list of Virtual Machine compute instances in their workspace.

- Name
- Workspace
- Created At
- Services
- Publish Status
- Actions

[![Compute Instances](https://docs.rafay.co/aiml/gpupaas/img/vm_success.png)](https://docs.rafay.co/aiml/gpupaas/img/vm_success.png)

---

## Delete Compute Instance

If the user does not require a compute instance, they can delete it by clicking on the delete icon on the right of the compute instance

> **Note**
> This action is irreversible and cannot be undone.

---
