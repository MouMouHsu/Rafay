---
title: "Compute Instances"
source: https://docs.rafay.co/aiml/gpupaas/users/compute_overview/
---

# Overview

A newly created workspace will have no active compute instances or any services. The end user can select from the available list of compute profiles in the Org and launch compute instances. The end user is provided with a vending machine type experience and presented with a list of available options that will map to the list of [compute profiles](https://docs.rafay.co/aiml/administration/overview/) that are curated and managed by the administrator (or GPU Cloud Provider for their customer orgs)

---

## Create Compute Instance

To create a compute instance, navigate to the **Developer Hub** and select a Compute type. This interface provides options to launch and manage resource instances using predefined compute profiles for AI/ML workloads.

By default, the **Developer Hub** supports the following predefined compute types:

- [Baremetal](https://docs.rafay.co/aiml/gpupaas/baremetal/)
- [Virtual Machines](https://docs.rafay.co/aiml/gpupaas/vm/)
- [Kubernetes](https://docs.rafay.co/aiml/gpupaas/k8s_type/)
- [vCluster](https://docs.rafay.co/aiml/gpupaas/vcluster/)

These types are visible in the Developer Hub UI and available for end users when creating compute instances.

Each type includes a short description in the `Developer Hub` and options to:

- Click `New <Instance Type>` to create a new instance.
- Click `View All` to view and manage existing instances.

In addition to the default types, users can define and register custom compute types based on their requirements. For example, a custom category such as `TestCategory` may appear in the list

Users can also access these types using the left navigation pane under the Compute section.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/comp_instance_home.png)](https://docs.rafay.co/aiml/gpupaas/img/comp_instance_home.png)

---
