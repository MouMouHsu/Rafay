---
title: "Custom Services"
source: https://docs.rafay.co/aiml/gpupaas/users/custom_services/
---

# Custom Services

Any custom or third-party AI/ML applications that administrators wish to package and expose as reusable service profiles can be made available to end users through a 1-click deployment experience using Custom Services.

Rafay allows administrators to define and publish a variety of custom services tailored to their organization’s needs. Examples of commonly published custom services include:

1. Inference as a Service
2. [Ray as a Service](https://docs.rafay.co/mlops-ray/overview/)
3. [MLOps based on Kubeflow](https://docs.rafay.co/mlops-kubeflow/overview/)
4. Fine Tuning as a Service

These services are defined as Custom Service Profiles, enabling a standardized, repeatable deployment process while abstracting infrastructure complexities for end users.

---

## Create Custom Service

To create a new custom service,

- Select the service type **Custom Service** from the left-hand menu of the console
- Choose a suitable profile based on the requirements

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/service_select.png)](https://docs.rafay.co/aiml/gpupaas/img/service_select.png)

Once the profile is selected, provide the required details. If pricing for the selected profile is configured in [Global Settings](https://docs.rafay.co/aiml/csp/global_settings/) by the Org Admin, a monthly estimate will be displayed.

- Provide a **Name** for the service (adding a Description is optional)
- Select the desired **Workspace** from the dropdown list
- Enter the required **API Key** and **Controller Endpoint** values
- Based on the configuration fields defined in the selected service profile and its associated template, users must provide the required details
- Click on **Deploy** to launch the service

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/customser_input.png)](https://docs.rafay.co/aiml/gpupaas/img/customser_input.png)

Depending on the complexity of the service, it may take a few minutes for all components to be deployed, become operational, and ready for use.

---

## Use Custom Service

Once a custom service has been successfully deployed, the user will be presented with instructions on how to access it and use it. For custom services, administrators designing the custom service need to make sure that they make this available to users. For custom services accessible via web browsers, administrators can decide to expose the service either via Ingress or a Load Balancer.

---

## View Custom Services

Clicking on the custom services menu will list of all the services the user has access to, their status and additional details about them. Note that custom services may span different workspaces and different instances. To view details about a specific custom service, users just need to click on the name.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/list_service.png)](https://docs.rafay.co/aiml/gpupaas/img/list_service.png)

---

## Delete Custom Service

To delete a custom service, users should click on the ellipses on the far right of the selected service and select delete.

> **Info**
> Once deletion has been initiated, it cannot be stopped or reversed. Users can create a new custom service if required.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/delete_cser.png)](https://docs.rafay.co/aiml/gpupaas/img/delete_cser.png)

---
