---
title: "Services"
source: https://docs.rafay.co/aiml/gpupaas/users/services_overview/
---

# Overview

The Services tab in the Developer Hub provides a unified interface to deploy and manage various AI/ML workloads using predefined service profiles. These profiles simplify the process of launching and managing infrastructure-backed applications by abstracting common configurations and operational requirements.

Rafay provides a number of services that administrators can make available to their end users, offering a "1-click" deployment experience for both native and custom AI/ML applications. These include:

- **[Inference as a Service](https://docs.rafay.co/aiml/gpupaas/inference/)**: Deploy trained models as APIs for real-time predictions using structured endpoint configurations.
- **[Notebooks](https://docs.rafay.co/aiml/gpupaas/notebook/)**: Launch interactive environments for data exploration, visualization, and development.
- **[AI/ML Jobs](https://docs.rafay.co/aiml/gpupaas/jobs/)**: Execute training, tuning, or batch inference workflows with scalable compute resources.
- **[Custom Services](https://docs.rafay.co/aiml/gpupaas/custom_services/)**: Deploy any custom or third-party application by publishing them as service profiles tailored to internal or business-specific needs.

These services are designed to deliver a standardized, repeatable, and scalable experience for end users while giving administrators control over resource configuration and access management.

---

## Create Custom Services

To create a service, open the **Developer Hub** and navigate to the **Home** page. The interface displays a categorized view with tabs for **Compute** and **Services**. Under the **Services** tab, users can view and manage various service profiles including **Custom Services**.

Each service type, such as **Notebooks**, **Inference Endpoints**, **AI/ML Jobs**, and **Custom Services**, is presented as a card with a description and quick-action buttons.

To begin creating a new service:

- Click on **New** in the corresponding service card.
- Alternatively, click **View All** to navigate to the full page for that service type.
- Users can also use the left-side menu under the **Services** section to directly access a specific service page.

Service Profiles are predefined configurations designed to define, provision, and manage services tailored to specific business or technical requirements. These profiles offer a structured, standardized, and repeatable approach for efficient service deployment and management.

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/custom_service_home.png)](https://docs.rafay.co/aiml/gpupaas/img/custom_service_home.png)

---

### Customizing Compute Types

**Super Admins** can extend this list by defining custom service types in the platform configuration via the **Ops Console**. For example, a custom type can be added to categorize services based on internal naming conventions or specific business requirements.

```
{
  "service": {
    "nav_label": "Services",
    "types": [
      {
        "value": "notebook",
        "label": "Notebooks",
        "icon": "zmdi zmdi-laptop",
        "description": "Notebooks are applications that run on compute instances.",
        "objectLabel": "Notebook",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-yellow-500/10 bg-yellow-100"
        },
        "homeServiceCard": {
          "description": "Notebook Profiles are predefined configurations that deliver an interactive environment for tasks such as data analysis, visualization, and machine learning development. By preconfiguring the required resources, tools, and dependencies, these profiles simplify the creation and management of notebook instances.",
          "iconClass": "border-red-500/10 bg-red-100 text-red-700/70"
        }
      },
      {
        "value": "inference",
        "label": "Inference Endpoints",
        "icon": "zmdi zmdi-cloud",
        "description": " Inference services are applications that run on compute instances.",
        "objectLabel": "Inference Endpoint",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-yellow-500/10 bg-yellow-100"
        },
        "homeServiceCard": {
          "description": "Inference Endpoint Profiles are predefined configurations designed to simplify and accelerate the deployment of machine learning models as APIs. These profiles provide a structured and standardized approach to serving trained models, enabling rapid prototyping and real-time predictions.",
          "iconClass": "border-yellow-500/10 bg-yellow-100 text-yellow-700/70"
        }
      },
      {
        "value": "jobs",
        "label": "AI/ML Jobs",
        "icon": "zmdi zmdi-brain",
        "description": " Jobs services are applications that run on compute instances.",
        "objectLabel": "AI/ML Job",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-blue-500/10 bg-blue-100"
        },
        "homeServiceCard": {
          "description": "AI/ML Job Profiles are predefined configurations designed to streamline and optimize AI/ML tasks, including training, tuning, and deploying machine learning models. These profiles deliver a consistent, scalable, and efficient setup across the machine learning lifecycle, reducing operational complexity and simplifying workflows.",
          "iconClass": "border-purple-500/10 bg-purple-100 text-purple-700/70"
        }
      },
      {
        "value": "custom",
        "label": "Custom Services",
        "icon": "zmdi zmdi-robot",
        "description": " Custom services are applications that run on compute instances.",
        "objectLabel": "Custom Service",
        "templateCard": {
          "labelClass": "text-red-700/70",
          "iconClass": "border-pink-500/10 bg-pink-100"
        },
        "homeServiceCard": {
          "description": "Custom Service Profiles are predefined configurations designed to define, provision, and manage services tailored to unique business requirements. These profiles offer a structured, standardized, and repeatable method for deploying and managing services efficiently.",
          "iconClass": "border-pink-500/10 bg-pink-100 text-pink-700/70"
        }
      }
    ]
  }
}
```

[![Hierarchy](https://docs.rafay.co/aiml/gpupaas/img/paas_customizations.png)](https://docs.rafay.co/aiml/gpupaas/img/paas_customizations.png)

---
