---
title: "Common Use Cases"
source: https://docs.rafay.co/usecases/overview/
category: Use-Cases
---

# Common Use Cases

- **Air Gapped Environments**   Deploy and operate Kubernetes clusters and infrastructure resources in highly regulated, air gapped networks.  [**Self Hosted Controller**](https://docs.rafay.co/selfhosted/overview/)
- **Cost Optimization**   Track and visualize costs associated with multi-tenant Kubernetes clusters. Implement charge-backs and identify/eliminate wastage by resizing over-allocated resources.  [**Visibility**](https://docs.rafay.co/usecases/cost-optimization/cost-visibility/)
- **Environment & Resource Provisioning**   Provide the means for developers to create reliable and secure environments via self-service workflows based on standardized infrastructure blueprints.  [**Landing Zones**](https://docs.rafay.co/usecases/env-res-prov/landingzone/)  |  [**Self Service**](https://docs.rafay.co/usecases/env-res-prov/std-res-creation/)
- **Kubernetes for Customer Sites**   Deploy and operate Kubernetes clusters in remote offices, branches and customer sites operating behind firewalls in isolated networks.  [**Customer Sites**](https://docs.rafay.co/usecases/paas/b2b/)
- **Kubernetes Lifecycle Management**   Provision, upgrade and manage Kubernetes clusters at scale across your organization, supporting 10-100s of application teams.  [**Hybrid Cloud**](https://docs.rafay.co/usecases/k8s-lifecycle/hybrid/)  |  [**Multi Cloud**](https://docs.rafay.co/usecases/k8s-lifecycle/multicloud/)  |  [**Cloud Migration**](https://docs.rafay.co/usecases/k8s-lifecycle/onprem-to-cloud/)  |  [**Rapid OS Updates**](https://docs.rafay.co/usecases/k8s-lifecycle/ami-updates/)  |  [**Centralized Visibility**](https://docs.rafay.co/usecases/k8s-lifecycle/central-visibility/)  |  [**Self Service**](https://docs.rafay.co/usecases/k8s-lifecycle/release-cycle/)  |  [**Standardization**](https://docs.rafay.co/usecases/k8s-lifecycle/std-clusters/)  |  [**HPC**](https://docs.rafay.co/usecases/k8s-lifecycle/hpc-clusters/)
- ![➡](https://cdn.jsdelivr.net/gh/jdecked/twemoji@16.0.1/assets/svg/27a1.svg) **Migration to Rafay**   Effortless and seamless migration of Kubernetes clusters and applications from other commercial and DIY platforms to Rafay  [**Rancher**](https://docs.rafay.co/usecases/migration/rancher/)  |  [**Mirantis**](https://docs.rafay.co/usecases/migration/mirantis/)
- **Multi Tenant Infrastructure**   Allow different teams to use the same Kubernetes cluster resources efficiently. Reduce costs and complexity while guaranteeing isolation and governance.  [**Hybrid Cloud**](https://docs.rafay.co/usecases/k8s-lifecycle/hybrid/)  |  [**Multi Cloud**](https://docs.rafay.co/usecases/k8s-lifecycle/multicloud/)
- **Standardization & Governance**   Allow multiple teams to use the same Kubernetes cluster efficiently. Reducing costs and complexity while maintaining proper isolation and governance.  [**Add-On Mgmt**](https://docs.rafay.co/usecases/standardization/addons/)  |  [**Add-On Workflows**](https://docs.rafay.co/usecases/standardization/addon-workflow/)  |  [**Compliance**](https://docs.rafay.co/usecases/standardization/compliance/)  |  [**Access via SSO**](https://docs.rafay.co/usecases/standardization/sso-access/)

---
