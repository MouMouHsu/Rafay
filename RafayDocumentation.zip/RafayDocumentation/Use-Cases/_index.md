# Use-Cases 文件索引

來源：https://docs.rafay.co/ ，擷取日期 2026-10-22

- [Common Use Cases](usecases/overview.md)  `/usecases/overview/`
- [Cost Visibility & Chargeback](usecases/cost-optimization/cost-visibility.md)  `/usecases/cost-optimization/cost-visibility/`
- [Standardized Resource Creation](usecases/env-res-prov/std-res-creation.md)  `/usecases/env-res-prov/std-res-creation/`
- [Cloud Landing Zone Management](usecases/env-res-prov/landingzone.md)  `/usecases/env-res-prov/landingzone/`
- [Automated AMI Refresh for Compliance](usecases/k8s-lifecycle/ami-updates.md)  `/usecases/k8s-lifecycle/ami-updates/`
- [Standardized Cluster Builds and Management](usecases/k8s-lifecycle/std-clusters.md)  `/usecases/k8s-lifecycle/std-clusters/`
- [Large-scale Upstream Kubernetes for HPC Workloads](usecases/k8s-lifecycle/hpc-clusters.md)  `/usecases/k8s-lifecycle/hpc-clusters/`
- [Multi-cloud Kubernetes](usecases/k8s-lifecycle/multicloud.md)  `/usecases/k8s-lifecycle/multicloud/`
- [Centralized Cluster Management and Visibility](usecases/k8s-lifecycle/central-visibility.md)  `/usecases/k8s-lifecycle/central-visibility/`
- [Accelerated Release Cycles](usecases/k8s-lifecycle/release-cycle.md)  `/usecases/k8s-lifecycle/release-cycle/`
- [Hybrid Cloud Kubernetes Management](usecases/k8s-lifecycle/hybrid.md)  `/usecases/k8s-lifecycle/hybrid/`
- [On-premises to Cloud Migration](usecases/k8s-lifecycle/onprem-to-cloud.md)  `/usecases/k8s-lifecycle/onprem-to-cloud/`
- [Mirantis to Rafay Migration](usecases/migration/mirantis.md)  `/usecases/migration/mirantis/`
- [Rancher to Rafay Migration](usecases/migration/rancher.md)  `/usecases/migration/rancher/`
- [Managed Kubernetes Service for Customer Sites](usecases/paas/b2b.md)  `/usecases/paas/b2b/`
- [Multi-tenant Self-service Clusters](usecases/selfservice/multitenant-selfservice.md)  `/usecases/selfservice/multitenant-selfservice/`
- [Consistent Addon Management Across Clusters](usecases/standardization/addons.md)  `/usecases/standardization/addons/`
- [Custom Workflow for Updating Kubernetes Addons](usecases/standardization/addon-workflow.md)  `/usecases/standardization/addon-workflow/`
- [Centralized Visibility for Compliance and Security](usecases/standardization/compliance.md)  `/usecases/standardization/compliance/`
- [Enterprise SSO for Kubernetes RBAC](usecases/standardization/sso-access.md)  `/usecases/standardization/sso-access/`
