# Catalog 文件索引

來源：https://docs.rafay.co/ ，擷取日期 2026-10-22

- [Template Catalog](template_catalog/introduction.md)  `/template_catalog/introduction/`
- [Overview](template_catalog/clusters.md)  `/template_catalog/clusters/`
- [System GKE Template](template_catalog/gke/system-gke.md)  `/template_catalog/gke/system-gke/`
- [Get Started with GKE System Template](template_catalog/get_started/gke_guide.md)  `/template_catalog/get_started/gke_guide/`
- [Rafay Managed Kubernetes Clusters (Rafay MKS)](template_catalog/mks/system-mks.md)  `/template_catalog/mks/system-mks/`
- [Rafay K8s Distro on Nutanix](template_catalog/nutanix/overview.md)  `/template_catalog/nutanix/overview/`
- [Getting Started with MKS on Nutanix](template_catalog/get_started/nutanix_guide.md)  `/template_catalog/get_started/nutanix_guide/`
- [Rafay MKS on VMware vSphere](template_catalog/vsphere-mks/overview.md)  `/template_catalog/vsphere-mks/overview/`
- [Rafay MKS on VMware vSphere](template_catalog/vsphere-mks/configuration.md)  `/template_catalog/vsphere-mks/configuration/`
- [Getting Started with MKS on VMware vSphere](template_catalog/get_started/vsphere_mks_guide.md)  `/template_catalog/get_started/vsphere_mks_guide/`
- [System AWS EKS Template](template_catalog/eks/eks.md)  `/template_catalog/eks/eks/`
- [Getting Started with EKS](template_catalog/get_started/eks/eks_guide.md)  `/template_catalog/get_started/eks/eks_guide/`
- [Configuration Examples for EKS System Template](template_catalog/get_started/eks/eks-system-template-examples.md)  `/template_catalog/get_started/eks/eks-system-template-examples/`
- [AWS Add-on IAM Permissions for EKS](template_catalog/get_started/eks/aws_addons_permissions.md)  `/template_catalog/get_started/eks/aws_addons_permissions/`
- [Overview](template_catalog/multi-tenancy.md)  `/template_catalog/multi-tenancy/`
- [Multi-tenancy on K8s- vCluster](template_catalog/vcluster/overview.md)  `/template_catalog/vcluster/overview/`
- [Getting Started with vCluster](template_catalog/get_started/vcluster/vcluster_guide.md)  `/template_catalog/get_started/vcluster/vcluster_guide/`
- [AWS Permissions for Amazon EKS Cluster Lifecycle Management](template_catalog/get_started/eks/eks_permissions.md)  `/template_catalog/get_started/eks/eks_permissions/`
- [Multi-tenancy on K8s - Namespace as a Service](template_catalog/ns_as_a_service/overview.md)  `/template_catalog/ns_as_a_service/overview/`
- [Getting Started with Namespace as a Service](template_catalog/get_started/namespace_asaservice.md)  `/template_catalog/get_started/namespace_asaservice/`
- [Overview](template_catalog/vm.md)  `/template_catalog/vm/`
- [End User Self Service for VMs](template_catalog/vm/benefits.md)  `/template_catalog/vm/benefits/`
- [Steps to Generate SSH Key Pair](template_catalog/vm/ssh-keygen.md)  `/template_catalog/vm/ssh-keygen/`
- [End User Self Service for VMs on VMware vSphere](template_catalog/vm/vsphere/overview.md)  `/template_catalog/vm/vsphere/overview/`
- [End User Self Service for VMs on VMware vSphere](template_catalog/vm/vsphere/administration.md)  `/template_catalog/vm/vsphere/administration/`
- [End User Self Service for VMs on VMware vSphere](template_catalog/vm/vsphere/enduser.md)  `/template_catalog/vm/vsphere/enduser/`
- [ServiceNow Workflow Approval](template_catalog/servicenow_workflow/overview.md)  `/template_catalog/servicenow_workflow/overview/`
- [Configure ServiceNow Catalog Integration](template_catalog/servicenow_workflow/configuration.md)  `/template_catalog/servicenow_workflow/configuration/`
- [Jira Workflow Approval](template_catalog/jira_workflow/overview.md)  `/template_catalog/jira_workflow/overview/`
- [Configure Jira Catalog Integration](template_catalog/jira_workflow/configuration.md)  `/template_catalog/jira_workflow/configuration/`
