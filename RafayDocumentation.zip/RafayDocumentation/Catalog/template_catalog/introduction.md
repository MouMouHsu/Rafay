---
title: "Template Catalog"
source: https://docs.rafay.co/template_catalog/introduction/
category: Catalog
---

# Introduction

The **Template Catalog** offers a centralized collection of pre-built templates designed to simplify and standardize complex operations. These templates provide all the required configurations by default, eliminating the need for users to write code or scripts to set up resource values. Users can either use the templates as they are or edit the resource values based on specific requirements. Whether it's managing clusters, deploying AI/ML workflows, or integrating with cloud platforms, the catalog ensures quick, error-free setup and consistent deployments. By serving as a reliable starting point tailored to various use cases, these templates enhance productivity, save time, and uphold best practices.

---

## Personas

There are typically two personas involved with the templates in the catalog.

### Platform Admin

- **Responsibilities**:
- Managing templates within the organization, including:
  - Sharing templates with other projects.
  - Cloning and customizing templates to meet specific requirements.
  - Restricting input variables to ensure standardization while allowing flexibility where needed.
- **Roles Required**:
  - `ENVIRONMENT_ADMIN`
  - `ORG_ADMIN`

### End User

- **Responsibilities**:
- Consuming templates shared by the Platform Admin.
- Depending on permissions, they can:
  - Directly use the template by providing the required inputs (e.g., API Key, secret, credentials).
  - Override certain input variables if customization is permitted by the Platform Admin.
- **Role Required**:
- `ENVIRONMENT_TEMPLATE_USER`

---

## Access Template Catalogs

> 🔒 Important Note:
> Only Organization Admins can access and clone the template catalogs.

To access the Template Catalog:

- Navigate to the console and click on **System**
- Select **Template Catalog**. The templates are categorized for easy navigation:
  - **Cluster LCM**: Focuses on lifecycle management of clusters - **Rafay K8s Distro on VMware vSphere**: Streamlines Kubernetes deployment on vSphere with prebuilt configurations, secure access, and multi-cluster management. - **Rafay K8s Distro on Private Cloud**: Simplifies Kubernetes cluster deployment on bare metal and VMs with preconfigured networking, storage, and Cluster Blueprints. - **Google Kubernetes Engine (GKE)**: Automates GKE cluster provisioning on GCP with preconfigured add-ons, secure access, and Day 0/Day 2 support.
  - **Private Cloud and Public Cloud**: Cater to controlled and cloud-based deployments
  - **AI/ML and MLOps**: Streamline machine learning workflows
  - **Multi-Tenancy**: Helps isolate resources across teams
  - **Kubeflow**: Supports ML platform deployments
  - **GCP**: Facilitates integration with Google Cloud services

[![Audit Logs Console](https://docs.rafay.co/template_catalog/img/tempelate_catalog.png)](https://docs.rafay.co/template_catalog/img/tempelate_catalog.png)

- Click on **More Info** to view the template details for the selected system template.

For example, the ***Kubeflow on Private Cloud*** template enables the deployment of a Kubeflow-based machine learning platform on an MKS cluster. It highlights the resources provisioned, such as FEAST, Kubeflow 1.9, and MLFlow, and lists pre-requisites like a GPU-enabled host cluster, API key configuration, and agent setup. The page also provides GPU node configuration instructions and specifies an estimated environment launch time of 27 minutes. Similarly, users can view the template details for each system template by clicking **More Info**.

[![Audit Logs Console](https://docs.rafay.co/template_catalog/img/templates_moreinfo.png)](https://docs.rafay.co/template_catalog/img/templates_moreinfo.png)

---

## Clone Templates

Organization Admins can clone templates to their projects by clicking **Get Started**, customize them as needed, and share them with other projects in the organization, enabling users to use these templates for launching or creating environments

- Provide a name and version
- Select an existing project from the drop-down or create a new project

Below is an example where the "Jupyter Notebook" template is cloned into a project named **ai-demo**.

- Click **Continue**

[![Audit Logs Console](https://docs.rafay.co/template_catalog/img/clone-templates.png)](https://docs.rafay.co/template_catalog/img/clone-templates.png)

This navigates to the Environment Template page within the selected project, where users can proceed with configuring the environment template

[![Audit Logs Console](https://docs.rafay.co/template_catalog/img/project_templates.png)](https://docs.rafay.co/template_catalog/img/project_templates.png)

Users can either use the template as it is, with the resource configurations already available in the template, or customize it further as needed.

[![Audit Logs Console](https://docs.rafay.co/template_catalog/img/resource_edit.png)](https://docs.rafay.co/template_catalog/img/resource_edit.png)

In both scenarios, it is necessary to add **Agents** and configure the **Context** to ensure proper setup and functionality.

[![Audit Logs Console](https://docs.rafay.co/template_catalog/img/temp_agents.png)](https://docs.rafay.co/template_catalog/img/temp_agents.png)

Save the changes and launch this template to create an environment.

[![Audit Logs Console](https://docs.rafay.co/template_catalog/img/launch_environment.png)](https://docs.rafay.co/template_catalog/img/launch_environment.png)

> ⭐ Important Note:
> When a template is cloned to a project, PaaS admins can utilize these environment templates to create compute instances within the same project through PaaS Studio, streamlining the process and ensuring consistency in deployments.

---

## Agent Configuration

An agent must be configured in the target project where the template is used. Without this, templates cannot be launched.

---

### Role Requirements Summary

- **Platform Admin**:
  - `ENVIRONMENT_ADMIN`
  - `ORG_ADMIN`
- **End User**:
  - `ENVIRONMENT_TEMPLATE_USER`

## Templating Workflows with Rafay

The following diagram illustrates the typical workflow for using environment templates to deliver an on-demand, consumable experience. For example, Cluster as a Service (CaaS) template workflows, and more.

```
sequenceDiagram
    autonumber
    actor PT as Platform Team
    participant RC as Rafay Controller
    participant RT as Reusable Templates (RTs)
    participant PRJ as Project (Team/SBU)
    actor SRE as SRE Team
    participant CL as Cluster
    participant OBS as Central Visibility

    Note over PT,RC: Step 1 — Build reusable templates
    PT->>RC: Create RTs (clusters, blueprints etc)
    RC->>RT: Version and store templates

    Note over PT,PRJ: Step 2 — Controlled sharing
    PT->>RC: Share RTs via hierarchical project sharing
    RC->>PRJ: Grant scoped access (RBAC, isolation)
    RC-->>SRE: Expose allowed variables only

    Note over SRE,RC: Step 3 — Self-service cluster creation
    SRE->>RC: Instantiate cluster using RTs with overrides
    RC->>CL: Provision cluster on cloud provider
    RC->>OBS: Register for centralized visibility

    Note over PT,CL: Step 4 — Fleet-wide updates
    PT->>RT: Select the fleet of environments
    RC->>CL: Rollout updates across fleets
    RC->>OBS: Show consolidated fleet-wide status and progress
```

---
