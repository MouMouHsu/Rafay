---
title: "Overview"
source: https://docs.rafay.co/template_catalog/multi-tenancy/
category: Catalog
---

# Overview

- **vCluster**   Provide end users with self-service provisioning of lightweight, virtual Kubernetes clusters (vClusters) running inside namespaces on a host Kubernetes cluster, enabling isolated and scalable multi-tenant Kubernetes environments.  [**Overview**](https://docs.rafay.co/template_catalog/vcluster/overview/) | [**Get Started**](https://docs.rafay.co/template_catalog/get_started/vcluster/vcluster_guide/)
- **Namespace as a Service**   Provide end users with self-service provisioning of Kubernetes namespaces on a shared cluster, enabling secure, isolated environments for deploying and managing applications.  [**Overview**](https://docs.rafay.co/template_catalog/ns_as_a_service/overview/) | [**Get Started**](https://docs.rafay.co/template_catalog/get_started/namespace_asaservice/)
