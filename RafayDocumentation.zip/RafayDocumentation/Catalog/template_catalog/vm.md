---
title: "Overview"
source: https://docs.rafay.co/template_catalog/vm/
category: Catalog
---

# Overview

- **Kernel Virtual Machine (KVM)**   Provide end users with self service provisioning of Virtual Machines (VMs) on [Kernel Virtual Machine-KVM](https://linux-kvm.org/page/Main_Page) for Linux on x86 hardware.  [**Overview**](https://docs.rafay.co/aiml/vm_service/overview/) | [**Get Started**](https://docs.rafay.co/aiml/vm_service/procedure/)
- **VMware vSphere**   Provide end users with self service provisioning of Virtual Machines (VMs) on [VMware vSphere](https://www.vmware.com/products/cloud-infrastructure/vsphere) cloud computing platform.  [**Overview**](https://docs.rafay.co/template_catalog/vm/vsphere/overview/) | [**Administration**](https://docs.rafay.co/template_catalog/vm/vsphere/administration/) | [**User Self Service**](https://docs.rafay.co/template_catalog/vm/vsphere/enduser/) | [**Videos**](https://www.youtube.com/watch?v=YuFm-GVstfg)
