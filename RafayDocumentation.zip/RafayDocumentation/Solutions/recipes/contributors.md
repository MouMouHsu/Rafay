---
title: "Technology Partners"
source: https://docs.rafay.co/recipes/contributors/
category: Solutions
---

# Contributors

## Overview

We collaborate extensively with technology partners in the CNCF landscape and beyond. To make things cookie cutter for our mutual users/customers, we invest in the development and ongoing maintenance of "Curated Recipes". Some of the recipes are developed by us, some are jointly developed with partners and some are developed/contributed by partners.

---

## Guidelines

Technology partners interested in developing and contributing joint recipes are recommended to follow the guidelines described below.

### Goals

The primary purpose of a joint recipe is for a mutual customer/prospect to be able to try things out quickly. They need to be able to get to the end state in 30 mins max. A recipe is not a best practices document. So, please ensure that there is very little friction (as few steps as possible) for the user.

---

### Org/Tenant

All technology partners that are part of our [Technology Alliances Program (TAP)](https://rafay.co/company/tech-partners/) are provided with a free, NFR Org/Tenant. Prospective partners can [sign up](https://rafay.co/become-a-partner/) to join our TAP program.

---

### Recommended Structure

In our experience, mutual users expect a curated experience from the joint recipes. We recommend a structure

#### Part 1

- High level overview of the "partner's" offering (typically one paragraph with URLs pointing to your website, docs etc.)
- Prerequisites (e.g. do they need a license, type of cluster, what kind of resources, etc.)
- Assumptions (e.g. cluster provisioned or imported into a project in an Org)

> **Note**
> This part should ideally take <5 min

---

#### Part 2

This will be a one-time task for mutual users and will generally include the creation of a standardized cluster blueprint with the partner's product brought in as an "add-on". Once a blueprint is created, it can be reused on any cluster in the customer's fleet.

- Create partner add-on using the built in App Catalog
- Create a custom blueprint using the partner's add-on
- Apply blueprint and steps to verify that everything is good. We strongly recommend leveraging the platform's capabilities for this. For example, use [Zero Trust Kubectl Access](https://docs.rafay.co/accessproxy/overview/) or the integrated [k8s resources dashboards](https://docs.rafay.co/dashboard/overview/)) to tell a better together story.

> **Note**
> This part should ideally take <10 min

---

#### Part 3

Describe how to use the partner offering deployed in the blueprint? For example, how will the user view the partner web console? using Ingress, LB etc?

> **Note**
> This part should ideally take <10 min

---

### Content Format

The recipe's content needs to be authored in ["markdown"](https://www.markdownguide.org/). Please use screenshots/images liberally and ideally in PNG format. Our docs platform is powered by an instance of [Material for Mkdocs](https://squidfunk.github.io/mkdocs-material/) hosted by us and backed by a CDN. The content is itself version controlled in our Git repository.

---

### Content Placement

Please review the existing organizational structure to understand the "categories". Let us know which category best fits your contributed recipe. We are open to creating new categories if it makes sense.

---
