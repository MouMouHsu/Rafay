---
title: "GPU PaaS Releases"
source: https://docs.rafay.co/releasenotes/gpu_release_information/
category: Releases
---

# Release Info-GPU PaaS

### Upcoming

| Release | Release Date |
| --- | --- |
| [3.1-43](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-43/) | TBD Oct, 2026 |
| [3.1-42](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-42/) | TBD Oct, 2026 |

---

#### 2026

| Release | Release Date |
| --- | --- |
| [3.1-41](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-41/) | 13 Oct, 2026 |
| [3.1-40 Patch 3](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-40-3/) | 26 Aug, 2026 |
| [3.1-40 Patch 2](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-40-2/) | 31 July, 2026 |
| [3.1-40 Patch 1](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-40-1/) | 17 July, 2026 |
| [3.1-40](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-40/) | 03 Jul, 2026 |
| [3.1-39](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-39/) | 15 May, 2026 |
| [3.1-38](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-38/) | 16 Feb, 2026 |

---

#### 2025

| Release | Release Date |
| --- | --- |
| [3.1-37 Update 2](https://docs.rafay.co/releasenotes/2025/gpupaas/v3.1-37u1-u2/#v31-37-update-2) | 23 Dec 2025 |
| [3.1-37 Update 1](https://docs.rafay.co/releasenotes/2025/gpupaas/v3.1-37u1-u2/#v31-37-update-1) | 12 Dec 2025 |
| [3.1-37](https://docs.rafay.co/releasenotes/2025/gpupaas/v3.1-37/) | 25 Nov, 2025 |
| [3.1-36](https://docs.rafay.co/releasenotes/2025/gpupaas/v3.1-36/) | 08 Oct, 2025 |
| [3.1-35](https://docs.rafay.co/releasenotes/2025/gpupaas/v3.1-35/) | 03 Sep, 2025 |
| [3.1-33](https://docs.rafay.co/releasenotes/2025/gpupaas/v3.1-33/) | 05 Aug, 2025 |
| [3.1-32](https://docs.rafay.co/releasenotes/2025/gpupaas/v3.1-32/) | 17 Jul, 2025 |
| [3.1-31](https://docs.rafay.co/releasenotes/2025/gpupaas/july/) | 08 Jul, 2025 |
| [3.1-30](https://docs.rafay.co/releasenotes/2025/gpupaas/june/) | 19 Jun, 2025 |
| [3.1-29](https://docs.rafay.co/releasenotes/2025/gpupaas/may/) | 29 May, 2025 |
| [3.1-28](https://docs.rafay.co/releasenotes/2025/gpupaas/may/) | 16 May, 2025 |

---
