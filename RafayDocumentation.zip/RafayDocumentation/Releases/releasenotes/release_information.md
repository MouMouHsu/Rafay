---
title: "Rafay - Release Information"
source: https://docs.rafay.co/releasenotes/release_information/
category: Releases
---

# Release Info-SaaS

### SaaS Controller

#### 2026

| Release | Preview Release Date | Production Release Date |
| --- | --- | --- |
| [4.3 Update 2](https://docs.rafay.co/releasenotes/2026/oct/#v43-update-2-saas) |  | 8 Oct, 2026 |
| [4.3 Update 1](https://docs.rafay.co/releasenotes/2026/oct/#v43-update-1-saas) |  | 1 Oct, 2026 |
| [4.3](https://docs.rafay.co/releasenotes/2026/sept/#v43-saas) | 10 Sept, 2026 | 17 Sept, 2026 |
| [4.2 Update 10](https://docs.rafay.co/releasenotes/2026/aug/#v42-update-10-saas) |  | 24 Aug, 2026 |
| [4.2 Update 9](https://docs.rafay.co/releasenotes/2026/aug/#v42-update-9-saas) |  | 17 Aug, 2026 |
| [4.2 Update 8](https://docs.rafay.co/releasenotes/2026/aug/#v42-update-8-saas) |  | 13 Aug, 2026 |
| [4.2 Update 7](https://docs.rafay.co/releasenotes/2026/aug/#v42-update-7-saas) |  | 06 Aug, 2026 |
| [4.2 Update 6](https://docs.rafay.co/releasenotes/2026/aug/#v42-update-6-saas) |  | 03 Aug, 2026 |
| [4.2 Update 5](https://docs.rafay.co/releasenotes/2026/jul/#v42-update-5-saas) |  | 23 Jul, 2026 |
| [4.2 Update 4](https://docs.rafay.co/releasenotes/2026/jul/#v42-update-4-saas) |  | 16 Jul, 2026 |
| [4.2 Update 3](https://docs.rafay.co/releasenotes/2026/jul/#v42-update-3-saas) |  | 09 Jul, 2026 |
| [4.2 Update 2](https://docs.rafay.co/releasenotes/2026/jul/#v42-update-2-saas) |  | 02 Jul, 2026 |
| [4.2 Update 1](https://docs.rafay.co/releasenotes/2026/june/#v42-update-1-saas) |  | 25 Jun, 2026 |
| [4.2](https://docs.rafay.co/releasenotes/2026/june/#v42-saas) | 05 June, 2026 | 11 June, 2026 |
| [4.1 Update 7](https://docs.rafay.co/releasenotes/2026/may/#v41-update-7-saas) |  | 28 May, 2026 |
| [4.1 Update 6](https://docs.rafay.co/releasenotes/2026/may/#v41-update-6-saas) |  | 14 May, 2026 |
| [4.1 Update 5](https://docs.rafay.co/releasenotes/2026/may/#v41-update-5-saas) |  | 07 May, 2026 |
| [4.1 Update 4](https://docs.rafay.co/releasenotes/2026/apr/#v41-update-4-saas) |  | 30 Apr, 2026 |
| [4.1 Update 3](https://docs.rafay.co/releasenotes/2026/apr/#v41-update-3-saas) |  | 16 Apr, 2026 |
| [4.1 Update 2](https://docs.rafay.co/releasenotes/2026/apr/#v41-update-2-saas) | 10 Apr, 2026 | 13 Apr, 2026 |
| [4.1 Update 1](https://docs.rafay.co/releasenotes/2026/apr/#v41-update-1-saas) | 30 Mar, 2026 | 01 Apr, 2026 |
| [4.1](https://docs.rafay.co/releasenotes/2026/mar/#v41-saas) | 18 Mar, 2026 | 27 Mar, 2026 |
| [4.0 Update 7](https://docs.rafay.co/releasenotes/2026/mar/#v40-update-7-saas) |  | 18 Mar, 2026 |
| [4.0 Update 6](https://docs.rafay.co/releasenotes/2026/mar/#v40-update-6-saas) |  | 12 Mar, 2026 |
| [4.0 Update 5](https://docs.rafay.co/releasenotes/2026/mar/#v40-update-5-saas) |  | 05 Mar, 2026 |
| [4.0 Update 4](https://docs.rafay.co/releasenotes/2026/feb/#v40-update-4-saas) |  | 25 Feb, 2026 |
| [4.0 Update 3](https://docs.rafay.co/releasenotes/2026/feb/#v40-update-3-saas) |  | 17 Feb, 2026 |
| [4.0 Update 2](https://docs.rafay.co/releasenotes/2026/feb/#v40-update-2-saas) |  | 11 Feb, 2026 |
| [4.0 Update 1](https://docs.rafay.co/releasenotes/2026/feb/#v40-update-1-saas) | 04 Feb, 2026 | 05 Feb, 2026 |
| [4.0](https://docs.rafay.co/releasenotes/2026/jan/#v40-saas) | 14 Jan, 2026 | 23 Jan, 2026 |
| [3.7 Update 7](https://docs.rafay.co/releasenotes/2026/jan/#v37-update-7-saas) | N/A | 13 Jan, 2026 |

#### 2025

| Release | Preview Release Date | Production Release Date |
| --- | --- | --- |
| [3.7 Update 6](https://docs.rafay.co/releasenotes/2025/dec/#v37-update-6-saas) | N/A | 22 Dec, 2025 |
| [3.7 Update 5](https://docs.rafay.co/releasenotes/2025/dec/#v37-update-5-saas) | N/A | 11 Dec, 2025 |
| [3.7 Update 4](https://docs.rafay.co/releasenotes/2025/nov/#v37-update-4-saas) | N/A | 25 Nov, 2025 |
| [3.7 Update 3](https://docs.rafay.co/releasenotes/2025/nov/#v37-update-3-saas) | N/A | 11 Nov, 2025 |
| [3.7 Update 2](https://docs.rafay.co/releasenotes/2025/nov/#v37-update-2-saas) | N/A | 04 Nov, 2025 |
| [3.7 Update 1](https://docs.rafay.co/releasenotes/2025/oct/#v37-update-1-saas) | 24 Oct ,2025 | 28 Oct, 2025 |
| [3.7](https://docs.rafay.co/releasenotes/2025/oct/#v37-saas) | 1 Oct ,2025 | 15 Oct, 2025 |
| [3.6 Update 2](https://docs.rafay.co/releasenotes/2025/sep/#36-update-2-saas) | N/A | 04 Sept, 2025 |
| [3.6 Update 1](https://docs.rafay.co/releasenotes/2025/aug/#36-update-1-saas) | N/A | 20 Aug, 2025 |
| [3.6](https://docs.rafay.co/releasenotes/2025/aug/#v36-saas) | 29 Jul, 2025 | 09 Aug, 2025 |
| [3.5](https://docs.rafay.co/releasenotes/2025/jun/#v35-saas) | 05 June , 2025 | 13 June , 2025 |
| [3.4 Update 1](https://docs.rafay.co/releasenotes/2025/may/#v34-update-1-saas) | N/A | 20 May, 2025 |
| [3.4](https://docs.rafay.co/releasenotes/2025/may/#v34-saas) | 25 Apr, 2025 | 04 May, 2025 |
| [3.3](https://docs.rafay.co/releasenotes/2025/apr/#v33-saas) | 31 Mar, 2025 | 4 Apr, 2025 |
| [3.2 Update 2](https://docs.rafay.co/releasenotes/2025/mar/#v32-update-2-saas) | N/A | 25 Mar, 2025 |
| [3.2 Update 1](https://docs.rafay.co/releasenotes/2025/mar/#v32-update-1-saas) | N/A | 05 Mar, 2025 |
| [3.2](https://docs.rafay.co/releasenotes/2025/feb/#v32-saas) | 20 Feb,2025 | 26 Feb, 2025 |
| [3.1 Update 1](https://docs.rafay.co/releasenotes/2025/feb/#v31-update-1-saas) | N/A | 17 Feb, 2025 |
| [3.1](https://docs.rafay.co/releasenotes/2025/jan/#v31-saas) | 21 Jan, 2025 | 30 Jan, 2025 |

#### 2024

| Release | Preview Release Date | Production Release Date |
| --- | --- | --- |
| [2.12 Update 1](https://docs.rafay.co/releasenotes/2024/dec/#v212-update-1-saas) | N/A | 26 Dec, 2024 |
| [2.12](https://docs.rafay.co/releasenotes/2024/dec/#v212-saas) | 02 Dec, 2024 | 09 Dec, 2024 |
| [2.11](https://docs.rafay.co/releasenotes/2024/nov/#v211-saas) | 23 Oct, 2024 | 05 Nov, 2024 |
| [2.10 Update 1](https://docs.rafay.co/releasenotes/2024/oct/#v210-update-1-saas) | N/A | 17 Oct, 2024 |
| [2.10](https://docs.rafay.co/releasenotes/2024/sept/#v210-saas) | 18 Sept, 2024 | 26 Sept, 2024 |
| [2.9](https://docs.rafay.co/releasenotes/2024/sept/#v29-saas) | 3 Sept, 2024 | 5 Sept, 2024 |
| [2.8](https://docs.rafay.co/releasenotes/2024/aug/#v28-saas) | 24 Jul, 2024 | 09 Aug, 2024 |
| [2.7](https://docs.rafay.co/releasenotes/2024/june/#v27-saas) | 12 Jun, 2024 | 28 Jun, 2024 |
| [2.6](https://docs.rafay.co/releasenotes/2024/may/#v26-saas) | 24 Apr, 2024 | 17 May, 2024 |
| [2.5](https://docs.rafay.co/releasenotes/2024/apr/#v25-saas) | 19 March, 2024 | 5 April, 2024 |
| [2.4](https://docs.rafay.co/releasenotes/2024/mar/#v24-saas) | 14 Feb, 2024 | 1 Mar, 2024 |
| [2.3 Update 1](https://docs.rafay.co/releasenotes/2024/jan/) | N/A | 30 Jan, 2024 |
| [2.3](https://docs.rafay.co/releasenotes/2024/jan/#v23-saas) | 4 Jan, 2024 | 19 Jan, 2024 |

#### 2023

| Release | Preview Release Date | Production Release Date |
| --- | --- | --- |
| [2.2 Update 1](https://docs.rafay.co/releasenotes/2023/dec/#v22-update-1-saas) | N/A | 12 Dec, 2023 |
| [2.2](https://docs.rafay.co/releasenotes/2023/dec/#v22-saas) | 22 Nov, 2023 | 08 Dec, 2023 |
| [2.1 Update 1](https://docs.rafay.co/releasenotes/2023/nov/#v21-update-1-saas) | N/A | 24 Nov, 2023 |
| [2.1](https://docs.rafay.co/releasenotes/2023/nov/#v21-saas) | 18 Oct, 2023 | 3 Nov, 2023 |
| [2.0](https://docs.rafay.co/releasenotes/2023/oct/#v20-saas) | 21 Sep, 2023 | 13 Oct, 2023 |
| [1.28](https://docs.rafay.co/releasenotes/2023/aug/#v128-saas) | 7 Aug, 2023 | 25 Aug, 2023 |
| [1.27](https://docs.rafay.co/releasenotes/2023/july/#v127-saas) | 11 July, 2023 | 28 July, 2023 |
| [1.26](https://docs.rafay.co/releasenotes/2023/june/#v126-saas) | 14 June, 2023 | 30 June, 2023 |
| [1.25](https://docs.rafay.co/releasenotes/2023/may/#v125-saas) | 17 May, 2023 | 26 May, 2023 |
| [1.24](https://docs.rafay.co/releasenotes/2023/apr/#v124) | 13 Apr, 2023 | 28 Apr, 2023 |

---

### Terraform Provider

#### 2026

| Version | Release Date |
| --- | --- |
| [1.1.67](https://docs.rafay.co/releasenotes/2026/sept/#v1167-terraform-provider) | 17 Sep, 2026 |
| [1.1.66](https://docs.rafay.co/releasenotes/2026/jul/#v1166-terraform-provider) | 27 Jul, 2026 |
| [1.1.65](https://docs.rafay.co/releasenotes/2026/june/#v1165-terraform-provider) | 11 June, 2026 |
| [1.1.64](https://docs.rafay.co/releasenotes/2026/may/#v1164-terraform-provider) | 14 May, 2026 |
| [1.1.63](https://docs.rafay.co/releasenotes/2026/may/#v1163-terraform-provider) | 07 May, 2026 |
| [1.1.62](https://docs.rafay.co/releasenotes/2026/apr/#v1162-terraform-provider) | 16 Apr, 2026 |
| [1.1.61](https://docs.rafay.co/releasenotes/2026/apr/#v1161-terraform-provider) | 13 Apr, 2026 |
| [1.1.60](https://docs.rafay.co/releasenotes/2026/mar/#v1160-terraform-provider) | 28 Mar, 2026 |
| [1.1.59](https://docs.rafay.co/releasenotes/2026/mar/#v1159-terraform-provider) | 18 Mar, 2026 |
| [1.1.58](https://docs.rafay.co/releasenotes/2026/mar/#v1158-terraform-provider) | 12 Mar, 2026 |
| [1.1.57](https://docs.rafay.co/releasenotes/2026/mar/#v1157-terraform-provider) | 05 Mar, 2026 |
| [1.1.56](https://docs.rafay.co/releasenotes/2026/jan/#v1156-terraform-provider) | 30 Jan, 2026 |

#### 2025

| Version | Release Date |
| --- | --- |
| [1.1.55](https://docs.rafay.co/releasenotes/2025/dec/#v1155-terraform-provider) | 11 Dec, 2025 |
| [1.1.54](https://docs.rafay.co/releasenotes/2025/nov/#v1154-terraform-provider) | 25 Nov, 2025 |
| [1.1.53](https://docs.rafay.co/releasenotes/2025/nov/#v1153-terraform-provider) | 17 Nov, 2025 |
| [1.1.52](https://docs.rafay.co/releasenotes/2025/oct/#v1152-terraform-provider) | 17 Oct, 2025 |
| [1.1.51](https://docs.rafay.co/releasenotes/2025/sep/#v1151-terraform-provider) | 4 Sept, 2025 |
| [1.1.50](https://docs.rafay.co/releasenotes/2025/aug/#v1150-terraform-provider) | 9 Aug, 2025 |
| [1.1.49](https://docs.rafay.co/releasenotes/2025/july/#v1149-terraform-provider) | 2 July, 2025 |
| [1.1.48](https://docs.rafay.co/releasenotes/2025/jun/#v1148-terraform-provider) | 26 June, 2025 |
| [1.1.47](https://docs.rafay.co/releasenotes/2025/may/#v1147-terraform-provider) | 20 May, 2025 |
| [1.1.46](https://docs.rafay.co/releasenotes/2025/apr/#v1146-terraform-provider) | 22 Apr, 2025 |
| [1.1.45](https://docs.rafay.co/releasenotes/2025/apr/#v1145-terraform-provider) | 7 Apr, 2025 |
| [1.1.44](https://docs.rafay.co/releasenotes/2025/mar/#v1144-terraform-provider) | 11 Mar, 2025 |
| [1.1.43](https://docs.rafay.co/releasenotes/2025/feb/#v1143-terraform-provider) | 7 Feb, 2025 |
| [1.1.42](https://docs.rafay.co/releasenotes/2025/feb/#v1142-terraform-provider) | 4 Feb, 2025 |
| [1.1.40](https://docs.rafay.co/releasenotes/2025/jan/#v1140-terraform-provider) | 20 Jan, 2025 |

#### 2024

| Version | Release Date |
| --- | --- |
| [1.1.39](https://docs.rafay.co/releasenotes/2024/dec/#v1139-terraform-provider) | 13 Dec, 2024 |
| [1.1.38](https://docs.rafay.co/releasenotes/2024/nov/#v1138-terraform-provider) | 20 Nov, 2024 |
| [1.1.37](https://docs.rafay.co/releasenotes/2024/nov/#v1137-terraform-provider) | 08 Nov, 2024 |
| [1.1.36](https://docs.rafay.co/releasenotes/2024/oct/#v1136-terraform-provider) | 16 Oct, 2024 |
| [1.1.35](https://docs.rafay.co/releasenotes/2024/sept/#v1135-terraform-provider) | 30 Sept, 2024 |
| [1.1.34](https://docs.rafay.co/releasenotes/2024/aug/#v1134-terraform-provider) | 13 Aug, 2024 |
| [1.1.33](https://docs.rafay.co/releasenotes/2024/july/#v1133-terraform-provider) | 10 July, 2024 |
| [1.1.32](https://docs.rafay.co/releasenotes/2024/june/#v1132-terraform-provider) | 21 June, 2024 |
| [1.1.30](https://docs.rafay.co/releasenotes/2024/may/#v1130-terraform-provider) | 20 May, 2024 |
| [1.1.28](https://docs.rafay.co/releasenotes/2024/apr/#v1128-terraform-provider) | 13 Apr, 2024 |
| [1.1.24](https://docs.rafay.co/releasenotes/2024/mar/#v1124-terraform-provider) | 05 Mar, 2024 |
| [1.1.23](https://docs.rafay.co/releasenotes/2024/jan/#v1123-terraform-provider) | 25 Jan, 2024 |

#### 2023

| Version | Release Date |
| --- | --- |
| [1.1.22](https://docs.rafay.co/releasenotes/2023/dec/#v1122-terraform-provider) | 11 Dec, 2023 |
| [1.1.20](https://docs.rafay.co/releasenotes/2023/nov/#v1120-terraform-provider) | 17 Nov, 2023 |
| [1.1.19](https://docs.rafay.co/releasenotes/2023/nov/#v1119-terraform-provider) | 16 Nov, 2023 |
| [1.1.18](https://docs.rafay.co/releasenotes/2023/nov/#v1118-terraform-provider) | 08 Nov, 2023 |
| [1.1.17](https://docs.rafay.co/releasenotes/2023/sept/#v1117-terraform-provider) | 11 Sep, 2023 |

---
