---
title: "Rafay Releases & Roadmap"
source: https://docs.rafay.co/releasenotes/overview/
category: Releases
---

# Releases and Public Roadmap

- **SaaS**   For SaaS Customers  [**Latest**](https://docs.rafay.co/releasenotes/2026/sept/) |  [**Release Info**](https://docs.rafay.co/releasenotes/release_information/) |  [**Preview ↗**](https://console.stage.rafay.dev/)
- **Self Hosted**   For Self-Hosted, Air-Gapped Customers  [**Latest**](https://docs.rafay.co/releasenotes/2026/selfhosted/mar/)
- **GPU PaaS**   For GPU PaaS Customers  [**Latest**](https://docs.rafay.co/releasenotes/2026/gpupaas/v3.1-40-3/) |  [**Release Info**](https://docs.rafay.co/releasenotes/gpu_release_information/)
- **Public Roadmap**   Please contact the [product team](https://docs.rafay.co/cdn-cgi/l/email-protection#562624393223352216243730372f783539) for more details.  [**Public Roadmap**](https://github.com/orgs/RafaySystems/projects/3/views/1)

---
